"""
MAFIA Phase 11 — Search Document Builder
==========================================
Builds three document types for vector indexing:
  1. Component documents — from component_intelligence.json + graph nodes
  2. Flow documents — from flow_intelligence.json
  3. Repo documents — from repo_manifest.json + graph_views.json

Each document carries metadata filters: layer, repo, confidence_bucket,
evidence_method, completeness, doc_type.

Usage:
    from phase11_search.document_builder import build_all_documents
    docs = build_all_documents("output/")
"""

import json
from pathlib import Path
from collections import defaultdict


# ── Confidence bucket ────────────────────────────────────────────────────────

def _conf_bucket(c: float) -> str:
    if c >= 0.90: return "exact"
    if c >= 0.80: return "strong"
    if c >= 0.60: return "inferred"
    if c >= 0.40: return "weak"
    return "guess"


def build_all_documents(output_dir: str) -> list[dict]:
    """Build all search documents. Returns list of {text, metadata, doc_id}."""
    output = Path(output_dir)
    docs = []
    docs.extend(_build_component_docs(output))
    docs.extend(_build_flow_docs(output))
    docs.extend(_build_e2e_flow_docs(output))
    docs.extend(_build_repo_docs(output))
    docs.extend(_build_ast_summary_docs(output))
    docs.extend(_build_uploaded_doc_docs(output))
    print(f"[DocBuilder] Built {len(docs)} documents "
          f"({sum(1 for d in docs if d['metadata']['doc_type']=='component')} component, "
          f"{sum(1 for d in docs if d['metadata']['doc_type']=='flow')} flow, "
          f"{sum(1 for d in docs if d['metadata']['doc_type']=='e2e_flow')} e2e_flow, "
          f"{sum(1 for d in docs if d['metadata']['doc_type']=='repo')} repo, "
          f"{sum(1 for d in docs if d['metadata']['doc_type']=='ast_summary')} ast_summary, "
          f"{sum(1 for d in docs if d['metadata']['doc_type']=='uploaded_doc')} uploaded_doc)")
    return docs


# ── Component documents ──────────────────────────────────────────────────────

# Types that add noise without search value
_SKIP_TYPES = {
    ("config", "property"),
    ("config", "env"),
    ("config", "secret"),
    ("config", "toggle"),
    ("api", "dto"),
    ("api", "entity"),
    ("ui", "selector"),
}

# Minimum confidence to index
_MIN_CONFIDENCE = 0.40


def _build_component_docs(output: Path) -> list[dict]:
    ci = _load_json(output / "component_intelligence.json")
    sg = _load_json(output / "system_graph.json")
    nodes = {n["id"]: n for n in sg.get("nodes", [])}
    edges = sg.get("edges", [])

    adj = defaultdict(list)
    rev = defaultdict(list)
    for e in edges:
        adj[e["source"]].append(e)
        rev[e["target"]].append(e)

    # Index component intelligence by entity_id
    comp_map = {c["entity_id"]: c for c in ci.get("components", [])}

    raw_docs = []
    skipped_type = 0
    skipped_conf = 0

    for nid, node in nodes.items():
        layer = node.get("layer", "")
        ntype = node.get("type", "")
        conf = node.get("confidence", 0)

        # Skip low-value types
        if (layer, ntype) in _SKIP_TYPES:
            skipped_type += 1
            continue

        # Skip low-confidence nodes
        if conf < _MIN_CONFIDENCE:
            skipped_conf += 1
            continue

        name = node.get("label", "")
        repo = node.get("repo", "")
        file_path = node.get("file", "")
        ev_method = node.get("evidence_method", "")

        # Build text from component intelligence if available
        comp = comp_map.get(nid)
        if comp:
            what = comp.get("what_it_does", "")
            stmts = " ".join(s.get("text", "") for s in comp.get("statements", []))
            text = f"{name} | {layer}.{ntype} | repo:{repo} | file:{file_path}\n{what}\n{stmts}"
        else:
            # Fallback: basic node info + neighbors
            up = [nodes.get(e["source"], {}).get("label", "") for e in rev.get(nid, [])[:5]]
            dn = [nodes.get(e["target"], {}).get("label", "") for e in adj.get(nid, [])[:5]]
            text = f"{name} | {layer}.{ntype} | repo:{repo} | file:{file_path}"
            if up:
                text += f"\nCalled by: {', '.join(up)}"
            if dn:
                text += f"\nCalls: {', '.join(dn)}"

        raw_docs.append({
            "doc_id": nid,
            "text": text[:2000],
            "metadata": {
                "doc_type": "component",
                "layer": layer,
                "type": ntype,
                "repo": repo,
                "file": file_path,
                "line": node.get("line"),
                "confidence": conf,
                "confidence_bucket": _conf_bucket(conf),
                "evidence_method": ev_method,
                "node_id": nid,
            },
        })

    # Dedup: keep highest-confidence doc per (name, layer, type)
    best = {}
    for doc in raw_docs:
        m = doc["metadata"]
        key = (doc["text"].split("|")[0].strip(), m["layer"], m["type"])
        existing = best.get(key)
        if not existing or m["confidence"] > existing["metadata"]["confidence"]:
            best[key] = doc

    docs = list(best.values())
    deduped = len(raw_docs) - len(docs)

    print(f"  [DocBuilder] Components: {len(nodes)} nodes -> "
          f"skipped {skipped_type} low-value types, {skipped_conf} low-confidence, "
          f"{deduped} duplicates -> {len(docs)} docs")

    return docs


# ── Flow documents ───────────────────────────────────────────────────────────

def _build_flow_docs(output: Path) -> list[dict]:
    fi = _load_json(output / "flow_intelligence.json")
    docs = []

    for flow in fi.get("flows", []):
        fid = flow.get("flow_id", "")
        entry = flow.get("entry", {})
        terminal = flow.get("terminal", {})
        completeness = flow.get("completeness", "partial")
        conf_range = flow.get("confidence_range", {})
        repos = flow.get("repos_involved", [])

        # Build text from flow intelligence
        parts = [
            flow.get("surface_summary", ""),
            flow.get("standard_summary", ""),
            flow.get("data_flow", ""),
            flow.get("business_intent", ""),
        ]

        # Add hop narration
        for h in flow.get("hop_narration", []):
            parts.append(f"Step {h.get('step',0)}: [{h.get('layer','')}] {h.get('description','')}")

        # Add failure points
        for fp in flow.get("failure_points", []):
            parts.append(f"Failure: {fp}")

        text = "\n".join(p for p in parts if p)

        avg_conf = conf_range.get("avg", 0)
        docs.append({
            "doc_id": fid,
            "text": text[:3000],
            "metadata": {
                "doc_type": "flow",
                "completeness": completeness,
                "hop_count": flow.get("hop_count", 0),
                "entry_layer": entry.get("layer", ""),
                "entry_name": entry.get("name", ""),
                "terminal_layer": terminal.get("layer", ""),
                "terminal_name": terminal.get("name", ""),
                "repos": repos,
                "confidence": avg_conf,
                "confidence_bucket": _conf_bucket(avg_conf),
                "evidence_method": "graph_traversal",
                "flow_id": fid,
            },
        })

    return docs


# ── E2E flow documents (raw chains with code components) ────────────────────

def _build_e2e_flow_docs(output: Path) -> list[dict]:
    """Build search documents from e2e_flows.json — the raw hop chains
    with their code components, so flows are searchable by the actual
    code entities they traverse."""
    data = _load_json(output / "e2e_flows.json")
    catalogs = data.get("catalogs", {})
    docs = []
    seen_ids = set()

    for catalog_name, flows in catalogs.items():
        if not isinstance(flows, list):
            continue
        for flow in flows:
            fid = flow.get("flow_id", "")
            if not fid or fid in seen_ids:
                continue
            seen_ids.add(fid)

            hops = flow.get("standard", [])
            if not hops:
                continue

            entry = flow.get("entry", {})
            terminal = flow.get("terminal", {})
            surface = flow.get("surface", {})
            conf_range = flow.get("confidence_range", {})
            completeness = flow.get("completeness", "unknown")

            # Build text from the actual hop chain code components
            parts = [f"{surface.get('entry', '')} -> {surface.get('terminal', '')}"]
            parts.append(surface.get("path", ""))
            for h in hops:
                rel = h.get("next_relation", {})
                rel_str = f" --{rel['type']}--> " if rel else ""
                parts.append(
                    f"[{h.get('layer','')}.{h.get('type','')}] "
                    f"{h.get('name','')}{rel_str}"
                    f"(repo:{h.get('repo','')}, conf:{h.get('confidence',0):.2f})"
                )

            bp = flow.get("breakpoint", {})
            if bp:
                parts.append(f"BREAKPOINT: {bp.get('reason_code','')} at {bp.get('node_name','')}")

            text = "\n".join(p for p in parts if p)
            avg_conf = conf_range.get("avg", 0)

            docs.append({
                "doc_id": f"e2e:{fid}",
                "text": text[:3000],
                "metadata": {
                    "doc_type": "e2e_flow",
                    "catalog": catalog_name,
                    "completeness": completeness,
                    "hop_count": flow.get("hop_count", 0),
                    "entry_layer": entry.get("layer", ""),
                    "entry_name": entry.get("name", ""),
                    "terminal_layer": terminal.get("layer", ""),
                    "terminal_name": terminal.get("name", ""),
                    "repos": flow.get("repos_involved", []),
                    "layers_touched": flow.get("layers_touched", []),
                    "confidence": avg_conf,
                    "confidence_bucket": _conf_bucket(avg_conf),
                    "evidence_method": "graph_traversal",
                    "flow_id": fid,
                    "reached_target": flow.get("reached_target", False),
                },
            })

    if docs:
        complete = sum(1 for d in docs if d["metadata"].get("completeness") == "complete")
        print(f"  [DocBuilder] E2E flows: {len(docs)} chains indexed ({complete} complete, {len(docs)-complete} partial)")
    return docs


# ── Repo documents ───────────────────────────────────────────────────────────

def _build_repo_docs(output: Path) -> list[dict]:
    manifest = _load_json(output / "repo_manifest.json")
    gv = _load_json(output / "graph_views.json")
    repo_view = gv.get("repo_view", {})

    docs = []
    for repo in manifest.get("repos", []):
        rid = repo["repo_id"]
        cls = repo.get("classification", [])
        stack = repo.get("detected_stack", [])
        scan = repo.get("scan_summary", {})
        signals = repo.get("detection_signals", [])

        # Graph view data
        rv = repo_view.get(rid, {})
        entity_count = rv.get("entity_count", 0)
        relation_count = rv.get("relation_count", 0)
        cross_repo_edges = rv.get("cross_repo_edges", [])

        text = (
            f"{rid} | classification: {', '.join(cls)} | stack: {', '.join(stack)}\n"
            f"Files: {scan.get('total_files',0)} total, {scan.get('scannable_files',0)} scannable\n"
            f"Entities: {entity_count}, Relations: {relation_count}\n"
            f"Signals: {'; '.join(signals[:5])}\n"
        )
        if cross_repo_edges:
            targets = list(set(e.get("target_repo", "") for e in cross_repo_edges[:10]))
            text += f"Connected to repos: {', '.join(targets)}\n"

        conf = repo.get("classification_confidence", 0)
        docs.append({
            "doc_id": f"repo:{rid}",
            "text": text[:2000],
            "metadata": {
                "doc_type": "repo",
                "repo": rid,
                "layer": cls[0] if cls else "unknown",
                "classification": cls,
                "stack": stack,
                "confidence": conf,
                "confidence_bucket": _conf_bucket(conf),
                "evidence_method": "classification",
            },
        })

    return docs


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# -- Uploaded document docs ----------------------------------------------------

def _build_uploaded_doc_docs(output: Path) -> list[dict]:
    """Build search documents from uploaded supplementary documents (chunked)."""
    try:
        from phase11_search.ingestion.doc_store import DocumentStore
        store = DocumentStore(str(output))
        docs = store.build_search_documents()
        if docs:
            doc_count = len(set(d["metadata"].get("chunk_of", d["doc_id"]) for d in docs))
            print(f"  [DocBuilder] Uploaded docs: {doc_count} docs -> {len(docs)} chunks indexed")
        return docs
    except Exception:
        return []


# ── AST summary documents ────────────────────────────────────────────────────

def _build_ast_summary_docs(output: Path) -> list[dict]:
    """Build search documents from ast_summaries.jsonl if available."""
    path = output / "ast_summaries.jsonl"
    if not path.exists():
        return []

    docs = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                s = json.loads(line)
                eid = s.get("entity_id", "")
                if not eid:
                    continue

                sig = s.get("signature", {})
                calls = s.get("calls", [])
                exc = s.get("exception_handling", [])
                config = s.get("config_refs", [])
                comp = s.get("complexity", {})

                # Build searchable text
                parts = []
                if sig.get("name"):
                    params = ", ".join(f"{p.get('type', '')} {p.get('name', '')}" for p in sig.get("parameters", []))
                    parts.append(f"{sig.get('name')}({params})")
                for ann in s.get("annotations", []):
                    parts.append(ann)
                for c in calls[:10]:
                    cond = " [conditional]" if c.get("conditional") else ""
                    parts.append(f"calls {c['target']}{cond}")
                for e in exc:
                    parts.append(f"handles {e['type']} ({e['action']})")
                for cr in config:
                    parts.append(f"uses config {cr}")
                if comp:
                    parts.append(f"{comp.get('branches', 0)} branches, {comp.get('lines', 0)} lines")

                text = f"{eid}\n" + "\n".join(parts)

                docs.append({
                    "doc_id": f"ast:{eid}",
                    "text": text[:2000],
                    "metadata": {
                        "doc_type": "ast_summary",
                        "layer": s.get("layer", ""),
                        "type": s.get("type", ""),
                        "repo": s.get("repo", ""),
                        "file": s.get("file", ""),
                        "confidence": s.get("confidence", 0),
                        "confidence_bucket": _conf_bucket(s.get("confidence", 0)),
                        "evidence_method": "ast",
                        "node_id": eid,
                        "call_count": len(calls),
                        "branch_count": comp.get("branches", 0),
                    },
                })
    except Exception:
        pass

    if docs:
        print(f"  [DocBuilder] AST summaries: {len(docs)} docs indexed")
    return docs
