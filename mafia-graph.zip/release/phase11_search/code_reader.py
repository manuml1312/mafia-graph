"""
MAFIA Phase 11 — Source Code Reader
======================================
Resolves entity IDs to actual source files on disk and reads code
for solution generation. Uses repo_manifest.json root_paths to
locate files, and entities.jsonl evidence for line ranges.

Usage:
    reader = CodeReader("output/")
    snippet = reader.read_entity_code("api:controller:marvel_flags_api:FlagController.java::getFlagTypes")
    context = reader.read_flow_code(flow_id, max_files=5)
"""

import json
from pathlib import Path
from typing import Optional


class CodeReader:
    """Reads source code files for entities and flows."""

    def __init__(self, output_dir: str):
        self.output = Path(output_dir)
        self._repo_roots = {}   # repo_id -> root_path
        self._entity_map = {}   # entity_id -> {file, line, repo, evidence}
        self._flow_map = {}     # flow_id -> flow record
        self._load()

    def _load(self):
        # Repo roots
        manifest = _load_json(self.output / "repo_manifest.json")
        for r in manifest.get("repos", []):
            self._repo_roots[r["repo_id"]] = r.get("root_path") or ""

        # Entity evidence (file paths + line numbers)
        try:
            with open(self.output / "entities.jsonl", 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    e = json.loads(line)
                    eid = e.get("id", "")
                    ev = e.get("evidence", {})
                    self._entity_map[eid] = {
                        "file": e.get("file") or "",
                        "line": e.get("line"),
                        "repo": e.get("repo") or "",
                        "evidence_line_start": ev.get("line_start"),
                        "evidence_line_end": ev.get("line_end"),
                        "snippet": ev.get("snippet", ""),
                    }
        except Exception:
            pass

        # Flows
        flows_data = _load_json(self.output / "e2e_flows.json")
        for cat_name, cat_flows in flows_data.get("catalogs", {}).items():
            for flow in cat_flows:
                self._flow_map[flow.get("flow_id", "")] = flow

    # ── Read code for a single entity ────────────────────────────────────

    def read_entity_code(
        self,
        entity_id: str,
        context_lines: int = 30,
    ) -> Optional[dict]:
        """
        Read source code for an entity. Returns file content around the
        entity's definition with context lines above and below.
        """
        info = self._entity_map.get(entity_id)
        if not info:
            return None

        repo = info["repo"]
        rel_file = info["file"]
        root = self._repo_roots.get(repo)
        if not root or not rel_file:
            return {"entity_id": entity_id, "error": "Cannot resolve file path",
                    "repo": repo, "file": rel_file}

        abs_path = Path(root) / rel_file
        if not abs_path.exists():
            return {"entity_id": entity_id, "error": f"File not found: {abs_path}",
                    "repo": repo, "file": rel_file, "abs_path": str(abs_path)}

        try:
            content = abs_path.read_text(encoding='utf-8', errors='ignore')
        except Exception as e:
            return {"entity_id": entity_id, "error": f"Read error: {e}",
                    "repo": repo, "file": rel_file}

        lines = content.splitlines()
        total_lines = len(lines)

        # Determine focus range
        center = (info.get("line") or info.get("evidence_line_start") or 1) - 1
        start = max(0, center - context_lines)
        end = min(total_lines, center + context_lines + 1)

        focused_lines = lines[start:end]

        return {
            "entity_id": entity_id,
            "repo": repo,
            "file": rel_file,
            "abs_path": str(abs_path),
            "total_lines": total_lines,
            "focus_start": start + 1,
            "focus_end": end,
            "entity_line": (info.get("line") or info.get("evidence_line_start")),
            "code": "\n".join(focused_lines),
            "full_file": len(focused_lines) >= total_lines,
        }

    # ── Read code for all hops in a flow ─────────────────────────────────

    def read_flow_code(
        self,
        flow_id: str,
        max_files: int = 10,
        context_lines: int = 20,
    ) -> dict:
        """
        Read source code for each hop in a flow. Returns code snippets
        for each unique file involved, ordered by hop sequence.
        """
        flow = self._flow_map.get(flow_id)
        if not flow:
            return {"flow_id": flow_id, "error": "Flow not found", "files": []}

        hops = flow.get("standard", [])
        seen_files = set()
        file_snippets = []

        for hop in hops:
            hid = hop.get("id", "")
            info = self._entity_map.get(hid)
            if not info:
                continue

            # Deduplicate by repo+file
            file_key = f"{info['repo']}::{info['file']}"
            if file_key in seen_files:
                continue
            seen_files.add(file_key)

            snippet = self.read_entity_code(hid, context_lines=context_lines)
            if snippet and not snippet.get("error"):
                file_snippets.append({
                    "hop_entity": hid,
                    "hop_name": hop.get("name", ""),
                    "hop_layer": hop.get("layer", ""),
                    "hop_type": hop.get("type", ""),
                    **snippet,
                })

            if len(file_snippets) >= max_files:
                break

        return {
            "flow_id": flow_id,
            "total_hops": len(hops),
            "files_read": len(file_snippets),
            "truncated": len(file_snippets) >= max_files,
            "files": file_snippets,
        }

    # ── Read full file with highlight region ─────────────────────────────

    def read_full_file(
        self,
        entity_id: str,
        highlight_context: int = 10,
    ) -> Optional[dict]:
        """
        Read the entire source file for an entity.
        Returns full file content with highlight_start/highlight_end marking
        the region associated with the entity (like a git diff highlight).
        """
        info = self._entity_map.get(entity_id)
        if not info:
            return None

        repo = info["repo"]
        rel_file = info["file"]
        root = self._repo_roots.get(repo)
        if not root or not rel_file:
            return {"entity_id": entity_id, "error": "Cannot resolve file path",
                    "repo": repo, "file": rel_file}

        abs_path = Path(root) / rel_file
        if not abs_path.exists():
            return {"entity_id": entity_id, "error": f"File not found: {abs_path}",
                    "repo": repo, "file": rel_file}

        try:
            content = abs_path.read_text(encoding='utf-8', errors='ignore')
        except Exception as e:
            return {"entity_id": entity_id, "error": f"Read error: {e}"}

        lines = content.splitlines()
        total_lines = len(lines)

        # Determine highlight region
        entity_line = info.get("line") or info.get("evidence_line_start") or 1
        highlight_start = max(1, entity_line - highlight_context)
        highlight_end = min(total_lines, entity_line + highlight_context)

        return {
            "entity_id": entity_id,
            "repo": repo,
            "file": rel_file,
            "abs_path": str(abs_path),
            "total_lines": total_lines,
            "entity_line": entity_line,
            "highlight_start": highlight_start,
            "highlight_end": highlight_end,
            "code": content,
        }

    def list_entity_files(self, entity_ids: list[str]) -> list[dict]:
        """List file paths for a set of entities (for UI display)."""
        results = []
        seen = set()
        for eid in entity_ids:
            info = self._entity_map.get(eid)
            if not info:
                continue
            file_key = f"{info['repo']}::{info['file']}"
            if file_key in seen:
                continue
            seen.add(file_key)

            root = self._repo_roots.get(info["repo"], "")
            abs_path = str(Path(root) / info["file"]) if root else ""
            exists = Path(abs_path).exists() if abs_path else False

            results.append({
                "entity_id": eid,
                "repo": info["repo"],
                "file": info["file"],
                "line": info.get("line"),
                "abs_path": abs_path,
                "exists": exists,
            })
        return results

    def stats(self) -> dict:
        return {
            "repos": len(self._repo_roots),
            "entities_with_files": len(self._entity_map),
            "flows": len(self._flow_map),
        }


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}
