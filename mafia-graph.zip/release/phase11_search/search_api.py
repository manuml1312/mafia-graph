"""
MAFIA Phase 11 — Search API Server
=====================================
Flask API serving hybrid vector + graph search, node profiles,
flow retrieval, blast radius, issue diagnosis, and source code reading.

Every response includes confidence badges, evidence_method, and
truncation flags.

Usage:
    python -m phase11_search.search_api
    # Then: GET http://localhost:5001/search?q=flagTypes&layer=bff
"""

import json
from pathlib import Path
from typing import Optional

from flask import Flask, request, jsonify, send_from_directory

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase11_search.vector_index import VectorIndex
from phase11_search.graph_retriever import GraphRetriever
from phase11_search.code_reader import CodeReader
from phase9_graph.blast_radius_engine import BlastRadiusEngine
from phase10_intelligence.issue_diagnosis import diagnose_issue
from phase11_search.chat_engine import ChatEngine
from phase11_search.bigquery_store import ConversationStore
from phase11_search.ingestion.doc_store import DocumentStore

# ── Globals (loaded once at startup) ─────────────────────────────────────────

_output_dir = ""
_retriever: Optional[GraphRetriever] = None
_code_reader: Optional[CodeReader] = None
_blast_engine: Optional[BlastRadiusEngine] = None
_flow_intel = {}
_chat_engine: Optional[ChatEngine] = None
_doc_store: Optional[DocumentStore] = None
_initialized = False  # True once _init() succeeds

app = Flask(__name__, static_folder=None)  # disable default /static — we serve our own
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB upload limit

# CORS for local dev
@app.after_request
def add_cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'GET,POST,OPTIONS'
    return response

# Serve Phase 12 UI
_ui_dir = str(Path(__file__).resolve().parent.parent / "phase12_ui")
print(f"[SearchAPI] UI dir: {_ui_dir} (exists: {Path(_ui_dir).exists()})")

@app.route("/")
def serve_root():
    """Landing page — upload repos and start pipeline."""
    return send_from_directory(_ui_dir, "landing.html")

@app.route("/explorer")
def serve_explorer():
    """Main explorer UI — served after pipeline completes."""
    return send_from_directory(_ui_dir, "index.html")

@app.route("/favicon.ico")
def favicon():
    return '', 204

# Serve root-level assets (e.g. mafia_ninja.jpg)
_root_dir = str(Path(__file__).resolve().parent.parent)

@app.route("/assets/<path:filename>")
def serve_asset(filename):
    return send_from_directory(_root_dir, filename)

@app.route("/static/<path:filename>")
def serve_static(filename):
    static_dir = str(Path(_ui_dir) / "static")
    print(f"[Static] Serving {filename} from {static_dir}")
    response = send_from_directory(static_dir, filename)
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


def _init(output_dir: str):
    global _output_dir, _retriever, _code_reader, _blast_engine, _flow_intel, _chat_engine, _doc_store, _initialized
    _output_dir = output_dir
    output = Path(output_dir)

    # ── Vector index (optional — needs Gemini embeddings) ────────────────
    vi = None
    index_dir = output / "search_index"
    has_faiss = (index_dir / "faiss.index").exists()
    has_docs = (index_dir / "documents.pkl").exists()
    if has_faiss or has_docs:
        print(f"[SearchAPI] Loading search index ({'vector' if has_faiss else 'keyword-only'} mode)...")
        try:
            vi = VectorIndex.load(str(index_dir))
        except Exception as e:
            print(f"[SearchAPI] Search index load failed: {e}")
    else:
        print("[SearchAPI] No search index found — search disabled (run pipeline to build)")

    # ── Graph retriever (needs system_graph.json) ────────────────────────
    graph_path = output / "system_graph.json"
    if graph_path.exists():
        print("[SearchAPI] Loading graph retriever...")
        _retriever = GraphRetriever(vi, str(graph_path))
    else:
        print("[SearchAPI] No system_graph.json — graph features disabled")
        _retriever = None

    # ── Code reader ──────────────────────────────────────────────────────
    print("[SearchAPI] Loading code reader...")
    try:
        _code_reader = CodeReader(output_dir)
    except Exception as e:
        print(f"[SearchAPI] Code reader failed: {e}")
        _code_reader = None

    # ── Blast radius ─────────────────────────────────────────────────────
    if graph_path.exists():
        print("[SearchAPI] Loading blast radius engine...")
        _blast_engine = BlastRadiusEngine(str(graph_path))
    else:
        _blast_engine = None

    # ── Flow intelligence ────────────────────────────────────────────────
    print("[SearchAPI] Loading flow intelligence...")
    fi = _load_json(output / "flow_intelligence.json")
    _flow_intel = {f["flow_id"]: f for f in fi.get("flows", [])}

    # ── Chat engine (optional — needs Gemini) ────────────────────────────
    try:
        _chat_engine = ChatEngine(output_dir)
    except Exception as e:
        print(f"[SearchAPI] Chat engine init failed (chat disabled): {e}")
        _chat_engine = None

    # ── Document store ───────────────────────────────────────────────────
    try:
        _doc_store = DocumentStore(output_dir)
    except Exception:
        _doc_store = None

    _initialized = True
    idx_stats = vi.stats() if vi else "no index"
    node_count = len(_retriever.nodes) if _retriever else 0
    print(f"[SearchAPI] Ready. Index: {idx_stats}, Nodes: {node_count}, Flows: {len(_flow_intel)}")


# ── Guard: require initialized data ──────────────────────────────────────────

# Routes that work without data loaded
_UNGUARDED_PATHS = {"/", "/explorer", "/favicon.ico"}
_UNGUARDED_PREFIXES = ("/static/", "/assets/", "/api/pipeline", "/api/upload", "/stats")

@app.before_request
def _guard_init():
    """Block data-dependent routes when pipeline hasn't run yet."""
    if _initialized:
        return None
    path = request.path
    if path in _UNGUARDED_PATHS:
        return None
    for prefix in _UNGUARDED_PREFIXES:
        if path.startswith(prefix):
            return None
    return jsonify({"error": "Data not loaded yet. Run the pipeline from the landing page first."}), 503


def _require_init():
    """Legacy per-endpoint guard (kept for explicit checks)."""
    if not _initialized:
        return jsonify({"error": "Data not loaded yet. Run the pipeline from the landing page first."}), 503
    return None


# ── GET /search ──────────────────────────────────────────────────────────────

@app.route("/search", methods=["GET"])
def search():
    """
    Hybrid search: vector + graph expansion + re-ranking.
    Query params: q, layer, repo, doc_type, confidence_bucket, evidence_method,
                  completeness, top_k, expand_depth
    """
    err = _require_init()
    if err: return err
    q = request.args.get("q", "")
    if not q:
        return jsonify({"error": "Missing query parameter 'q'"}), 400

    filters = {}
    for key in ("layer", "repo", "doc_type", "confidence_bucket", "evidence_method", "completeness", "min_confidence"):
        val = request.args.get(key)
        if val:
            filters[key] = val

    top_k = int(request.args.get("top_k", 20))
    expand_depth = int(request.args.get("expand_depth", 1))

    result = _retriever.retrieve(q, top_k=top_k, filters=filters, expand_depth=expand_depth)
    return jsonify(result)


# ── GET /node/<id> ───────────────────────────────────────────────────────────

@app.route("/node/<path:node_id>", methods=["GET"])
def get_node(node_id: str):
    """Node profile with counts, intelligence, and file info."""
    err = _require_init()
    if err: return err
    profile = _retriever.get_node_profile(node_id)
    if not profile:
        return jsonify({"error": f"Node not found: {node_id}"}), 404

    # Add file info
    files = _code_reader.list_entity_files([node_id])
    profile["files"] = files
    return jsonify(profile)


# ── GET /node/<id>/neighbors ─────────────────────────────────────────────────

@app.route("/node/<path:node_id>/neighbors", methods=["GET"])
def get_neighbors(node_id: str):
    """Node neighbors with direction, depth, limit."""
    direction = request.args.get("direction", "both")
    depth = int(request.args.get("depth", 1))
    limit = int(request.args.get("limit", 50))
    result = _retriever.get_neighbors(node_id, direction=direction, depth=depth, limit=limit)
    return jsonify(result)


# ── GET /flows ───────────────────────────────────────────────────────────────

@app.route("/flows", methods=["GET"])
def get_flows():
    """List flows, optionally filtered by start_node."""
    start_node = request.args.get("start_node", "")
    mode = request.args.get("mode", "surface")
    limit = int(request.args.get("limit", 50))

    results = []
    for fid, flow in _flow_intel.items():
        if start_node:
            hop_ids = {h.get("id", "") for h in flow.get("hop_narration", [])}
            entry_id = flow.get("entry", {}).get("id", "")
            if start_node not in hop_ids and start_node != entry_id:
                continue

        if mode == "surface":
            results.append({
                "flow_id": fid,
                "surface_summary": flow.get("surface_summary", ""),
                "completeness": flow.get("completeness", ""),
                "hop_count": flow.get("hop_count", 0),
                "confidence": flow.get("confidence_range", {}).get("avg", 0),
            })
        else:
            results.append(flow)

        if len(results) >= limit:
            break

    return jsonify({
        "total": len(results),
        "mode": mode,
        "truncated": len(results) >= limit,
        "flows": results,
    })


# ── GET /flow/<id> ───────────────────────────────────────────────────────────

@app.route("/flow/<path:flow_id>", methods=["GET"])
def get_flow(flow_id: str):
    """
    Flow detail with depth modes:
      surface — summary only
      standard — full intelligence + hop narration
      deep — standard + source code for each hop
    """
    depth = request.args.get("depth", "standard")
    flow = _flow_intel.get(flow_id)
    if not flow:
        return jsonify({"error": f"Flow not found: {flow_id}"}), 404

    result = dict(flow)

    if depth == "deep":
        # Attach source code for each hop
        code = _code_reader.read_flow_code(flow_id, max_files=10, context_lines=25)
        result["source_code"] = code

    # Add file listing for all hops
    hop_ids = [h.get("id", "") for h in flow.get("hop_narration", []) if h.get("id")]
    result["files"] = _code_reader.list_entity_files(hop_ids)

    return jsonify(result)


# ── POST /blast_radius ───────────────────────────────────────────────────────

@app.route("/blast_radius", methods=["POST"])
def blast_radius():
    """Compute blast radius for a component."""
    body = request.get_json(force=True)
    component_id = body.get("component_id", "")
    direction = body.get("direction", "downstream")
    change_type = body.get("change_type", "failure")
    max_depth = body.get("max_depth", 6)

    if not component_id:
        return jsonify({"error": "Missing component_id"}), 400

    result = _blast_engine.compute(component_id, direction=direction,
                                    change_type=change_type, max_depth=max_depth)
    return jsonify(result)


# ── POST /blast_radius/explain ───────────────────────────────────────────────

@app.route("/blast_radius/explain", methods=["POST"])
def blast_radius_explain():
    """AI-generated narrative for blast radius results using RAG retrieval."""
    if not _chat_engine:
        return jsonify({"error": "Chat engine not available"}), 503

    body = request.get_json(force=True)
    origin = body.get("origin", "")
    origin_label = body.get("origin_label", origin)
    origin_layer = body.get("origin_layer", "")
    direction = body.get("direction", "downstream")
    change_type = body.get("change_type", "failure")
    severity_counts = body.get("severity_counts", {})
    by_layer = body.get("by_layer", {})
    nodes = body.get("nodes", [])[:20]

    if not origin:
        return jsonify({"error": "Missing origin"}), 400

    # Retrieve descriptions for impacted components via graph
    component_contexts = []
    seen = set()
    for n in nodes[:12]:
        nid = n.get("id", "")
        if nid in seen:
            continue
        seen.add(nid)
        try:
            profile = _retriever.get_node_profile(nid)
            nd = (profile or {}).get("node", {})
            desc = nd.get("description") or nd.get("label", "")
            component_contexts.append(
                f"- [{n.get('layer','').upper()}] {nd.get('label', nid)} "
                f"(type={n.get('type','')}, severity={n.get('bucket','')}, "
                f"depth={n.get('depth','')}, relation={n.get('relation_from_parent','')}) "
                f"-- {desc[:200]}"
            )
        except Exception:
            component_contexts.append(
                f"- [{n.get('layer','').upper()}] {n.get('label', nid)} "
                f"(severity={n.get('bucket','')}, depth={n.get('depth','')})"
            )

    origin_desc = ""
    try:
        origin_profile = _retriever.get_node_profile(origin)
        origin_nd = (origin_profile or {}).get("node", {})
        origin_desc = origin_nd.get("description") or origin_nd.get("label", origin_label)
    except Exception:
        origin_desc = origin_label

    prompt = (
        "You are analyzing the blast radius of a code change in a multi-layer system "
        "(UI -> BFF -> API -> DB).\n\n"
        f"The component being changed:\n"
        f"  Name: {origin_label}\n"
        f"  Layer: {origin_layer}\n"
        f"  Description: {origin_desc}\n"
        f"  Change type: {change_type}\n"
        f"  Direction: {direction}\n\n"
        f"Severity summary: {json.dumps(severity_counts)}\n"
        f"Impacted layers: {json.dumps(by_layer)}\n\n"
        f"Impacted components (sorted by severity):\n"
        + "\n".join(component_contexts) + "\n\n"
        "Write a concise (3-5 sentences) developer-facing explanation of:\n"
        "1. What this component does and why it matters\n"
        f"2. What would concretely happen if it experiences a {change_type} -- "
        "which downstream services/UIs/tables break and how\n"
        "3. Which impacted components are most critical to check first and why\n\n"
        "Be specific -- name the actual components, layers, and relations. "
        "Do NOT use generic language. Label each statement [OBSERVED] or [DERIVED]."
    )

    try:
        from phase11_search.chat_engine import _get_gemini
        gemini = _get_gemini()
        explanation = gemini.generate(
            [{"role": "user", "text": prompt}],
            temperature=0.3,
        )
        return jsonify({"explanation": explanation})
    except Exception as e:
        return jsonify({"error": f"AI generation failed: {e}"}), 500


# ── POST /issue/diagnose ─────────────────────────────────────────────────────

@app.route("/issue/diagnose", methods=["POST"])
def issue_diagnose():
    """Diagnose an issue using retrieval + graph."""
    body = request.get_json(force=True)
    issue_text = body.get("issue_text", "")
    if not issue_text:
        return jsonify({"error": "Missing issue_text"}), 400

    result = diagnose_issue(issue_text, _output_dir)

    # Enrich with source code for top change points
    if result.get("likely_change_points"):
        top_files = []
        for cp in result["likely_change_points"][:3]:
            comp = cp.get("component", "")
            # Try to find entity by name match
            for eid, info in _code_reader._entity_map.items():
                if comp and comp in eid:
                    code = _code_reader.read_entity_code(eid, context_lines=15)
                    if code and not code.get("error"):
                        top_files.append(code)
                    break
        result["source_code_hints"] = top_files

    return jsonify(result)


# ── GET /code/<entity_id> ────────────────────────────────────────────────────

@app.route("/code/<path:entity_id>", methods=["GET"])
def read_code(entity_id: str):
    """Read source code for an entity (focused view)."""
    context = int(request.args.get("context_lines", 30))
    result = _code_reader.read_entity_code(entity_id, context_lines=context)
    if not result:
        return jsonify({"error": f"Entity not found: {entity_id}"}), 404
    return jsonify(result)


@app.route("/codefile", methods=["GET"])
def read_full_code():
    """Read entire source file for an entity, with highlight range."""
    entity_id = request.args.get("id", "")
    if not entity_id:
        return jsonify({"error": "Missing id parameter"}), 400
    result = _code_reader.read_full_file(entity_id)
    if not result:
        return jsonify({"error": f"Entity not found: {entity_id}"}), 404
    return jsonify(result)


# ── GET /subgraph ────────────────────────────────────────────────────────────

@app.route("/subgraph", methods=["GET"])
def subgraph():
    """Neighborhood slice with edge_types filter + budget."""
    center = request.args.get("center", "")
    if not center:
        return jsonify({"error": "Missing center parameter"}), 400
    direction = request.args.get("direction", "both")
    depth = int(request.args.get("depth", 2))
    limit = int(request.args.get("limit", 50))
    edge_types = request.args.get("edge_types", "flow")  # flow | structural | all

    flow_edges = {"fetches","calls_api","delegates_to","uses_repo","calls_function",
                  "reads_from","writes_to","routes_to","calls","entity_maps_to","uses_table"}
    structural_edges = {"defined_in","belongs_to_repo","belongs_to_layer","imports","exports"}

    if edge_types == "flow":
        allowed = flow_edges
        use_adj = _retriever.adj
        use_rev = _retriever.rev
        use_edge_map = _retriever._edge_map
    elif edge_types == "structural":
        allowed = structural_edges
        use_adj = _retriever.struct_adj
        use_rev = _retriever.struct_rev
        use_edge_map = _retriever._struct_edge_map
    else:
        allowed = flow_edges | structural_edges
        # Merge both
        use_adj = defaultdict(list)
        use_rev = defaultdict(list)
        use_edge_map = {**_retriever._edge_map, **_retriever._struct_edge_map}
        for k, v in _retriever.adj.items(): use_adj[k].extend(v)
        for k, v in _retriever.struct_adj.items(): use_adj[k].extend(v)
        for k, v in _retriever.rev.items(): use_rev[k].extend(v)
        for k, v in _retriever.struct_rev.items(): use_rev[k].extend(v)

    # BFS from center
    from collections import deque, defaultdict
    visited = {center: 0}
    queue = deque([(center, 0)])
    slice_nodes = []
    slice_edges = []

    while queue and len(slice_nodes) < limit:
        nid, d = queue.popleft()
        node = _retriever.nodes.get(nid)
        if node:
            slice_nodes.append(node)

        if d >= depth:
            continue

        neighbors = []
        if direction in ("downstream", "both"):
            for tgt in use_adj.get(nid, []):
                edge = use_edge_map.get((nid, tgt), {})
                if edge.get("type", "") in allowed:
                    neighbors.append((tgt, edge, nid))
        if direction in ("upstream", "both"):
            for src in use_rev.get(nid, []):
                edge = use_edge_map.get((src, nid), {})
                if edge.get("type", "") in allowed:
                    neighbors.append((src, edge, src))

        for nbr, edge, src in neighbors:
            if nbr not in visited and len(slice_nodes) < limit:
                visited[nbr] = d + 1
                queue.append((nbr, d + 1))
                slice_edges.append(edge)

    return jsonify({
        "center": center,
        "nodes": slice_nodes[:limit],
        "edges": slice_edges,
        "metadata": {
            "truncated": len(slice_nodes) >= limit,
            "limit": limit,
            "depth": depth,
            "edge_types": edge_types,
            "total_nodes": len(slice_nodes),
            "total_edges": len(slice_edges),
        },
    })


# ── GET /coverage ────────────────────────────────────────────────────────────

@app.route("/coverage", methods=["GET"])
def coverage():
    """Coverage dashboard data."""
    cov = _load_json(Path(_output_dir) / "coverage_report.json")
    mapping = _load_json(Path(_output_dir) / "mapping_confidence_report.json")
    gate = _load_json(Path(_output_dir) / "quality_gate_report.json")

    # Flow completeness stats
    complete = sum(1 for f in _flow_intel.values() if f.get("completeness") == "complete")
    partial = sum(1 for f in _flow_intel.values() if f.get("completeness") != "complete")

    # Breakpoint distribution
    bp_by_layer = {}
    for f in _flow_intel.values():
        for h in f.get("hop_narration", []):
            if h.get("confidence", 1) < 0.5:
                l = h.get("layer", "unknown")
                bp_by_layer[l] = bp_by_layer.get(l, 0) + 1

    # Orphan queries
    orphans = {"bff_no_ui_caller": [], "db_no_api_caller": [], "api_no_bff_caller": []}
    for nid, node in _retriever.nodes.items():
        layer = node.get("layer", "")
        ntype = node.get("type", "")
        upstream = _retriever.rev.get(nid, [])
        if layer == "bff" and ntype == "endpoint" and not upstream:
            orphans["bff_no_ui_caller"].append({"id": nid, "name": node.get("label", "")})
        elif layer == "db" and ntype == "function" and not upstream:
            orphans["db_no_api_caller"].append({"id": nid, "name": node.get("label", "")})
        elif layer == "api" and ntype == "endpoint" and not any(
            _retriever.nodes.get(s, {}).get("layer") == "bff" for s in upstream
        ):
            orphans["api_no_bff_caller"].append({"id": nid, "name": node.get("label", "")})

    for k in orphans:
        orphans[k] = orphans[k][:20]

    return jsonify({
        "coverage": cov,
        "mapping": mapping,
        "quality_gate": gate,
        "flow_completeness": {"complete": complete, "partial": partial, "total": complete + partial},
        "breakpoint_distribution": bp_by_layer,
        "orphans": orphans,
    })


# ── GET /repos ───────────────────────────────────────────────────────────────

@app.route("/repos", methods=["GET"])
def repos():
    """Repo dependency view."""
    gv = _load_json(Path(_output_dir) / "graph_views.json")
    manifest = _load_json(Path(_output_dir) / "repo_manifest.json")

    repo_nodes = []
    for r in manifest.get("repos", []):
        rv = gv.get("repo_view", {}).get(r["repo_id"], {})
        repo_nodes.append({
            "id": r["repo_id"],
            "classification": r.get("classification", []),
            "stack": r.get("detected_stack", []),
            "confidence": r.get("classification_confidence", 0),
            "entity_count": rv.get("entity_count", 0),
            "relation_count": rv.get("relation_count", 0),
        })

    # Build inter-repo edges from graph
    repo_edges = {}
    for src, targets in _retriever.adj.items():
        src_repo = _retriever.nodes.get(src, {}).get("repo", "")
        for tgt in targets:
            tgt_repo = _retriever.nodes.get(tgt, {}).get("repo", "")
            if src_repo and tgt_repo and src_repo != tgt_repo:
                key = f"{src_repo}::{tgt_repo}"
                if key not in repo_edges:
                    repo_edges[key] = {"source": src_repo, "target": tgt_repo, "count": 0}
                repo_edges[key]["count"] += 1

    return jsonify({
        "repos": repo_nodes,
        "edges": list(repo_edges.values()),
    })


# ── POST /chat ────────────────────────────────────────────────────────────────

@app.route("/chat", methods=["POST"])
def chat():
    """AI Chat with hybrid RAG + optional code reading."""
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    body = request.get_json(force=True)
    message = body.get("message", "")
    conv_id = body.get("conversation_id", "")
    code_mode = body.get("code_mode", False)

    if not message:
        return jsonify({"error": "Missing message"}), 400

    if not conv_id:
        conv_id = _chat_engine.create_conversation()

    result = _chat_engine.chat(conv_id, message, code_mode=code_mode)
    return jsonify(result)


# ── GET /conversations ─────────────────────────────────────────────────────

@app.route("/conversations", methods=["GET"])
def list_conversations():
    if not _chat_engine:
        return jsonify({"conversations": []})
    convs = _chat_engine.list_conversations()
    return jsonify({"conversations": convs})


@app.route("/conversations/<conv_id>", methods=["GET"])
def get_conversation(conv_id):
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    data = _chat_engine.get_conversation_history(conv_id)
    if not data.get("conversation"):
        return jsonify({"error": "Conversation not found"}), 404
    return jsonify(data)


@app.route("/conversations/<conv_id>/state", methods=["POST"])
def update_conversation_state(conv_id):
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    body = request.get_json(force=True)
    _chat_engine.store.update_working_set(
        conv_id,
        node_ids=body.get("node_ids"),
        flow_ids=body.get("flow_ids"),
        filters=body.get("filters"),
        toggle_code=body.get("toggle_code"),
    )
    return jsonify({"ok": True})


# ── POST /conversations (create new) ───────────────────────────────────

@app.route("/conversations", methods=["POST"])
def create_conversation():
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    body = request.get_json(force=True) if request.data else {}
    conv_id = _chat_engine.create_conversation(title=body.get("title", ""))
    return jsonify({"conversation_id": conv_id})


# ── GET /stats ───────────────────────────────────────────────────────────────

@app.route("/graph/full", methods=["GET"])
def graph_full():
    """Return all nodes and edges for full graph visualization.
    Supports optional layer/type filters and a limit."""
    err = _require_init()
    if err: return err
    layer = request.args.get("layer", "")
    ntype = request.args.get("type", "")
    limit = int(request.args.get("limit", 500))

    nodes = []
    for nid, n in _retriever.nodes.items():
        if layer and n.get("layer", "") != layer:
            continue
        if ntype and n.get("type", "") != ntype:
            continue
        nodes.append(n)
        if len(nodes) >= limit:
            break

    node_ids = {n["id"] for n in nodes}
    edges = []
    for nid in node_ids:
        for tgt in _retriever.adj.get(nid, []):
            if tgt in node_ids:
                edge = _retriever._edge_map.get((nid, tgt), {})
                edges.append({"source": nid, "target": tgt,
                              "type": edge.get("type", ""), "confidence": edge.get("confidence", 0)})

    return jsonify({
        "nodes": nodes, "edges": edges,
        "total_nodes": len(_retriever.nodes),
        "truncated": len(nodes) >= limit,
    })


@app.route("/inventory", methods=["GET"])
def inventory():
    """Full inventory of all nodes and edges, grouped by layer and type."""
    err = _require_init()
    if err: return err

    by_layer = {}
    for nid, n in _retriever.nodes.items():
        layer = n.get("layer", "unknown")
        ntype = n.get("type", "unknown")
        by_layer.setdefault(layer, {}).setdefault(ntype, []).append({
            "id": nid, "label": n.get("label", ""), "repo": n.get("repo", ""),
            "file": n.get("file", ""), "line": n.get("line"),
            "confidence": n.get("confidence", 0),
            "evidence_method": n.get("evidence_method", ""),
        })

    edge_types = {}
    for src in _retriever.adj:
        for tgt in _retriever.adj[src]:
            edge = _retriever._edge_map.get((src, tgt), {})
            etype = edge.get("type", "unknown")
            edge_types.setdefault(etype, {"count": 0, "samples": []})
            edge_types[etype]["count"] += 1
            if len(edge_types[etype]["samples"]) < 5:
                edge_types[etype]["samples"].append({
                    "source": src.split(":")[-1][:40], "target": tgt.split(":")[-1][:40],
                    "confidence": edge.get("confidence", 0),
                })

    return jsonify({
        "nodes_by_layer": by_layer,
        "edge_types": edge_types,
        "total_nodes": len(_retriever.nodes),
        "total_edges": sum(len(v) for v in _retriever.adj.values()),
    })


@app.route("/codetree", methods=["GET"])
def codetree():
    """Return all nodes organized as repo → file → entities (sorted by line),
    plus cross-file edges so the UI can show which files reference each other."""
    err = _require_init()
    if err: return err

    # Build repo → file → [nodes sorted by line]
    tree = {}  # repo → { file → [node, ...] }
    for nid, n in _retriever.nodes.items():
        repo = n.get("repo", "_unknown")
        fpath = n.get("file", "_no_file")
        tree.setdefault(repo, {}).setdefault(fpath, []).append({
            "id": nid, "label": n.get("label", ""),
            "layer": n.get("layer", ""), "type": n.get("type", ""),
            "line": n.get("line"), "confidence": n.get("confidence", 0),
            "evidence_method": n.get("evidence_method", ""),
            "properties": n.get("properties", {}),
        })

    # Sort entities within each file by line number
    for repo in tree:
        for fpath in tree[repo]:
            tree[repo][fpath].sort(key=lambda x: x.get("line") or 0)

    # Sort files within each repo by path
    sorted_tree = {}
    for repo in sorted(tree.keys()):
        sorted_tree[repo] = dict(sorted(tree[repo].items()))

    # Cross-file edges: source_file → target_file with relation details
    cross_file = []  # [{source_file, target_file, source_node, target_node, type, confidence}]
    seen_pairs = set()
    for src_id in _retriever.adj:
        src_node = _retriever.nodes.get(src_id, {})
        src_file = src_node.get("file", "")
        src_repo = src_node.get("repo", "")
        if not src_file:
            continue
        for tgt_id in _retriever.adj[src_id]:
            tgt_node = _retriever.nodes.get(tgt_id, {})
            tgt_file = tgt_node.get("file", "")
            if not tgt_file or (src_repo == tgt_node.get("repo", "") and src_file == tgt_file):
                continue
            pair_key = (src_id, tgt_id)
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)
            edge = _retriever._edge_map.get((src_id, tgt_id), {})
            cross_file.append({
                "source_repo": src_repo, "source_file": src_file,
                "source_node": src_id, "source_label": src_node.get("label", ""),
                "source_line": src_node.get("line"),
                "target_repo": tgt_node.get("repo", ""), "target_file": tgt_file,
                "target_node": tgt_id, "target_label": tgt_node.get("label", ""),
                "target_line": tgt_node.get("line"),
                "type": edge.get("type", ""), "confidence": edge.get("confidence", 0),
            })

    return jsonify({
        "tree": sorted_tree,
        "cross_file_edges": cross_file,
        "total_nodes": len(_retriever.nodes),
        "total_files": sum(len(files) for files in tree.values()),
        "total_repos": len(tree),
        "total_cross_file": len(cross_file),
    })


@app.route("/ast/all", methods=["GET"])
def ast_all():
    """Return all AST summaries, optionally filtered by repo/language."""
    ast_path = Path(_output_dir) / "ast_summaries.jsonl"
    if not ast_path.exists():
        return jsonify({"summaries": [], "total": 0, "error": "No AST summaries. Run the pipeline first."})

    repo_filter = request.args.get("repo", "")
    lang_filter = request.args.get("language", "")
    limit = int(request.args.get("limit", 500))

    summaries = []
    try:
        with open(ast_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                s = json.loads(line)
                if repo_filter and s.get("repo", "") != repo_filter:
                    continue
                if lang_filter and s.get("language", "") != lang_filter:
                    continue
                summaries.append(s)
                if len(summaries) >= limit:
                    break
    except Exception:
        pass

    return jsonify({"summaries": summaries, "total": len(summaries), "truncated": len(summaries) >= limit})


@app.route("/stats", methods=["GET"])
def stats():
    if not _initialized:
        return jsonify({"index": {}, "graph": {}, "code_reader": {}, "flows": 0, "uploaded_docs": 0, "initialized": False})
    return jsonify({
        "index": _retriever.vi.stats() if _retriever and _retriever.vi else {},
        "graph": {"nodes": len(_retriever.nodes), "edges": sum(len(v) for v in _retriever.adj.values())} if _retriever else {},
        "code_reader": _code_reader.stats() if _code_reader else {},
        "flows": len(_flow_intel),
        "uploaded_docs": _doc_store.count() if _doc_store else 0,
        "initialized": True,
    })


# -- Document upload/management endpoints --------------------------------------

def _index_new_doc(doc_id: str):
    """Embed all chunks of an uploaded doc into the live FAISS index."""
    if not _doc_store or not _retriever:
        return
    doc = _doc_store.get(doc_id)
    if not doc:
        return
    search_docs = _doc_store.build_search_documents()
    new_chunks = [d for d in search_docs if d["metadata"].get("chunk_of") == doc_id
                  or d["doc_id"] == doc_id]
    if not new_chunks:
        return
    try:
        result = _retriever.vi.update_incremental(new_chunks)
        index_dir = str(Path(_output_dir) / "search_index")
        _retriever.vi.save(index_dir)
        print(f"[SearchAPI] Indexed {len(new_chunks)} chunks for {doc_id}: +{result['added']}")
    except Exception as e:
        print(f"[SearchAPI] Failed to index doc {doc_id}: {e}")

@app.route("/docs", methods=["GET"])
def list_docs():
    """List all uploaded supplementary documents."""
    if not _doc_store:
        return jsonify({"documents": [], "total": 0})
    docs = _doc_store.list_all()
    return jsonify({"documents": docs, "total": len(docs)})


@app.route("/docs/upload", methods=["POST"])
def upload_doc():
    """Upload a document file for indexing.
    Accepts multipart/form-data with 'file' field.
    Optional form fields: title, tags (comma-separated), author, description.
    """
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503

    if "file" not in request.files:
        return jsonify({"error": "No file provided. Use multipart/form-data with 'file' field."}), 400

    uploaded = request.files["file"]
    if not uploaded.filename:
        return jsonify({"error": "Empty filename"}), 400

    import tempfile
    tmp_dir = Path(tempfile.mkdtemp())
    tmp_path = tmp_dir / uploaded.filename
    uploaded.save(str(tmp_path))

    tags = [t.strip() for t in request.form.get("tags", "").split(",") if t.strip()]
    title = request.form.get("title", "")
    author = request.form.get("author", "")
    description = request.form.get("description", "")

    doc_id = _doc_store.ingest(
        str(tmp_path),
        tags=tags,
        title=title or None,
        author=author or None,
        description=description or None,
    )

    tmp_path.unlink(missing_ok=True)
    try:
        tmp_dir.rmdir()
    except Exception:
        pass

    if not doc_id:
        return jsonify({"error": f"Unsupported file type: {uploaded.filename}"}), 400

    # Auto-index into vector search
    _index_new_doc(doc_id)

    doc = _doc_store.get(doc_id)
    return jsonify({
        "doc_id": doc_id,
        "file_name": doc.get("file_name", ""),
        "doc_type": doc.get("doc_type", ""),
        "text_length": doc.get("text_length", 0),
        "chunk_count": doc.get("chunk_count", 0),
        "message": "Document ingested and indexed.",
    })


@app.route("/docs/<path:doc_id>", methods=["GET"])
def get_doc(doc_id: str):
    """Get a specific uploaded document with its extracted text and chunks."""
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503
    doc = _doc_store.get(doc_id)
    if not doc:
        return jsonify({"error": f"Document not found: {doc_id}"}), 404
    # Include chunks but exclude full text blob to keep response manageable
    result = {k: v for k, v in doc.items() if k != "text"}
    result["chunks"] = doc.get("chunks", [])
    return jsonify(result)


@app.route("/docs/<path:doc_id>", methods=["DELETE"])
def delete_doc(doc_id: str):
    """Delete an uploaded document and remove from vector index."""
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503
    if _doc_store.delete(doc_id):
        # Rebuild index without the deleted doc
        try:
            all_docs = _doc_store.build_search_documents()
            _retriever.vi.update_incremental(all_docs)
            _retriever.vi.save(str(Path(_output_dir) / "search_index"))
        except Exception:
            pass
        return jsonify({"ok": True, "message": f"Deleted {doc_id}"})
    return jsonify({"error": f"Document not found: {doc_id}"}), 404


@app.route("/docs/ingest-dir", methods=["POST"])
def ingest_directory():
    """Ingest all supported documents from a directory path."""
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503
    body = request.get_json(force=True)
    dir_path = body.get("path", "")
    tags = body.get("tags", [])
    if not dir_path:
        return jsonify({"error": "Missing 'path' in request body"}), 400
    ingested = _doc_store.ingest_directory(dir_path, tags=tags)
    # Auto-index all new docs
    for did in ingested:
        _index_new_doc(did)
    return jsonify({"ingested": len(ingested), "doc_ids": ingested})


# -- AST file structure endpoint -----------------------------------------------

@app.route("/ast_file/<path:entity_id>", methods=["GET"])
def get_ast_file(entity_id: str):
    """Get ALL AST summaries for the same file as entity_id, sorted by line.
    Returns {target_id, file, repo, methods: [...]} so the UI can render
    the full file structure with the target method highlighted."""
    ast_path = Path(_output_dir) / "ast_summaries.jsonl"
    if not ast_path.exists():
        return jsonify({"error": "AST summaries not available"}), 404

    entity_node = _retriever.nodes.get(entity_id, {}) if _retriever else {}
    entity_repo = entity_node.get("repo", "")
    entity_file = entity_node.get("file", "")
    entity_line = entity_node.get("line", 0)

    if not entity_repo or not entity_file:
        return jsonify({"error": "Cannot resolve file for entity"}), 404

    # Collect all summaries for this file
    file_methods = []
    target_id = None
    try:
        with open(ast_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                s = json.loads(line)
                if s.get("repo") == entity_repo and s.get("file") == entity_file:
                    file_methods.append(s)
                    if s.get("entity_id") == entity_id or s.get("discovered_id") == entity_id:
                        target_id = s.get("entity_id")
                    elif not target_id and entity_line:
                        if s.get("line_start", 0) <= entity_line <= s.get("line_end", 0):
                            target_id = s.get("entity_id")
    except Exception:
        pass

    file_methods.sort(key=lambda m: m.get("line_start", 0))

    return jsonify({
        "target_id": target_id or entity_id,
        "file": entity_file,
        "repo": entity_repo,
        "total_methods": len(file_methods),
        "methods": file_methods,
    })


# -- AST summary endpoint ------------------------------------------------------

@app.route("/ast_summary/<path:entity_id>", methods=["GET"])
def get_ast_summary(entity_id: str):
    """Get AST structural summary for an entity.
    Matches by entity_id, discovered_id, or by (repo, file, line) proximity."""
    ast_path = Path(_output_dir) / "ast_summaries.jsonl"
    if not ast_path.exists():
        return jsonify({"error": "AST summaries not available. Run: python -m phase10_ast.run_ast_summaries"}), 404

    # Parse entity_id to extract repo, file, line for fuzzy matching
    entity_node = _retriever.nodes.get(entity_id, {}) if _retriever else {}
    entity_repo = entity_node.get("repo", "")
    entity_file = entity_node.get("file", "")
    entity_line = entity_node.get("line", 0)

    best_match = None
    best_distance = 999

    try:
        with open(ast_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                s = json.loads(line)
                # Exact ID match
                if s.get("entity_id") == entity_id or s.get("discovered_id") == entity_id:
                    return jsonify(s)
                # Proximity match: same repo + same file + close line number
                if entity_repo and entity_file:
                    if s.get("repo") == entity_repo and s.get("file") == entity_file:
                        s_start = s.get("line_start", 0)
                        s_end = s.get("line_end", 0)
                        if entity_line and s_start:
                            # Entity line falls within method range, or within 5 lines
                            if s_start <= entity_line <= s_end:
                                return jsonify(s)
                            dist = min(abs(entity_line - s_start), abs(entity_line - s_end))
                            if dist < best_distance:
                                best_distance = dist
                                best_match = s
    except Exception:
        pass

    if best_match and best_distance <= 10:
        return jsonify(best_match)

    return jsonify({"error": f"No AST summary for {entity_id}"}), 404


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# ── Pipeline API endpoints (landing page → processing → explorer) ────────────

# ── Workspace for uploaded repos ──────────────────────────────────────────────
_workspace_dir = str(Path(__file__).resolve().parent.parent / "workspace")


@app.route("/api/upload-repos", methods=["POST"])
def upload_repos():
    """Accept multipart file upload preserving folder structure.
    Files arrive with webkitRelativePath-style names: repoName/path/to/file.java
    We reconstruct the tree under workspace/."""
    import shutil
    ws = Path(_workspace_dir)
    # Clear previous workspace
    if ws.exists():
        shutil.rmtree(ws, ignore_errors=True)
    ws.mkdir(parents=True, exist_ok=True)

    files = request.files.getlist("files")
    paths = request.form.getlist("paths")  # relative paths sent alongside
    if not files:
        return jsonify({"error": "No files uploaded"}), 400

    root_folders = set()
    saved = 0
    for i, f in enumerate(files):
        rel = paths[i] if i < len(paths) else f.filename
        if not rel:
            continue
        # Normalise separators
        rel = rel.replace("\\", "/")
        # Track root folder name
        parts = rel.split("/")
        if len(parts) > 1:
            root_folders.add(parts[0])
        dest = ws / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        f.save(str(dest))
        saved += 1

    # Determine source roots: each top-level folder in workspace
    if root_folders:
        source_roots = [str(ws / rf) for rf in sorted(root_folders) if (ws / rf).is_dir()]
    else:
        source_roots = [str(ws)]

    return jsonify({
        "saved": saved,
        "source_roots": source_roots,
        "root_folders": sorted(root_folders),
    })


@app.route("/api/pipeline/start", methods=["POST"])
def pipeline_start():
    """Start the MAFIA pipeline on provided source roots."""
    from phase11_search.pipeline_runner import run_pipeline_async, is_running
    if is_running():
        return jsonify({"error": "Pipeline already running"}), 409

    body = request.get_json(force=True)
    source_roots = body.get("source_roots", [])
    if not source_roots:
        return jsonify({"error": "No source_roots provided"}), 400

    # Validate paths exist
    missing = [p for p in source_roots if not Path(p).exists()]
    if missing:
        return jsonify({"error": f"Paths not found: {', '.join(missing)}"}), 400

    enable_genai = body.get("enable_genai", False)
    enable_vector_index = body.get("enable_vector_index", False)
    progress = run_pipeline_async(source_roots, _output_dir, enable_genai=enable_genai,
                                  full=True, enable_vector_index=enable_vector_index)
    return jsonify({"status": "started", "source_roots": source_roots})


@app.route("/api/pipeline/status", methods=["GET"])
def pipeline_status():
    """Get current pipeline progress."""
    from phase11_search.pipeline_runner import get_progress
    progress = get_progress()
    snap = progress.snapshot()

    # If pipeline just completed and we haven't initialized the explorer yet, do it
    if snap["status"] == "complete" and not _initialized:
        try:
            _init(_output_dir)
        except Exception as e:
            print(f"[SearchAPI] Post-pipeline init failed: {e}")

    return jsonify(snap)


@app.route("/api/pipeline/debug", methods=["GET"])
def pipeline_debug():
    """Return full pipeline state including all events and thread status."""
    from phase11_search.pipeline_runner import get_progress, get_thread
    progress = get_progress()
    snap = progress.snapshot()
    t = get_thread()
    snap["thread_alive"] = t.is_alive() if t else False
    snap["events"] = list(progress.events)  # full event list, not capped at 50
    return jsonify(snap)


@app.route("/api/pipeline/has-data", methods=["GET"])
def pipeline_has_data():
    """Check if output data exists (for skip-to-explorer logic)."""
    output = Path(_output_dir)
    has_graph = (output / "system_graph.json").exists()
    has_entities = (output / "entities.jsonl").exists()
    has_index = (output / "search_index" / "metadata.json").exists()
    return jsonify({
        "has_data": has_graph and has_entities,
        "has_index": has_index,
        "initialized": _initialized,
    })


if __name__ == "__main__":
    import argparse as _ap
    _parser = _ap.ArgumentParser(description="MAFIA Search API + Landing")
    _parser.add_argument("--port", type=int, default=5001)
    _parser.add_argument("--skip-init", action="store_true",
                         help="Start server without loading data (for fresh installs)")
    _args = _parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    output_dir = str(base / "output")
    _output_dir = output_dir
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Try to init if data exists, otherwise start in landing-only mode
    has_data = (Path(output_dir) / "system_graph.json").exists()
    if has_data and not _args.skip_init:
        try:
            _init(output_dir)
        except Exception as e:
            print(f"[SearchAPI] Init failed (landing mode): {e}")
    else:
        print("[SearchAPI] No existing data — starting in landing mode")
        print("[SearchAPI] Upload repos via the landing page to begin analysis")

    print(f"\n[SearchAPI] Starting on http://localhost:{_args.port}")
    app.run(host="0.0.0.0", port=_args.port, debug=False)
