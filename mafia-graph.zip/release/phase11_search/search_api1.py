"""
MAFIA Phase 11 — Search API Server
=====================================
Flask API serving hybrid vector + graph search, node profiles,
flow retrieval, blast radius, issue diagnosis, and source code reading.

Every response includes confidence badges, evidence_method, and
truncation flags.

Usage:
    python -m phase11_search.search_api1
    # Then: GET http://localhost:5001/search?q=flagTypes&layer=bff
"""

import json
from pathlib import Path
from typing import Optional

from flask import Flask, request, jsonify, send_from_directory

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase11_search.vector_index import VectorIndex
from phase11_search.graph_retriever import GraphRetriever
from phase11_search.code_reader import CodeReader
from phase9_graph.blast_radius_engine import BlastRadiusEngine
from phase9_graph.confidence_propagation import propagate_flow, compute_graph_trust_zones
from phase9_graph.annotation_store import AnnotationStore
from phase9_graph.weak_point_detector import WeakPointDetector
from phase9_graph.change_simulator import ChangeSimulator
from phase9_graph.temporal_snapshots import TemporalSnapshots
from phase10_intelligence.issue_diagnosis import diagnose_issue
from phase11_search.chat_engine import ChatEngine
from phase11_search.bigquery_store import ConversationStore
from phase11_search.ingestion.doc_store import DocumentStore

# ── Globals (loaded once at startup) ─────────────────────────────────────────

_output_dir = ""
_retriever: Optional[GraphRetriever] = None
_code_reader: Optional[CodeReader] = None
_blast_engine: Optional[BlastRadiusEngine] = None
_flow_intel = {}
_chat_engine: Optional[ChatEngine] = None
_doc_store: Optional[DocumentStore] = None
_annotation_store: Optional[AnnotationStore] = None
_weak_detector: Optional[WeakPointDetector] = None
_change_sim: Optional[ChangeSimulator] = None
_temporal: Optional[TemporalSnapshots] = None
_initialized = False  # True once _init() succeeds

app = Flask(__name__, static_folder=None)  # disable default /static — we serve our own
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB upload limit

# CORS for local dev
@app.after_request
def add_cors(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'GET,POST,OPTIONS'
    return response

# Serve Phase 12 UI
_ui_dir = str(Path(__file__).resolve().parent.parent / "phase12_ui")
print(f"[SearchAPI] UI dir: {_ui_dir} (exists: {Path(_ui_dir).exists()})")

@app.route("/")
def serve_root():
    """Landing page — upload repos and start pipeline."""
    return send_from_directory(_ui_dir, "landing.html")

@app.route("/explorer")
def serve_explorer():
    """Main explorer UI (v2 redesign)."""
    return send_from_directory(str(Path(_ui_dir) / "v2"), "index.html")

@app.route("/favicon.ico")
def favicon():
    return '', 204

# Serve root-level assets (e.g. mafia_ninja.jpg)
_root_dir = str(Path(__file__).resolve().parent.parent)

@app.route("/assets/<path:filename>")
def serve_asset(filename):
    return send_from_directory(_root_dir, filename)

@app.route("/static/<path:filename>")
def serve_static(filename):
    static_dir = str(Path(_ui_dir) / "static")
    print(f"[Static] Serving {filename} from {static_dir}")
    response = send_from_directory(static_dir, filename)
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response


def _init(output_dir: str):
    global _output_dir, _retriever, _code_reader, _blast_engine, _flow_intel, _chat_engine, _doc_store, _initialized
    _output_dir = output_dir
    output = Path(output_dir)

    # ── FAST PATH: everything needed to render the explorer ──────────────
    # These all complete in <1s total

    # Vector index
    vi = None
    index_dir = output / "search_index"
    has_faiss = (index_dir / "faiss.index").exists()
    has_docs = (index_dir / "documents.pkl").exists()
    if has_faiss or has_docs:
        print(f"[SearchAPI] Loading search index ({'vector' if has_faiss else 'keyword-only'} mode)...")
        try:
            vi = VectorIndex.load(str(index_dir))
        except Exception as e:
            print(f"[SearchAPI] Search index load failed: {e}")
    else:
        print("[SearchAPI] No search index found")

    # Graph retriever
    graph_path = output / "system_graph.json"
    if graph_path.exists():
        print("[SearchAPI] Loading graph retriever...")
        _retriever = GraphRetriever(vi, str(graph_path))
    else:
        print("[SearchAPI] No system_graph.json")
        _retriever = None

    # Code reader
    print("[SearchAPI] Loading code reader...")
    try:
        _code_reader = CodeReader(output_dir)
    except Exception as e:
        print(f"[SearchAPI] Code reader failed: {e}")
        _code_reader = None

    # Blast radius
    if graph_path.exists():
        print("[SearchAPI] Loading blast radius engine...")
        _blast_engine = BlastRadiusEngine(str(graph_path))
    else:
        _blast_engine = None

    # New engines (#2, #8, #6, #5, #4)
    _annotation_store = AnnotationStore(str(output))
    print(f"[SearchAPI] Annotations: {_annotation_store.stats()['total']} loaded")

    if graph_path.exists():
        _weak_detector = WeakPointDetector(str(graph_path))
        print("[SearchAPI] Weak-point detector loaded")
    else:
        _weak_detector = None

    if _blast_engine:
        # Load flows for change simulator
        _all_flows = []
        try:
            _fd = _load_json(output / "e2e_flows.json")
            for _cv in (_fd.get("catalogs", {}) or {}).values():
                _all_flows.extend(_cv)
            _all_flows.extend(_fd.get("flows", []))
        except Exception:
            pass
        _change_sim = ChangeSimulator(_blast_engine, _all_flows)
        print(f"[SearchAPI] Change simulator loaded ({len(_all_flows)} flows)")
    else:
        _change_sim = None

    _temporal = TemporalSnapshots(str(output))
    print(f"[SearchAPI] Temporal snapshots: {len(_temporal.list_snapshots())} snapshots")

    # Flow intelligence
    print("[SearchAPI] Loading flow intelligence...")
    fi = _load_json(output / "flow_intelligence.json")
    _flow_intel = {f["flow_id"]: f for f in fi.get("flows", [])}

    # ── Mark ready — explorer is now usable ──────────────────────────────
    _initialized = True
    node_count = len(_retriever.nodes) if _retriever else 0
    print(f"[SearchAPI] Ready (fast path). Nodes: {node_count}, Flows: {len(_flow_intel)}")

    # ── SLOW PATH: load in background, explorer works without these ──────
    import threading
    threading.Thread(target=_init_slow, args=(output_dir,), daemon=True).start()


def _init_slow(output_dir: str):
    """Load heavy components in background after explorer is already usable."""
    global _chat_engine, _doc_store
    print("[SearchAPI] Background: loading chat engine...")
    try:
        _chat_engine = ChatEngine(
            output_dir,
            retriever=_retriever,
            code_reader=_code_reader,
            flow_intel=_flow_intel,
        )
    except Exception as e:
        print(f"[SearchAPI] Chat engine init failed (chat disabled): {e}")
        _chat_engine = None

    print("[SearchAPI] Background: loading document store...")
    try:
        _doc_store = DocumentStore(output_dir)
    except Exception:
        _doc_store = None

    idx_stats = _retriever.vi.stats() if _retriever and _retriever.vi else "no index"
    print(f"[SearchAPI] Background load complete. Index: {idx_stats}")


# ── Guard: require initialized data ──────────────────────────────────────────

# Routes that work without data loaded
_UNGUARDED_PATHS = {"/", "/explorer", "/favicon.ico"}
_UNGUARDED_PREFIXES = ("/static/", "/assets/", "/api/pipeline", "/api/upload", "/api/sessions", "/api/init", "/api/resolve-local", "/stats")

@app.before_request
def _guard_init():
    """Block data-dependent routes when pipeline hasn't run yet."""
    if _initialized:
        return None
    path = request.path
    if path in _UNGUARDED_PATHS:
        return None
    for prefix in _UNGUARDED_PREFIXES:
        if path.startswith(prefix):
            return None
    return jsonify({"error": "Data not loaded yet. Run the pipeline from the landing page first."}), 503


def _require_init():
    """Legacy per-endpoint guard (kept for explicit checks)."""
    if not _initialized:
        return jsonify({"error": "Data not loaded yet. Run the pipeline from the landing page first."}), 503
    return None


# ── GET /search ──────────────────────────────────────────────────────────────

@app.route("/search", methods=["GET"])
def search():
    """
    Hybrid search: vector + graph expansion + re-ranking.
    Query params: q, layer, repo, doc_type, confidence_bucket, evidence_method,
                  completeness, top_k, expand_depth
    """
    err = _require_init()
    if err: return err
    q = request.args.get("q", "")
    if not q:
        return jsonify({"error": "Missing query parameter 'q'"}), 400

    filters = {}
    for key in ("layer", "repo", "doc_type", "confidence_bucket", "evidence_method", "completeness", "min_confidence"):
        val = request.args.get(key)
        if val:
            filters[key] = val

    top_k = int(request.args.get("top_k", 20))
    expand_depth = int(request.args.get("expand_depth", 1))

    result = _retriever.retrieve(q, top_k=top_k, filters=filters, expand_depth=expand_depth)
    return jsonify(result)


# ── GET /node/<id> ───────────────────────────────────────────────────────────

@app.route("/node/<path:node_id>", methods=["GET"])
def get_node(node_id: str):
    """Node profile with counts, intelligence, and file info."""
    err = _require_init()
    if err: return err
    profile = _retriever.get_node_profile(node_id)
    if not profile:
        return jsonify({"error": f"Node not found: {node_id}"}), 404

    # Add file info
    files = _code_reader.list_entity_files([node_id])
    profile["files"] = files
    return jsonify(profile)


# ── GET /node/<id>/neighbors ─────────────────────────────────────────────────

@app.route("/node/<path:node_id>/neighbors", methods=["GET"])
def get_neighbors(node_id: str):
    """Node neighbors with direction, depth, limit."""
    direction = request.args.get("direction", "both")
    depth = int(request.args.get("depth", 1))
    limit = int(request.args.get("limit", 50))
    result = _retriever.get_neighbors(node_id, direction=direction, depth=depth, limit=limit)
    return jsonify(result)


# ── GET /flows ───────────────────────────────────────────────────────────────

@app.route("/flows", methods=["GET"])
def get_flows():
    """List flows, optionally filtered by start_node."""
    start_node = request.args.get("start_node", "")
    mode = request.args.get("mode", "surface")
    limit = int(request.args.get("limit", 50))

    results = []
    for fid, flow in _flow_intel.items():
        if start_node:
            hop_ids = {h.get("id", "") for h in flow.get("hop_narration", [])}
            entry_id = flow.get("entry", {}).get("id", "")
            if start_node not in hop_ids and start_node != entry_id:
                continue

        if mode == "surface":
            results.append({
                "flow_id": fid,
                "surface_summary": flow.get("surface_summary", ""),
                "completeness": flow.get("completeness", ""),
                "hop_count": flow.get("hop_count", 0),
                "confidence": flow.get("confidence_range", {}).get("avg", 0),
            })
        else:
            results.append(flow)

        if len(results) >= limit:
            break

    return jsonify({
        "total": len(results),
        "mode": mode,
        "truncated": len(results) >= limit,
        "flows": results,
    })


# ── GET /flow/<id> ───────────────────────────────────────────────────────────

@app.route("/flow/<path:flow_id>", methods=["GET"])
def get_flow(flow_id: str):
    """
    Flow detail with depth modes:
      surface — summary only
      standard — full intelligence + hop narration
      deep — standard + source code for each hop
    """
    depth = request.args.get("depth", "standard")
    flow = _flow_intel.get(flow_id)
    if not flow:
        return jsonify({"error": f"Flow not found: {flow_id}"}), 404

    result = dict(flow)

    if depth == "deep":
        # Attach source code for each hop
        code = _code_reader.read_flow_code(flow_id, max_files=10, context_lines=25)
        result["source_code"] = code

    # Add file listing for all hops
    hop_ids = [h.get("id", "") for h in flow.get("hop_narration", []) if h.get("id")]
    result["files"] = _code_reader.list_entity_files(hop_ids)

    return jsonify(result)


# ── POST /blast_radius ───────────────────────────────────────────────────────

@app.route("/blast_radius", methods=["POST"])
def blast_radius():
    """Compute blast radius for a component."""
    body = request.get_json(force=True)
    component_id = body.get("component_id", "")
    direction = body.get("direction", "downstream")
    change_type = body.get("change_type", "failure")
    max_depth = body.get("max_depth", 6)

    if not component_id:
        return jsonify({"error": "Missing component_id"}), 400

    result = _blast_engine.compute(component_id, direction=direction,
                                    change_type=change_type, max_depth=max_depth)
    return jsonify(result)


# ── POST /blast_radius/flow ──────────────────────────────────────────────────

@app.route("/blast_radius/flow", methods=["POST"])
def blast_radius_flow():
    """Compute blast radius for an entire flow — what breaks if this flow fails."""
    body = request.get_json(force=True)
    flow_id = body.get("flow_id", "")
    direction = body.get("direction", "both")
    change_type = body.get("change_type", "failure")
    max_depth = body.get("max_depth", 4)

    if not flow_id:
        return jsonify({"error": "Missing flow_id"}), 400

    # Load flows from the current output
    all_flows = []
    try:
        flows_path = Path(_output_dir) / "e2e_flows.json"
        if flows_path.exists():
            import json as _json
            with open(flows_path, 'r', encoding='utf-8') as f:
                flows_data = _json.load(f)
            # Flatten catalogs into a single list
            for catalog_flows in (flows_data.get("catalogs", {}) or {}).values():
                all_flows.extend(catalog_flows)
            all_flows.extend(flows_data.get("flows", []))
    except Exception:
        pass

    # Find the target flow
    target_flow = None
    for fl in all_flows:
        if fl.get("flow_id") == flow_id:
            target_flow = fl
            break

    if not target_flow:
        return jsonify({"error": f"Flow not found: {flow_id}"}), 404

    # Extract hop node IDs from the flow
    hops = target_flow.get("standard", target_flow.get("hops", []))

    result = _blast_engine.compute_flow_blast(
        flow_hops=hops,
        flow_id=flow_id,
        direction=direction,
        change_type=change_type,
        max_depth=max_depth,
        all_flows=all_flows,
    )
    return jsonify(result)


# ── POST /blast_radius/explain ───────────────────────────────────────────────

@app.route("/blast_radius/explain", methods=["POST"])
def blast_radius_explain():
    """AI-generated narrative for blast radius results using RAG retrieval."""
    if not _chat_engine:
        return jsonify({"error": "Chat engine not available"}), 503

    body = request.get_json(force=True)
    origin = body.get("origin", "")
    origin_label = body.get("origin_label", origin)
    origin_layer = body.get("origin_layer", "")
    direction = body.get("direction", "downstream")
    change_type = body.get("change_type", "failure")
    severity_counts = body.get("severity_counts", {})
    by_layer = body.get("by_layer", {})
    nodes = body.get("nodes", [])[:20]

    if not origin:
        return jsonify({"error": "Missing origin"}), 400

    # Retrieve descriptions for impacted components via graph
    component_contexts = []
    seen = set()
    for n in nodes[:12]:
        nid = n.get("id", "")
        if nid in seen:
            continue
        seen.add(nid)
        try:
            profile = _retriever.get_node_profile(nid)
            nd = (profile or {}).get("node", {})
            desc = nd.get("description") or nd.get("label", "")
            component_contexts.append(
                f"- [{n.get('layer','').upper()}] {nd.get('label', nid)} "
                f"(type={n.get('type','')}, severity={n.get('bucket','')}, "
                f"depth={n.get('depth','')}, relation={n.get('relation_from_parent','')}) "
                f"-- {desc[:200]}"
            )
        except Exception:
            component_contexts.append(
                f"- [{n.get('layer','').upper()}] {n.get('label', nid)} "
                f"(severity={n.get('bucket','')}, depth={n.get('depth','')})"
            )

    origin_desc = ""
    try:
        origin_profile = _retriever.get_node_profile(origin)
        origin_nd = (origin_profile or {}).get("node", {})
        origin_desc = origin_nd.get("description") or origin_nd.get("label", origin_label)
    except Exception:
        origin_desc = origin_label

    prompt = (
        "You are analyzing the blast radius of a code change in a multi-layer system "
        "(UI -> BFF -> API -> DB).\n\n"
        f"The component being changed:\n"
        f"  Name: {origin_label}\n"
        f"  Layer: {origin_layer}\n"
        f"  Description: {origin_desc}\n"
        f"  Change type: {change_type}\n"
        f"  Direction: {direction}\n\n"
        f"Severity summary: {json.dumps(severity_counts)}\n"
        f"Impacted layers: {json.dumps(by_layer)}\n\n"
        f"Impacted components (sorted by severity):\n"
        + "\n".join(component_contexts) + "\n\n"
        "Write a concise (3-5 sentences) developer-facing explanation of:\n"
        "1. What this component does and why it matters\n"
        f"2. What would concretely happen if it experiences a {change_type} -- "
        "which downstream services/UIs/tables break and how\n"
        "3. Which impacted components are most critical to check first and why\n\n"
        "Be specific -- name the actual components, layers, and relations. "
        "Do NOT use generic language. Label each statement [OBSERVED] or [DERIVED]."
    )

    try:
        from phase11_search.chat_engine import _get_gemini
        gemini = _get_gemini()
        explanation = gemini.generate(
            [{"role": "user", "text": prompt}],
            temperature=0.3,
        )
        return jsonify({"explanation": explanation})
    except Exception as e:
        return jsonify({"error": f"AI generation failed: {e}"}), 500


# ══════════════════════════════════════════════════════════════════════════════
# Feature #2: Confidence Propagation
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/confidence/flow/<path:flow_id>")
def confidence_flow(flow_id):
    """Compute propagated confidence for a flow."""
    all_flows = []
    try:
        fd = _load_json(Path(_output_dir) / "e2e_flows.json")
        for cv in (fd.get("catalogs", {}) or {}).values():
            all_flows.extend(cv)
        all_flows.extend(fd.get("flows", []))
    except Exception:
        pass
    target = next((f for f in all_flows if f.get("flow_id") == flow_id), None)
    if not target:
        return jsonify({"error": f"Flow not found: {flow_id}"}), 404
    hops = target.get("standard", target.get("hops", []))
    result = propagate_flow(hops)
    result["flow_id"] = flow_id
    return jsonify(result)

@app.route("/confidence/trust-zones")
def trust_zones():
    """Compute trust zones for all nodes in the graph."""
    graph_path = Path(_output_dir) / "system_graph.json"
    if not graph_path.exists():
        return jsonify({"error": "No graph data"}), 404
    data = _load_json(graph_path)
    result = compute_graph_trust_zones(data.get("nodes", []), data.get("edges", []))
    return jsonify(result)


# ══════════════════════════════════════════════════════════════════════════════
# Feature #8: Decision Annotations
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/annotations", methods=["GET"])
def list_annotations():
    q = request.args.get("q", "")
    cat = request.args.get("category", "")
    sev = request.args.get("severity", "")
    results = _annotation_store.search(q, cat, sev) if _annotation_store else []
    return jsonify({"annotations": results, "stats": _annotation_store.stats() if _annotation_store else {}})

@app.route("/annotations", methods=["POST"])
def add_annotation():
    if not _annotation_store:
        return jsonify({"error": "Annotation store not initialized"}), 503
    body = request.get_json(force=True)
    ann = _annotation_store.add(
        target_id=body.get("target_id", ""),
        target_type=body.get("target_type", "node"),
        category=body.get("category", "context"),
        text=body.get("text", ""),
        author=body.get("author", "anonymous"),
        tags=body.get("tags", []),
        severity=body.get("severity", "info"),
    )
    return jsonify(ann)

@app.route("/annotations/<path:target_id>")
def get_annotations_for(target_id):
    results = _annotation_store.get_for_target(target_id) if _annotation_store else []
    return jsonify({"annotations": results})

@app.route("/annotations/<ann_id>", methods=["DELETE"])
def delete_annotation(ann_id):
    if not _annotation_store:
        return jsonify({"error": "Not initialized"}), 503
    ok = _annotation_store.delete(ann_id)
    return jsonify({"deleted": ok})


# ══════════════════════════════════════════════════════════════════════════════
# Feature #6: Weak-Point Detection
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/weak-points")
def weak_points():
    """Analyze structural weak points in the system graph."""
    if not _weak_detector:
        return jsonify({"error": "Weak-point detector not loaded"}), 503
    return jsonify(_weak_detector.analyze())


# ══════════════════════════════════════════════════════════════════════════════
# Feature #5: Change Simulation
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/simulate", methods=["POST"])
def simulate_change():
    """Simulate a change and compute risk."""
    if not _change_sim:
        return jsonify({"error": "Change simulator not loaded"}), 503
    body = request.get_json(force=True)
    sim_type = body.get("type", "removal")
    node_id = body.get("node_id", "")
    if not node_id:
        return jsonify({"error": "Missing node_id"}), 400
    if sim_type == "removal":
        return jsonify(_change_sim.simulate_removal(node_id))
    elif sim_type == "contract_change":
        return jsonify(_change_sim.simulate_contract_change(node_id, body.get("changes", [])))
    elif sim_type == "failure":
        return jsonify(_change_sim.simulate_failure(node_id, body.get("duration", "transient")))
    return jsonify({"error": f"Unknown simulation type: {sim_type}"}), 400


# ══════════════════════════════════════════════════════════════════════════════
# Feature #4: Temporal Snapshots
# ══════════════════════════════════════════════════════════════════════════════

@app.route("/snapshots", methods=["GET"])
def list_snapshots():
    if not _temporal:
        return jsonify({"error": "Not initialized"}), 503
    return jsonify({"snapshots": _temporal.list_snapshots()})

@app.route("/snapshots", methods=["POST"])
def save_snapshot():
    if not _temporal:
        return jsonify({"error": "Not initialized"}), 503
    body = request.get_json(force=True)
    entry = _temporal.save_snapshot(label=body.get("label"))
    return jsonify(entry)

@app.route("/snapshots/diff", methods=["POST"])
def diff_snapshots():
    if not _temporal:
        return jsonify({"error": "Not initialized"}), 503
    body = request.get_json(force=True)
    return jsonify(_temporal.diff(body.get("a", ""), body.get("b", "")))

@app.route("/snapshots/flow-drift", methods=["POST"])
def flow_drift():
    if not _temporal:
        return jsonify({"error": "Not initialized"}), 503
    body = request.get_json(force=True)
    return jsonify(_temporal.flow_drift(body.get("a", ""), body.get("b", "")))


# ── POST /issue/diagnose ─────────────────────────────────────────────────────

@app.route("/issue/diagnose", methods=["POST"])
def issue_diagnose():
    """Diagnose an issue using retrieval + graph."""
    body = request.get_json(force=True)
    issue_text = body.get("issue_text", "")
    if not issue_text:
        return jsonify({"error": "Missing issue_text"}), 400

    result = diagnose_issue(issue_text, _output_dir)

    # Enrich with source code for top change points
    if result.get("likely_change_points"):
        top_files = []
        for cp in result["likely_change_points"][:3]:
            comp = cp.get("component", "")
            # Try to find entity by name match
            for eid, info in _code_reader._entity_map.items():
                if comp and comp in eid:
                    code = _code_reader.read_entity_code(eid, context_lines=15)
                    if code and not code.get("error"):
                        top_files.append(code)
                    break
        result["source_code_hints"] = top_files

    return jsonify(result)


# ── GET /code/<entity_id> ────────────────────────────────────────────────────

@app.route("/code/<path:entity_id>", methods=["GET"])
def read_code(entity_id: str):
    """Read source code for an entity (focused view)."""
    context = int(request.args.get("context_lines", 30))
    result = _code_reader.read_entity_code(entity_id, context_lines=context)
    if not result:
        return jsonify({"error": f"Entity not found: {entity_id}"}), 404
    return jsonify(result)


@app.route("/codefile", methods=["GET"])
def read_full_code():
    """Read entire source file for an entity, with highlight range."""
    entity_id = request.args.get("id", "")
    if not entity_id:
        return jsonify({"error": "Missing id parameter"}), 400
    result = _code_reader.read_full_file(entity_id)
    if not result:
        return jsonify({"error": f"Entity not found: {entity_id}"}), 404
    return jsonify(result)


# ── GET /subgraph ────────────────────────────────────────────────────────────

@app.route("/subgraph", methods=["GET"])
def subgraph():
    """Neighborhood slice with edge_types filter + budget."""
    center = request.args.get("center", "")
    if not center:
        return jsonify({"error": "Missing center parameter"}), 400
    direction = request.args.get("direction", "both")
    depth = int(request.args.get("depth", 2))
    limit = int(request.args.get("limit", 50))
    edge_types = request.args.get("edge_types", "flow")  # flow | structural | all

    flow_edges = {"fetches","calls_api","delegates_to","uses_repo","calls_function",
                  "reads_from","writes_to","routes_to","calls","entity_maps_to","uses_table"}
    structural_edges = {"defined_in","belongs_to_repo","belongs_to_layer","imports","exports"}

    if edge_types == "flow":
        allowed = flow_edges
        use_adj = _retriever.adj
        use_rev = _retriever.rev
        use_edge_map = _retriever._edge_map
    elif edge_types == "structural":
        allowed = structural_edges
        use_adj = _retriever.struct_adj
        use_rev = _retriever.struct_rev
        use_edge_map = _retriever._struct_edge_map
    else:
        allowed = flow_edges | structural_edges
        # Merge both
        use_adj = defaultdict(list)
        use_rev = defaultdict(list)
        use_edge_map = {**_retriever._edge_map, **_retriever._struct_edge_map}
        for k, v in _retriever.adj.items(): use_adj[k].extend(v)
        for k, v in _retriever.struct_adj.items(): use_adj[k].extend(v)
        for k, v in _retriever.rev.items(): use_rev[k].extend(v)
        for k, v in _retriever.struct_rev.items(): use_rev[k].extend(v)

    # BFS from center
    from collections import deque, defaultdict
    visited = {center: 0}
    queue = deque([(center, 0)])
    slice_nodes = []
    slice_edges = []

    while queue and len(slice_nodes) < limit:
        nid, d = queue.popleft()
        node = _retriever.nodes.get(nid)
        if node:
            slice_nodes.append(node)

        if d >= depth:
            continue

        neighbors = []
        if direction in ("downstream", "both"):
            for tgt in use_adj.get(nid, []):
                edge = use_edge_map.get((nid, tgt), {})
                if edge.get("type", "") in allowed:
                    neighbors.append((tgt, edge, nid))
        if direction in ("upstream", "both"):
            for src in use_rev.get(nid, []):
                edge = use_edge_map.get((src, nid), {})
                if edge.get("type", "") in allowed:
                    neighbors.append((src, edge, src))

        for nbr, edge, src in neighbors:
            if nbr not in visited and len(slice_nodes) < limit:
                visited[nbr] = d + 1
                queue.append((nbr, d + 1))
                slice_edges.append(edge)

    return jsonify({
        "center": center,
        "nodes": slice_nodes[:limit],
        "edges": slice_edges,
        "metadata": {
            "truncated": len(slice_nodes) >= limit,
            "limit": limit,
            "depth": depth,
            "edge_types": edge_types,
            "total_nodes": len(slice_nodes),
            "total_edges": len(slice_edges),
        },
    })


# ── GET /coverage ────────────────────────────────────────────────────────────

@app.route("/coverage", methods=["GET"])
def coverage():
    """Coverage dashboard data."""
    cov = _load_json(Path(_output_dir) / "coverage_report.json")
    mapping = _load_json(Path(_output_dir) / "mapping_confidence_report.json")
    gate = _load_json(Path(_output_dir) / "quality_gate_report.json")

    # Flow completeness stats
    complete = sum(1 for f in _flow_intel.values() if f.get("completeness") == "complete")
    partial = sum(1 for f in _flow_intel.values() if f.get("completeness") != "complete")

    # Breakpoint distribution
    bp_by_layer = {}
    for f in _flow_intel.values():
        for h in f.get("hop_narration", []):
            if h.get("confidence", 1) < 0.5:
                l = h.get("layer", "unknown")
                bp_by_layer[l] = bp_by_layer.get(l, 0) + 1

    # Orphan queries
    orphans = {"bff_no_ui_caller": [], "db_no_api_caller": [], "api_no_bff_caller": []}
    for nid, node in _retriever.nodes.items():
        layer = node.get("layer", "")
        ntype = node.get("type", "")
        upstream = _retriever.rev.get(nid, [])
        if layer == "bff" and ntype == "endpoint" and not upstream:
            orphans["bff_no_ui_caller"].append({"id": nid, "name": node.get("label", "")})
        elif layer == "db" and ntype == "function" and not upstream:
            orphans["db_no_api_caller"].append({"id": nid, "name": node.get("label", "")})
        elif layer == "api" and ntype == "endpoint" and not any(
            _retriever.nodes.get(s, {}).get("layer") == "bff" for s in upstream
        ):
            orphans["api_no_bff_caller"].append({"id": nid, "name": node.get("label", "")})

    for k in orphans:
        orphans[k] = orphans[k][:20]

    return jsonify({
        "coverage": cov,
        "mapping": mapping,
        "quality_gate": gate,
        "flow_completeness": {"complete": complete, "partial": partial, "total": complete + partial},
        "breakpoint_distribution": bp_by_layer,
        "orphans": orphans,
    })


# ── GET /repos ───────────────────────────────────────────────────────────────

@app.route("/repos", methods=["GET"])
def repos():
    """Repo dependency view."""
    gv = _load_json(Path(_output_dir) / "graph_views.json")
    manifest = _load_json(Path(_output_dir) / "repo_manifest.json")

    repo_nodes = []
    # Count entities per repo from live graph as fallback
    repo_entity_counts = {}
    repo_relation_counts = {}
    if _retriever:
        for nid, n in _retriever.nodes.items():
            rp = n.get('repo', '')
            if rp:
                repo_entity_counts[rp] = repo_entity_counts.get(rp, 0) + 1
        for src, targets in _retriever.adj.items():
            rp = _retriever.nodes.get(src, {}).get('repo', '')
            if rp:
                repo_relation_counts[rp] = repo_relation_counts.get(rp, 0) + len(targets)
    for r in manifest.get("repos", []):
        rv = gv.get("repo_view", {}).get(r["repo_id"], {})
        repo_nodes.append({
            "id": r["repo_id"],
            "classification": r.get("classification", []),
            "stack": r.get("detected_stack", []),
            "confidence": r.get("classification_confidence", 0),
            "entity_count": rv.get("entity_count") or repo_entity_counts.get(r["repo_id"], 0),
            "relation_count": rv.get("relation_count") or repo_relation_counts.get(r["repo_id"], 0),
        })

    # Build inter-repo edges from graph
    repo_edges = {}
    for src, targets in _retriever.adj.items():
        src_repo = _retriever.nodes.get(src, {}).get("repo", "")
        for tgt in targets:
            tgt_repo = _retriever.nodes.get(tgt, {}).get("repo", "")
            if src_repo and tgt_repo and src_repo != tgt_repo:
                key = f"{src_repo}::{tgt_repo}"
                if key not in repo_edges:
                    repo_edges[key] = {"source": src_repo, "target": tgt_repo, "count": 0}
                repo_edges[key]["count"] += 1

    return jsonify({
        "repos": repo_nodes,
        "edges": list(repo_edges.values()),
    })


# ── POST /chat ────────────────────────────────────────────────────────────────

@app.route("/chat", methods=["POST"])
def chat():
    """AI Chat with hybrid RAG + optional code reading."""
    if not _chat_engine:
        return jsonify({"error": "Chat is still loading in the background. Try again in a few seconds."}), 503
    body = request.get_json(force=True)
    message = body.get("message", "")
    conv_id = body.get("conversation_id", "")
    code_mode = body.get("code_mode", False)

    if not message:
        return jsonify({"error": "Missing message"}), 400

    if not conv_id:
        conv_id = _chat_engine.create_conversation()

    try:
        result = _chat_engine.chat(conv_id, message, code_mode=code_mode)
        return jsonify(result)
    except Exception as e:
        import traceback
        print(f"[Chat] Error: {e}\n{traceback.format_exc()}")
        return jsonify({"error": f"Chat failed: {type(e).__name__}: {e}"}), 500


# ── GET /conversations ─────────────────────────────────────────────────────

@app.route("/conversations", methods=["GET"])
def list_conversations():
    if not _chat_engine:
        return jsonify({"conversations": []})
    convs = _chat_engine.list_conversations()
    return jsonify({"conversations": convs})


@app.route("/conversations/<conv_id>", methods=["GET"])
def get_conversation(conv_id):
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    data = _chat_engine.get_conversation_history(conv_id)
    if not data.get("conversation"):
        return jsonify({"error": "Conversation not found"}), 404
    return jsonify(data)


@app.route("/conversations/<conv_id>/state", methods=["POST"])
def update_conversation_state(conv_id):
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    body = request.get_json(force=True)
    _chat_engine.store.update_working_set(
        conv_id,
        node_ids=body.get("node_ids"),
        flow_ids=body.get("flow_ids"),
        filters=body.get("filters"),
        toggle_code=body.get("toggle_code"),
    )
    return jsonify({"ok": True})


# ── POST /conversations (create new) ───────────────────────────────────

@app.route("/conversations", methods=["POST"])
def create_conversation():
    if not _chat_engine:
        return jsonify({"error": "Chat engine not initialized"}), 503
    body = request.get_json(force=True) if request.data else {}
    conv_id = _chat_engine.create_conversation(title=body.get("title", ""))
    return jsonify({"conversation_id": conv_id})


# ── GET /stats ───────────────────────────────────────────────────────────────

@app.route("/graph/full", methods=["GET"])
def graph_full():
    """Return all nodes and edges for full graph visualization.
    Supports optional layer/type filters and a limit.
    Also injects edges from complete flow chains so UI→API→DB paths are visible."""
    err = _require_init()
    if err: return err
    layer = request.args.get("layer", "")
    ntype = request.args.get("type", "")
    limit = int(request.args.get("limit", 500))
    mode = request.args.get("mode", "full")  # full | flows_only

    nodes = []
    for nid, n in _retriever.nodes.items():
        if layer and n.get("layer", "") != layer:
            continue
        if ntype and n.get("type", "") != ntype:
            continue
        nodes.append(n)
        if len(nodes) >= limit:
            break

    node_ids = {n["id"] for n in nodes}

    # Collect edges from adjacency map
    edges = []
    seen_edges = set()
    for nid in node_ids:
        for tgt in _retriever.adj.get(nid, []):
            if tgt in node_ids:
                pair = (nid, tgt)
                if pair not in seen_edges:
                    seen_edges.add(pair)
                    edge = _retriever._edge_map.get(pair, {})
                    edges.append({
                        "source": nid, "target": tgt,
                        "type": edge.get("type", ""),
                        "confidence": edge.get("confidence", 0),
                    })

    # Inject flow-chain edges from complete flows so UI→API→DB paths are visible
    # These are the hop sequences in e2e_flows.json that may not all be in adj
    flow_chain_edges = 0
    e2e_path = Path(_output_dir) / "e2e_flows.json"
    if e2e_path.exists():
        try:
            e2e = _load_json(e2e_path)
            for catalog_name, flows in e2e.get("catalogs", {}).items():
                if not isinstance(flows, list):
                    continue
                for flow in flows:
                    hops = flow.get("standard", [])
                    for i in range(len(hops) - 1):
                        src_id = hops[i].get("id", "")
                        tgt_id = hops[i + 1].get("id", "")
                        if not src_id or not tgt_id:
                            continue
                        # Add nodes if not already included (up to limit)
                        for nid in (src_id, tgt_id):
                            if nid not in node_ids and len(nodes) < limit * 2:
                                n = _retriever.nodes.get(nid)
                                if n:
                                    nodes.append(n)
                                    node_ids.add(nid)
                        pair = (src_id, tgt_id)
                        if pair not in seen_edges and src_id in node_ids and tgt_id in node_ids:
                            seen_edges.add(pair)
                            rel = hops[i].get("next_relation") or {}
                            edges.append({
                                "source": src_id, "target": tgt_id,
                                "type": rel.get("type", "flow_hop"),
                                "confidence": rel.get("confidence", 0.8),
                                "flow_id": flow.get("flow_id", ""),
                                "completeness": flow.get("completeness", ""),
                            })
                            flow_chain_edges += 1
        except Exception:
            pass

    # Annotate nodes with flow_ids so the UI can highlight full flow chains
    node_flow_map = {}  # node_id -> set of flow_ids
    if e2e_path.exists():
        try:
            e2e2 = _load_json(e2e_path) if not flow_chain_edges else e2e  # reuse if already loaded
            for cat_flows in (e2e2.get("catalogs", {}) or {}).values():
                if not isinstance(cat_flows, list): continue
                for flow in cat_flows:
                    fid = flow.get("flow_id", "")
                    for hop in flow.get("standard", []):
                        hid = hop.get("id", "")
                        if hid: node_flow_map.setdefault(hid, set()).add(fid)
        except Exception:
            pass
    for n in nodes:
        fids = node_flow_map.get(n["id"])
        if fids:
            n["flow_ids"] = list(fids)

    return jsonify({
        "nodes": nodes, "edges": edges,
        "total_nodes": len(_retriever.nodes),
        "truncated": len(nodes) >= limit,
        "flow_chain_edges_injected": flow_chain_edges,
    })



# ══════════════════════════════════════════════════════════════════════════════
# Architecture Diagram — architecture.md based
# ══════════════════════════════════════════════════════════════════════════════

def _find_arch_md() -> str | None:
    """Find architecture.md in output dir, .mafia dir, or project root."""
    candidates = [
        Path(_output_dir) / "architecture.md",
    ]
    # Also check source roots from manifest
    manifest = _load_json(Path(_output_dir) / "repo_manifest.json")
    for r in manifest.get("repos", [])[:5]:
        rp = r.get("root_path", "")
        if rp:
            root = Path(rp).parent
            candidates.append(root / "architecture.md")
            candidates.append(root / ".mafia" / "architecture.md")
            candidates.append(Path(rp) / "architecture.md")
    for p in candidates:
        if p.exists():
            return str(p)
    return None


def _parse_arch_md(text: str) -> dict:
    """Parse architecture.md into {title, zones, components, edges}."""
    import re
    lines = text.split("\n")
    title = ""
    zones = []
    components = []
    edges = []
    current_zone = None
    current_comp = None
    in_connections = False

    for line in lines:
        stripped = line.strip()

        # Title
        if stripped.startswith("# ") and not title:
            title = stripped[2:].strip()
            # Strip "Architecture — " prefix if present
            if "—" in title:
                title = title.split("—", 1)[1].strip()
            elif "-" in title and title.index("-") < 20:
                title = title.split("-", 1)[1].strip()
            continue

        # Zone (## heading)
        if stripped.startswith("## "):
            zone_name = stripped[3:].strip()
            if zone_name.lower() == "connections":
                in_connections = True
                current_zone = None
                current_comp = None
                continue
            in_connections = False
            current_zone = {"id": re.sub(r'\W+', '_', zone_name).lower(), "label": zone_name, "component_ids": []}
            zones.append(current_zone)
            current_comp = None
            continue

        # Component (### heading)
        if stripped.startswith("### ") and not in_connections:
            comp_name = stripped[4:].strip()
            comp_id = re.sub(r'\W+', '_', comp_name).lower()
            current_comp = {
                "id": comp_id, "label": comp_name,
                "type": "service", "description": "", "color": "",
                "zone": current_zone["id"] if current_zone else "",
            }
            components.append(current_comp)
            if current_zone:
                current_zone["component_ids"].append(comp_id)
            continue

        # Component metadata (- key: value)
        if current_comp and stripped.startswith("- ") and ":" in stripped and not in_connections:
            kv = stripped[2:].split(":", 1)
            key = kv[0].strip().lower()
            val = kv[1].strip() if len(kv) > 1 else ""
            if key == "type": current_comp["type"] = val
            elif key == "description": current_comp["description"] = val
            elif key == "color": current_comp["color"] = val
            continue

        # Connection line: Source -> Target : label
        if in_connections and "->" in stripped:
            match = re.match(r'^(.+?)\s*->\s*(.+?)(?:\s*:\s*(.+))?$', stripped)
            if match:
                src_name = match.group(1).strip()
                tgt_name = match.group(2).strip()
                label = (match.group(3) or "").strip()
                src_id = re.sub(r'\W+', '_', src_name).lower()
                tgt_id = re.sub(r'\W+', '_', tgt_name).lower()
                edges.append({"source": src_id, "target": tgt_id, "label": label})

    return {"title": title, "zones": zones, "components": components, "edges": edges}


@app.route("/graph/architecture", methods=["GET"])
def graph_architecture():
    """Return parsed architecture.md for D3 rendering.
    If no architecture.md exists, returns {exists: false} so the UI can show the prompt."""
    err = _require_init()
    if err: return err

    arch_path = _find_arch_md()
    if not arch_path:
        return jsonify({"exists": False, "components": [], "edges": [], "zones": []})

    try:
        text = Path(arch_path).read_text(encoding="utf-8")
    except Exception as e:
        return jsonify({"exists": False, "error": str(e)})

    parsed = _parse_arch_md(text)
    parsed["exists"] = True
    parsed["path"] = arch_path
    return jsonify(parsed)


@app.route("/graph/architecture/prompt", methods=["GET"])
def graph_architecture_prompt():
    """Generate the AI prompt populated with graph context for creating architecture.md."""
    err = _require_init()
    if err: return err

    # Load the prompt template
    template_path = Path(__file__).resolve().parent.parent / "schemas" / "samples" / "architecture_prompt.md"
    try:
        template = template_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"[SearchAPI] Failed to read architecture prompt template at {template_path}: {e}")
        template = (
            "# Generate Architecture Diagram\n\n"
            "Create an `architecture.md` file for this project using the MAFIA architecture format.\n\n"
            "## Format\n\n"
            "Each `##` section is a zone (swimlane). Each `###` is a component with `- type:` and `- description:`.\n"
            "The last `## Connections` section lists edges as `Source -> Target : label`.\n\n"
            "Valid types: frontend, gateway, service, database, queue, external, agent, storage, config\n\n"
            "## System Context\n\n"
            "### Repositories\n{repos}\n\n"
            "### Entity Summary by Layer\n{entity_summary}\n\n"
            "### Key Components\n{key_components}\n\n"
            "### Cross-Layer Connections\n{connections}\n\n"
            "### End-to-End Flows\n{flows}\n\n"
            "## Instructions\n\n"
            "Using the context above, create an architecture.md that groups the system into 3-6 zones, "
            "identifies major components, and maps connections with meaningful labels.\n"
        )

    # Populate with graph data
    manifest = _load_json(Path(_output_dir) / "repo_manifest.json")
    repos_text = ""
    for r in manifest.get("repos", []):
        cls = (r.get("classification", []) or ["unknown"])[0]
        stack = ", ".join(r.get("detected_stack", [])[:4])
        repos_text += f"- {r['repo_id']} [{cls}] — {stack}\n"

    # Entity summary by layer
    layer_counts: dict[str, dict[str, int]] = {}
    for n in _retriever.nodes.values():
        l = n.get("layer", "unknown")
        t = n.get("type", "unknown")
        layer_counts.setdefault(l, {}).setdefault(t, 0)
        layer_counts[l][t] += 1
    entity_text = ""
    for layer in ["ui", "bff", "api", "db", "data", "config"]:
        if layer not in layer_counts: continue
        types = ", ".join(f"{t}: {c}" for t, c in sorted(layer_counts[layer].items(), key=lambda x: -x[1]))
        entity_text += f"- **{layer.upper()}**: {types}\n"

    # Key components (high-confidence services, controllers, functions)
    key_types = {"service", "controller", "component", "function", "table", "repository"}
    key_comps = []
    for nid, n in _retriever.nodes.items():
        if n.get("type") in key_types and n.get("confidence", 0) >= 0.7:
            key_comps.append(n)
    key_comps.sort(key=lambda x: -x.get("confidence", 0))
    key_text = ""
    for n in key_comps[:30]:
        label = n.get("label", "").split("::")[-1] if "::" in n.get("label", "") else n.get("label", "")
        key_text += f"- [{n.get('layer','').upper()}] {label} ({n.get('type','')}, {n.get('repo','')}) — {int(n.get('confidence',0)*100)}%\n"

    # Cross-layer connections (sample)
    conn_text = ""
    seen = set()
    count = 0
    for src_id, targets in _retriever.adj.items():
        src = _retriever.nodes.get(src_id, {})
        for tgt_id in targets:
            tgt = _retriever.nodes.get(tgt_id, {})
            if src.get("layer") != tgt.get("layer") and src.get("layer") and tgt.get("layer"):
                edge = _retriever._edge_map.get((src_id, tgt_id), {})
                key = f"{src.get('layer')}->{tgt.get('layer')}:{edge.get('type','')}"
                if key not in seen:
                    seen.add(key)
                    sl = src.get("label", "").split("::")[-1] if "::" in src.get("label", "") else src.get("label", "")
                    tl = tgt.get("label", "").split("::")[-1] if "::" in tgt.get("label", "") else tgt.get("label", "")
                    conn_text += f"- {sl} ({src.get('layer','').upper()}) --[{edge.get('type','')}]--> {tl} ({tgt.get('layer','').upper()})\n"
                    count += 1
                    if count >= 25: break
        if count >= 25: break

    # Flows
    flow_text = ""
    for fid, f in list(_flow_intel.items())[:10]:
        hops = f.get("hop_narration", [])
        chain = " → ".join(h.get("name", "?") for h in hops[:6])
        flow_text += f"- {f.get('surface_summary', fid)[:60]}: {chain}\n"

    prompt = template.replace("{repos}", repos_text or "No repos found")
    prompt = prompt.replace("{entity_summary}", entity_text or "No entities")
    prompt = prompt.replace("{key_components}", key_text or "No key components")
    prompt = prompt.replace("{connections}", conn_text or "No cross-layer connections")
    prompt = prompt.replace("{flows}", flow_text or "No flows")

    # Also check if architecture.md already exists
    arch_path = _find_arch_md()

    return jsonify({
        "prompt": prompt,
        "exists": arch_path is not None,
        "path": arch_path,
    })


@app.route("/graph/architecture/save", methods=["POST"])
def graph_architecture_save():
    """Save architecture.md content to the output directory."""
    body = request.get_json(force=True)
    content = body.get("content", "")
    if not content:
        return jsonify({"error": "No content provided"}), 400
    save_path = Path(_output_dir) / "architecture.md"
    try:
        save_path.write_text(content, encoding="utf-8")
        return jsonify({"ok": True, "path": str(save_path)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/graph/flows", methods=["GET"])
def graph_flows():
    """Return a subgraph of only the complete flow chains (UI→API→DB).
    Each node is annotated with its position in the flow.
    Ideal for the 'show me the whole application' view."""
    err = _require_init()
    if err: return err

    completeness_filter = request.args.get("completeness", "")  # complete | partial | ""
    limit = int(request.args.get("limit", 200))

    e2e_path = Path(_output_dir) / "e2e_flows.json"
    if not e2e_path.exists():
        return jsonify({"nodes": [], "edges": [], "flows": [], "error": "No flow data"})

    e2e = _load_json(e2e_path)
    flow_nodes = {}   # id -> node with flow annotations
    flow_edges = {}   # (src,tgt) -> edge
    flow_summaries = []

    for catalog_name, flows in e2e.get("catalogs", {}).items():
        if catalog_name in ("complete_flows", "partial_flows"):
            continue  # avoid double-counting
        if not isinstance(flows, list):
            continue
        for flow in flows:
            comp = flow.get("completeness", "partial")
            if completeness_filter and comp != completeness_filter:
                continue

            hops = flow.get("standard", [])
            flow_id = flow.get("flow_id", "")
            layers_touched = flow.get("layers_touched", [])

            flow_summaries.append({
                "flow_id": flow_id,
                "completeness": comp,
                "hop_count": flow.get("hop_count", len(hops)),
                "layers": layers_touched,
                "entry": flow.get("entry", {}).get("name", ""),
                "terminal": flow.get("terminal", {}).get("name", ""),
                "confidence": flow.get("confidence_range", {}).get("avg", 0),
            })

            for i, hop in enumerate(hops):
                nid = hop.get("id", "")
                if not nid:
                    continue
                base_node = _retriever.nodes.get(nid, {})
                if nid not in flow_nodes:
                    flow_nodes[nid] = {
                        **base_node,
                        "id": nid,
                        "flow_position": i,
                        "flow_ids": [flow_id],
                        "is_entry": i == 0,
                        "is_terminal": i == len(hops) - 1,
                    }
                else:
                    flow_nodes[nid]["flow_ids"].append(flow_id)

                if i < len(hops) - 1:
                    next_hop = hops[i + 1]
                    tgt_id = next_hop.get("id", "")
                    if tgt_id:
                        pair = (nid, tgt_id)
                        rel = hop.get("next_relation") or {}
                        if pair not in flow_edges:
                            flow_edges[pair] = {
                                "source": nid, "target": tgt_id,
                                "type": rel.get("type", "flow_hop"),
                                "confidence": rel.get("confidence", 0.8),
                                "flow_id": flow_id,
                                "completeness": comp,
                            }

    nodes_list = list(flow_nodes.values())[:limit]
    edges_list = list(flow_edges.values())

    # Only include edges where both endpoints are in the node list
    included_ids = {n["id"] for n in nodes_list}
    edges_list = [e for e in edges_list
                  if e["source"] in included_ids and e["target"] in included_ids]

    return jsonify({
        "nodes": nodes_list,
        "edges": edges_list,
        "flows": flow_summaries,
        "total_nodes": len(flow_nodes),
        "total_edges": len(flow_edges),
        "total_flows": len(flow_summaries),
        "truncated": len(nodes_list) >= limit,
    })


@app.route("/inventory", methods=["GET"])
def inventory():
    """Full inventory of all nodes and edges, grouped by layer and type."""
    err = _require_init()
    if err: return err

    by_layer = {}
    for nid, n in _retriever.nodes.items():
        layer = n.get("layer", "unknown")
        ntype = n.get("type", "unknown")
        by_layer.setdefault(layer, {}).setdefault(ntype, []).append({
            "id": nid, "label": n.get("label", ""), "repo": n.get("repo", ""),
            "file": n.get("file", ""), "line": n.get("line"),
            "confidence": n.get("confidence", 0),
            "evidence_method": n.get("evidence_method", ""),
        })

    edge_types = {}
    for src in _retriever.adj:
        for tgt in _retriever.adj[src]:
            edge = _retriever._edge_map.get((src, tgt), {})
            etype = edge.get("type", "unknown")
            edge_types.setdefault(etype, {"count": 0, "samples": []})
            edge_types[etype]["count"] += 1
            if len(edge_types[etype]["samples"]) < 5:
                edge_types[etype]["samples"].append({
                    "source": src.split(":")[-1][:40], "target": tgt.split(":")[-1][:40],
                    "confidence": edge.get("confidence", 0),
                })

    return jsonify({
        "nodes_by_layer": by_layer,
        "edge_types": edge_types,
        "total_nodes": len(_retriever.nodes),
        "total_edges": sum(len(v) for v in _retriever.adj.values()),
    })


@app.route("/codetree", methods=["GET"])
def codetree():
    """Return all nodes organized as repo → file → entities (sorted by line),
    plus cross-file edges so the UI can show which files reference each other."""
    err = _require_init()
    if err: return err

    # Build repo → file → [nodes sorted by line]
    tree = {}  # repo → { file → [node, ...] }
    for nid, n in _retriever.nodes.items():
        repo = n.get("repo", "_unknown")
        fpath = n.get("file") or "_no_file"
        tree.setdefault(repo, {}).setdefault(fpath, []).append({
            "id": nid, "label": n.get("label", ""),
            "layer": n.get("layer", ""), "type": n.get("type", ""),
            "line": n.get("line"), "confidence": n.get("confidence", 0),
            "evidence_method": n.get("evidence_method", ""),
            "properties": n.get("properties", {}),
        })

    # Sort entities within each file by line number
    for repo in tree:
        for fpath in tree[repo]:
            tree[repo][fpath].sort(key=lambda x: x.get("line") or 0)

    # Sort files within each repo by path
    sorted_tree = {}
    for repo in sorted(tree.keys()):
        sorted_tree[repo] = dict(sorted(tree[repo].items()))

    # Cross-file edges: source_file → target_file with relation details
    cross_file = []  # [{source_file, target_file, source_node, target_node, type, confidence}]
    seen_pairs = set()
    for src_id in _retriever.adj:
        src_node = _retriever.nodes.get(src_id, {})
        src_file = src_node.get("file", "")
        src_repo = src_node.get("repo", "")
        if not src_file:
            continue
        for tgt_id in _retriever.adj[src_id]:
            tgt_node = _retriever.nodes.get(tgt_id, {})
            tgt_file = tgt_node.get("file", "")
            if not tgt_file or (src_repo == tgt_node.get("repo", "") and src_file == tgt_file):
                continue
            pair_key = (src_id, tgt_id)
            if pair_key in seen_pairs:
                continue
            seen_pairs.add(pair_key)
            edge = _retriever._edge_map.get((src_id, tgt_id), {})
            cross_file.append({
                "source_repo": src_repo, "source_file": src_file,
                "source_node": src_id, "source_label": src_node.get("label", ""),
                "source_line": src_node.get("line"),
                "target_repo": tgt_node.get("repo", ""), "target_file": tgt_file,
                "target_node": tgt_id, "target_label": tgt_node.get("label", ""),
                "target_line": tgt_node.get("line"),
                "type": edge.get("type", ""), "confidence": edge.get("confidence", 0),
            })

    return jsonify({
        "tree": sorted_tree,
        "cross_file_edges": cross_file,
        "total_nodes": len(_retriever.nodes),
        "total_files": sum(len(files) for files in tree.values()),
        "total_repos": len(tree),
        "total_cross_file": len(cross_file),
    })


@app.route("/ast/all", methods=["GET"])
def ast_all():
    """Return all AST summaries, optionally filtered by repo/language."""
    ast_path = Path(_output_dir) / "ast_summaries.jsonl"
    if not ast_path.exists():
        return jsonify({"summaries": [], "total": 0, "error": "No AST summaries. Run the pipeline first."})

    repo_filter = request.args.get("repo", "")
    lang_filter = request.args.get("language", "")
    limit = int(request.args.get("limit", 500))

    summaries = []
    try:
        with open(ast_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                s = json.loads(line)
                if repo_filter and s.get("repo", "") != repo_filter:
                    continue
                if lang_filter and s.get("language", "") != lang_filter:
                    continue
                summaries.append(s)
                if len(summaries) >= limit:
                    break
    except Exception:
        pass

    return jsonify({"summaries": summaries, "total": len(summaries), "truncated": len(summaries) >= limit})


@app.route("/stats", methods=["GET"])
def stats():
    if not _initialized:
        return jsonify({"index": {}, "graph": {}, "code_reader": {}, "flows": 0, "uploaded_docs": 0, "initialized": False})
    return jsonify({
        "index": _retriever.vi.stats() if _retriever and _retriever.vi else {},
        "graph": {"nodes": len(_retriever.nodes), "edges": sum(len(v) for v in _retriever.adj.values())} if _retriever else {},
        "code_reader": _code_reader.stats() if _code_reader else {},
        "flows": len(_flow_intel),
        "uploaded_docs": _doc_store.count() if _doc_store else 0,
        "initialized": True,
    })


# -- Document upload/management endpoints --------------------------------------

def _index_new_doc(doc_id: str):
    """Embed all chunks of an uploaded doc into the live FAISS index."""
    if not _doc_store or not _retriever:
        return
    doc = _doc_store.get(doc_id)
    if not doc:
        return
    search_docs = _doc_store.build_search_documents()
    new_chunks = [d for d in search_docs if d["metadata"].get("chunk_of") == doc_id
                  or d["doc_id"] == doc_id]
    if not new_chunks:
        return
    try:
        result = _retriever.vi.update_incremental(new_chunks)
        index_dir = str(Path(_output_dir) / "search_index")
        _retriever.vi.save(index_dir)
        print(f"[SearchAPI] Indexed {len(new_chunks)} chunks for {doc_id}: +{result['added']}")
    except Exception as e:
        print(f"[SearchAPI] Failed to index doc {doc_id}: {e}")

@app.route("/docs", methods=["GET"])
def list_docs():
    """List all uploaded supplementary documents."""
    if not _doc_store:
        return jsonify({"documents": [], "total": 0})
    docs = _doc_store.list_all()
    return jsonify({"documents": docs, "total": len(docs)})


@app.route("/docs/upload", methods=["POST"])
def upload_doc():
    """Upload a document file for indexing.
    Accepts multipart/form-data with 'file' field.
    Optional form fields: title, tags (comma-separated), author, description.
    """
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503

    if "file" not in request.files:
        return jsonify({"error": "No file provided. Use multipart/form-data with 'file' field."}), 400

    uploaded = request.files["file"]
    if not uploaded.filename:
        return jsonify({"error": "Empty filename"}), 400

    import tempfile
    tmp_dir = Path(tempfile.mkdtemp())
    tmp_path = tmp_dir / uploaded.filename
    uploaded.save(str(tmp_path))

    tags = [t.strip() for t in request.form.get("tags", "").split(",") if t.strip()]
    title = request.form.get("title", "")
    author = request.form.get("author", "")
    description = request.form.get("description", "")

    doc_id = _doc_store.ingest(
        str(tmp_path),
        tags=tags,
        title=title or None,
        author=author or None,
        description=description or None,
    )

    tmp_path.unlink(missing_ok=True)
    try:
        tmp_dir.rmdir()
    except Exception:
        pass

    if not doc_id:
        return jsonify({"error": f"Unsupported file type: {uploaded.filename}"}), 400

    # Auto-index into vector search
    _index_new_doc(doc_id)

    doc = _doc_store.get(doc_id)
    return jsonify({
        "doc_id": doc_id,
        "file_name": doc.get("file_name", ""),
        "doc_type": doc.get("doc_type", ""),
        "text_length": doc.get("text_length", 0),
        "chunk_count": doc.get("chunk_count", 0),
        "message": "Document ingested and indexed.",
    })


@app.route("/docs/<path:doc_id>", methods=["GET"])
def get_doc(doc_id: str):
    """Get a specific uploaded document with its extracted text and chunks."""
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503
    doc = _doc_store.get(doc_id)
    if not doc:
        return jsonify({"error": f"Document not found: {doc_id}"}), 404
    # Include chunks but exclude full text blob to keep response manageable
    result = {k: v for k, v in doc.items() if k != "text"}
    result["chunks"] = doc.get("chunks", [])
    return jsonify(result)


@app.route("/docs/<path:doc_id>", methods=["DELETE"])
def delete_doc(doc_id: str):
    """Delete an uploaded document and remove from vector index."""
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503
    if _doc_store.delete(doc_id):
        # Rebuild index without the deleted doc
        try:
            all_docs = _doc_store.build_search_documents()
            _retriever.vi.update_incremental(all_docs)
            _retriever.vi.save(str(Path(_output_dir) / "search_index"))
        except Exception:
            pass
        return jsonify({"ok": True, "message": f"Deleted {doc_id}"})
    return jsonify({"error": f"Document not found: {doc_id}"}), 404


@app.route("/docs/ingest-dir", methods=["POST"])
def ingest_directory():
    """Ingest all supported documents from a directory path."""
    if not _doc_store:
        return jsonify({"error": "Document store not initialized"}), 503
    body = request.get_json(force=True)
    dir_path = body.get("path", "")
    tags = body.get("tags", [])
    if not dir_path:
        return jsonify({"error": "Missing 'path' in request body"}), 400
    ingested = _doc_store.ingest_directory(dir_path, tags=tags)
    # Auto-index all new docs
    for did in ingested:
        _index_new_doc(did)
    return jsonify({"ingested": len(ingested), "doc_ids": ingested})


# -- AST file structure endpoint -----------------------------------------------

@app.route("/ast_file/<path:entity_id>", methods=["GET"])
def get_ast_file(entity_id: str):
    """Get ALL AST summaries for the same file as entity_id, sorted by line.
    Returns {target_id, file, repo, methods: [...]} so the UI can render
    the full file structure with the target method highlighted."""
    ast_path = Path(_output_dir) / "ast_summaries.jsonl"
    if not ast_path.exists():
        return jsonify({"error": "AST summaries not available"}), 404

    entity_node = _retriever.nodes.get(entity_id, {}) if _retriever else {}
    entity_repo = entity_node.get("repo", "")
    entity_file = entity_node.get("file", "")
    entity_line = entity_node.get("line", 0)
    # Load all summaries once
    all_summaries = []
    try:
        with open(ast_path, "r", encoding="utf-8") as af:
            for raw in af:
                raw = raw.strip()
                if raw:
                    all_summaries.append(json.loads(raw))
    except Exception:
        pass

    # If not in graph, resolve repo/file from AST summaries or by parsing the ID
    if not entity_repo or not entity_file:
        for s in all_summaries:
            if s.get("entity_id") == entity_id or s.get("discovered_id") == entity_id:
                entity_repo = s.get("repo", "")
                entity_file = s.get("file", "")
                break
    if not entity_repo or not entity_file:
        parts = entity_id.split(":")
        if len(parts) >= 4:
            entity_repo = parts[2]
            entity_file = ":".join(parts[3:]).split("::")[0]
        elif len(parts) >= 2:
            entity_repo = parts[0]
            entity_file = parts[1].split("::")[0] if "::" in parts[1] else parts[1]
    if not entity_file:
        return jsonify({"error": "Cannot resolve file", "entity_id": entity_id}), 404

    file_methods = []
    target_id = None
    for s in all_summaries:
        if s.get("repo") == entity_repo and s.get("file") == entity_file:
            file_methods.append(s)
            sid = s.get("entity_id") or s.get("discovered_id", "")
            if sid == entity_id:
                target_id = sid
            elif not target_id and entity_line and s.get("line_start", 0) <= entity_line <= s.get("line_end", 0):
                target_id = sid

    file_methods.sort(key=lambda m: m.get("line_start", 0))
    return jsonify({"target_id": target_id or entity_id, "file": entity_file, "repo": entity_repo, "total_methods": len(file_methods), "methods": file_methods})



# -- AST summary endpoint ------------------------------------------------------

@app.route("/ast_summary/<path:entity_id>", methods=["GET"])
def get_ast_summary(entity_id: str):
    """Get AST structural summary for an entity.
    Matches by entity_id, discovered_id, or by (repo, file, line) proximity."""
    ast_path = Path(_output_dir) / "ast_summaries.jsonl"
    if not ast_path.exists():
        return jsonify({"error": "AST summaries not available. Run: python -m phase10_ast.run_ast_summaries"}), 404

    # Parse entity_id to extract repo, file, line for fuzzy matching
    entity_node = _retriever.nodes.get(entity_id, {}) if _retriever else {}
    entity_repo = entity_node.get("repo", "")
    entity_file = entity_node.get("file", "")
    entity_line = entity_node.get("line", 0)

    best_match = None
    best_distance = 999

    try:
        with open(ast_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                s = json.loads(line)
                # Exact ID match
                if s.get("entity_id") == entity_id or s.get("discovered_id") == entity_id:
                    return jsonify(s)
                # Proximity match: same repo + same file + close line number
                if entity_repo and entity_file:
                    if s.get("repo") == entity_repo and s.get("file") == entity_file:
                        s_start = s.get("line_start", 0)
                        s_end = s.get("line_end", 0)
                        if entity_line and s_start:
                            # Entity line falls within method range, or within 5 lines
                            if s_start <= entity_line <= s_end:
                                return jsonify(s)
                            dist = min(abs(entity_line - s_start), abs(entity_line - s_end))
                            if dist < best_distance:
                                best_distance = dist
                                best_match = s
    except Exception:
        pass

    if best_match and best_distance <= 10:
        return jsonify(best_match)

    return jsonify({"error": f"No AST summary for {entity_id}"}), 404


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


# ── Pipeline API endpoints (landing page → processing → explorer) ────────────

# ── Workspace for uploaded repos ──────────────────────────────────────────────
_workspace_dir = str(Path(__file__).resolve().parent.parent / "workspace")


@app.route("/api/resolve-local", methods=["POST"])
def resolve_local():
    """Try to find a folder by name on the local machine.
    Searches Downloads, Desktop, Documents, home dir, and common dev paths.
    Returns the full path if found so the UI can skip uploading."""
    body = request.get_json(force=True)
    folder_name = body.get("name", "").strip()
    if not folder_name:
        return jsonify({"path": None})

    import os
    home = Path(os.path.expanduser("~"))
    search_roots = [
        home / "Downloads",
        home / "Desktop",
        home / "Documents",
        home / "Projects",
        home / "repos",
        home / "code",
        home / "dev",
        home,
        Path("C:/repos"),
        Path("C:/projects"),
        Path("C:/dev"),
        Path("D:/repos"),
        Path("D:/projects"),
    ]

    for root in search_roots:
        candidate = root / folder_name
        try:
            if candidate.is_dir():
                return jsonify({"path": str(candidate), "found": True})
        except Exception:
            continue

    return jsonify({"path": None, "found": False})


@app.route("/api/upload-repos", methods=["POST"])
def upload_repos():
    """Accept multipart file upload preserving folder structure.
    Files arrive with webkitRelativePath-style names: repoName/path/to/file.java
    We reconstruct the tree under workspace/."""
    import shutil
    ws = Path(_workspace_dir)
    # Clear previous workspace
    if ws.exists():
        shutil.rmtree(ws, ignore_errors=True)
    ws.mkdir(parents=True, exist_ok=True)

    files = request.files.getlist("files")
    paths = request.form.getlist("paths")  # relative paths sent alongside
    if not files:
        return jsonify({"error": "No files uploaded"}), 400

    root_folders = set()
    saved = 0
    for i, f in enumerate(files):
        rel = paths[i] if i < len(paths) else f.filename
        if not rel:
            continue
        # Normalise separators
        rel = rel.replace("\\", "/")
        # Track root folder name
        parts = rel.split("/")
        if len(parts) > 1:
            root_folders.add(parts[0])
        dest = ws / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        f.save(str(dest))
        saved += 1

    # Determine source roots: each top-level folder in workspace
    if root_folders:
        source_roots = [str(ws / rf) for rf in sorted(root_folders) if (ws / rf).is_dir()]
    else:
        source_roots = [str(ws)]

    return jsonify({
        "saved": saved,
        "source_roots": source_roots,
        "root_folders": sorted(root_folders),
    })


@app.route("/api/pipeline/start", methods=["POST"])
def pipeline_start():
    """Start the MAFIA pipeline on provided source roots."""
    global _output_dir, _initialized, _retriever, _code_reader, _blast_engine, _flow_intel, _chat_engine, _doc_store
    from phase11_search.pipeline_runner import run_pipeline_async, is_running
    if is_running():
        return jsonify({"error": "Pipeline already running"}), 409

    body = request.get_json(force=True)
    source_roots = body.get("source_roots", [])
    if not source_roots:
        return jsonify({"error": "No source_roots provided"}), 400

    missing = [p for p in source_roots if not Path(p).exists()]
    if missing:
        return jsonify({"error": f"Paths not found: {', '.join(missing)}"}), 400

    # Allow the UI to specify a custom output dir for this run (session isolation)
    requested_output = body.get("output_dir", "").strip()
    if requested_output:
        _output_dir = requested_output
        Path(_output_dir).mkdir(parents=True, exist_ok=True)
    # else: use whatever _output_dir is currently set to

    # Reset state so the explorer doesn't show stale data while pipeline runs
    _initialized = False
    _retriever = None
    _code_reader = None
    _blast_engine = None
    _flow_intel = {}
    _chat_engine = None
    _doc_store = None

    enable_genai = body.get("enable_genai", False)
    enable_vector_index = body.get("enable_vector_index", False)
    full = body.get("full", True)
    run_pipeline_async(source_roots, _output_dir, enable_genai=enable_genai,
                       full=full, enable_vector_index=enable_vector_index)
    return jsonify({"status": "started", "source_roots": source_roots, "output_dir": _output_dir, "mode": "full" if full else "incremental"})


@app.route("/api/pipeline/status", methods=["GET"])
def pipeline_status():
    """Get current pipeline progress."""
    from phase11_search.pipeline_runner import get_progress
    progress = get_progress()
    snap = progress.snapshot()

    # If pipeline just completed and we haven't initialized the explorer yet, do it
    if snap["status"] == "complete" and not _initialized:
        try:
            # Auto-register this run as a session so it appears in the drawer
            _register_session(_output_dir)
            _init(_output_dir)
        except Exception as e:
            print(f"[SearchAPI] Post-pipeline init failed: {e}")

    return jsonify(snap)


@app.route("/api/pipeline/debug", methods=["GET"])
def pipeline_debug():
    """Return full pipeline state including all events and thread status."""
    from phase11_search.pipeline_runner import get_progress, get_thread
    progress = get_progress()
    snap = progress.snapshot()
    t = get_thread()
    snap["thread_alive"] = t.is_alive() if t else False
    snap["events"] = list(progress.events)  # full event list, not capped at 50
    return jsonify(snap)


@app.route("/api/pipeline/has-data", methods=["GET"])
def pipeline_has_data():
    """Check if output data exists (for skip-to-explorer logic)."""
    output = Path(_output_dir)
    has_graph = (output / "system_graph.json").exists()
    has_entities = (output / "entities.jsonl").exists()
    has_index = (output / "search_index" / "metadata.json").exists()
    return jsonify({
        "has_data": has_graph and has_entities,
        "has_index": has_index,
        "initialized": _initialized,
    })


@app.route("/api/pipeline/rerun", methods=["POST"])
def pipeline_rerun():
    """Re-run the pipeline on the active session's existing source roots.
    Body: {full: bool (default false = incremental), enable_genai: bool, enable_vector_index: bool}
    Reads source_roots from the session's repo_manifest.json."""
    global _initialized, _retriever, _code_reader, _blast_engine, _flow_intel, _chat_engine, _doc_store
    from phase11_search.pipeline_runner import run_pipeline_async, is_running
    if is_running():
        return jsonify({"error": "Pipeline already running"}), 409

    manifest_path = Path(_output_dir) / "repo_manifest.json"
    if not manifest_path.exists():
        return jsonify({"error": "No repo_manifest.json in active session — run a full scan first"}), 400

    try:
        import json as _j
        manifest = _j.loads(manifest_path.read_text(encoding="utf-8"))
    except Exception as e:
        return jsonify({"error": f"Failed to read manifest: {e}"}), 500

    source_roots = list({r.get("source_root", "") or str(Path(r["root_path"]).parent)
                         for r in manifest.get("repos", []) if r.get("root_path")})
    if not source_roots:
        return jsonify({"error": "No source roots found in manifest"}), 400

    body = request.get_json(force=True) if request.data else {}
    full = body.get("full", False)
    enable_genai = body.get("enable_genai", False)
    enable_vector_index = body.get("enable_vector_index", False)

    _initialized = False
    _retriever = None
    _code_reader = None
    _blast_engine = None
    _flow_intel = {}
    _chat_engine = None
    _doc_store = None

    run_pipeline_async(source_roots, _output_dir, enable_genai=enable_genai,
                       full=full, enable_vector_index=enable_vector_index)
    mode = "full" if full else "incremental"
    return jsonify({"status": "started", "mode": mode, "source_roots": source_roots, "output_dir": _output_dir})


@app.route("/api/sessions/add-sources", methods=["POST"])
def add_sources_to_session():
    """Add new source paths to the active session's manifest and re-run.
    Body: {source_roots: [str], run: bool (default true)}"""
    global _initialized, _retriever, _code_reader, _blast_engine, _flow_intel, _chat_engine, _doc_store
    body = request.get_json(force=True)
    new_roots = body.get("source_roots", [])
    if not new_roots:
        return jsonify({"error": "No source_roots provided"}), 400

    missing = [p for p in new_roots if not Path(p).exists()]
    if missing:
        return jsonify({"error": f"Paths not found: {', '.join(missing)}"}), 400

    # Merge with existing source roots from manifest
    manifest_path = Path(_output_dir) / "repo_manifest.json"
    existing_roots = set()
    if manifest_path.exists():
        try:
            import json as _j
            manifest = _j.loads(manifest_path.read_text(encoding="utf-8"))
            for r in manifest.get("repos", []):
                sr = r.get("source_root", "") or str(Path(r["root_path"]).parent)
                if sr:
                    existing_roots.add(sr)
        except Exception:
            pass

    all_roots = list(existing_roots | set(new_roots))
    added = [r for r in new_roots if r not in existing_roots]

    should_run = body.get("run", True)
    if should_run:
        from phase11_search.pipeline_runner import run_pipeline_async, is_running
        if is_running():
            return jsonify({"error": "Pipeline already running"}), 409

        _initialized = False
        _retriever = None
        _code_reader = None
        _blast_engine = None
        _flow_intel = {}
        _chat_engine = None
        _doc_store = None

        enable_genai = body.get("enable_genai", False)
        enable_vector_index = body.get("enable_vector_index", False)
        run_pipeline_async(all_roots, _output_dir, enable_genai=enable_genai,
                           full=False, enable_vector_index=enable_vector_index)

    return jsonify({"ok": True, "added": added, "total_roots": len(all_roots),
                    "running": should_run, "output_dir": _output_dir})


@app.route("/api/sessions/versions", methods=["GET"])
def session_versions():
    """Return version history for the active session."""
    from phase14_orchestration.artifact_versioning import ArtifactVersioner
    path = request.args.get("path", _output_dir)
    av = ArtifactVersioner(path)
    history = av.get_history()
    diff = av.diff() if len(history) >= 2 else {}
    return jsonify({"versions": history, "latest_diff": diff, "path": path})


# ── Session management ────────────────────────────────────────────────────────

import os as _os
import json as _json
from pathlib import Path as _Path
from datetime import datetime as _dt

_SESSIONS_REGISTRY = str(_Path(__file__).resolve().parent.parent / "output" / ".sessions.json")


def _sessions_registry_path() -> str:
    """Registry always lives next to the server's base output dir, not the active session."""
    return str(_Path(__file__).resolve().parent.parent / "output" / ".sessions.json")


def _load_sessions_registry() -> dict:
    try:
        with open(_sessions_registry_path(), "r", encoding="utf-8") as f:
            return _json.load(f)
    except Exception:
        return {"active": None, "sessions": []}


def _save_sessions_registry(reg: dict):
    p = _sessions_registry_path()
    _Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        _json.dump(reg, f, indent=2)


def _register_session(path: str, name: str = "") -> None:
    """Upsert a session entry and mark it active. Safe to call from any thread."""
    reg = _load_sessions_registry()
    now = _dt.utcnow().isoformat()
    existing = next((s for s in reg.get("sessions", []) if s["path"] == path), None)
    if existing:
        existing["last_used"] = now
        if name:
            existing["name"] = name
    else:
        reg.setdefault("sessions", []).append({
            "name": name or _Path(path).name,
            "path": path,
            "created_at": now,
            "last_used": now,
        })
    reg["active"] = path
    _save_sessions_registry(reg)


@app.route("/api/sessions", methods=["GET"])
def list_sessions():
    reg = _load_sessions_registry()
    sessions = []
    for s in reg.get("sessions", []):
        path = s.get("path", "")
        has_data = (_Path(path) / "system_graph.json").exists() if path else False
        manifest = {}
        if has_data:
            try:
                with open(_Path(path) / "repo_manifest.json", "r", encoding="utf-8") as f:
                    manifest = _json.load(f)
            except Exception:
                pass
        sessions.append({
            "name": s.get("name", ""),
            "path": path,
            "created_at": s.get("created_at", ""),
            "last_used": s.get("last_used", ""),
            "has_data": has_data,
            "is_active": path == reg.get("active"),
            "repos": [r.get("repo_id", "") for r in manifest.get("repos", [])[:5]],
        })
    return jsonify({"sessions": sessions, "active": reg.get("active")})


@app.route("/api/sessions/active", methods=["GET"])
def get_active_session():
    reg = _load_sessions_registry()
    active = reg.get("active") or _output_dir
    return jsonify({"path": active, "initialized": _initialized})


import threading as _threading
_init_lock = _threading.Lock()
_init_status = {"state": "idle", "message": ""}  # idle | loading | ready | error


def _init_async(path: str):
    """Run _init in a background thread, updating _init_status."""
    global _init_status
    with _init_lock:
        _init_status = {"state": "loading", "message": "Loading search index..."}
    try:
        _init(path)
        # _initialized is now True after fast path
        with _init_lock:
            _init_status = {"state": "ready", "message": "Ready"}
    except Exception as e:
        with _init_lock:
            _init_status = {"state": "error", "message": str(e)}


@app.route("/api/init/status", methods=["GET"])
def init_status():
    """Poll this to know when _init() has finished loading."""
    with _init_lock:
        s = dict(_init_status)
    s["initialized"] = _initialized
    return jsonify(s)


@app.route("/api/ai/status", methods=["GET"])
def ai_status():
    """Return whether AI chat is available and what capabilities it has."""
    available = _chat_engine is not None
    return jsonify({
        "available": available,
        "capabilities": [
            {"icon": "🔍", "name": "Semantic Search", "desc": "Ask natural-language questions about endpoints, functions, tables, and flows"},
            {"icon": "🔧", "name": "Code Mode", "desc": "Toggle Code Mode to let the AI read source files and suggest fixes"},
            {"icon": "🔬", "name": "AST Mode", "desc": "Toggle AST Mode to include method signatures, call graphs, and exception paths"},
            {"icon": "💥", "name": "Blast Radius", "desc": "Ask 'what breaks if X changes?' for AI-narrated impact analysis"},
            {"icon": "🔗", "name": "Flow Tracing", "desc": "Trace end-to-end flows across UI → BFF → API → DB layers"},
            {"icon": "🐛", "name": "Issue Diagnosis", "desc": "Paste an error or symptom and get graph-grounded root cause analysis"},
        ],
        "setup_contact": {
            "name": "Manu M L",
            "role": "Package Owner",
            "message": "AI features require Google Cloud credentials (Gemini). Contact Manu M L, package owner, to get set up.",
        },
    })


@app.route("/api/sessions/set", methods=["POST"])
def set_active_session():
    global _output_dir, _initialized, _retriever, _code_reader, _blast_engine, _flow_intel, _chat_engine, _doc_store
    body = request.get_json(force=True)
    path = body.get("path", "").strip()
    name = body.get("name", "").strip()
    if not path:
        return jsonify({"error": "Missing path"}), 400

    _Path(path).mkdir(parents=True, exist_ok=True)

    _register_session(path, name)

    _output_dir = path
    _initialized = False
    _retriever = None
    _code_reader = None
    _blast_engine = None
    _flow_intel = {}
    _chat_engine = None
    _doc_store = None

    has_data = (_Path(path) / "system_graph.json").exists()
    if has_data:
        # Start loading in background — respond immediately so UI can show loading screen
        t = _threading.Thread(target=_init_async, args=(path,), daemon=True)
        t.start()
        return jsonify({"ok": True, "path": path, "loading": True})

    return jsonify({"ok": True, "path": path, "loaded": False})


@app.route("/api/sessions/new", methods=["POST"])
def new_session():
    """Create a new session folder under output/ and register it.
    Body: {name: str}  — name becomes the folder name (sanitized).
    Returns: {path, name}"""
    body = request.get_json(force=True) if request.data else {}
    raw_name = body.get("name", "").strip()

    # Sanitize: keep alphanumeric, dash, underscore, dot
    import re as _re
    safe = _re.sub(r'[^\w\-.]', '_', raw_name) if raw_name else ""
    # Append timestamp so two runs of the same project never collide
    ts = _dt.utcnow().strftime("%Y%m%d_%H%M%S")
    folder_name = f"{safe}_{ts}" if safe else ts

    base_output = _Path(__file__).resolve().parent.parent / "output"
    session_path = str(base_output / folder_name)
    _Path(session_path).mkdir(parents=True, exist_ok=True)

    _register_session(session_path, name=raw_name or folder_name)
    return jsonify({"path": session_path, "name": raw_name or folder_name})


@app.route("/api/sessions/delete", methods=["POST"])
def delete_session():
    body = request.get_json(force=True)
    path = body.get("path", "")
    reg = _load_sessions_registry()
    reg["sessions"] = [s for s in reg.get("sessions", []) if s["path"] != path]
    if reg.get("active") == path:
        reg["active"] = reg["sessions"][0]["path"] if reg["sessions"] else None
    _save_sessions_registry(reg)
    return jsonify({"ok": True})


@app.route("/api/sessions/suggest", methods=["GET"])
def suggest_session_paths():
    """Return candidate output directories that look like valid MAFIA sessions.
    Searches the default output dir, all known session paths, and subdirectories
    of any partial path the user has typed."""
    q = request.args.get("q", "").strip()
    _MARKERS = ("system_graph.json", "entities.jsonl", "run_state.json")

    def _is_mafia_dir(p: _Path) -> bool:
        return any((p / m).exists() for m in _MARKERS)

    candidates = set()

    # 1) Built-in default output dir
    default_out = _Path(__file__).resolve().parent.parent / "output"
    candidates.add(str(default_out))

    # 2) All previously registered session paths
    reg = _load_sessions_registry()
    for s in reg.get("sessions", []):
        candidates.add(s["path"])

    # 3) If user has typed something, scan its parent for sibling dirs
    if q:
        q_path = _Path(q)
        scan_dir = q_path if q_path.is_dir() else q_path.parent
        try:
            if scan_dir.is_dir():
                for child in scan_dir.iterdir():
                    if child.is_dir():
                        candidates.add(str(child))
        except PermissionError:
            pass

    results = []
    seen = set()
    for c in candidates:
        c_norm = str(_Path(c))
        if c_norm in seen:
            continue
        seen.add(c_norm)
        p = _Path(c)
        if not p.exists():
            continue
        if q and q.lower() not in c_norm.lower():
            continue
        results.append({"path": c_norm, "has_data": _is_mafia_dir(p), "name": p.name})

    results.sort(key=lambda x: (not x["has_data"], x["path"].lower()))
    return jsonify({"suggestions": results[:12]})


if __name__ == "__main__":
    import argparse as _ap
    _parser = _ap.ArgumentParser(description="MAFIA Search API + Landing")
    _parser.add_argument("--port", type=int, default=5001)
    _parser.add_argument("--skip-init", action="store_true",
                         help="Start server without loading data (for fresh installs)")
    _args = _parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    output_dir = str(base / "output")
    # Also check .mafia/output (created by `mafia init`)
    mafia_output = str(base / ".mafia" / "output")
    if not (Path(output_dir) / "system_graph.json").exists() and (Path(mafia_output) / "system_graph.json").exists():
        output_dir = mafia_output
    _output_dir = output_dir
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    # Try to init if data exists, otherwise start in landing-only mode
    has_data = (Path(output_dir) / "system_graph.json").exists()
    if has_data and not _args.skip_init:
        try:
            _init(output_dir)
        except Exception as e:
            print(f"[SearchAPI] Init failed (landing mode): {e}")
    else:
        print("[SearchAPI] No existing data — starting in landing mode")
        print("[SearchAPI] Upload repos via the landing page to begin analysis")

    print(f"\n[SearchAPI] Starting on http://localhost:{_args.port}")
    app.run(host="0.0.0.0", port=_args.port, debug=False)
