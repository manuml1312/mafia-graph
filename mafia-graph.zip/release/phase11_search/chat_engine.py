"""
MAFIA Phase 11 — Chat Engine (Hybrid RAG + Code-Grounded Assistant)
=====================================================================
Orchestrates: retrieval → (optional) code reading → Gemini prompt → provenance validation.

Two modes controlled by toggle:
  OFF (rag): Answers from graph + flow intelligence + vector search only
  ON  (code_grounded): Also reads actual source files for retrieved entities

Maintains conversation history and working set via BigQuery store.

Usage:
    engine = ChatEngine(output_dir)
    response = engine.chat(conv_id, "What calls flagTypes?", code_mode=False)
"""

import os
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase11_search.graph_retriever import GraphRetriever
from phase11_search.vector_index import VectorIndex
from phase11_search.code_reader import CodeReader
from phase11_search.bigquery_store import ConversationStore

# ── Gemini config (from centralized ai_config) ────────────────────────────────────

try:
    from utils.ai_config import get_ai_config as _get_ai_cfg
    _ai = _get_ai_cfg()
except Exception:
    _ai = None

SA_KEY_PATH = _ai.sa_key_path if _ai else ""
CERT_FILE_PATH = _ai.cert_file if _ai else ""
GCP_PROJECT = _ai.gcp_project if _ai else ""
GCP_LOCATION = _ai.gcp_location if _ai else "us-central1"
GEMINI_MODEL = _ai.gemini_model if _ai else "gemini-2.5-flash"

# ── Gemini client ────────────────────────────────────────────────────────────

class _GeminiChat:
    def __init__(self):
        from google.oauth2 import service_account
        from google.auth.transport.requests import AuthorizedSession
        if os.path.exists(CERT_FILE_PATH):
            os.environ['REQUESTS_CA_BUNDLE'] = CERT_FILE_PATH
        self.creds = service_account.Credentials.from_service_account_file(
            SA_KEY_PATH, scopes=["https://www.googleapis.com/auth/cloud-platform"])
        self.session = AuthorizedSession(self.creds)
        if os.path.exists(CERT_FILE_PATH):
            self.session.verify = CERT_FILE_PATH
        self.url = (
            f"https://{GCP_LOCATION}-aiplatform.googleapis.com/v1/"
            f"projects/{GCP_PROJECT}/locations/{GCP_LOCATION}/"
            f"publishers/google/models/{GEMINI_MODEL}:generateContent"
        )

    def generate(self, messages: list[dict], temperature: float = 0.2) -> str:
        contents = []
        for m in messages:
            contents.append({"role": m["role"], "parts": [{"text": m["text"]}]})
        payload = {
            "contents": contents,
            "generationConfig": {"temperature": temperature, "maxOutputTokens": 4096},
        }
        for attempt in range(3):
            try:
                resp = self.session.post(self.url, json=payload, timeout=120)
                if resp.status_code == 429:
                    time.sleep(min(30, 2 ** attempt))
                    continue
                resp.raise_for_status()
                parts = resp.json()["candidates"][0]["content"]["parts"]
                return parts[0]["text"].strip()
            except Exception as e:
                if attempt == 2:
                    return f"[Gemini error: {e}]"
                time.sleep(2)
        return "[Gemini error: max retries]"

_gemini = None
def _get_gemini():
    global _gemini
    if _gemini is None:
        _gemini = _GeminiChat()
    return _gemini


# ── System prompt ────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are a code intelligence assistant. You have no name — you are a servant to your boss.
You help your boss understand, debug, and navigate any multi-layer codebase (UI → BFF → API → DB).

Rules:
1. Always address the user as "Boss" with respect.
2. Every statement must be labeled with provenance: [OBSERVED], [DERIVED], [INFERRED], or [UNKNOWN]
3. [OBSERVED] = directly from code evidence or extracted entities
4. [DERIVED] = computed from the dependency graph or flow chains
5. [INFERRED] = your interpretation — always mark clearly
6. [UNKNOWN] = you don't have evidence — say so, never invent
7. NEVER invent file paths, function names, table names, or API endpoints not in the context
8. When code context is provided, reference specific files and line numbers
9. When suggesting fixes, show the exact file and what to change
10. Be concise and direct. Your boss wants answers, not essays.
11. If the question is about a specific component, start with what it does (OBSERVED), then where it's used (DERIVED), then why (INFERRED)."""


# ── Chat Engine ──────────────────────────────────────────────────────────────

class ChatEngine:
    """Hybrid RAG chat engine with toggle-controlled code reading."""

    def __init__(self, output_dir: str,
                 retriever: Optional[GraphRetriever] = None,
                 code_reader: Optional[CodeReader] = None,
                 flow_intel: Optional[dict] = None):
        self.output_dir = output_dir
        output = Path(output_dir)

        # Use pre-loaded components if provided (avoids double-loading)
        if retriever is not None:
            self.retriever = retriever
        else:
            vi = None
            index_dir = output / "search_index"
            if (index_dir / "faiss.index").exists():
                try:
                    vi = VectorIndex.load(str(index_dir))
                except Exception as e:
                    print(f"[ChatEngine] Vector index load failed: {e}")
            self.retriever = GraphRetriever(vi, str(output / "system_graph.json"))

        if code_reader is not None:
            self.code_reader = code_reader
        else:
            self.code_reader = CodeReader(output_dir)

        if flow_intel is not None:
            self.flow_intel = flow_intel
        else:
            fi = _load_json(output / "flow_intelligence.json")
            self.flow_intel = {f["flow_id"]: f for f in fi.get("flows", [])}

        self.store = ConversationStore(output_dir)

        # Guardrail sets derived from the retriever
        self.known_node_ids = set(self.retriever.nodes.keys())
        self.known_files = {n.get("file", "") for n in self.retriever.nodes.values() if n.get("file")}

        print(f"[ChatEngine] Ready. {len(self.known_node_ids)} nodes, {len(self.flow_intel)} flows")

    # ── Main chat method ─────────────────────────────────────────────────

    def chat(self, conv_id: str, user_message: str, code_mode: bool = False) -> dict:
        """
        Process a user message and return an assistant response.

        Args:
            conv_id: conversation ID (creates new if doesn't exist)
            user_message: the user's question
            code_mode: if True, read source code for retrieved entities

        Returns:
            dict with: response, sources, code_snippets, provenance, warnings
        """
        start_time = time.time()

        # Ensure conversation exists
        if not self.store.get_conversation(conv_id):
            self.store.create_conversation()
            conv_id = list(self.store._memory["conversations"].keys())[-1]

        # Store user message
        self.store.add_message(conv_id, "user", user_message)

        # Step 1: Retrieve relevant context
        retrieval = self.retriever.retrieve(user_message, top_k=10, expand_depth=1)
        node_results = retrieval.get("node_results", [])[:8]
        flow_results = retrieval.get("flow_results", [])[:3]

        # Log retrieval
        self.store.log_retrieval(
            conv_id, user_message,
            [r["doc_id"] for r in node_results],
            [r["doc_id"] for r in flow_results],
            retrieval.get("graph_expanded", 0),
            [r.get("final_score", 0) for r in node_results],
        )

        # Update working set with retrieved nodes
        self.store.update_working_set(
            conv_id,
            node_ids=[r["metadata"].get("node_id", "") for r in node_results if r["metadata"].get("node_id")],
            flow_ids=[r["metadata"].get("flow_id", "") for r in flow_results if r["metadata"].get("flow_id")],
            toggle_code=code_mode,
        )

        # Step 2: Build context
        context_parts = []
        sources = []

        # Node context
        for r in node_results:
            context_parts.append(f"[Component] {r['text'][:400]}")
            sources.append({"type": "component", "id": r["doc_id"],
                           "confidence": r["metadata"].get("confidence", 0)})

        # Flow context
        for r in flow_results:
            fid = r["metadata"].get("flow_id", "")
            flow = self.flow_intel.get(fid, {})
            if flow:
                narration = "\n".join(
                    f"  Step {h['step']}: [{h['layer']}] {h['description'][:100]}"
                    for h in flow.get("hop_narration", [])[:8]
                )
                context_parts.append(f"[Flow] {flow.get('surface_summary','')}\n{narration}")
                sources.append({"type": "flow", "id": fid,
                               "confidence": flow.get("confidence_range", {}).get("avg", 0)})

        # Step 3: Code reading (toggle ON only)
        code_snippets = []
        if code_mode:
            code_snippets = self._read_code_for_context(conv_id, node_results[:5])
            for cs in code_snippets:
                context_parts.append(
                    f"[Code] {cs['repo']}/{cs['file']}:{cs.get('entity_line','?')}\n"
                    f"```\n{cs['code'][:1500]}\n```"
                )

        # Step 4: Build conversation for Gemini with token-budget context (#8)
        history = self.store.get_messages(conv_id, limit=50)  # fetch more, trim by tokens
        gemini_messages = [{"role": "user", "text": SYSTEM_PROMPT}]

        # Fill history newest-to-oldest within a token budget
        TOKEN_BUDGET = 6000  # ~24k chars; leaves room for context + response
        used = len(SYSTEM_PROMPT) // 4
        history_to_include = []
        for msg in reversed(history[:-1]):  # exclude current message, newest first
            tokens = len(msg["text"]) // 4
            if used + tokens > TOKEN_BUDGET:
                break
            history_to_include.append(msg)
            used += tokens
        for msg in reversed(history_to_include):  # restore chronological order
            role = "user" if msg["role"] == "user" else "model"
            gemini_messages.append({"role": role, "text": msg["text"]})

        # Current turn with context
        context_block = "\n\n".join(context_parts)
        current_prompt = f"""Context from the system graph and evidence:
{context_block}

User question: {user_message}

Answer the question using ONLY the context above. Label every statement with [OBSERVED], [DERIVED], [INFERRED], or [UNKNOWN].
{"You have access to source code — reference specific files and lines when suggesting fixes." if code_mode else ""}"""

        gemini_messages.append({"role": "user", "text": current_prompt})

        # Step 5: Generate response
        gemini = _get_gemini()
        response_text = gemini.generate(gemini_messages)

        latency_ms = int((time.time() - start_time) * 1000)

        # Step 6: Validate guardrails
        warnings = self._check_guardrails(response_text)

        # Store assistant message with structured metadata for reload
        msg_metadata = {
            "sources": sources,
            "code_snippets": [{"repo": cs["repo"], "file": cs["file"],
                               "line": cs.get("entity_line")} for cs in code_snippets],
            "retrieval_stats": {
                "nodes_retrieved": len(node_results),
                "flows_retrieved": len(flow_results),
                "graph_expanded": retrieval.get("graph_expanded", 0),
                "code_files_read": len(code_snippets),
            },
            "warnings": warnings,
            "latency_ms": latency_ms,
        }
        self.store.add_message(conv_id, "assistant", response_text,
                               latency_ms=latency_ms, metadata=msg_metadata)

        return {
            "conversation_id": conv_id,
            "response": response_text,
            "sources": sources,
            "retrieved_context": [{"id": s["id"], "type": s["type"],
                                   "confidence": s.get("confidence", 0),
                                   "text": cp[:200]} for s, cp in zip(sources, context_parts[:len(sources)])],
            "code_snippets": [{"repo": cs["repo"], "file": cs["file"],
                               "line": cs.get("entity_line")} for cs in code_snippets],
            "code_mode": code_mode,
            "latency_ms": latency_ms,
            "warnings": warnings,
            "retrieval_stats": {
                "nodes_retrieved": len(node_results),
                "flows_retrieved": len(flow_results),
                "graph_expanded": retrieval.get("graph_expanded", 0),
                "code_files_read": len(code_snippets),
            },
        }

    # ── Code reading (bounded) ───────────────────────────────────────────

    def _read_code_for_context(self, conv_id: str, node_results: list,
                                max_files: int = 5) -> list:
        snippets = []
        seen_files = set()
        for r in node_results:
            nid = r["metadata"].get("node_id", "")
            if not nid:
                continue
            code = self.code_reader.read_entity_code(nid, context_lines=20)
            if not code or code.get("error"):
                continue
            file_key = f"{code['repo']}::{code['file']}"
            if file_key in seen_files:
                continue
            seen_files.add(file_key)
            snippets.append(code)

            if len(snippets) >= max_files:
                break
        return snippets

    # ── Guardrails ───────────────────────────────────────────────────────

    def _check_guardrails(self, response_text: str) -> list:
        warnings = []
        # Check for file paths not in known files
        import re
        paths = re.findall(r'(?:src/|app/|pages/|components/)[\w/.-]+\.\w+', response_text)
        for p in paths:
            if p not in self.known_files and not any(p in f for f in self.known_files):
                warnings.append(f"Potentially invented file path: {p}")

        # Check for provenance labels
        has_labels = any(tag in response_text for tag in ["[OBSERVED]", "[DERIVED]", "[INFERRED]", "[UNKNOWN]"])
        if not has_labels and len(response_text) > 100:
            warnings.append("Response missing provenance labels")

        return warnings

    # ── Convenience methods ──────────────────────────────────────────────

    def get_conversation_history(self, conv_id: str) -> dict:
        conv = self.store.get_conversation(conv_id)
        msgs = self.store.get_messages(conv_id)
        ws = self.store.get_working_set(conv_id)
        code_refs = self.store.get_code_refs(conv_id)
        return {
            "conversation": conv,
            "messages": msgs,
            "working_set": ws,
            "code_refs": code_refs,
        }

    def list_conversations(self) -> list:
        return self.store.list_conversations()

    def create_conversation(self, title: str = "") -> str:
        return self.store.create_conversation(title=title)


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}
