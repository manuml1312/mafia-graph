"""
MAFIA Phase 11 -- Document Content Extractor
================================================
Extracts text from uploaded documents for vector indexing.
Supports: PDF, DOCX, XLSX, images (via description), Markdown, plain text.

Each extractor degrades gracefully if its library is not installed.

Usage:
    from phase11_search.ingestion.doc_extractor import extract_document
    result = extract_document("/path/to/design.pdf")
    # result = {"text": "...", "doc_type": "pdf", "pages": 12, ...}
"""

import os
import re
from pathlib import Path
from typing import Optional


# -- Supported extensions ------------------------------------------------------

DOC_EXTENSIONS = {".md", ".txt", ".rst"}
PDF_EXTENSIONS = {".pdf"}
OFFICE_EXTENSIONS = {".docx", ".xlsx"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"}

ALL_DOC_EXTENSIONS = DOC_EXTENSIONS | PDF_EXTENSIONS | OFFICE_EXTENSIONS | IMAGE_EXTENSIONS


def is_supported(file_path: str) -> bool:
    """Check if this file type can be ingested."""
    return Path(file_path).suffix.lower() in ALL_DOC_EXTENSIONS


def extract_document(file_path: str) -> Optional[dict]:
    """Extract text content from a document file.
    Returns {text, doc_type, metadata} or None if unsupported/failed."""
    ext = Path(file_path).suffix.lower()
    name = Path(file_path).name

    if ext in DOC_EXTENSIONS:
        return _extract_text(file_path, ext)
    elif ext in PDF_EXTENSIONS:
        return _extract_pdf(file_path)
    elif ext == ".docx":
        return _extract_docx(file_path)
    elif ext == ".xlsx":
        return _extract_xlsx(file_path)
    elif ext in IMAGE_EXTENSIONS:
        return _extract_image(file_path)
    return None


# -- Plain text / Markdown -----------------------------------------------------

def _extract_text(file_path: str, ext: str) -> Optional[dict]:
    try:
        text = Path(file_path).read_text(encoding="utf-8", errors="ignore")
        doc_type = "markdown" if ext == ".md" else "text"
        return {
            "text": text,
            "doc_type": doc_type,
            "metadata": {
                "file_name": Path(file_path).name,
                "char_count": len(text),
                "word_count": len(text.split()),
            },
        }
    except Exception:
        return None


# -- PDF -----------------------------------------------------------------------

def _extract_pdf(file_path: str) -> Optional[dict]:
    try:
        from pypdf import PdfReader
    except ImportError:
        return {
            "text": "",
            "doc_type": "pdf",
            "metadata": {
                "file_name": Path(file_path).name,
                "error": "pypdf not installed. Run: pip install pypdf",
            },
        }
    try:
        reader = PdfReader(file_path)
        pages = []
        for page in reader.pages:
            text = page.extract_text()
            if text:
                pages.append(text)
        full_text = "\n\n".join(pages)
        return {
            "text": full_text,
            "doc_type": "pdf",
            "metadata": {
                "file_name": Path(file_path).name,
                "page_count": len(reader.pages),
                "char_count": len(full_text),
                "word_count": len(full_text.split()),
            },
        }
    except Exception as e:
        return {
            "text": "",
            "doc_type": "pdf",
            "metadata": {"file_name": Path(file_path).name, "error": str(e)},
        }


# -- DOCX ----------------------------------------------------------------------

def _extract_docx(file_path: str) -> Optional[dict]:
    try:
        from docx import Document
    except ImportError:
        return {
            "text": "",
            "doc_type": "docx",
            "metadata": {
                "file_name": Path(file_path).name,
                "error": "python-docx not installed. Run: pip install python-docx",
            },
        }
    try:
        doc = Document(file_path)
        lines = []
        for para in doc.paragraphs:
            style = para.style.name if para.style else ""
            text = para.text.strip()
            if not text:
                continue
            if style.startswith("Heading 1"):
                lines.append(f"# {text}")
            elif style.startswith("Heading 2"):
                lines.append(f"## {text}")
            elif style.startswith("Heading 3"):
                lines.append(f"### {text}")
            else:
                lines.append(text)
        # Tables
        for table in doc.tables:
            rows = [[cell.text.strip() for cell in row.cells] for row in table.rows]
            if rows:
                lines.append("| " + " | ".join(rows[0]) + " |")
                lines.append("| " + " | ".join("---" for _ in rows[0]) + " |")
                for row in rows[1:]:
                    lines.append("| " + " | ".join(row) + " |")
        full_text = "\n".join(lines)
        return {
            "text": full_text,
            "doc_type": "docx",
            "metadata": {
                "file_name": Path(file_path).name,
                "paragraph_count": len(doc.paragraphs),
                "table_count": len(doc.tables),
                "char_count": len(full_text),
                "word_count": len(full_text.split()),
            },
        }
    except Exception as e:
        return {
            "text": "",
            "doc_type": "docx",
            "metadata": {"file_name": Path(file_path).name, "error": str(e)},
        }


# -- XLSX ----------------------------------------------------------------------

def _extract_xlsx(file_path: str) -> Optional[dict]:
    try:
        import openpyxl
    except ImportError:
        return {
            "text": "",
            "doc_type": "xlsx",
            "metadata": {
                "file_name": Path(file_path).name,
                "error": "openpyxl not installed. Run: pip install openpyxl",
            },
        }
    try:
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        sections = []
        total_rows = 0
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                if all(cell is None for cell in row):
                    continue
                rows.append([str(cell) if cell is not None else "" for cell in row])
            if not rows:
                continue
            total_rows += len(rows)
            sections.append(f"## Sheet: {sheet_name}")
            if rows:
                sections.append("| " + " | ".join(rows[0]) + " |")
                sections.append("| " + " | ".join("---" for _ in rows[0]) + " |")
                for row in rows[1:]:
                    sections.append("| " + " | ".join(row) + " |")
        wb.close()
        full_text = "\n".join(sections)
        return {
            "text": full_text,
            "doc_type": "xlsx",
            "metadata": {
                "file_name": Path(file_path).name,
                "sheet_count": len(wb.sheetnames) if hasattr(wb, 'sheetnames') else 0,
                "total_rows": total_rows,
                "char_count": len(full_text),
            },
        }
    except Exception as e:
        return {
            "text": "",
            "doc_type": "xlsx",
            "metadata": {"file_name": Path(file_path).name, "error": str(e)},
        }


# -- Images --------------------------------------------------------------------

def _extract_image(file_path: str) -> Optional[dict]:
    """For images, we store metadata and a placeholder description.
    Actual vision-based extraction would require an LLM call (optional).
    """
    name = Path(file_path).name
    ext = Path(file_path).suffix.lower()
    try:
        size = os.path.getsize(file_path)
    except OSError:
        size = 0

    # Basic description from filename
    stem = Path(file_path).stem.replace("-", " ").replace("_", " ")
    text = f"Image: {name}. {stem}."

    return {
        "text": text,
        "doc_type": "image",
        "metadata": {
            "file_name": name,
            "format": ext.lstrip("."),
            "size_bytes": size,
            "note": "Image content not extracted. Upload to AI chat for vision analysis.",
        },
    }
