"""
MAFIA Phase 11 -- Document Store
====================================
Manages uploaded supplementary documents (design docs, runbooks, PDFs,
architecture diagrams). Stores extracted text + metadata in a JSONL file
and produces search documents for vector indexing.

Documents are stored in output/uploaded_docs/ with metadata in
output/doc_store.jsonl.

Usage:
    from phase11_search.ingestion.doc_store import DocumentStore
    store = DocumentStore("output")
    doc_id = store.ingest("/path/to/design.pdf", tags=["architecture"])
    docs = store.build_search_documents()  # for vector indexing
"""

import json
import hashlib
import shutil
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

from phase11_search.ingestion.doc_extractor import extract_document, is_supported


class DocumentStore:
    """Manages uploaded supplementary documents with chunk-based indexing."""

    CHUNK_SIZE = 1500       # chars per chunk (~375 tokens)
    CHUNK_OVERLAP = 200     # overlap between chunks for context continuity

    def __init__(self, output_dir: str):
        self._output = Path(output_dir)
        self._store_dir = self._output / "uploaded_docs"
        self._store_dir.mkdir(parents=True, exist_ok=True)
        self._index_path = self._output / "doc_store.jsonl"
        self._docs = self._load_index()

    def _load_index(self) -> dict[str, dict]:
        """Load existing document index."""
        docs = {}
        if self._index_path.exists():
            try:
                with open(self._index_path, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            d = json.loads(line)
                            docs[d["doc_id"]] = d
            except Exception:
                pass
        return docs

    def _save_index(self):
        """Persist document index."""
        with open(self._index_path, "w", encoding="utf-8") as f:
            for doc in self._docs.values():
                f.write(json.dumps(doc, ensure_ascii=False) + "\n")

    # -- Ingest ----------------------------------------------------------------

    def ingest(
        self,
        file_path: str,
        tags: list[str] = None,
        title: str = None,
        author: str = None,
        description: str = None,
    ) -> Optional[str]:
        """Ingest a document file. Copies to store, extracts text, indexes.
        Returns doc_id or None if unsupported."""
        src = Path(file_path)
        if not src.exists():
            return None
        if not is_supported(file_path):
            return None

        # Generate stable doc_id from content hash
        content_hash = hashlib.sha256(src.read_bytes()).hexdigest()[:12]
        doc_id = f"doc:{src.stem}:{content_hash}"

        # Check if already ingested
        if doc_id in self._docs:
            return doc_id

        # Copy file to store
        dest = self._store_dir / f"{content_hash}_{src.name}"
        if not dest.exists():
            shutil.copy2(src, dest)

        # Extract text
        extracted = extract_document(file_path)
        if not extracted:
            return None

        # Build record
        chunks = self._chunk_text(extracted["text"], title or src.stem)
        record = {
            "doc_id": doc_id,
            "file_name": src.name,
            "stored_path": str(dest),
            "original_path": str(src),
            "doc_type": extracted["doc_type"],
            "title": title or src.stem.replace("-", " ").replace("_", " "),
            "author": author or "",
            "description": description or "",
            "tags": tags or [],
            "text": extracted["text"][:50000],
            "text_length": len(extracted["text"]),
            "chunk_count": len(chunks),
            "chunks": chunks,
            "metadata": extracted.get("metadata", {}),
            "ingested_at": datetime.now(timezone.utc).isoformat(),
        }

        self._docs[doc_id] = record
        self._save_index()
        return doc_id

    # -- Ingest from directory -------------------------------------------------

    def ingest_directory(self, dir_path: str, tags: list[str] = None, recursive: bool = True) -> list[str]:
        """Ingest all supported documents from a directory."""
        ingested = []
        root = Path(dir_path)
        if not root.is_dir():
            return ingested
        pattern = "**/*" if recursive else "*"
        for p in sorted(root.glob(pattern)):
            if p.is_file() and is_supported(str(p)):
                doc_id = self.ingest(str(p), tags=tags)
                if doc_id:
                    ingested.append(doc_id)
        return ingested

    # -- Query -----------------------------------------------------------------

    def get(self, doc_id: str) -> Optional[dict]:
        return self._docs.get(doc_id)

    def list_all(self) -> list[dict]:
        """List all ingested documents (without full text or chunks)."""
        return [
            {k: v for k, v in d.items() if k not in ("text", "chunks")}
            for d in self._docs.values()
        ]

    def search_by_tag(self, tag: str) -> list[dict]:
        return [d for d in self._docs.values() if tag in d.get("tags", [])]

    def count(self) -> int:
        return len(self._docs)

    # -- Delete ----------------------------------------------------------------

    def delete(self, doc_id: str) -> bool:
        if doc_id not in self._docs:
            return False
        doc = self._docs.pop(doc_id)
        stored = Path(doc.get("stored_path", ""))
        if stored.exists():
            stored.unlink(missing_ok=True)
        self._save_index()
        return True

    # -- Build search documents for vector indexing ----------------------------

    def build_search_documents(self) -> list[dict]:
        """Produce one search document per chunk for fine-grained retrieval."""
        docs = []
        for d in self._docs.values():
            chunks = d.get("chunks", [])
            title = d.get("title", "")
            tags = d.get("tags", [])
            desc = d.get("description", "")
            doc_id = d["doc_id"]

            if not chunks:
                # Legacy doc without chunks — treat full text as single chunk
                text = d.get("text", "")
                if not text:
                    continue
                chunks = [{"index": 0, "text": text[:3000], "heading": ""}]

            for chunk in chunks:
                ci = chunk["index"]
                heading = chunk.get("heading", "")
                chunk_text = chunk["text"]

                # Prefix with doc context so embedding captures document identity
                search_text = f"{title}"
                if heading:
                    search_text += f" > {heading}"
                if desc:
                    search_text += f"\n{desc}"
                if tags:
                    search_text += f"\n{' '.join(tags)}"
                search_text += f"\n{chunk_text}"

                docs.append({
                    "doc_id": f"{doc_id}:chunk:{ci}",
                    "text": search_text[:3000],
                    "metadata": {
                        "doc_type": "uploaded_doc",
                        "sub_type": d.get("doc_type", ""),
                        "file_name": d.get("file_name", ""),
                        "title": title,
                        "heading": heading,
                        "author": d.get("author", ""),
                        "tags": tags,
                        "chunk_index": ci,
                        "chunk_of": doc_id,
                        "total_chunks": len(chunks),
                        "text_length": d.get("text_length", 0),
                        "ingested_at": d.get("ingested_at", ""),
                        "confidence": 1.0,
                        "confidence_bucket": "exact",
                        "evidence_method": "uploaded",
                        "layer": "",
                        "repo": "",
                    },
                })
        return docs

    # -- Chunking --------------------------------------------------------------

    def _chunk_text(self, text: str, doc_title: str = "") -> list[dict]:
        """Split text into overlapping chunks, respecting section boundaries.
        Returns [{index, text, heading}, ...]."""
        if not text:
            return []

        # Split on markdown headings or double newlines to find sections
        sections = self._split_sections(text)

        chunks = []
        idx = 0
        for heading, body in sections:
            # Sub-chunk long sections
            for piece in self._split_by_size(body, self.CHUNK_SIZE, self.CHUNK_OVERLAP):
                chunks.append({
                    "index": idx,
                    "text": piece.strip(),
                    "heading": heading,
                })
                idx += 1

        # If no chunks produced (very short doc), use full text
        if not chunks and text.strip():
            chunks.append({"index": 0, "text": text.strip(), "heading": ""})

        return chunks

    @staticmethod
    def _split_sections(text: str) -> list[tuple[str, str]]:
        """Split text into (heading, body) pairs using markdown headings."""
        import re
        parts = re.split(r'^(#{1,4}\s+.+)$', text, flags=re.MULTILINE)

        sections = []
        current_heading = ""
        current_body = []

        for part in parts:
            if re.match(r'^#{1,4}\s+', part):
                # Flush previous section
                if current_body:
                    sections.append((current_heading, "\n".join(current_body)))
                current_heading = part.strip().lstrip("# ").strip()
                current_body = []
            else:
                if part.strip():
                    current_body.append(part)

        # Flush last section
        if current_body:
            sections.append((current_heading, "\n".join(current_body)))

        # If no headings found, treat as single section
        if not sections and text.strip():
            sections = [("", text)]

        return sections

    @staticmethod
    def _split_by_size(text: str, chunk_size: int, overlap: int) -> list[str]:
        """Split text into overlapping pieces, breaking at paragraph boundaries."""
        if len(text) <= chunk_size:
            return [text] if text.strip() else []

        pieces = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            if end < len(text):
                # Try to break at paragraph boundary
                break_at = text.rfind("\n\n", start + chunk_size // 2, end)
                if break_at == -1:
                    break_at = text.rfind("\n", start + chunk_size // 2, end)
                if break_at > start:
                    end = break_at
            piece = text[start:end].strip()
            if piece:
                pieces.append(piece)
            start = end - overlap if end < len(text) else len(text)

        return pieces
