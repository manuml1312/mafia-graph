"""
MAFIA Phase 11 — Local Conversation Store
==========================================
Replaces BigQuery with a local JSON file: output/conversations.json
Same interface as the original ConversationStore so nothing else needs changing.
"""

import json
import uuid
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class ConversationStore:
    """Persists conversations and messages to a local JSON file."""

    def __init__(self, output_dir: str = ""):
        self._lock = threading.Lock()
        self._path = Path(output_dir) / "conversations.json" if output_dir else None
        self._data = {"conversations": {}, "messages": {}, "working_sets": {}, "code_refs": {}}
        self._dirty = False
        self._flush_timer = None
        if self._path and self._path.exists():
            try:
                with open(self._path, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
                total = sum(len(v) for v in self._data.get("messages", {}).values())
                print(f"[LocalStore] Loaded {len(self._data['conversations'])} conversations, {total} messages")
            except Exception as e:
                print(f"[LocalStore] Could not load conversations: {e}")

    def _schedule_save(self):
        """Debounce writes — flush at most once every 2 seconds (#5)."""
        if self._flush_timer is not None:
            self._flush_timer.cancel()
        self._dirty = True
        self._flush_timer = threading.Timer(2.0, self._flush)
        self._flush_timer.daemon = True
        self._flush_timer.start()

    def _flush(self):
        """Write to disk only if dirty."""
        with self._lock:
            if not self._dirty or not self._path:
                return
            try:
                self._path.parent.mkdir(parents=True, exist_ok=True)
                tmp = self._path.with_suffix(".tmp")
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self._data, f, ensure_ascii=False, indent=2)
                tmp.replace(self._path)
                self._dirty = False
            except Exception as e:
                print(f"[LocalStore] Save failed: {e}")

    def _save(self):
        """Legacy call site — now schedules a debounced flush instead of writing immediately."""
        self._schedule_save()

    # ── Conversations ────────────────────────────────────────────────────

    def create_conversation(self, user_id: str = "default",
                            project_id: str = "default", title: str = "") -> str:
        conv_id = str(uuid.uuid4())[:12]
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._data["conversations"][conv_id] = {
                "conversation_id": conv_id, "user_id": user_id,
                "project_id": project_id, "created_at": now,
                "last_active_at": now, "title": title or f"Chat {conv_id[:6]}",
                "mode_default": "rag",
            }
            self._data["messages"][conv_id] = []
            self._data["working_sets"][conv_id] = {
                "selected_node_ids": [], "selected_flow_ids": [],
                "filters_json": "{}", "toggle_code_mode": False,
            }
            self._save()
        return conv_id

    def get_conversation(self, conv_id: str) -> Optional[dict]:
        return self._data["conversations"].get(conv_id)

    def list_conversations(self, project_id: str = "", limit: int = 20) -> list:
        convs = list(self._data["conversations"].values())
        if project_id:
            convs = [c for c in convs if c.get("project_id") == project_id]
        convs.sort(key=lambda c: c.get("last_active_at", ""), reverse=True)
        return convs[:limit]

    # ── Messages ─────────────────────────────────────────────────────────

    def add_message(self, conv_id: str, role: str, text: str,
                    tokens: int = 0, latency_ms: int = 0, trace_id: str = "",
                    metadata: Optional[dict] = None) -> str:
        msg_id = str(uuid.uuid4())[:12]
        now = datetime.now(timezone.utc).isoformat()
        entry = {
            "message_id": msg_id, "conversation_id": conv_id,
            "role": role, "text": text, "timestamp": now,
            "tokens": tokens, "latency_ms": latency_ms, "trace_id": trace_id,
        }
        if metadata:
            entry["metadata"] = metadata
        with self._lock:
            if conv_id not in self._data["messages"]:
                self._data["messages"][conv_id] = []
            self._data["messages"][conv_id].append(entry)
            if conv_id in self._data["conversations"]:
                self._data["conversations"][conv_id]["last_active_at"] = now
                conv = self._data["conversations"][conv_id]
                if role == "user" and not conv.get("title_set"):
                    conv["title"] = text[:60]
                    conv["title_set"] = True
            self._save()
        return msg_id

    def get_messages(self, conv_id: str, limit: int = 50) -> list:
        return self._data["messages"].get(conv_id, [])[-limit:]

    # ── Working Set ──────────────────────────────────────────────────────

    def update_working_set(self, conv_id: str, node_ids: list = None,
                           flow_ids: list = None, filters: dict = None,
                           toggle_code: bool = None):
        with self._lock:
            ws = self._data["working_sets"].setdefault(conv_id, {})
            if node_ids is not None:
                ws["selected_node_ids"] = node_ids
            if flow_ids is not None:
                ws["selected_flow_ids"] = flow_ids
            if filters is not None:
                ws["filters_json"] = json.dumps(filters)
            if toggle_code is not None:
                ws["toggle_code_mode"] = toggle_code
            ws["updated_at"] = datetime.now(timezone.utc).isoformat()
            self._save()

    def get_working_set(self, conv_id: str) -> dict:
        return self._data["working_sets"].get(conv_id, {})

    # ── Code Context Refs ────────────────────────────────────────────────

    def add_code_ref(self, conv_id: str, repo_id: str, file_path: str,
                     start_line: int, end_line: int, content_hash: str = "",
                     evidence_method: str = "", confidence: float = 0):
        entry = {
            "conversation_id": conv_id, "repo_id": repo_id,
            "file_path": file_path, "start_line": start_line, "end_line": end_line,
            "content_hash": content_hash, "evidence_method": evidence_method,
            "confidence": confidence,
            "opened_at": datetime.now(timezone.utc).isoformat(),
        }
        with self._lock:
            self._data["code_refs"].setdefault(conv_id, []).append(entry)
            self._save()

    def get_code_refs(self, conv_id: str) -> list:
        return self._data["code_refs"].get(conv_id, [])

    # ── Retrieval telemetry (no-op locally) ─────────────────────────────

    def log_retrieval(self, conv_id: str, query_text: str,
                      topk_nodes: list, topk_flows: list,
                      graph_expansion: int, rerank_scores: list):
        pass  # not persisted locally — add file logging here if needed
