"""
MAFIA Phase 11 — Graph-Assisted Retrieval
============================================
Enhances vector search results by expanding through the system graph
and re-ranking based on confidence, completeness, graph distance,
and evidence richness.

Usage:
    retriever = GraphRetriever(vector_index, graph_path)
    results = retriever.retrieve("flag types returning 500", top_k=10, filters={})
"""

import json
from pathlib import Path
from collections import defaultdict
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase11_search.vector_index import VectorIndex

# ── Graph cache keyed by output_dir (#1 + #11) ───────────────────────────────────────────────────────────────────
# Stores the parsed graph dict so re-loading on session switch is instant
# and BlastRadiusEngine can reuse the same object without re-reading the file.
_graph_cache: dict[str, dict] = {}  # graph_path -> parsed dict


def get_cached_graph(graph_path: str) -> dict:
    """Return cached parsed graph, loading from disk only when the path is new."""
    if graph_path not in _graph_cache:
        _graph_cache[graph_path] = _load_json(graph_path)
        print(f"[GraphCache] Loaded and cached: {graph_path}")
    return _graph_cache[graph_path]


def invalidate_graph_cache(graph_path: str = None):
    """Call after a pipeline run to force re-load on next access."""
    if graph_path:
        _graph_cache.pop(graph_path, None)
    else:
        _graph_cache.clear()


class GraphRetriever:
    """Hybrid vector + graph retrieval with re-ranking."""

    def __init__(self, vector_index: VectorIndex, graph_path: str):
        self.vi = vector_index
        self.nodes = {}
        self.adj = defaultdict(list)
        self.rev = defaultdict(list)
        self._edge_map = {}
        # Structural edges (loaded separately from relations.jsonl)
        self.struct_adj = defaultdict(list)
        self.struct_rev = defaultdict(list)
        self._struct_edge_map = {}
        self._load_graph(graph_path)

    def _load_graph(self, graph_path: str):
        data = get_cached_graph(graph_path)  # cache hit on session switch
        for n in data.get("nodes", []):
            self.nodes[n["id"]] = n
        for e in data.get("edges", []):
            self.adj[e["source"]].append(e["target"])
            self.rev[e["target"]].append(e["source"])
            self._edge_map[(e["source"], e["target"])] = e

        # Load structural edges from relations.jsonl
        structural_types = {"belongs_to_repo", "belongs_to_layer", "defined_in", "imports", "exports"}
        rel_path = str(Path(graph_path).parent / "relations.jsonl")
        try:
            with open(rel_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    r = json.loads(line)
                    if r.get("type") in structural_types:
                        src, tgt = r["source"], r["target"]
                        self.struct_adj[src].append(tgt)
                        self.struct_rev[tgt].append(src)
                        self._struct_edge_map[(src, tgt)] = r
        except Exception:
            pass
        print(f"[GraphRetriever] Structural edges loaded: {sum(len(v) for v in self.struct_adj.values())}")

    # ── Main retrieval ───────────────────────────────────────────────────

    def retrieve(
        self,
        query: str,
        top_k: int = 20,
        filters: Optional[dict] = None,
        expand_depth: int = 1,
        expand_budget: int = 30,
    ) -> dict:
        """
        1. Vector search (or keyword fallback) for top candidates
        2. Extract node IDs from results
        3. Expand via graph neighborhood
        4. Re-rank all candidates
        """
        # Step 1: Vector search or keyword fallback
        if self.vi and self.vi.index is not None:
            vector_results = self.vi.search(query, top_k=top_k * 3, filters=filters)
        else:
            vector_results = self._keyword_search(query, top_k=top_k * 3, filters=filters)

        # Step 2: Extract node IDs
        seed_ids = set()
        for r in vector_results[:top_k]:
            nid = r["metadata"].get("node_id") or r["metadata"].get("flow_id", "")
            if nid and nid in self.nodes:
                seed_ids.add(nid)

        # Step 3: Graph expansion (budgeted)
        expanded_ids = self._expand(seed_ids, expand_depth, expand_budget)

        # Step 4: Fetch documents for expanded nodes
        expanded_docs = []
        seen = {r["doc_id"] for r in vector_results}
        if self.vi:
            for nid in expanded_ids:
                if nid in seen:
                    continue
                doc = self.vi.get_document(nid)
                if doc:
                    expanded_docs.append({
                        "doc_id": doc["doc_id"],
                        "score": 0.3,
                        "text": doc["text"][:500],
                        "metadata": doc["metadata"],
                        "source": "graph_expansion",
                    })
                    seen.add(nid)

        # Step 5: Re-rank everything
        all_candidates = []
        for r in vector_results:
            r["source"] = "vector_search"
            all_candidates.append(r)
        all_candidates.extend(expanded_docs)

        ranked = self._rerank(all_candidates, seed_ids)

        # Split into node results and flow results
        node_results = [r for r in ranked if r["metadata"].get("doc_type") == "component"]
        flow_results = [r for r in ranked if r["metadata"].get("doc_type") == "flow"]
        repo_results = [r for r in ranked if r["metadata"].get("doc_type") == "repo"]

        return {
            "query": query,
            "filters": filters or {},
            "total_results": len(ranked),
            "node_results": node_results[:top_k],
            "flow_results": flow_results[:top_k],
            "repo_results": repo_results[:5],
            "graph_expanded": len(expanded_docs),
            "truncated": len(ranked) > top_k,
        }

    # ── Graph expansion ──────────────────────────────────────────────────

    def _expand(self, seed_ids: set, depth: int, budget: int) -> set:
        """BFS expansion from seed nodes, limited by budget."""
        expanded = set()
        frontier = list(seed_ids)
        visited = set(seed_ids)

        for _ in range(depth):
            next_frontier = []
            for nid in frontier:
                for neighbor in self.adj.get(nid, []) + self.rev.get(nid, []):
                    if neighbor not in visited and len(expanded) < budget:
                        visited.add(neighbor)
                        expanded.add(neighbor)
                        next_frontier.append(neighbor)
            frontier = next_frontier

        return expanded

    # ── Re-ranking ───────────────────────────────────────────────────────

    def _rerank(self, candidates: list[dict], seed_ids: set) -> list[dict]:
        """Re-rank with normalized base scores so boosts can't bury good vector results."""
        if not candidates:
            return candidates

        # Normalize base scores to [0, 1] (#6)
        max_score = max((c.get("score", 0) for c in candidates), default=1) or 1

        for c in candidates:
            base = c.get("score", 0) / max_score  # normalized
            meta = c.get("metadata", {})

            conf_boost  = meta.get("confidence", 0) * 0.15
            comp_boost  = 0.08 if meta.get("completeness") == "complete" else 0
            ev_boost    = 0.04 if meta.get("evidence_method") in ("regex", "ast") else 0

            nid = meta.get("node_id", "")
            prox_boost = 0
            if nid in seed_ids:
                prox_boost = 0.15
            elif nid:
                for sid in seed_ids:
                    if nid in self.adj.get(sid, []) or nid in self.rev.get(sid, []):
                        prox_boost = 0.08
                        break

            # Cap total boost at 0.3 so graph expansion can't bury high-confidence vector results
            total_boost = min(conf_boost + comp_boost + ev_boost + prox_boost, 0.3)
            c["final_score"] = base + total_boost

        candidates.sort(key=lambda x: -x.get("final_score", 0))
        return candidates

    # ── Node queries ─────────────────────────────────────────────────────

    def get_node_profile(self, node_id: str) -> Optional[dict]:
        """Get full node profile with counts."""
        node = self.nodes.get(node_id)
        if not node:
            return None
        doc = self.vi.get_document(node_id) if self.vi else None
        return {
            "node": node,
            "intelligence": doc["text"] if doc else None,
            "upstream_count": len(self.rev.get(node_id, [])),
            "downstream_count": len(self.adj.get(node_id, [])),
            "confidence": node.get("confidence", 0),
            "evidence_method": node.get("evidence_method", ""),
        }

    def get_neighbors(self, node_id: str, direction: str = "both",
                      depth: int = 1, limit: int = 50) -> dict:
        """Get node neighbors with metadata."""
        result = {"node_id": node_id, "direction": direction, "neighbors": []}

        if direction in ("downstream", "both"):
            for tgt in self.adj.get(node_id, [])[:limit]:
                n = self.nodes.get(tgt, {})
                edge = self._edge_map.get((node_id, tgt), {})
                result["neighbors"].append({
                    "id": tgt, "label": n.get("label", ""),
                    "layer": n.get("layer", ""), "type": n.get("type", ""),
                    "relation": edge.get("type", ""), "direction": "downstream",
                    "confidence": n.get("confidence", 0),
                })

        if direction in ("upstream", "both"):
            for src in self.rev.get(node_id, [])[:limit]:
                n = self.nodes.get(src, {})
                edge = self._edge_map.get((src, node_id), {})
                result["neighbors"].append({
                    "id": src, "label": n.get("label", ""),
                    "layer": n.get("layer", ""), "type": n.get("type", ""),
                    "relation": edge.get("type", ""), "direction": "upstream",
                    "confidence": n.get("confidence", 0),
                })

        result["total"] = len(result["neighbors"])
        result["truncated"] = result["total"] >= limit
        return result


    def _keyword_search(self, query: str, top_k: int = 60,
                         filters: Optional[dict] = None) -> list[dict]:
        """Keyword search using inverted index — O(terms) instead of O(docs)."""
        if not self.vi or not self.vi.documents:
            return []
        q_terms = set(query.lower().split())
        inv = getattr(self.vi, '_inv_index', None)

        if inv is not None:
            # Fast path: union candidate doc indices from inverted index
            hit_counts: dict[int, int] = {}
            for term in q_terms:
                for idx in inv.get(term, []):
                    hit_counts[idx] = hit_counts.get(idx, 0) + 1
            candidates = [
                (idx, count) for idx, count in hit_counts.items()
            ]
        else:
            # Fallback: linear scan
            candidates = [
                (i, sum(1 for t in q_terms if t in doc["text"].lower()))
                for i, doc in enumerate(self.vi.documents)
            ]
            candidates = [(i, c) for i, c in candidates if c > 0]

        candidates.sort(key=lambda x: -x[1])
        scored = []
        for idx, hits in candidates[:top_k * 2]:
            doc = self.vi.documents[idx]
            meta = doc["metadata"]
            if filters:
                from phase11_search.vector_index import _matches_filters
                if not _matches_filters(meta, filters):
                    continue
            scored.append({
                "doc_id": doc["doc_id"],
                "score": hits / max(len(q_terms), 1),
                "text": doc["text"][:500],
                "metadata": meta,
            })
            if len(scored) >= top_k:
                break
        return scored


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}
