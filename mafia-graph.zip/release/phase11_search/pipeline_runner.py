"""
MAFIA — Pipeline Runner (API-callable)
========================================
Wraps the full MAFIA pipeline (Phase 2 → 14) as a callable function
with progress callbacks for real-time UI streaming.
"""

import json
import time
import threading
import shutil
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


class PipelineProgress:
    """Thread-safe progress tracker with event log."""

    def __init__(self):
        self.lock = threading.Lock()
        self.phase = ""
        self.phase_num = 0
        self.total_phases = 10
        self.status = "idle"  # idle | running | complete | failed
        self.message = ""
        self.events: list[dict] = []
        self.error = ""
        self.started_at = None
        self.finished_at = None
        self.stats = {}

    def start(self):
        with self.lock:
            self.status = "running"
            self.started_at = time.time()
            self._emit("pipeline_start", "Pipeline started")

    def set_phase(self, num: int, label: str, message: str = ""):
        with self.lock:
            self.phase_num = num
            self.phase = label
            self.message = message or f"Running {label}..."
            self._emit("phase_start", f"Phase {num}: {label}")

    def log(self, message: str, level: str = "info"):
        with self.lock:
            self.message = message
            self._emit(level, message)

    def complete(self, stats: dict = None):
        with self.lock:
            self.status = "complete"
            self.finished_at = time.time()
            self.stats = stats or {}
            self._emit("pipeline_complete", "Pipeline complete")

    def fail(self, error: str):
        with self.lock:
            self.status = "failed"
            self.error = error
            self.finished_at = time.time()
            self._emit("error", error)

    def snapshot(self) -> dict:
        with self.lock:
            elapsed = 0
            if self.started_at:
                elapsed = (self.finished_at or time.time()) - self.started_at
            return {
                "status": self.status,
                "phase": self.phase,
                "phase_num": self.phase_num,
                "total_phases": self.total_phases,
                "message": self.message,
                "error": self.error,
                "elapsed_s": round(elapsed, 1),
                "stats": self.stats,
                "events": list(self.events[-50:]),
            }

    def _emit(self, kind: str, message: str):
        self.events.append({
            "kind": kind,
            "message": message,
            "time": datetime.now(timezone.utc).isoformat(),
        })


def _build_keyword_index(output_dir: str, progress: PipelineProgress):
    """
    Build a minimal keyword-searchable index (no Gemini needed).
    Saves documents.pkl + metadata.json so GraphRetriever can do
    keyword fallback search. Removes any stale faiss.index.
    """
    import pickle
    from datetime import datetime, timezone
    from phase11_search.document_builder import build_all_documents

    output = Path(output_dir)
    index_dir = output / "search_index"
    index_dir.mkdir(parents=True, exist_ok=True)

    # Remove stale FAISS index from previous vector-enabled runs
    stale_faiss = index_dir / "faiss.index"
    if stale_faiss.exists():
        stale_faiss.unlink()
        progress.log("Removed stale faiss.index from previous run")

    docs = build_all_documents(output_dir)
    progress.log(f"Built {len(docs)} search documents (text + fuzzy, no embeddings)")

    with open(index_dir / "documents.pkl", "wb") as f:
        pickle.dump(docs, f)

    meta = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_documents": len(docs),
        "dim": 0,
        "embedding_model": "keyword_only",
        "index_type": "keyword_fallback",
    }
    with open(index_dir / "metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)


# Global progress singleton
_progress = PipelineProgress()
_pipeline_thread: threading.Thread | None = None


def get_progress() -> PipelineProgress:
    return _progress


def get_thread() -> threading.Thread | None:
    return _pipeline_thread


def is_running() -> bool:
    return _progress.status == "running"


def run_pipeline_async(source_roots: list[str], output_dir: str,
                       enable_genai: bool = False, full: bool = True,
                       enable_vector_index: bool = False) -> PipelineProgress:
    """Start the pipeline in a background thread. Returns the progress tracker."""
    global _pipeline_thread, _progress

    if is_running():
        return _progress

    _progress = PipelineProgress()

    _pipeline_thread = threading.Thread(
        target=_run_pipeline,
        args=(source_roots, output_dir, enable_genai, full, _progress, enable_vector_index),
        daemon=True,
    )
    _pipeline_thread.start()
    return _progress


def _run_pipeline(source_roots: list[str], output_dir: str,
                  enable_genai: bool, full: bool, progress: PipelineProgress,
                  enable_vector_index: bool = False):
    """Execute the full pipeline with progress reporting.
    When full=False (incremental), skips repos whose fingerprint hasn't changed."""
    try:
        progress.start()
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)

        mode_label = "full" if full else "incremental"
        progress.log(f"Pipeline mode: {mode_label}")

        # ── Phase 2: Repo scanning ───────────────────────────────────────
        progress.set_phase(2, "Repository Scanning", "Discovering and classifying repositories...")
        from phase2_repo_intake.repo_scanner import build_manifest, discover_repos
        from phase2_repo_intake.arch_detector import detect_architecture

        # Validate paths exist before handing off to the scanner
        missing = [p for p in source_roots if not Path(p).exists()]
        if missing:
            progress.fail(f"Source paths not found: {', '.join(missing)}")
            return

        # Quick discovery pass so the UI shows something before the slow parallel scan
        discovered = discover_repos(source_roots)
        if not discovered:
            progress.fail(
                "No repositories found in the provided paths. "
                "Check that the uploaded folders contain source code."
            )
            return
        names = ', '.join(r.name for r in discovered[:5])
        suffix = '...' if len(discovered) > 5 else ''
        progress.log(f"Discovered {len(discovered)} repo(s): {names}{suffix}")

        manifest_path = str(output / "repo_manifest.json")
        manifest = build_manifest(source_roots, manifest_path)
        repo_count = len(manifest.get("repos", []))
        progress.log(f"Classified {repo_count} repositories")

        # ── Incremental: detect changed repos ────────────────────────────
        from phase14_orchestration.run_state import RunState
        rs = RunState(output_dir)
        if not full:
            changed = [r for r in manifest.get("repos", []) if rs.repo_changed(r["repo_id"], r["root_path"])]
            skipped = repo_count - len(changed)
            if skipped > 0:
                progress.log(f"Incremental: {len(changed)} repos changed, {skipped} unchanged (skipped)")
            if not changed:
                progress.log("No repos changed since last run — skipping extraction, rebuilding downstream")
        else:
            changed = None  # None = extract all

        if repo_count == 0:
            progress.fail("No repositories found in the provided paths.")
            return

        # ── Architecture Detection (before extraction) ───────────────────────────
        progress.log("Detecting application architecture...")
        try:
            arch_profile = detect_architecture(source_roots, output_dir)
            flow_patterns = arch_profile.get('global', {}).get('flow_patterns', [])
            progress.log(f"Architecture detected: {', '.join(flow_patterns[:3]) or 'generic'}")
        except Exception as e:
            progress.log(f"Architecture detection failed (continuing): {e}", level="warn")
            arch_profile = {}

        # ── Symbol Resolution Index (before extraction) ───────────────────────────
        progress.log("Building symbol resolution index...")
        try:
            from phase3_extraction_framework.symbol_resolver import build_symbol_index
            symbol_index = build_symbol_index(source_roots, output_dir)
            total_vars = sum(len(r.get('var_types', {})) for r in symbol_index.values())
            progress.log(f"Symbol index: {total_vars} variable type mappings across {len(symbol_index)} repos")
        except Exception as e:
            progress.log(f"Symbol index failed (continuing): {e}", level="warn")

        # ── Phase 3: Extraction ──────────────────────────────────────────
        progress.set_phase(3, "Code Extraction", f"Extracting entities from {repo_count} repos...")
        from phase3_extraction_framework.dispatcher import ExtractionDispatcher
        from phase4_extractors.ui.ui_extractor import UiExtractor
        from phase4_extractors.bff.bff_extractor import BffExtractor
        from phase4_extractors.api.api_extractor import ApiExtractor
        from phase4_extractors.db.databricks_extractor import DatabricksExtractor
        from phase4_extractors.db.pg_sql_extractor import PgSqlExtractor
        from phase4_extractors.db.bigquery_extractor import BigQueryExtractor
        from phase4_extractors.ts_extractor import TreeSitterExtractor

        dispatcher = ExtractionDispatcher(manifest_path, output_dir)
        dispatcher.register("*", TreeSitterExtractor)  # AST-first: runs on ALL repos
        dispatcher.register("ui", UiExtractor)
        dispatcher.register("bff", BffExtractor)
        dispatcher.register("api", ApiExtractor)
        dispatcher.register("api", PgSqlExtractor)
        dispatcher.register("db", PgSqlExtractor)
        dispatcher.register("data", DatabricksExtractor)
        dispatcher.register("*", BigQueryExtractor)  # runs on all repos — detects BQ usage anywhere

        report = dispatcher.run(repo_workers=4, file_workers=8)
        entity_count = report.get("total_entities", 0)
        relation_count = report.get("total_relations", 0)
        progress.log(f"Extracted {entity_count} entities, {relation_count} relations")

        # ── Structural relations ─────────────────────────────────────────
        progress.set_phase(3, "Structural Relations", "Building cross-file relations...")
        from phase3_extraction_framework.structural_relations import emit_structural_relations
        emit_structural_relations(output_dir, manifest_path)

        # ── Validation ───────────────────────────────────────────────────
        progress.log("Validating artifacts...")
        from schemas.validator import ArtifactValidator
        validator = ArtifactValidator()
        ep = str(output / "entities.jsonl")
        rp = str(output / "relations.jsonl")
        if Path(ep).exists(): validator.load_entities(ep)
        if Path(rp).exists(): validator.load_relations(rp)
        validation = validator.validate()
        validator.save_report(validation, str(output / "validation_report.json"))

        # ── Phase 5: Legacy ──────────────────────────────────────────────
        progress.set_phase(5, "Legacy Artifacts", "Generating compatibility artifacts...")
        from phase5_compatibility.legacy_generators import generate_legacy_artifacts
        generate_legacy_artifacts(output_dir)

        # ── Phase 6: Coverage ────────────────────────────────────────────
        progress.set_phase(6, "Coverage Analysis", "Analyzing extraction coverage...")
        from phase6_coverage.coverage_builder import build_coverage_report
        build_coverage_report(output_dir)

        # ── Phase 7: Mapping ─────────────────────────────────────────────
        progress.set_phase(7, "Mapping Confidence", "Evaluating cross-layer mappings...")
        from phase7_mapping.mapping_evaluator import build_mapping_confidence_report
        build_mapping_confidence_report(output_dir)

        # ── Phase 8: Quality gate ────────────────────────────────────────
        progress.set_phase(8, "Quality Gate", "Running quality checks...")
        from phase8_hardening.quality_gate import run_quality_gate
        gate_report = run_quality_gate(output_dir)
        gate_passed = gate_report.get("gate_passed", False)
        progress.log(f"Quality gate: {'PASSED' if gate_passed else 'FAILED'}")

        # ── Phase 9: Graph + flows ───────────────────────────────────────
        progress.set_phase(9, "Graph Construction", "Building system graph and flows...")
        from phase9_graph.graph_builder import build_graph
        from phase9_graph.graph_validator import validate_graph
        build_graph(output_dir)
        validate_graph(output_dir)

        try:
            from phase9_graph.topology_analyzer import analyze_topology
            analyze_topology(output_dir)
        except Exception:
            pass

        try:
            from phase9_graph.graph_visualizer import generate_html
            generate_html(output_dir)
        except Exception:
            pass

        # ── Phase 10: AI Intelligence ────────────────────────────────────
        progress.set_phase(10, "AI Intelligence", "Generating AST summaries + component and flow intelligence...")

        # AST structural summaries (tree-sitter)
        try:
            from utils.ts_parser import any_available as ts_available
            if ts_available():
                from phase10_ast.run_ast_summaries import run as run_ast, run_discover as run_ast_discover
                progress.log("Running AST structural summaries...")
                run_ast(output_dir)
                progress.log("Running AST discover mode (gap analysis)...")
                run_ast_discover(output_dir)
            else:
                progress.log("tree-sitter not installed — skipping AST summaries", level="warn")
        except Exception as e:
            progress.log(f"AST summaries failed: {e}", level="warn")

        from phase10_intelligence.component_intelligence import generate_component_intelligence
        from phase10_intelligence.flow_intelligence import generate_flow_intelligence
        generate_component_intelligence(output_dir, gemini_client=None, max_components=200)
        generate_flow_intelligence(output_dir, gemini_client=None)

        # ── Phase 11: Search index ───────────────────────────────────────
        progress.set_phase(11, "Search Index", "Building search index...")
        if enable_vector_index:
            try:
                from phase11_search.vector_index import VectorIndex
                from phase11_search.document_builder import build_all_documents
                docs = build_all_documents(output_dir)
                vi = VectorIndex()
                progress.log("Embedding documents via Gemini (vector indexing ON)...")
                vi.build(docs)
                vi.save(str(output / "search_index"))
                progress.log(f"Indexed {len(docs)} documents with embeddings")
            except Exception as e:
                progress.log(f"Vector index (Gemini) failed: {e} — falling back to keyword index", level="warn")
                try:
                    _build_keyword_index(output_dir, progress)
                except Exception as e2:
                    progress.log(f"Keyword index also failed: {e2}", level="warn")
        else:
            progress.log("Vector indexing OFF — building text + fuzzy search index")
            try:
                _build_keyword_index(output_dir, progress)
            except Exception as e:
                progress.log(f"Keyword index failed: {e}", level="warn")

        # ── Phase 14: Versioning ─────────────────────────────────────────
        progress.set_phase(14, "Versioning", "Saving run state...")
        from phase14_orchestration.artifact_versioning import ArtifactVersioner
        # Mark each repo's fingerprint so next incremental run can skip unchanged
        for repo_meta in manifest.get("repos", []):
            rs.mark_done(repo_meta["repo_id"], repo_meta["root_path"])
        if full:
            rs.mark_full_run()
        rs.save()
        av = ArtifactVersioner(output_dir)
        v = av.next_version()
        av.record(v, stats={"entity_count": entity_count, "relation_count": relation_count,
                            "mode": mode_label, "repos_total": repo_count})

        # ── Done ─────────────────────────────────────────────────────────
        progress.complete(stats={
            "repos": repo_count,
            "entities": entity_count,
            "relations": relation_count,
            "gate_passed": gate_passed,
            "version": v,
            "mode": mode_label,
        })

    except Exception as e:
        import traceback
        try:
            progress.fail(f"{type(e).__name__}: {e}\n{traceback.format_exc()}")
        except Exception:
            pass
    except BaseException as e:
        # Catch SystemExit / KeyboardInterrupt so the thread never dies silently
        try:
            progress.fail(f"{type(e).__name__}: {e}")
        except Exception:
            pass
        raise
