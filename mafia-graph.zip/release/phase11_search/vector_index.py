"""
MAFIA Phase 11 — FAISS Vector Index + Gemini Embeddings
=========================================================
Embeds search documents using Gemini text-embedding-004 via Vertex AI,
stores in FAISS (IndexFlatIP with normalized vectors for cosine similarity),
and maintains a JSON metadata index for filtered retrieval.

Usage:
    python -m phase11_search.vector_index          # build index
    from phase11_search.vector_index import VectorIndex
    idx = VectorIndex.load("output/search_index/")
    results = idx.search("flag types endpoint", top_k=10, filters={"layer": "bff"})
"""

import os
import json
import time
import pickle
import threading
import numpy as np
import faiss
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from google.oauth2 import service_account
from google.auth.transport.requests import AuthorizedSession

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase11_search.document_builder import build_all_documents

# ── Gemini embedding config (mirrors RAG/config.py) ─────────────────────────

try:
    from utils.ai_config import get_ai_config as _get_ai_cfg
    _ai = _get_ai_cfg()
except Exception:
    _ai = None

SA_KEY_PATH = _ai.sa_key_path if _ai else ""
CERT_FILE_PATH = _ai.cert_file if _ai else ""
GCP_PROJECT = _ai.gcp_project if _ai else ""
GCP_LOCATION = _ai.gcp_location if _ai else "us-central1"
EMBEDDING_MODEL = _ai.embedding_model if _ai else "text-embedding-004"
EMBEDDING_DIMENSION = _ai.embedding_dimension if _ai else 768


# ── Gemini embedding client ─────────────────────────────────────────────────

class _EmbeddingClient:
    """Gemini text-embedding-004 via Vertex AI REST API."""

    def __init__(self):
        if os.path.exists(CERT_FILE_PATH):
            os.environ['REQUESTS_CA_BUNDLE'] = CERT_FILE_PATH
            os.environ['GRPC_DEFAULT_SSL_ROOTS_FILE_PATH'] = CERT_FILE_PATH

        self.creds = service_account.Credentials.from_service_account_file(
            SA_KEY_PATH,
            scopes=["https://www.googleapis.com/auth/cloud-platform"],
        )
        self.session = AuthorizedSession(self.creds)
        if os.path.exists(CERT_FILE_PATH):
            self.session.verify = CERT_FILE_PATH

        self.url = (
            f"https://{GCP_LOCATION}-aiplatform.googleapis.com/v1/"
            f"projects/{GCP_PROJECT}/locations/{GCP_LOCATION}/"
            f"publishers/google/models/{EMBEDDING_MODEL}:predict"
        )

    def embed_one(self, text: str, max_retries: int = 4) -> list[float]:
        payload = {"instances": [{"content": text}]}
        last_err = None
        for attempt in range(max_retries):
            try:
                resp = self.session.post(self.url, json=payload, timeout=60)
                if resp.status_code == 429:
                    time.sleep(min(30, 2 ** attempt))
                    continue
                resp.raise_for_status()
                return resp.json()["predictions"][0]["embeddings"]["values"]
            except Exception as e:
                last_err = e
                if attempt < max_retries - 1:
                    time.sleep(min(20, 1.5 ** attempt))
        raise RuntimeError(f"Embedding failed: {last_err}")

    def embed_batch(self, texts: list[str], max_workers: int = 8) -> list[list[float]]:
        """Embed texts in parallel with rate-limited ThreadPoolExecutor."""
        total = len(texts)
        results = [None] * total
        zero_vec = [0.0] * EMBEDDING_DIMENSION
        done_count = 0
        lock = threading.Lock()

        # Token-bucket rate limiter: refill ~max_workers tokens/sec
        rate_limit = int(max_workers * 1.5)
        semaphore = threading.Semaphore(rate_limit)
        stop_event = threading.Event()

        def _refill():
            while not stop_event.is_set():
                time.sleep(1.0)
                for _ in range(rate_limit):
                    try:
                        semaphore.release()
                    except ValueError:
                        break

        refill_thread = threading.Thread(target=_refill, daemon=True)
        refill_thread.start()

        def _do_embed(idx: int) -> None:
            nonlocal done_count
            semaphore.acquire()
            try:
                results[idx] = self.embed_one(texts[idx][:2000])
            except Exception as e:
                print(f"  [WARN] Embed failed for doc {idx}: {e}")
                results[idx] = zero_vec
            with lock:
                done_count += 1
                if done_count % 50 == 0 or done_count == total:
                    print(f"  Embedded {done_count}/{total}...")

        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = [pool.submit(_do_embed, i) for i in range(total)]
            for f in as_completed(futures):
                f.result()

        stop_event.set()
        return results


_client = None

def _get_client() -> _EmbeddingClient:
    global _client
    if _client is None:
        _client = _EmbeddingClient()
    return _client


# ── LRU-cached query embedding (#2) ───────────────────────────────────────────────────────────────────
from functools import lru_cache

@lru_cache(maxsize=256)
def _embed_cached(text: str) -> tuple:
    """Cache query embeddings — eliminates 300-800ms Gemini round-trip on repeat queries."""
    return tuple(_get_client().embed_one(text))


# ── Vector Index ─────────────────────────────────────────────────────────────

class VectorIndex:
    """FAISS index with metadata sidecar for filtered search."""

    def __init__(self):
        self.index: Optional[faiss.IndexFlatIP] = None
        self.documents: list[dict] = []
        self.dim: int = EMBEDDING_DIMENSION

    # ── Build from documents ─────────────────────────────────────────────

    def build(self, documents: list[dict]):
        """Embed all documents via Gemini and build FAISS index."""
        self.documents = documents
        texts = [d["text"] for d in documents]

        print(f"[VectorIndex] Embedding {len(texts)} documents via Gemini {EMBEDDING_MODEL}...")
        client = _get_client()
        raw = client.embed_batch(texts)

        embeddings = np.array(raw, dtype="float32")
        # Normalize for cosine similarity (IndexFlatIP)
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
        norms[norms == 0] = 1
        embeddings = embeddings / norms

        self.index = faiss.IndexFlatIP(self.dim)
        self.index.add(embeddings)
        print(f"[VectorIndex] Index built: {self.index.ntotal} vectors, dim={self.dim}")

    # ── Search ───────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 20,
        filters: Optional[dict] = None,
    ) -> list[dict]:
        if not self.index or self.index.ntotal == 0:
            return []

        q_vec = np.array([_embed_cached(query[:2000])], dtype="float32")
        norms = np.linalg.norm(q_vec, axis=1, keepdims=True)
        norms[norms == 0] = 1
        q_vec = q_vec / norms

        fetch_k = min(top_k * 5, self.index.ntotal)
        scores, indices = self.index.search(q_vec, fetch_k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            doc = self.documents[idx]
            if filters and not _matches_filters(doc["metadata"], filters):
                continue
            results.append({
                "doc_id": doc["doc_id"],
                "score": float(score),
                "text": doc["text"][:500],
                "metadata": doc["metadata"],
            })
            if len(results) >= top_k:
                break

        return results

    def get_document(self, doc_id: str) -> Optional[dict]:
        for d in self.documents:
            if d["doc_id"] == doc_id:
                return d
        return None

    # ── Persistence ──────────────────────────────────────────────────────

    def save(self, index_dir: str):
        path = Path(index_dir)
        path.mkdir(parents=True, exist_ok=True)

        faiss.write_index(self.index, str(path / "faiss.index"))

        with open(path / "documents.pkl", 'wb') as f:
            pickle.dump(self.documents, f)

        meta = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_documents": len(self.documents),
            "dim": self.dim,
            "embedding_model": EMBEDDING_MODEL,
            "index_type": "IndexFlatIP",
        }
        with open(path / "metadata.json", 'w', encoding='utf-8') as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)

        print(f"[VectorIndex] Saved to {path} ({len(self.documents)} docs)")

    @classmethod
    def load(cls, index_dir: str) -> "VectorIndex":
        path = Path(index_dir)
        vi = cls()

        faiss_path = path / "faiss.index"
        if faiss_path.exists():
            vi.index = faiss.read_index(str(faiss_path))
        else:
            vi.index = None

        docs_path = path / "documents.pkl"
        if docs_path.exists():
            with open(docs_path, 'rb') as f:
                vi.documents = pickle.load(f)

        meta_path = path / "metadata.json"
        if meta_path.exists():
            with open(meta_path, 'r', encoding='utf-8') as f:
                meta = json.load(f)
            vi.dim = meta.get("dim", EMBEDDING_DIMENSION)

        # Build inverted index for fast keyword search (#3)
        vi._build_inverted_index()

        mode = "vector" if vi.index else "keyword-only"
        print(f"[VectorIndex] Loaded {len(vi.documents)} docs ({mode} mode)")
        return vi

    def _build_inverted_index(self):
        """Build term → [doc_indices] map once at load time.
        O(terms) lookup instead of O(docs) linear scan on every keyword search."""
        self._inv_index: dict[str, list[int]] = {}
        for i, doc in enumerate(self.documents):
            for term in set(doc["text"].lower().split()):
                if len(term) >= 2:  # skip single-char noise
                    self._inv_index.setdefault(term, []).append(i)
        print(f"[VectorIndex] Inverted index built: {len(self._inv_index)} terms")

    def stats(self) -> dict:
        by_type = {}
        by_layer = {}
        for d in self.documents:
            dt = d["metadata"].get("doc_type", "?")
            by_type[dt] = by_type.get(dt, 0) + 1
            layer = d["metadata"].get("layer", "?")
            by_layer[layer] = by_layer.get(layer, 0) + 1
        return {
            "total_documents": len(self.documents),
            "total_vectors": self.index.ntotal if self.index else 0,
            "dim": self.dim,
            "embedding_model": EMBEDDING_MODEL,
            "by_type": by_type,
            "by_layer": by_layer,
        }

    # -- Incremental update ----------------------------------------------------

    def update_incremental(self, new_documents: list[dict]) -> dict:
        """Add only new documents to the existing index.
        Compares by doc_id. Embeds only docs not already in the index.
        Returns {added, skipped, removed, total}."""
        existing_ids = {d["doc_id"] for d in self.documents}
        new_ids = {d["doc_id"] for d in new_documents}

        # Find docs to add (in new but not in existing)
        to_add = [d for d in new_documents if d["doc_id"] not in existing_ids]

        # Find docs to remove (in existing but not in new)
        removed_ids = existing_ids - new_ids

        if not to_add and not removed_ids:
            print(f"[VectorIndex] Incremental: no changes (0 added, 0 removed)")
            return {"added": 0, "skipped": len(existing_ids), "removed": 0, "total": len(self.documents)}

        # Handle removals: rebuild index without removed docs
        if removed_ids:
            keep_indices = [i for i, d in enumerate(self.documents) if d["doc_id"] not in removed_ids]
            self.documents = [self.documents[i] for i in keep_indices]
            # Rebuild FAISS from kept vectors
            if keep_indices and self.index and self.index.ntotal > 0:
                all_vecs = np.zeros((self.index.ntotal, self.dim), dtype="float32")
                for i in range(self.index.ntotal):
                    all_vecs[i] = self.index.reconstruct(i)
                kept_vecs = np.array([all_vecs[i] for i in keep_indices], dtype="float32")
                self.index = faiss.IndexFlatIP(self.dim)
                self.index.add(kept_vecs)
            else:
                self.index = faiss.IndexFlatIP(self.dim)

        # Embed and add new docs
        if to_add:
            texts = [d["text"][:2000] for d in to_add]
            print(f"[VectorIndex] Incremental: embedding {len(to_add)} new documents...")
            client = _get_client()
            raw = client.embed_batch(texts)
            new_vecs = np.array(raw, dtype="float32")
            norms = np.linalg.norm(new_vecs, axis=1, keepdims=True)
            norms[norms == 0] = 1
            new_vecs = new_vecs / norms

            if self.index is None:
                self.index = faiss.IndexFlatIP(self.dim)
            self.index.add(new_vecs)
            self.documents.extend(to_add)

        result = {
            "added": len(to_add),
            "skipped": len(existing_ids) - len(removed_ids),
            "removed": len(removed_ids),
            "total": len(self.documents),
        }
        print(f"[VectorIndex] Incremental: +{result['added']} added, -{result['removed']} removed, {result['total']} total")
        return result


def _matches_filters(metadata: dict, filters: dict) -> bool:
    for key, value in filters.items():
        if not value:
            continue
        # Special: min_confidence is a threshold filter
        if key == "min_confidence":
            thresholds = {"exact": 0.90, "strong": 0.80, "inferred": 0.60, "weak": 0.40}
            min_conf = thresholds.get(value, 0)
            if metadata.get("confidence", 0) < min_conf:
                return False
            continue
        meta_val = metadata.get(key)
        if isinstance(meta_val, list):
            if value not in meta_val:
                return False
        elif meta_val != value:
            return False
    return True


# ── Build and save ───────────────────────────────────────────────────────────

def build_index(output_dir: str, incremental: bool = False) -> VectorIndex:
    """Build or incrementally update the vector index.
    incremental=True loads existing index and only embeds new documents."""
    index_dir = str(Path(output_dir) / "search_index")
    docs = build_all_documents(output_dir)

    if incremental and Path(index_dir).exists() and (Path(index_dir) / "faiss.index").exists():
        print(f"[VectorIndex] Incremental mode: loading existing index...")
        vi = VectorIndex.load(index_dir)
        result = vi.update_incremental(docs)
        vi.save(index_dir)
        print(f"[VectorIndex] Incremental done: +{result['added']}, -{result['removed']}, {result['total']} total")
        return vi
    else:
        vi = VectorIndex()
        vi.build(docs)
        vi.save(index_dir)
        return vi


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="MAFIA Vector Index Builder")
    parser.add_argument("--incremental", action="store_true",
                        help="Only embed new documents, keep existing vectors")
    parser.add_argument("--full", action="store_true",
                        help="Force full rebuild (default if no existing index)")
    parser.add_argument("--output-dir", default=None)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    output_dir = args.output_dir or str(base / "output")
    incremental = args.incremental and not args.full
    build_index(output_dir, incremental=incremental)
