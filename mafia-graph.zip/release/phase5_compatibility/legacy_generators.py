"""
MAFIA Phase 5 — Legacy Artifact Generators
============================================
Generates backward-compatible JSON files from canonical entities.jsonl + relations.jsonl
so that existing downstream consumers continue to work during migration.

Produces:
  - bff_endpoints.json
  - api_endpoints.json
  - db_layer_mapping.json
  - ui_snapshot.json

Usage:
    python -m phase5_compatibility.legacy_generators
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def generate_legacy_artifacts(output_dir: str) -> dict:
    """Generate legacy artifacts only when there's actual data for them."""
    output = Path(output_dir)
    entities = _load_jsonl(output / "entities.jsonl")
    relations = _load_jsonl(output / "relations.jsonl")

    if not entities:
        print("  [SKIP] No entities — skipping legacy artifact generation")
        return {}

    entity_map = {e["id"]: e for e in entities}
    rel_by_source = defaultdict(list)
    rel_by_target = defaultdict(list)
    for r in relations:
        rel_by_source[r.get("source", "")].append(r)
        rel_by_target[r.get("target", "")].append(r)

    stats = {}
    layers_present = {e.get("layer") for e in entities}

    # Only generate files for layers that actually have data
    if "bff" in layers_present:
        bff_data = _generate_bff_endpoints(entities, relations, entity_map, rel_by_source)
        if bff_data.get("endpoints"):
            _write_json(output / "bff_endpoints.json", bff_data)
            stats["bff_endpoints"] = len(bff_data["endpoints"])

    if "api" in layers_present:
        api_data = _generate_api_endpoints(entities, relations, entity_map, rel_by_source)
        if api_data.get("endpoints"):
            _write_json(output / "api_endpoints.json", api_data)
            stats["api_endpoints"] = len(api_data["endpoints"])

    if "db" in layers_present:
        db_data = _generate_db_layer_mapping(entities, relations, entity_map)
        if db_data.get("functions") or db_data.get("tables"):
            _write_json(output / "db_layer_mapping.json", db_data)
            stats["db_functions"] = len(db_data.get("functions", []))
            stats["db_tables"] = len(db_data.get("tables", []))

    if "ui" in layers_present:
        ui_data = _generate_ui_snapshot(entities, relations, entity_map, rel_by_source)
        if ui_data.get("components") or ui_data.get("hooks") or ui_data.get("fetch_defs"):
            _write_json(output / "ui_snapshot.json", ui_data)
            stats["ui_components"] = len(ui_data.get("components", []))

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 5 -- Legacy Artifact Generation")
    print(f"{'='*60}")
    for k, v in stats.items():
        print(f"  {k}: {v}")
    print(f"  Output: {output}")
    print(f"{'='*60}\n")

    return stats


def _generate_bff_endpoints(entities, relations, entity_map, rel_by_source):
    endpoints = []
    bff_eps = [e for e in entities if e.get("layer") == "bff" and e.get("type") == "endpoint"]

    for ep in bff_eps:
        ep_entry = {
            "endpoint": ep.get("name", ""),
            "repo": ep.get("repo", ""),
            "file": ep.get("file", ""),
            "line": ep.get("line"),
            "variable_name": ep.get("properties", {}).get("variable_name", ""),
            "confidence": ep.get("confidence", 0),
            "controller": None,
            "downstream_api": [],
            "middleware": [],
        }

        for r in rel_by_source.get(ep["id"], []):
            if r["type"] == "routes_to":
                tgt = entity_map.get(r["target"], {})
                ep_entry["controller"] = {
                    "name": tgt.get("name", ""),
                    "file": tgt.get("file", ""),
                    "line": tgt.get("line"),
                }
                # Trace controller -> API constants
                for cr in rel_by_source.get(r["target"], []):
                    if cr["type"] == "calls_api":
                        api_tgt = entity_map.get(cr["target"], {})
                        ep_entry["downstream_api"].append({
                            "constant": api_tgt.get("name", ""),
                            "path": api_tgt.get("properties", {}).get("endpoint_path", ""),
                        })
            elif r["type"] == "validates_with":
                tgt = entity_map.get(r["target"], {})
                ep_entry["middleware"].append(tgt.get("name", ""))

        endpoints.append(ep_entry)

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": "canonical_entities",
        "endpoints": endpoints,
    }


def _generate_api_endpoints(entities, relations, entity_map, rel_by_source):
    endpoints = []
    api_eps = [e for e in entities if e.get("layer") == "api" and e.get("type") == "endpoint"]

    for ep in api_eps:
        props = ep.get("properties", {})
        ep_entry = {
            "method": props.get("http_method", ""),
            "path": props.get("endpoint_path", ""),
            "repo": ep.get("repo", ""),
            "file": ep.get("file", ""),
            "line": ep.get("line"),
            "handler": props.get("handler_method", ""),
            "confidence": ep.get("confidence", 0),
            "service_calls": [],
            "db_functions": [],
            "db_tables": [],
        }

        # Trace: endpoint -> controller -> service -> repo -> db
        for r in rel_by_source.get(ep["id"], []):
            if r["type"] == "routes_to":
                for sr in rel_by_source.get(r["target"], []):
                    if sr["type"] == "delegates_to":
                        svc = entity_map.get(sr["target"], {})
                        ep_entry["service_calls"].append(svc.get("name", ""))
                        for rr in rel_by_source.get(sr["target"], []):
                            if rr["type"] == "uses_repo":
                                for dr in rel_by_source.get(rr["target"], []):
                                    db_tgt = entity_map.get(dr["target"], {})
                                    if dr["type"] == "calls_function":
                                        ep_entry["db_functions"].append(db_tgt.get("name", ""))
                                    elif dr["type"] in ("reads_from", "writes_to", "uses_table"):
                                        ep_entry["db_tables"].append(db_tgt.get("name", ""))

        endpoints.append(ep_entry)

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": "canonical_entities",
        "endpoints": endpoints,
    }


def _generate_db_layer_mapping(entities, relations, entity_map):
    functions = []
    tables = []

    for e in entities:
        if e.get("layer") != "db":
            continue
        if e.get("type") == "function":
            functions.append({
                "name": e.get("name", ""),
                "qualifier": e.get("id", "").split(":")[-1],
                "repo": e.get("repo", ""),
                "file": e.get("file"),
                "db_type": e.get("properties", {}).get("db_type", ""),
                "confidence": e.get("confidence", 0),
            })
        elif e.get("type") == "table":
            tables.append({
                "name": e.get("name", ""),
                "qualifier": e.get("id", "").split(":")[-1],
                "repo": e.get("repo", ""),
                "file": e.get("file"),
                "db_type": e.get("properties", {}).get("db_type", ""),
                "schema": e.get("properties", {}).get("schema", ""),
                "confidence": e.get("confidence", 0),
            })

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": "canonical_entities",
        "functions": functions,
        "tables": tables,
    }


def _generate_ui_snapshot(entities, relations, entity_map, rel_by_source):
    components = []
    hooks = []
    fetch_defs = []
    routes = []

    for e in entities:
        if e.get("layer") != "ui":
            continue
        entry = {
            "name": e.get("name", ""),
            "file": e.get("file", ""),
            "line": e.get("line"),
            "repo": e.get("repo", ""),
            "confidence": e.get("confidence", 0),
        }
        if e["type"] == "component":
            entry["hooks_used"] = []
            for r in rel_by_source.get(e["id"], []):
                if r["type"] == "calls":
                    tgt = entity_map.get(r["target"], {})
                    if tgt.get("type") == "hook":
                        entry["hooks_used"].append(tgt.get("name", ""))
            components.append(entry)
        elif e["type"] == "hook":
            hooks.append(entry)
        elif e["type"] == "fetch_def":
            entry["path_suffix"] = e.get("properties", {}).get("path_suffix", "")
            entry["env_var"] = e.get("properties", {}).get("env_var", "")
            fetch_defs.append(entry)
        elif e["type"] == "route":
            routes.append(entry)

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source": "canonical_entities",
        "components": components,
        "hooks": hooks,
        "fetch_defs": fetch_defs,
        "routes": routes,
    }


def _write_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    generate_legacy_artifacts(str(base / "output"))
