# MAFIA Skills for Kiro

## First-Time Setup
```bash
cd MAFIA_Phase1_Execution
setup.bat              # creates venv, installs deps, validates
setup.bat --extras     # + extra language grammars
# Then activate: .venv\Scripts\activate
```

## Available Operations

### Analyze Codebase
- Scan repos: `python -m phase2_repo_intake.repo_scanner --source-roots {paths}`
- Extract: `python -m phase3_extraction_framework.run_extraction` (add `--full` for full, `--from-phase 9` for graph-only)
- AST: `python -m phase10_ast.run_ast_summaries --discover`

### Query Data (Python)
```python
import json
# Load entities
entities = [json.loads(l) for l in open("output/entities.jsonl")]
# Load graph
graph = json.load(open("output/system_graph.json"))
# Load flows
flows = json.load(open("output/e2e_flows.json"))
# Filter: entities by layer/type/repo/confidence
api_eps = [e for e in entities if e["layer"]=="api" and e["type"]=="endpoint"]
```

### Query Data (HTTP — localhost:5001)
- Search: `GET /search?q={query}&layer={layer}`
- Node: `GET /node/{entity_id}`
- Neighbors: `GET /node/{id}/neighbors?depth=2`
- Flows: `GET /flows` or `GET /flow/{flow_id}?depth=deep`
- Blast radius: `POST /blast_radius {"component_id": "...", "direction": "both"}`
- Code: `GET /code/{entity_id}` or `GET /codefile?id={entity_id}`
- Chat: `POST /chat {"message": "...", "code_mode": true}`

### Entity ID Format
`{layer}:{type}:{repo}:{qualifier}` — e.g. `api:endpoint:flags_api:GET:/flagTypes`

### Layers
ui → bff → api → db (+ config, shared)
