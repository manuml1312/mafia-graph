# MAFIA — Multi-Artifact Flow Intelligence Architecture

Automated codebase analysis pipeline that discovers repositories, classifies them by architectural layer (UI, BFF, API, DB), extracts entities and relationships, builds a system graph, assembles end-to-end flows, and serves an interactive explorer with AI-powered search and blast radius analysis.

Replaces hardcoded repo lists and manually curated mapping files with a confidence-scored extraction pipeline producing canonical artifacts that all downstream stages consume.

---

## Table of Contents

- [Prerequisites](#prerequisites)
- [Setup](#setup)
- [Quick Start](#quick-start)
- [Pipeline Overview](#pipeline-overview)
- [Commands Reference](#commands-reference)
- [Phase Control](#phase-control)
- [Output Artifacts](#output-artifacts)
- [Architecture](#architecture)
- [How Incremental Mode Works](#how-incremental-mode-works)
- [Confidence Scoring](#confidence-scoring)
- [Troubleshooting](#troubleshooting)
- [Project Structure](#project-structure)

---

## Prerequisites

- **Python 3.10+** (uses `list[str]`, `dict[str, float]` type hints)
- **Access to source repositories** on local disk
- **Google Cloud service account** (for Gemini AI features and BigQuery — optional)

### Optional Dependencies

| Package | What it enables |
|---------|----------------|
| `tree-sitter` + language grammars | AST structural summaries (19 languages) |
| `networkx` | Topology analysis (community detection, god nodes) |
| `graspologic` | Leiden community detection (falls back to Louvain) |
| `pypdf` | PDF document ingestion |
| `python-docx` | DOCX document ingestion |
| `openpyxl` | XLSX document ingestion |

## Setup

```bash
cd MAFIA_Phase1_Execution/
setup.bat              # creates venv, installs all deps, validates imports
setup.bat --extras     # also installs 9 extra tree-sitter grammars
```

Then activate the virtual environment:
```bash
# Windows
.venv\Scripts\activate

# Mac / Linux
source .venv/bin/activate
```

Optional: For GenAI features, set up Google credentials:
```bash
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa-key.json
```

---

## Quick Start

```bash
cd MAFIA_Phase1_Execution/

# Step 1: Scan repos and produce manifest
python -m phase2_repo_intake.repo_scanner \
    --source-roots /path/to/marvel_repos /path/to/web_app_release

# Step 2: Run the full pipeline (incremental by default)
python -m phase3_extraction_framework.run_extraction

# Step 3: Run AST discover mode (structural summaries for ALL methods)
python -m phase10_ast.run_ast_summaries --discover

# Step 4: Build the search index (incremental if index exists)
python -m phase11_search.vector_index --incremental

# Step 5: Start the UI + API server
python -m phase11_search.search_api1
# → Open http://localhost:5001
```

That's it. The pipeline extracts entities from all repos, builds a graph, assembles flows, AST discover adds structural summaries for every method in the codebase, and the UI lets you search, explore flows, inspect code structure, upload documents, and compute blast radius.

---

## Pipeline Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        MAFIA Pipeline Flow                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Phase 2: repo_scanner                                              │
│  ├── Scans source directories                                       │
│  ├── Detects tech stacks (React, Koa, Spring Boot, PySpark, etc.)   │
│  ├── Classifies repos: ui / bff / api / db / data / config          │
│  └── Produces: repo_manifest.json                                   │
│       │                                                             │
│       ▼                                                             │
│  Phase 3: Extraction (incremental by default)                       │
│  ├── Dispatcher routes repos to extractors by classification        │
│  ├── UiExtractor      → React components, hooks, fetch_defs         │
│  ├── BffExtractor     → Koa endpoints, controllers, constants       │
│  ├── ApiExtractor     → Spring Boot endpoints → service → repo → DB │
│  ├── PgSqlExtractor   → PostgreSQL functions, tables, views         │
│  ├── DatabricksExtractor → PySpark tables, Unity Catalog            │
│  ├── ConfigExtractor  → .env, .properties, .yml across all repos    │
│  ├── Structural relations (imports, exports, config usage)          │
│  ├── Artifact validation (schema + referential integrity)           │
│  └── Produces: entities.jsonl, relations.jsonl                      │
│       │                                                             │
│       ▼                                                             │
│  Phase 5: Legacy compatibility artifacts                            │
│  └── bff_endpoints.json, api_endpoints.json, db_layer_mapping.json  │
│       │                                                             │
│       ▼                                                             │
│  Phase 6: Coverage analysis                                         │
│  └── coverage_report.json (parse rate, extraction rate, gaps)       │
│       │                                                             │
│       ▼                                                             │
│  Phase 7: Mapping confidence + (optional) GenAI gap analysis        │
│  └── mapping_confidence_report.json (UI→BFF→API→DB hop quality)     │
│       │                                                             │
│       ▼                                                             │
│  Phase 8: Quality gate                                              │
│  └── quality_gate_report.json (PASS/FAIL with 18 checks)           │
│       │                                                             │
│       ▼                                                             │
│  Phase 9: Graph construction + flow assembly + topology + visualization     │
│  ├── system_graph.json (7000+ nodes, 6900+ edges)                   │
│  ├── e2e_flows.json (298 flows across 6 catalogs)                   │
│  ├── graph_views.json (layer + repo pre-aggregations)               │
│  ├── topology_report.json (communities, god nodes, surprises)       │
│  └── system_graph.html (interactive vis.js visualization)           │
│       │                                                             │
│       ▼                                                             │
│  Phase 10: AI intelligence + AST structural summaries               │
│  ├── component_intelligence.json (per-node AI summaries)            │
│  ├── flow_intelligence.json (per-flow AI narratives)                │
│  └── ast_summaries.jsonl (structural summaries for all methods)     │
│       │                                                             │
│       ▼                                                             │
│  Phase 11: Search index + API server + document ingestion           │
│  ├── FAISS vector index (Gemini text-embedding-004)                 │
│  ├── Document ingestion (PDF, DOCX, XLSX, Markdown, images)         │
│  ├── Flask API (search, node profiles, flows, blast radius, chat)   │
│  └── Phase 12 UI served at http://localhost:5001                    │
│       │                                                             │
│       ▼                                                             │
│  Phase 13: Evaluation (optional, --evaluate)                        │
│  ├── Gold dataset builder (high-confidence benchmark)               │
│  └── Precision/recall/F1 + drift analysis                           │
│       │                                                             │
│       ▼                                                             │
│  Phase 14: Versioning + run-state (always runs)                     │
│  ├── run_state.json (per-repo fingerprints for incremental)         │
│  └── artifact_versions.json (version history + optional snapshots)  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Commands Reference

All commands run from the `MAFIA_Phase1_Execution/` directory.

### Core Pipeline

```bash
# Default: incremental extraction (skip unchanged repos)
python -m phase3_extraction_framework.run_extraction

# Force full re-extraction of all repos
python -m phase3_extraction_framework.run_extraction --full

# With GenAI assist (requires Google credentials)
python -m phase3_extraction_framework.run_extraction --enable-genai

# With snapshot (archive artifacts for rollback)
python -m phase3_extraction_framework.run_extraction --snapshot

# With Phase 13 evaluation gate
python -m phase3_extraction_framework.run_extraction --evaluate

# All features combined
python -m phase3_extraction_framework.run_extraction --enable-genai --snapshot --evaluate
```

### Phase Control

```bash
# Skip extraction, rebuild graph + intelligence only
python -m phase3_extraction_framework.run_extraction --from-phase 9

# Run extraction + validation only, stop before coverage
python -m phase3_extraction_framework.run_extraction --to-phase 3

# Run only coverage → mapping → gate
python -m phase3_extraction_framework.run_extraction --from-phase 6 --to-phase 8

# Rebuild everything from graph onward (after manual entity edits)
python -m phase3_extraction_framework.run_extraction --from-phase 9
```

### Repo Scanning (Phase 2 — run separately)

```bash
python -m phase2_repo_intake.repo_scanner \
    --source-roots /path/to/marvel_repos /path/to/web_app_release
```

### Search Index + UI Server (Phase 11-12 — run separately)

```bash
# Build/rebuild the vector search index (full)
python -m phase11_search.vector_index

# Incremental: only embed new documents (after AST discover or doc upload)
python -m phase11_search.vector_index --incremental

# Start the API server + UI
python -m phase11_search.search_api1
# → http://localhost:5001
```

### AST Structural Summaries (standalone block)

```bash
# Entity-mode: summarize methods that match existing entities
python -m phase10_ast.run_ast_summaries

# Discover mode: walk ALL source files, summarize every method, report gaps
python -m phase10_ast.run_ast_summaries --discover

# With options
python -m phase10_ast.run_ast_summaries --discover --languages java,typescript --workers 4
python -m phase10_ast.run_ast_summaries --entity-types api:controller,api:service
```

### Standalone Phase Commands

```bash
# Phase 6: Coverage report only
python -m phase6_coverage.coverage_builder

# Phase 7: Mapping confidence only
python -m phase7_mapping.mapping_evaluator

# Phase 8: Quality gate only
python -m phase8_hardening.quality_gate

# Phase 8: Save/compare regression baseline
python -m phase8_hardening.regression_runner --save-baseline
python -m phase8_hardening.regression_runner

# Phase 13: Build gold benchmark datasets
python -m phase13_evaluation.gold_dataset_builder

# Phase 13: Evaluate current vs gold
python -m phase13_evaluation.metric_calculators
```

### CLI Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--full` | off | Force full re-extraction (default is incremental) |
| `--from-phase N` | 3 | Start from phase N |
| `--to-phase N` | 14 | Stop after phase N |
| `--enable-genai` | off | Enable Gemini AI assist + post-hoc gap analysis |
| `--gemini-model` | gemini-2.5-flash | Gemini model name |
| `--sa-key-path` | org default | Path to Google service account JSON key |
| `--cert-file` | org default | CA cert file for ZScaler/proxy bypass |
| `--repo-workers` | 4 | Parallel repo extraction workers |
| `--file-workers` | 8 | Parallel file extraction workers per repo |
| `--snapshot` | off | Archive artifacts to `output/snapshots/v{N}/` |
| `--evaluate` | off | Run Phase 13 P/R/F1 evaluation gate |
| `--no-cache` | off | Disable file-level extraction cache |
| `--manifest` | output/repo_manifest.json | Path to manifest |
| `--output-dir` | output/ | Output directory |

---

## Phase Control

Phases are numbered and run sequentially. Use `--from-phase` and `--to-phase` to run subsets:

| Phase | What it does | Depends on |
|-------|-------------|------------|
| 3 | Extraction + structural relations + validation | repo_manifest.json |
| 5 | Legacy compatibility artifacts | entities.jsonl |
| 6 | Coverage analysis | entities.jsonl, relations.jsonl |
| 7 | Mapping confidence + GenAI post-hoc | entities.jsonl, relations.jsonl |
| 8 | Quality gate (18 checks, PASS/FAIL) | coverage + mapping + validation reports |
| 9 | Graph construction + flow assembly + topology + HTML viz | entities.jsonl, relations.jsonl |
| 10 | AI intelligence (component + flow summaries) | system_graph.json, e2e_flows.json |
| 13 | Evaluation against gold datasets (needs `--evaluate`) | benchmark/gold_*.jsonl |
| 14 | Versioning + run-state persistence | always runs |

Common patterns:
- **Code changed, need fresh extraction**: `python -m phase3_extraction_framework.run_extraction` (incremental)
- **Tweaked extractor logic, need full re-run**: `python -m phase3_extraction_framework.run_extraction --full`
- **Just want to rebuild the graph**: `--from-phase 9`
- **Just want to re-run AI intelligence**: `--from-phase 10 --to-phase 10`

---

## Output Artifacts

All artifacts are written to `output/`.

### Core Artifacts (5 canonical)

| File | Format | Description |
|------|--------|-------------|
| `repo_manifest.json` | JSON | All repos, their classification, stack, and root paths |
| `entities.jsonl` | JSONL | Every extracted entity (endpoints, controllers, functions, tables, etc.) |
| `relations.jsonl` | JSONL | Every extracted edge between entities |
| `coverage_report.json` | JSON | File parse rate, extraction rate, gap analysis |
| `mapping_confidence_report.json` | JSON | Cross-layer mapping quality, `ready_for_flow_gen` gate |

### Analysis Artifacts

| File | Description |
|------|-------------|
| `extraction_report.json` | Per-repo extraction summaries with extractor stats |
| `validation_report.json` | Schema + referential integrity validation results |
| `quality_gate_report.json` | Pass/fail gate decision with per-check details |
| `system_graph.json` | Full system graph (nodes + edges + metadata) |
| `e2e_flows.json` | End-to-end flows across 6 catalogs with breakpoints |
| `graph_views.json` | Pre-aggregated layer + repo views |
| `topology_report.json` | Community detection, god nodes, bridge nodes, surprises |
| `system_graph.html` | Interactive vis.js graph visualization |
| `graph_diff.json` | Structural diff vs previous run (added/removed entities) |
| `graph_validation_report.json` | Graph structural validation |
| `component_intelligence.json` | AI-generated per-component summaries |
| `flow_intelligence.json` | AI-generated per-flow narratives |
| `unresolved_artifacts.json` | Entities/relations that couldn't be fully resolved |
| `low_confidence_zones.json` | Low-confidence entity/relation zones |
| `genai_suggestions.json` | GenAI suggestions (only with `--enable-genai`) |

### AST Summaries

| File | Description |
|------|-------------|
| `ast_summaries.jsonl` | Structural summaries for all discovered methods (signature, calls, exceptions, config refs, complexity) |
| `ast_discovered.jsonl` | Methods found by AST but not in entity graph (extraction gaps) |
| `ast_summary_report.json` | Discovery stats: files scanned, methods found, coverage % |

### Document Ingestion

| File | Description |
|------|-------------|
| `doc_store.jsonl` | Index of uploaded supplementary documents |
| `uploaded_docs/` | Stored copies of uploaded files |
| `cache/` | File-level extraction cache (SHA256-keyed) |
| `cache/ast/` | AST summary cache |

### Legacy Compatibility

| File | Description |
|------|-------------|
| `bff_endpoints.json` | BFF endpoint list (backward compat) |
| `api_endpoints.json` | API endpoint list (backward compat) |
| `db_layer_mapping.json` | DB function/table mapping (backward compat) |
| `ui_snapshot.json` | UI component snapshot (backward compat) |

### Versioning & Evaluation

| File | Description |
|------|-------------|
| `run_state.json` | Per-repo fingerprints for incremental change detection |
| `artifact_versions.json` | Version history with per-run stats |
| `regression_baseline.json` | Regression comparison baseline |
| `benchmark/gold_entities.jsonl` | Gold benchmark entities (≥90% confidence, regex/ast) |
| `benchmark/gold_relations.jsonl` | Gold benchmark relations |
| `benchmark/gold_flows.json` | Gold benchmark flows |
| `benchmark/gold_manifest.json` | Gold dataset metadata |
| `benchmark/evaluation_report.json` | P/R/F1 evaluation results |

### Search Index

| File | Description |
|------|-------------|
| `search_index/faiss.index` | FAISS vector index |
| `search_index/documents.pkl` | Pickled document store |
| `search_index/metadata.json` | Index metadata |

---

## Architecture

### System Layers

The pipeline analyzes a 4-layer microservice architecture:

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│    UI    │────▶│   BFF    │────▶│   API    │────▶│    DB    │
│ React/   │     │ Koa/     │     │ Spring   │     │ Postgres │
│ Next.js  │     │ Express  │     │ Boot     │     │ Databricks│
└──────────┘     └──────────┘     └──────────┘     └──────────┘
  fetches         calls_api       delegates_to      calls_function
                                  uses_repo         reads_from
```

### Entity Types by Layer

| Layer | Entity Types |
|-------|-------------|
| UI | component, hook, selector, fetch_def, route, env_var, module |
| BFF | endpoint, constant, controller, middleware, service |
| API | endpoint, controller, service, repository, entity, dto, util, config |
| DB | function, table, view, schema |
| Config | env, toggle, property, secret |

### Canonical ID Format

```
Entity:   {layer}:{type}:{repo}:{qualifier}
Relation: {source_id}--{type}-->{target_id}

Example:  api:endpoint:marvel_flags_api:/flagTypes
          bff:controller:marvel_flags_bff:FlagController.getFlagTypes
```

### Extractor Registration

| Classification | Extractor | What it extracts |
|---------------|-----------|-----------------|
| `ui` | UiExtractor | React components, hooks, selectors, fetch_defs, routes |
| `bff` | BffExtractor | Koa/Express endpoints, constants, controllers, middleware |
| `api` | ApiExtractor | Spring Boot full call chain: endpoint → controller → service → repo → DB |
| `api`, `db` | PgSqlExtractor | PostgreSQL functions, tables, views, function-to-function deps |
| `data` | DatabricksExtractor | PySpark tables, functions, Unity Catalog 3-part names |
| `*` (all) | ConfigExtractor | .env, .properties, .yml → env, toggle, secret, property |

---

## How Incremental Mode Works

By default, the pipeline runs in incremental mode:

1. **Fingerprinting**: Each repo is fingerprinted using `SHA256(file_count:total_size:max_mtime)`. This catches any file add, delete, or modify.

2. **Change detection**: On each run, fingerprints are compared against `run_state.json` from the last successful run.

3. **Selective extraction**: Only changed repos are re-extracted. Entities and relations from unchanged repos are preserved and merged back.

4. **Full downstream**: All post-extraction phases (validation, coverage, graph, intelligence) always run on the complete merged dataset.

```
Run 1 (no prior state → full extraction):
  51 repos extracted → run_state.json saved with fingerprints

Run 2 (3 repos changed):
  48 repos skipped (fingerprint match)
  3 repos re-extracted
  Preserved 7000 entities from 48 unchanged repos
  Merged with 200 new entities from 3 changed repos
  Full downstream pipeline on merged 7200 entities
```

Use `--full` to force re-extraction of all repos regardless of fingerprints.

---

## Confidence Scoring

Every entity and relation carries a confidence score (0.0–1.0):

| Score | Label | When it's used |
|-------|-------|---------------|
| 0.95 | Exact | Deterministic match from AST or known code pattern |
| 0.85 | Strong | High-confidence heuristic with naming convention + context |
| 0.70 | Inferred | Cross-file resolution, URL segment match |
| 0.50 | Weak | Partial evidence, some ambiguity |
| 0.30 | Guess | Very low evidence, flagged for review |

GenAI-sourced entities are always capped at 0.70 and tagged `evidence_method="genai"`.

After extraction, a Bayesian adjustment pass applies:
- **+0.05** per additional extractor confirming the same entity (capped +0.10)
- **+0.03** if entity has both upstream and downstream relations
- **-0.05** if entity has zero relations (except config layer)
- **-0.10** if entity is in a test/mock file

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| SSL cert errors (ZScaler) | `export REQUESTS_CA_BUNDLE=/path/to/merged-cacerts.pem` |
| BigQuery auth fails | Check SA key path in `phase11_search/bigquery_store.py` |
| FAISS numpy version conflict | `pip install "numpy<2"` |
| Empty search results | Rebuild vector index: `python -m phase11_search.vector_index` |
| Graph validation errors | Check `entities.jsonl` for dangling refs, run `--from-phase 9` |
| Quality gate FAILED | Check `quality_gate_report.json` for which check failed |
| "No repos changed" on first run | Expected if `run_state.json` doesn't exist yet — use `--full` for first run |
| Incremental lost entities | Verify `run_state.json` exists from a prior run; use `--full` to reset |
| GenAI spinning / timeout | Check network access to Gemini API, verify SA credentials |
| Phase 13 "no gold datasets" | Run `python -m phase13_evaluation.gold_dataset_builder` first |

### Logs & Reports

| What | Where |
|------|-------|
| Extraction stats | `output/extraction_report.json` |
| Validation errors | `output/validation_report.json` |
| Coverage gaps | `output/coverage_report.json` |
| Quality gate details | `output/quality_gate_report.json` |
| Graph validation | `output/graph_validation_report.json` |
| Regression comparison | `output/regression_baseline.json` |
| Version history | `output/artifact_versions.json` |
| Evaluation P/R/F1 | `output/benchmark/evaluation_report.json` |

---

## Project Structure

```
MAFIA_Phase1_Execution/
├── phase2_repo_intake/                 # Repo discovery + classification
│   ├── repo_scanner.py                 #   → repo_manifest.json
│   └── source_adapters.py              #   Pluggable intake (local/git/archive)
├── phase3_extraction_framework/        # Extraction engine + unified pipeline
│   ├── run_extraction.py               #   ★ MAIN ENTRY POINT — unified pipeline runner
│   ├── base_extractor.py               #   ABC all extractors subclass
│   ├── dispatcher.py                   #   Routes repos → extractors, merges, flushes
│   └── structural_relations.py         #   Post-processing cross-file relations
├── phase4_extractors/                  # Deterministic extractors
│   ├── ui/ui_extractor.py              #   React/Next.js
│   ├── bff/bff_extractor.py            #   Koa/Express TypeScript
│   ├── api/api_extractor.py            #   Spring Boot Java (full call chain)
│   ├── db/pg_sql_extractor.py          #   PostgreSQL .sql files
│   ├── db/databricks_extractor.py      #   PySpark/Databricks
│   ├── config/config_extractor.py      #   .env, .properties, .yml
│   └── ast_helpers.py                  #   AST parsing (TS/JS/Java/Python)
├── phase5_compatibility/               # Legacy artifact generators
│   └── legacy_generators.py
├── phase6_coverage/                    # Coverage analysis
│   └── coverage_builder.py
├── phase7_mapping/                     # Cross-layer mapping evaluation
│   └── mapping_evaluator.py
├── phase7_genai/                       # GenAI-assisted gap analysis (optional)
│   ├── gemini_client.py                #   Gemini API client
│   ├── prompt_templates.py             #   Structured prompts
│   └── pattern_discovery.py            #   Gap resolver engine
├── phase8_hardening/                   # Quality gates + regression
│   ├── quality_gate.py                 #   18-check pass/fail gate
│   └── regression_runner.py            #   Baseline save + comparison
├── phase9_graph/                       # Graph construction
│   ├── graph_builder.py                #   system_graph.json + e2e_flows.json
│   ├── graph_query.py                  #   Graph query utilities
│   ├── graph_validator.py              #   Graph structural validation
│   ├── blast_radius_engine.py          #   Impact analysis engine
│   ├── topology_analyzer.py            #   Community detection, god nodes, surprises
│   └── graph_visualizer.py             #   Interactive vis.js HTML export
├── phase10_intelligence/               # AI enrichment
│   ├── component_intelligence.py       #   Per-node AI summaries (AST-aware)
│   ├── flow_intelligence.py            #   Per-flow AI narratives
│   ├── issue_diagnosis.py              #   Issue diagnosis engine
│   └── provenance.py                   #   Provenance label utilities
├── phase10_ast/                        # AST structural summaries (standalone)
│   └── run_ast_summaries.py            #   Entity mode + discover mode (19 languages)
├── phase11_search/                     # Search + API server
│   ├── search_api1.py                   #   Flask API (serves UI + API + doc upload)
│   ├── vector_index.py                 #   FAISS + Gemini embeddings (incremental)
│   ├── graph_retriever.py              #   Hybrid vector + graph search
│   ├── document_builder.py             #   Search document construction (5 doc types)
│   ├── code_reader.py                  #   Source code file reader
│   ├── chat_engine.py                  #   RAG + code-grounded AI chat
│   ├── bigquery_store.py               #   Conversation persistence
│   └── ingestion/                      #   Document ingestion subsystem
│       ├── doc_extractor.py            #     PDF, DOCX, XLSX, MD, image extraction
│       └── doc_store.py                #     Upload management + search doc builder
├── phase12_ui/                         # Web UI
│   ├── index.html                      #   SPA shell
│   └── static/
│       ├── app.js                      #   Explorer, flows, blast radius
│       ├── chat.js                     #   AI chat panel
│       └── styles.css                  #   Styling
├── phase13_evaluation/                 # Evaluation + QA
│   ├── gold_dataset_builder.py         #   Build gold benchmark datasets
│   └── metric_calculators.py           #   P/R/F1 + drift analysis
├── phase14_orchestration/              # Orchestration + incremental
│   ├── orchestrator.py                 #   Redirects to unified run_extraction.py
│   ├── run_state.py                    #   Per-repo fingerprint tracking
│   └── artifact_versioning.py          #   Version history + snapshots
├── schemas/                            # Schema definitions + utilities
│   ├── emitter.py                      #   Thread-safe entity/relation emission
│   ├── id_format.py                    #   Canonical ID format + validation
│   ├── validator.py                    #   Artifact validation
│   └── artifact_schemas.json           #   JSON Schema (draft-07)
├── utils/                              # Shared utilities
│   ├── file_classifier.py              #   File eligibility classification
│   ├── fuzzy.py                        #   Jaro-Winkler fuzzy matching
│   ├── ts_parser.py                    #   Tree-sitter wrapper (19 languages)
│   ├── ast_summarizer.py               #   AST structural summary extraction
│   ├── file_cache.py                   #   SHA256 per-file extraction cache
│   ├── ignore_loader.py                #   .mafiaignore pattern support
│   └── security.py                     #   Label sanitization, path validation
├── output/                             # Generated artifacts (runtime)
├── ARTIFACT_CONTRACT.md                # Master schema contract
└── RISK_LOG.md                         # Risk register
```

---

## First-Time Setup Walkthrough

```bash
# 1. Scan your repos
python -m phase2_repo_intake.repo_scanner \
    --source-roots /path/to/all/marvel/repos

# 2. Run full extraction (first time, no prior state)
python -m phase3_extraction_framework.run_extraction --full

# 3. Build gold datasets for future regression checks
python -m phase13_evaluation.gold_dataset_builder

# 4. Build search index
python -m phase11_search.vector_index

# 5. Start the server
python -m phase11_search.search_api1

# 6. Open http://localhost:5001 — search, explore, blast radius
```

### After Code Changes

```bash
# Just run the pipeline — incremental mode handles the rest
python -m phase3_extraction_framework.run_extraction

# Re-run AST discover to pick up new methods
python -m phase10_ast.run_ast_summaries --discover

# Incremental re-index (only embeds new documents)
python -m phase11_search.vector_index --incremental

# Restart the server to pick up new data
python -m phase11_search.search_api1
```
