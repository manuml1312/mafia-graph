"""
MAFIA Phase 10 — AST Structural Summaries (Standalone Block)
================================================================
Reads existing entities.jsonl + repo_manifest.json, parses source files
with tree-sitter, and produces ast_summaries.jsonl — one structural
summary per entity that has meaningful internal structure.

Runs independently. No pipeline re-run needed.

Usage:
    python -m phase10_ast.run_ast_summaries
    python -m phase10_ast.run_ast_summaries --output-dir output --languages java,typescript
    python -m phase10_ast.run_ast_summaries --entity-types api:controller,api:service,bff:controller
    python -m phase10_ast.run_ast_summaries --max-entities 5000 --workers 8
    python -m phase10_ast.run_ast_summaries --no-cache
"""

import json
import hashlib
import os
import argparse
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils.ts_parser import (
    is_available, any_available, available_languages,
    parse_file, EXT_TO_LANG,
)
from utils.ast_summarizer import summarize_entity, discover_all_methods


# ── Default entity types to summarize ────────────────────────────────────────

DEFAULT_ENTITY_TYPES = {
    ("api", "controller"),
    ("api", "service"),
    ("api", "repository"),
    ("bff", "controller"),
    ("bff", "middleware"),
    ("ui", "component"),
    ("ui", "hook"),
    ("ui", "fetch_def"),
    ("db", "function"),
}

# ── Cache ────────────────────────────────────────────────────────────────────

class AstCache:
    """Optional cache for AST summaries keyed by file content + entity span."""

    def __init__(self, output_dir: str):
        self._dir = Path(output_dir) / "cache" / "ast"
        self._dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _key(file_path: str, entity_id: str, line_start: int, line_end: int, language: str) -> str:
        h = hashlib.sha256()
        try:
            h.update(Path(file_path).read_bytes())
        except OSError:
            return ""
        h.update(f"\x00{entity_id}:{line_start}:{line_end}:{language}".encode())
        return h.hexdigest()

    def get(self, file_path: str, entity_id: str, line_start: int, line_end: int, language: str):
        key = self._key(file_path, entity_id, line_start, line_end, language)
        if not key:
            return None
        entry = self._dir / f"{key}.json"
        if not entry.exists():
            return None
        try:
            return json.loads(entry.read_text(encoding="utf-8"))
        except Exception:
            return None

    def put(self, file_path: str, entity_id: str, line_start: int, line_end: int, language: str, summary: dict):
        key = self._key(file_path, entity_id, line_start, line_end, language)
        if not key:
            return
        entry = self._dir / f"{key}.json"
        tmp = entry.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(summary, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, entry)
        except Exception:
            tmp.unlink(missing_ok=True)

    def clear(self) -> int:
        count = 0
        for f in self._dir.glob("*.json"):
            f.unlink(missing_ok=True)
            count += 1
        return count


# ── Entity loading ───────────────────────────────────────────────────────────

def _load_entities(output_dir: str) -> list[dict]:
    path = Path(output_dir) / "entities.jsonl"
    entities = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    entities.append(json.loads(line))
    except Exception:
        pass
    return entities


def _load_repo_paths(output_dir: str) -> dict[str, str]:
    """Load repo_id -> root_path mapping from manifest."""
    path = Path(output_dir) / "repo_manifest.json"
    try:
        with open(path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
        return {r["repo_id"]: r["root_path"] for r in manifest.get("repos", [])}
    except Exception:
        return {}


# ── Single entity processing ─────────────────────────────────────────────────

def _process_entity(
    entity: dict,
    repo_paths: dict,
    cache: AstCache = None,
) -> dict:
    """Process one entity. Returns {"summary": dict|None, "status": str, "reason": str}."""
    eid = entity.get("id", "")
    layer = entity.get("layer", "")
    etype = entity.get("type", "")
    repo = entity.get("repo", "")
    rel_file = entity.get("file", "")
    evidence = entity.get("evidence", {})
    line_start = evidence.get("line_start") or entity.get("line")
    line_end = evidence.get("line_end")

    if not rel_file:
        return {"summary": None, "status": "skipped", "reason": "no_file"}
    if not line_start:
        return {"summary": None, "status": "skipped", "reason": "no_line"}

    # Resolve full file path
    repo_root = repo_paths.get(repo, "")
    if not repo_root:
        return {"summary": None, "status": "skipped", "reason": "no_repo_path"}

    full_path = os.path.join(repo_root, rel_file)
    if not os.path.isfile(full_path):
        return {"summary": None, "status": "skipped", "reason": "file_not_found"}

    # Determine language
    ext = Path(rel_file).suffix.lower()
    language = EXT_TO_LANG.get(ext)
    if not language:
        return {"summary": None, "status": "skipped", "reason": "unsupported_language"}
    if not is_available(language):
        return {"summary": None, "status": "skipped", "reason": f"grammar_not_installed:{language}"}

    line_end_val = line_end or line_start

    # Check cache
    if cache:
        cached = cache.get(full_path, eid, line_start, line_end_val, language)
        if cached:
            return {"summary": cached, "status": "cached", "reason": ""}

    # Parse and summarize
    result = parse_file(full_path, language)
    if not result:
        return {"summary": None, "status": "failed", "reason": "parse_error"}

    tree, source = result
    summary = summarize_entity(tree, source, language, line_start, line_end_val, eid)
    if not summary:
        return {"summary": None, "status": "skipped", "reason": "no_node_at_line"}

    # Enrich with entity metadata
    summary["file"] = rel_file
    summary["repo"] = repo
    summary["layer"] = layer
    summary["type"] = etype

    # Cache it
    if cache:
        cache.put(full_path, eid, line_start, line_end_val, language, summary)

    return {"summary": summary, "status": "ok", "reason": ""}


# ── Main ─────────────────────────────────────────────────────────────────────

def run(
    output_dir: str,
    languages: set[str] = None,
    entity_types: set[tuple[str, str]] = None,
    max_entities: int = 20000,
    workers: int = 8,
    use_cache: bool = True,
) -> dict:
    """Run AST summary generation. Returns the report dict."""
    output = Path(output_dir)

    # Check tree-sitter availability
    if not any_available():
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "available": False,
            "reason": "tree-sitter not installed. Run: pip install tree-sitter tree-sitter-java tree-sitter-typescript tree-sitter-javascript tree-sitter-python",
            "summaries_generated": 0,
        }
        _write_report(output, report)
        print(f"\n  [SKIP] tree-sitter not installed.")
        print(f"  Run: pip install tree-sitter tree-sitter-java tree-sitter-typescript tree-sitter-javascript tree-sitter-python")
        return report

    avail_langs = set(available_languages())
    if languages:
        avail_langs &= languages
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 10 -- AST Structural Summaries")
    print(f"{'='*60}")
    print(f"  Languages available: {', '.join(sorted(avail_langs))}")

    # Load entities
    entities = _load_entities(output_dir)
    if not entities:
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "available": True,
            "reason": "no entities found in entities.jsonl",
            "summaries_generated": 0,
        }
        _write_report(output, report)
        print(f"  [SKIP] No entities found in entities.jsonl")
        return report

    repo_paths = _load_repo_paths(output_dir)
    target_types = entity_types or DEFAULT_ENTITY_TYPES

    # Filter eligible entities
    eligible = []
    for e in entities:
        lt = (e.get("layer", ""), e.get("type", ""))
        if lt not in target_types:
            continue
        rel_file = e.get("file", "")
        ext = Path(rel_file).suffix.lower() if rel_file else ""
        lang = EXT_TO_LANG.get(ext, "")
        if lang not in avail_langs:
            continue
        eligible.append(e)

    eligible = eligible[:max_entities]
    print(f"  Entities total: {len(entities)}")
    print(f"  Eligible for AST: {len(eligible)}")
    print(f"  Target types: {', '.join(f'{l}:{t}' for l, t in sorted(target_types))}")
    print(f"  Workers: {workers}")
    print(f"  Cache: {'ON' if use_cache else 'OFF'}")

    if not eligible:
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "available": True,
            "languages": sorted(avail_langs),
            "entities_total": len(entities),
            "entities_eligible": 0,
            "summaries_generated": 0,
            "reason": "no eligible entities for available languages",
        }
        _write_report(output, report)
        print(f"  [SKIP] No eligible entities")
        return report

    # Init cache
    cache = AstCache(output_dir) if use_cache else None

    # Process entities
    summaries = []
    status_counts = {"ok": 0, "cached": 0, "skipped": 0, "failed": 0}
    skip_reasons = {}
    errors = []

    if workers <= 1:
        for entity in eligible:
            result = _process_entity(entity, repo_paths, cache)
            _tally(result, summaries, status_counts, skip_reasons, errors)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_map = {
                pool.submit(_process_entity, entity, repo_paths, cache): entity
                for entity in eligible
            }
            for future in as_completed(future_map):
                try:
                    result = future.result()
                except Exception as exc:
                    entity = future_map[future]
                    result = {"summary": None, "status": "failed", "reason": str(exc)}
                    errors.append({"entity_id": entity.get("id", ""), "error": str(exc)})
                _tally(result, summaries, status_counts, skip_reasons, errors)

    # Write ast_summaries.jsonl
    summaries_path = output / "ast_summaries.jsonl"
    with open(summaries_path, "w", encoding="utf-8") as f:
        for s in summaries:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    # Write report
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "available": True,
        "languages": sorted(avail_langs),
        "entities_total": len(entities),
        "entities_eligible": len(eligible),
        "summaries_generated": status_counts["ok"],
        "summaries_cached": status_counts["cached"],
        "skipped": status_counts["skipped"],
        "failed": status_counts["failed"],
        "skip_reasons": dict(sorted(skip_reasons.items(), key=lambda x: -x[1])),
        "errors": errors[:20],
    }
    _write_report(output, report)

    print(f"\n  Results:")
    print(f"    Generated: {status_counts['ok']}")
    print(f"    Cached:    {status_counts['cached']}")
    print(f"    Skipped:   {status_counts['skipped']}")
    print(f"    Failed:    {status_counts['failed']}")
    if skip_reasons:
        print(f"  Skip reasons:")
        for reason, count in sorted(skip_reasons.items(), key=lambda x: -x[1]):
            print(f"    {reason:35s} {count}")
    print(f"  Output: {summaries_path}")
    print(f"{'='*60}\n")

    return report


def _tally(result, summaries, status_counts, skip_reasons, errors):
    status = result["status"]
    status_counts[status] = status_counts.get(status, 0) + 1
    if result["summary"]:
        summaries.append(result["summary"])
    if status == "skipped" and result["reason"]:
        skip_reasons[result["reason"]] = skip_reasons.get(result["reason"], 0) + 1
    if status == "failed" and result["reason"]:
        errors.append({"reason": result["reason"]})


def _write_report(output: Path, report: dict):
    report_path = output / "ast_summary_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)


# ── Discover mode: walk all source files, summarize every method ───────────

SKIP_DIRS = {
    'node_modules', '.git', 'dist', 'build', 'out', 'target', '.idea',
    '.mvn', '.next', '.gradle', '__pycache__', '.venv', 'venv',
    '_scm_config', '_scm_container', '_scm_jenkins', 'wdyr',
    'test', 'tests', '__tests__', '__test__', 'spec', 'specs',
    'coverage', '.turbo', 'vendor', 'third_party', 'third-party',
    'generated', 'gen',
}

MAX_FILE_SIZE = 2 * 1024 * 1024


def _collect_source_files(repo_path: str, avail_langs: set[str]) -> list[tuple[str, str, str]]:
    """Walk repo and collect (full_path, rel_path, language) for all parseable files."""
    files = []
    for root, dirs, filenames in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fname in filenames:
            ext = Path(fname).suffix.lower()
            lang = EXT_TO_LANG.get(ext)
            if not lang or lang not in avail_langs:
                continue
            fpath = os.path.join(root, fname)
            try:
                if os.path.getsize(fpath) > MAX_FILE_SIZE:
                    continue
            except OSError:
                continue
            rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
            files.append((fpath, rel, lang))
    return files


def _discover_one_file(
    full_path: str,
    rel_path: str,
    language: str,
    repo_id: str,
) -> Optional[list[dict]]:
    """Parse one file and return summaries for all methods/functions found.
    Returns [] if parsed but no methods, None if parse failed."""
    result = parse_file(full_path, language)
    if not result:
        return None
    tree, source = result
    return discover_all_methods(tree, source, language, rel_path, repo_id)


def run_discover(
    output_dir: str,
    languages: set[str] = None,
    workers: int = 8,
) -> dict:
    """Discover mode: walk all source files in all repos, produce AST summaries
    for every method/function, and identify extraction gaps."""
    output = Path(output_dir)

    if not any_available():
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "available": False,
            "mode": "discover",
            "reason": "tree-sitter not installed",
        }
        _write_report(output, report)
        print(f"\n  [SKIP] tree-sitter not installed.")
        return report

    avail_langs = set(available_languages())
    if languages:
        avail_langs &= languages

    repo_paths = _load_repo_paths(output_dir)
    if not repo_paths:
        print(f"  [SKIP] No repo_manifest.json found")
        return {"error": "no manifest"}

    # Load existing entity IDs for gap detection
    existing_entities = _load_entities(output_dir)
    entity_locations = set()
    for e in existing_entities:
        f = e.get("file", "")
        line = e.get("line") or e.get("evidence", {}).get("line_start")
        if f and line:
            entity_locations.add((e.get("repo", ""), f, line))

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 10 -- AST Discover Mode")
    print(f"{'='*60}")
    print(f"  Languages: {', '.join(sorted(avail_langs))}")
    print(f"  Repos: {len(repo_paths)}")
    print(f"  Existing entities: {len(existing_entities)} ({len(entity_locations)} with file+line)")
    print(f"  Workers: {workers}")

    # Collect all source files across all repos
    all_files = []  # (full_path, rel_path, language, repo_id)
    for repo_id, repo_root in repo_paths.items():
        if not os.path.isdir(repo_root):
            continue
        for full_path, rel_path, lang in _collect_source_files(repo_root, avail_langs):
            all_files.append((full_path, rel_path, lang, repo_id))

    print(f"  Source files found: {len(all_files)}")

    if not all_files:
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "available": True,
            "mode": "discover",
            "source_files": 0,
            "methods_discovered": 0,
        }
        _write_report(output, report)
        return report

    # Process all files
    all_summaries = []
    files_parsed = 0
    files_failed = 0
    files_no_methods = 0

    if workers <= 1:
        for full_path, rel_path, lang, repo_id in all_files:
            summaries = _discover_one_file(full_path, rel_path, lang, repo_id)
            if summaries is not None:
                all_summaries.extend(summaries)
                files_parsed += 1
                if not summaries:
                    files_no_methods += 1
            else:
                files_failed += 1
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            future_map = {
                pool.submit(_discover_one_file, fp, rp, lang, rid): (fp, rp, lang, rid)
                for fp, rp, lang, rid in all_files
            }
            for future in as_completed(future_map):
                try:
                    summaries = future.result()
                    if summaries is not None:
                        all_summaries.extend(summaries)
                        files_parsed += 1
                        if not summaries:
                            files_no_methods += 1
                    else:
                        files_failed += 1
                except Exception:
                    files_failed += 1

    # Split into matched (has entity) vs discovered (no entity = gap)
    matched = []
    discovered = []
    for s in all_summaries:
        repo = s.get("repo", "")
        f = s.get("file", "")
        line = s.get("line_start", 0)
        # Check if any entity exists within ±5 lines of this method
        is_matched = False
        for offset in range(-5, 6):
            if (repo, f, line + offset) in entity_locations:
                is_matched = True
                break
        if is_matched:
            s["matched_entity"] = True
            matched.append(s)
        else:
            s["matched_entity"] = False
            discovered.append(s)

    # Write ast_summaries.jsonl (ALL methods — both matched and discovered)
    summaries_path = output / "ast_summaries.jsonl"
    with open(summaries_path, "w", encoding="utf-8") as f:
        for s in all_summaries:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    # Write ast_discovered.jsonl (ONLY methods with no matching entity = gaps)
    discovered_path = output / "ast_discovered.jsonl"
    with open(discovered_path, "w", encoding="utf-8") as f:
        for s in discovered:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")

    # Gap analysis by repo and language
    gap_by_repo = {}
    gap_by_lang = {}
    for s in discovered:
        repo = s.get("repo", "unknown")
        lang = s.get("language", "unknown")
        gap_by_repo[repo] = gap_by_repo.get(repo, 0) + 1
        gap_by_lang[lang] = gap_by_lang.get(lang, 0) + 1

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "available": True,
        "mode": "discover",
        "languages": sorted(avail_langs),
        "source_files_scanned": len(all_files),
        "files_parsed": files_parsed,
        "files_with_methods": files_parsed - files_no_methods,
        "files_no_methods": files_no_methods,
        "files_failed": files_failed,
        "methods_discovered": len(all_summaries),
        "methods_matched_to_entities": len(matched),
        "methods_not_in_graph": len(discovered),
        "extraction_coverage": round(len(matched) / len(all_summaries), 3) if all_summaries else 0,
        "gap_by_repo": dict(sorted(gap_by_repo.items(), key=lambda x: -x[1])),
        "gap_by_language": dict(sorted(gap_by_lang.items(), key=lambda x: -x[1])),
        "existing_entities": len(existing_entities),
    }
    _write_report(output, report)

    print(f"\n  Results:")
    print(f"    Files scanned:           {len(all_files)}")
    print(f"    Files parsed:            {files_parsed}")
    print(f"    Files with methods:      {files_parsed - files_no_methods}")
    print(f"    Files no methods:        {files_no_methods} (interfaces, types, configs)")
    print(f"    Files failed to parse:   {files_failed}")
    print(f"    Methods discovered:      {len(all_summaries)}")
    print(f"    Matched to entities:     {len(matched)}")
    print(f"    NOT in graph (gaps):     {len(discovered)}")
    print(f"    Extraction coverage:     {report['extraction_coverage']:.1%}")
    if gap_by_repo:
        print(f"  Gap by repo (top 10):")
        for repo, count in sorted(gap_by_repo.items(), key=lambda x: -x[1])[:10]:
            print(f"    {repo:50s} {count:5d} methods missing")
    if gap_by_lang:
        print(f"  Gap by language:")
        for lang, count in sorted(gap_by_lang.items(), key=lambda x: -x[1]):
            print(f"    {lang:20s} {count:5d} methods missing")
    print(f"  Output:")
    print(f"    {summaries_path}     ({len(all_summaries)} total)")
    print(f"    {discovered_path}    ({len(discovered)} gaps)")
    print(f"{'='*60}\n")

    return report


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="MAFIA AST Structural Summaries — standalone enrichment block"
    )
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--languages", default=None,
                        help="Comma-separated: java,typescript,javascript,python")
    parser.add_argument("--entity-types", default=None,
                        help="Comma-separated layer:type pairs, e.g. api:controller,bff:controller")
    parser.add_argument("--max-entities", type=int, default=20000)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--no-cache", action="store_true")
    parser.add_argument("--discover", action="store_true",
                        help="Discover mode: walk ALL source files, summarize every method, report extraction gaps")
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    output_dir = args.output_dir or str(base / "output")

    languages = None
    if args.languages:
        languages = set(args.languages.split(","))

    if args.discover:
        run_discover(
            output_dir=output_dir,
            languages=languages,
            workers=args.workers,
        )
    else:
        entity_types = None
        if args.entity_types:
            entity_types = set()
            for pair in args.entity_types.split(","):
                parts = pair.strip().split(":")
                if len(parts) == 2:
                    entity_types.add((parts[0], parts[1]))

        run(
            output_dir=output_dir,
            languages=languages,
            entity_types=entity_types,
            max_entities=args.max_entities,
            workers=args.workers,
            use_cache=not args.no_cache,
        )


if __name__ == "__main__":
    main()
