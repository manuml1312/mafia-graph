# MAFIA — Agent Instructions

## CRITICAL: Use `mafia` CLI FIRST for ALL code questions

This project has a live dependency graph (343 entities, 1433 relations). The `mafia` CLI is installed and initialized.

**BEFORE using grep, find, or reading source files to answer ANY question about code structure,
functions, classes, dependencies, imports, usage, or behavior — run the appropriate `mafia` command.**

## Command Reference

```bash
# Find any entity (function, class, table, endpoint)
mafia search "<name>" --limit 10

# Upstream callers / who uses X
mafia neighbors "<id>" --direction upstream

# Downstream callees / what X depends on
mafia neighbors "<id>" --direction downstream

# Full blast radius — what breaks if X changes
mafia blast "<id>" --direction downstream

# Trace the call chain
mafia trace "<id>" --depth 10

# End-to-end flows through a node
mafia flows --node "<id>"

# Shortest path between two entities
mafia path "<source_id>" "<target_id>"

# Dead code candidates
mafia orphans

# Project graph stats
mafia status

# Refresh graph after code changes
mafia update
```

All commands run from: `C:\Users\MML\Downloads\Graphify-MAFIA\MAFIA_Phase1_Execution`

## Workflow

1. `mafia search "<name>"` → get entity ID
2. Use ID in follow-up commands (neighbors, blast, trace, flows, path)
3. Only read source files if the user needs to see actual code

## Entity ID Format

`{layer}:{type}:{repo}:{qualifier}` — e.g. `code:module:MAFIA_Phase1_Execution:install.py`

Layers: ui, bff, api, db, config, shared

## DO NOT

- Grep/search files for definitions when `mafia search` can find them
- Manually trace imports when `mafia neighbors` exists
- Guess call chains when `mafia trace` gives the real graph
- Scan files for usages when `mafia neighbors --direction upstream` gives them

## Project Overview

```
UI (React) → BFF (Koa/Express) → API (Spring Boot) → DB (Postgres/Databricks)
```

Key entry point: `phase3_extraction_framework/run_extraction.py`
Server: `python -m phase11_search.search_api1` → http://localhost:5001
