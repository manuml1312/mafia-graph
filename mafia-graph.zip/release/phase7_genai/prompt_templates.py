"""
MAFIA Phase 7 — GenAI Prompt Templates (gemini-2.5-flash)
===========================================================
Per-request-type structured prompts. Each prompt:
  - Tells Gemini exactly what the extractor tried and where it got stuck
  - Provides the code context the extractor was looking at
  - Enforces strict JSON output schema
  - Caps confidence at 0.70 in the prompt itself
"""


SYSTEM_CONTEXT = (
    "You are a code analysis specialist assisting the MAFIA extraction pipeline. "
    "Deterministic extractors (regex + AST) have already run. You are called ONLY "
    "for cases they could not handle. Your job is to analyze the provided code and "
    "return structured JSON with entities and relations the extractors missed.\n\n"
    "STRICT RULES:\n"
    "1. Output ONLY valid JSON — no markdown fences, no explanation text\n"
    "2. Every entity/relation MUST have a line number and code snippet as evidence\n"
    "3. Never invent anything not visible in the provided code\n"
    "4. Confidence must be between 0.0 and 0.70 (you are an assist, not the source of truth)\n"
    "5. If you find nothing, return the empty structure shown in the schema\n"
)


# ── Batched repo-level assist prompt ─────────────────────────────────────────

BATCH_ASSIST_PROMPT = """{system}

You are assisting extractors for repo "{repo_id}" (classified as: {classification}).
Below are {request_count} assist requests from extractors that got stuck.
For each request, analyze the code and return what the extractor could not find.

{requests_block}

Return JSON with this exact structure:
{{
  "results": [
    {{
      "request_index": <0-based index matching the request above>,
      "entities": [
        {{
          "type": "<endpoint|controller|service|repository|component|hook|function|table|middleware>",
          "name": "<symbol name>",
          "line": <line_number>,
          "snippet": "<evidence code, max 200 chars>"
        }}
      ],
      "relations": [
        {{
          "source_name": "<caller symbol>",
          "target_name": "<callee symbol or table/function name>",
          "type": "<calls|delegates_to|uses_repo|reads_from|writes_to|fetches|calls_function|calls_api>",
          "line": <line_number>,
          "snippet": "<evidence>"
        }}
      ],
      "pattern_notes": "<optional: describe any wrapper/framework pattern the extractor should learn>"
    }}
  ]
}}"""


# ── Per-request-type context blocks (inserted into requests_block) ───────────

REQUEST_HEADER = "--- Request {index} [{request_type}] ---"

ZERO_EXTRACTION_BLOCK = """File: {file}
Language: {language}
The extractor found 0 entities in this file. It should contain {expected}.
Code:
```
{code}
```
Find any endpoints, controllers, services, components, hooks, or DB references."""

UNRESOLVED_CALL_CHAIN_BLOCK = """File: {file}, Line: {line}
The extractor found method "{method_name}" but could not trace what it calls.
What it tried: {what_i_tried}
What it needs: the service/repository methods this code delegates to.
Method body:
```
{code}
```
Identify the call chain: what services, repositories, or functions does this method invoke?"""

UNRESOLVED_FIELD_BLOCK = """File: {file}, Line: {line}
The extractor sees a field call like "this.{field_name}.{method_name}()" but cannot
resolve "{field_name}" to a concrete class/file.
What it tried: {what_i_tried}
Known files in this repo: {known_files}
Code context:
```
{code}
```
What class is "{field_name}" likely to be? What file would it map to?"""

COMPLEX_BODY_BLOCK = """File: {file}, Line: {line}
The extractor found a method but its body uses lambdas, streams, or nested logic
that regex cannot parse. It needs the service/repo calls inside.
Method body:
```
{code}
```
Extract all service calls, repository calls, and DB function references from this body."""

DYNAMIC_URL_BLOCK = """File: {file}, Line: {line}
The extractor found an HTTP call but the URL is built dynamically (template literals,
string concatenation, or variable references). It cannot extract the endpoint path.
Code context:
```
{code}
```
What is the likely endpoint path this code calls? Include the HTTP method if visible."""

WRAPPER_PATTERN_BLOCK = """File: {file}
This file has {entity_count} entities but {relation_count} relations — the extractor
suspects custom wrappers are hiding standard framework calls.
Code:
```
{code}
```
Identify any wrapper functions/classes that abstract: HTTP calls, route registration,
DB queries, or service delegation. For each wrapper, show what it wraps."""

ADDITIONAL_BLOCK = """File: {file}, Line: {line}
Request type: {request_type}
Context: {context}
What the extractor tried: {what_i_tried}
What it needs: {what_i_need}
Code:
```
{code}
```
Analyze and return any entities or relations visible in this code."""


# ── Post-hoc gap analysis (cross-layer, runs after all repos) ────────────────

CROSS_LAYER_MAPPING_PROMPT = """{system}

Our pipeline extracted entities across UI, BFF, API, and DB layers but some
cross-layer mappings could not be resolved deterministically.

Source entity ({source_layer}): {source_id}
  Name: {source_name}
  File: {source_file}
  Code context:
```
{source_snippet}
```

Known {target_layer} entities (candidates):
{target_candidates}

Which target entity does this source most likely connect to?
Consider: URL path segments, naming conventions, constant references, import chains.

Return JSON:
{{
  "best_match": {{
    "target_id": "<entity ID from candidates, or null>",
    "confidence": <0.0-0.70>,
    "reasoning": "<evidence-based explanation>"
  }},
  "alternatives": [
    {{"target_id": "<id>", "confidence": <float>, "reasoning": "<why>"}}
  ]
}}"""


# ── Template selector ────────────────────────────────────────────────────────

REQUEST_TEMPLATES = {
    "zero_extraction": ZERO_EXTRACTION_BLOCK,
    "unresolved_call_chain": UNRESOLVED_CALL_CHAIN_BLOCK,
    "unresolved_field_type": UNRESOLVED_FIELD_BLOCK,
    "complex_body_parse": COMPLEX_BODY_BLOCK,
    "dynamic_url_resolution": DYNAMIC_URL_BLOCK,
    "wrapper_pattern": WRAPPER_PATTERN_BLOCK,
}
