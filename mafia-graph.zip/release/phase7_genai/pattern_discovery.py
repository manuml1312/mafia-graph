"""
MAFIA Phase 7 — GenAI-Assisted Pattern Discovery (Team-Player Architecture)
=============================================================================
GenAI operates as an on-call specialist that extractors consult when stuck,
NOT as a standalone post-processing phase.

Two modes of operation:
  1. INLINE ASSIST (during extraction):
     Extractors call self.request_assist() when regex/AST hits a wall.
     After each repo finishes, the dispatcher passes collected requests to
     GenAIAssistResolver.resolve_repo_requests() which batches them into
     efficient Gemini calls and emits resolved entities/relations.

  2. POST-HOC GAP ANALYSIS (after all extraction):
     run_posthoc_analysis() reads coverage + mapping reports and resolves
     cross-layer mapping gaps that no single extractor could see.

Budget: ~150 calls/pipeline, ~15 calls/repo, batched 3-5 requests per call.
All outputs: evidence_method="genai", confidence ≤ 0.70.
Produces: genai_suggestions.json

Usage:
    # Inline (wired by dispatcher automatically when --enable-genai):
    resolver = GenAIAssistResolver(client)
    dispatcher.enable_genai(resolver)

    # Post-hoc (called from run_extraction.py):
    resolver.run_posthoc_analysis(output_dir, manifest_path)
"""

import json
import os
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase7_genai.gemini_client import GeminiClient
from phase7_genai.prompt_templates import (
    SYSTEM_CONTEXT, BATCH_ASSIST_PROMPT, REQUEST_HEADER,
    REQUEST_TEMPLATES, ADDITIONAL_BLOCK, CROSS_LAYER_MAPPING_PROMPT,
)
from schemas.emitter import CanonicalEmitter


# ── Budget limits ────────────────────────────────────────────────────────────

MAX_CALLS_PER_REPO = 15
MAX_CALLS_PER_PIPELINE = 150
MAX_REQUESTS_PER_BATCH = 5
GENAI_CONFIDENCE_CAP = 0.70


# ── Inline assist resolver ───────────────────────────────────────────────────

class GenAIAssistResolver:
    """Resolves extractor assist requests via batched Gemini calls."""

    def __init__(self, client: GeminiClient):
        self._client = client
        self._total_calls = 0
        self._total_entities = 0
        self._total_relations = 0
        self._all_suggestions: list[dict] = []
        self._all_requests_log: list[dict] = []

    @property
    def is_available(self) -> bool:
        return self._client.is_available and self._total_calls < MAX_CALLS_PER_PIPELINE

    # ── Per-repo inline resolution ───────────────────────────────────────────

    def resolve_repo_requests(
        self, repo_id: str, repo_path: str, repo_meta: dict,
        requests: list[dict],
    ) -> Optional[CanonicalEmitter]:
        """
        Resolve a batch of assist requests for one repo.
        Called by the dispatcher after all extractors finish for a repo.
        Returns a CanonicalEmitter with GenAI-discovered entities/relations,
        or None if nothing was found or budget exhausted.
        """
        if not self.is_available or not requests:
            return None

        # Budget: cap requests per repo
        requests = requests[:MAX_REQUESTS_PER_BATCH * (MAX_CALLS_PER_REPO // 1)]
        classification = ", ".join(repo_meta.get("classification", ["unknown"]))
        emitter = CanonicalEmitter("genai_inline")
        repo_calls = 0

        # Batch requests into groups of MAX_REQUESTS_PER_BATCH
        for batch_start in range(0, len(requests), MAX_REQUESTS_PER_BATCH):
            if repo_calls >= MAX_CALLS_PER_REPO or self._total_calls >= MAX_CALLS_PER_PIPELINE:
                break

            batch = requests[batch_start:batch_start + MAX_REQUESTS_PER_BATCH]
            requests_block = self._build_requests_block(batch, repo_path)

            prompt = BATCH_ASSIST_PROMPT.format(
                system=SYSTEM_CONTEXT,
                repo_id=repo_id,
                classification=classification,
                request_count=len(batch),
                requests_block=requests_block,
            )

            response = self._client.generate(prompt)
            self._total_calls += 1
            repo_calls += 1

            if not response:
                continue

            parsed = _safe_parse_json(response)
            if not parsed or "results" not in parsed:
                continue

            # Process each result and emit into the canonical emitter
            for result in parsed.get("results", []):
                idx = result.get("request_index", -1)
                if idx < 0 or idx >= len(batch):
                    continue
                req = batch[idx]

                for ent in result.get("entities", []):
                    etype = _normalize_type(ent.get("type", ""), repo_meta.get("classification", []))
                    if not etype:
                        continue
                    layer, entity_type = etype
                    try:
                        emitter.emit_entity(
                            layer=layer, entity_type=entity_type, repo=repo_id,
                            qualifier=f"{req['file']}::{ent.get('name', 'unknown')}",
                            name=ent.get("name", "unknown"),
                            file=req["file"], line=ent.get("line", 1),
                            confidence=min(GENAI_CONFIDENCE_CAP, 0.65),
                            evidence_file=req["file"], evidence_method="genai",
                            evidence_line_start=ent.get("line", 1),
                            evidence_snippet=ent.get("snippet", "")[:200],
                            properties={
                                "genai_request_type": req["request_type"],
                                "genai_extractor": req["extractor"],
                            },
                            warnings=["genai_assisted: resolved by Gemini from extractor assist request"],
                        )
                        self._total_entities += 1
                    except Exception:
                        pass

                for rel in result.get("relations", []):
                    rtype = rel.get("type", "")
                    from schemas.id_format import RELATION_TYPES
                    if rtype not in RELATION_TYPES:
                        continue
                    # Resolve source and target to real entity IDs
                    src_id = self._resolve_entity_id(
                        rel.get("source_name", ""), repo_id, repo_meta, req, emitter)
                    tgt_id = self._resolve_entity_id(
                        rel.get("target_name", ""), repo_id, repo_meta, req, emitter)
                    if not src_id or not tgt_id:
                        continue
                    try:
                        emitter.emit_relation(
                            source_id=src_id, target_id=tgt_id,
                            relation_type=rtype,
                            confidence=min(GENAI_CONFIDENCE_CAP, 0.60),
                            evidence_file=req["file"], evidence_method="genai",
                            evidence_line_start=rel.get("line"),
                            evidence_snippet=rel.get("snippet", "")[:200],
                            properties={"genai_request_type": req["request_type"]},
                        )
                        self._total_relations += 1
                    except Exception:
                        pass

                # Log suggestion
                self._all_suggestions.append({
                    "repo": repo_id,
                    "request_type": req["request_type"],
                    "file": req["file"],
                    "entities_found": len(result.get("entities", [])),
                    "relations_found": len(result.get("relations", [])),
                    "pattern_notes": result.get("pattern_notes", ""),
                })

            # Log all requests for the report
            for req in batch:
                self._all_requests_log.append({**req, "repo_id": repo_id})

        if emitter.stats()["entity_ids"] == 0 and emitter.stats()["relation_ids"] == 0:
            return None
        return emitter

    def _resolve_entity_id(self, name, repo_id, repo_meta, req, emitter):
        """Resolve a GenAI-provided symbol name to a real entity ID.
        Searches: 1) emitter's own entities (just emitted by GenAI),
        2) name pattern in the request's file context,
        3) constructs a canonical ID using the request file path."""
        if not name:
            return None
        name_lower = name.lower().split(".")[-1]  # strip class prefix like "raveService.method"

        # 1. Search GenAI-emitted entities in this batch
        for eid, ent in emitter._entities.items():
            if ent.get("repo") == repo_id and name_lower in eid.lower():
                return eid

        # 2. Construct canonical ID using the request's file path
        # This matches how the deterministic extractors build IDs
        req_file = req.get("file", "")
        classification = repo_meta.get("classification", ["api"])
        layer = classification[0] if classification[0] in ("ui", "bff", "api", "db") else "api"

        # Try the most common patterns
        for etype in ("service", "controller", "repository"):
            candidate = f"{layer}:{etype}:{repo_id}:{req_file}::{name_lower}"
            if candidate in emitter._entities:
                return candidate

        # 3. Emit the entity now so the relation has a valid target
        from schemas.id_format import ENTITY_TYPES
        for etype in ("service", "repository", "controller"):
            if etype in ENTITY_TYPES.get(layer, set()):
                try:
                    return emitter.emit_entity(
                        layer=layer, entity_type=etype, repo=repo_id,
                        qualifier=f"{req_file}::{name_lower}",
                        name=name,
                        file=req_file, line=req.get("line", 1),
                        confidence=min(GENAI_CONFIDENCE_CAP, 0.55),
                        evidence_file=req_file, evidence_method="genai",
                        evidence_line_start=req.get("line", 1),
                        properties={"genai_resolved": True},
                        warnings=["genai_assisted: entity created for relation target"],
                    )
                except Exception:
                    continue
        return None

    # ── Build the requests block for the batch prompt ────────────────────

    def _build_requests_block(self, batch: list[dict], repo_path: str) -> str:
        blocks = []
        for i, req in enumerate(batch):
            header = REQUEST_HEADER.format(index=i, request_type=req["request_type"])

            template = REQUEST_TEMPLATES.get(req["request_type"], ADDITIONAL_BLOCK)

            # Build template kwargs from the request
            kwargs = {
                "file": req.get("file", ""),
                "line": req.get("line", ""),
                "code": req.get("code_snippet", "") or req.get("context", ""),
                "language": _guess_language(req.get("file", "")),
                "what_i_tried": req.get("what_i_tried", "regex pattern matching"),
                "what_i_need": req.get("what_i_need", "entities and relations in this code"),
                "context": req.get("context", ""),
                "request_type": req.get("request_type", ""),
                # Type-specific fields from extra
                "method_name": req.get("extra", {}).get("method_name", ""),
                "field_name": req.get("extra", {}).get("field_name", ""),
                "known_files": req.get("extra", {}).get("known_files", ""),
                "entity_count": req.get("extra", {}).get("entity_count", 0),
                "relation_count": req.get("extra", {}).get("relation_count", 0),
                "expected": req.get("extra", {}).get("expected", "entities"),
            }

            # Read file content if code_snippet not provided
            if not kwargs["code"] and repo_path:
                full_path = os.path.join(repo_path, req.get("file", ""))
                if os.path.exists(full_path):
                    try:
                        with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                            kwargs["code"] = f.read(16000)
                    except Exception:
                        pass

            try:
                body = template.format(**kwargs)
            except KeyError:
                body = ADDITIONAL_BLOCK.format(**kwargs)

            blocks.append(f"{header}\n{body}")

        return "\n\n".join(blocks)

    # ── Post-hoc gap analysis (cross-layer mappings) ─────────────────────────

    def run_posthoc_analysis(self, output_dir: str, manifest_path: Optional[str] = None) -> dict:
        """
        Post-hoc analysis: resolve cross-layer mapping gaps that no single
        extractor could see. Runs after all extraction + structural relations.
        """
        output = Path(output_dir)
        if not self.is_available:
            return self._build_report(output, "budget_exhausted_or_unavailable")

        mapping = _load_json(output / "mapping_confidence_report.json")
        entities = _load_jsonl(output / "entities.jsonl")
        entity_map = {e["id"]: e for e in entities}
        manifest = _load_json(Path(manifest_path)) if manifest_path else _load_json(output / "repo_manifest.json")
        repo_map = {r["repo_id"]: r for r in manifest.get("repos", [])}

        emitter = CanonicalEmitter("genai_posthoc")
        posthoc_calls = 0

        for hop_name in ("ui_to_bff", "bff_to_api"):
            hop = mapping.get("layer_mappings", {}).get(hop_name, {})
            unresolved = hop.get("unresolved_details", [])
            if not unresolved:
                continue

            src_layer, tgt_layer = hop_name.split("_to_")
            tgt_entities = [
                e for e in entity_map.values()
                if e.get("layer") == tgt_layer and e.get("type") in ("endpoint", "controller")
            ]
            target_summary = "\n".join(
                f"  - {e['id']}: {e.get('name', '')} (file: {e.get('file', '')})"
                for e in tgt_entities[:40]
            )

            for src_id in unresolved[:10]:
                if posthoc_calls >= 10 or self._total_calls >= MAX_CALLS_PER_PIPELINE:
                    break
                src = entity_map.get(src_id, {})
                if not src:
                    continue

                # Read source context
                repo_meta = repo_map.get(src.get("repo", ""), {})
                snippet = _read_context(repo_meta.get("root_path", ""), src.get("file", ""), src.get("line"))

                prompt = CROSS_LAYER_MAPPING_PROMPT.format(
                    system=SYSTEM_CONTEXT,
                    source_layer=src_layer, target_layer=tgt_layer,
                    source_id=src_id, source_name=src.get("name", ""),
                    source_file=src.get("file", ""),
                    source_snippet=snippet[:4000],
                    target_candidates=target_summary[:4000],
                )

                response = self._client.generate(prompt)
                self._total_calls += 1
                posthoc_calls += 1

                if not response:
                    continue
                parsed = _safe_parse_json(response)
                if not parsed:
                    continue

                best = parsed.get("best_match", {})
                if best.get("target_id") and best.get("confidence", 0) >= 0.40:
                    from schemas.id_format import RELATION_TYPES
                    rtype = "fetches" if hop_name == "ui_to_bff" else "calls_api"
                    if rtype in RELATION_TYPES:
                        try:
                            emitter.emit_relation(
                                source_id=src_id, target_id=best["target_id"],
                                relation_type=rtype,
                                confidence=min(GENAI_CONFIDENCE_CAP, best["confidence"]),
                                evidence_file=src.get("file", ""), evidence_method="genai",
                                properties={
                                    "genai_reasoning": best.get("reasoning", ""),
                                    "genai_task": "posthoc_mapping",
                                },
                            )
                            self._total_relations += 1
                        except Exception:
                            pass

                    self._all_suggestions.append({
                        "repo": src.get("repo", ""),
                        "request_type": "cross_layer_mapping",
                        "file": src.get("file", ""),
                        "hop": hop_name,
                        "source": src_id,
                        "target": best["target_id"],
                        "confidence": best.get("confidence", 0),
                        "reasoning": best.get("reasoning", ""),
                    })

        # Flush posthoc entities/relations
        if emitter.stats()["entity_ids"] > 0 or emitter.stats()["relation_ids"] > 0:
            emitter.flush(
                str(output / "entities.jsonl"),
                str(output / "relations.jsonl"),
            )

        return self._build_report(output)

    # ── Report generation ────────────────────────────────────────────────────

    def _build_report(self, output: Path, status: str = "completed") -> dict:
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "status": status,
            "genai_model": self._client.model_name,
            "budget": {
                "max_per_repo": MAX_CALLS_PER_REPO,
                "max_per_pipeline": MAX_CALLS_PER_PIPELINE,
                "calls_used": self._total_calls,
                "calls_remaining": MAX_CALLS_PER_PIPELINE - self._total_calls,
            },
            "totals": {
                "entities_emitted": self._total_entities,
                "relations_emitted": self._total_relations,
                "suggestions": len(self._all_suggestions),
                "requests_processed": len(self._all_requests_log),
            },
            "by_request_type": _count_by_key(self._all_requests_log, "request_type"),
            "suggestions": self._all_suggestions,
            "gemini_stats": self._client.stats(),
        }

        report_path = output / "genai_suggestions.json"
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        # Print summary
        print(f"\n{'='*60}")
        print(f"  MAFIA Phase 7 -- GenAI Assist Summary")
        print(f"{'='*60}")
        print(f"  Gemini calls used:    {self._total_calls}/{MAX_CALLS_PER_PIPELINE}")
        print(f"  Requests processed:   {len(self._all_requests_log)}")
        print(f"  Entities emitted:     {self._total_entities}")
        print(f"  Relations emitted:    {self._total_relations}")
        print(f"  By type: {_count_by_key(self._all_requests_log, 'request_type')}")
        print(f"  Tokens used:          {self._client.stats()['total_tokens']}")
        print(f"  Report: {report_path}")
        print(f"{'='*60}\n")

        return report

    def stats(self) -> dict:
        return {
            "calls_used": self._total_calls,
            "entities_emitted": self._total_entities,
            "relations_emitted": self._total_relations,
            "requests_processed": len(self._all_requests_log),
        }


# ── Helpers ──────────────────────────────────────────────────────────────────

def _safe_parse_json(text: str) -> Optional[dict]:
    if not text:
        return None
    text = text.strip()
    # Strip markdown fences
    if text.startswith("```"):
        lines = text.splitlines()
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end])
            except json.JSONDecodeError:
                pass
    return None


def _normalize_type(raw: str, classification: list[str]) -> Optional[tuple[str, str]]:
    """Map GenAI type string to (layer, entity_type) tuple."""
    from schemas.id_format import ENTITY_TYPES
    raw = raw.lower().strip()
    type_map = {
        "endpoint": "endpoint", "route": "endpoint", "api_endpoint": "endpoint",
        "controller": "controller", "handler": "controller",
        "service": "service", "repository": "repository", "dao": "repository",
        "component": "component", "page": "component",
        "hook": "hook", "function": "function",
        "table": "table", "view": "view",
        "middleware": "middleware",
    }
    etype = type_map.get(raw)
    if not etype:
        return None
    # Find which layer this type belongs to, preferring the repo's classification
    for c in classification:
        if c in ENTITY_TYPES and etype in ENTITY_TYPES[c]:
            return (c, etype)
    for layer, types in ENTITY_TYPES.items():
        if etype in types:
            return (layer, etype)
    return None


def _guess_entity_id(name: str, repo_id: str, repo_meta: dict) -> Optional[str]:
    """Best-effort entity ID construction from a symbol name."""
    if not name:
        return None
    classification = repo_meta.get("classification", ["shared"])
    layer = classification[0] if classification[0] in ("ui", "bff", "api", "db") else "shared"
    return f"{layer}:service:{repo_id}:{name}"


def _guess_language(file_path: str) -> str:
    ext = Path(file_path).suffix.lower()
    return {
        '.ts': 'typescript', '.tsx': 'typescript',
        '.js': 'javascript', '.jsx': 'javascript',
        '.java': 'java', '.py': 'python', '.sql': 'sql',
    }.get(ext, 'unknown')


def _read_context(repo_path: str, file: str, line: Optional[int] = None) -> str:
    if not repo_path or not file:
        return ""
    full = os.path.join(repo_path, file)
    try:
        with open(full, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        if line:
            lines = content.splitlines()
            start = max(0, (line or 1) - 5)
            end = min(len(lines), (line or 1) + 25)
            return "\n".join(lines[start:end])
        return content[:8000]
    except Exception:
        return ""


def _count_by_key(items: list[dict], key: str) -> dict:
    counts = {}
    for item in items:
        val = item.get(key, "unknown")
        counts[val] = counts.get(val, 0) + 1
    return counts


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items
