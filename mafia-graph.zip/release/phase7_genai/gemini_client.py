"""
MAFIA Phase 7 — Gemini Client (Organisation Service Account)
==============================================================
Calls Gemini via Vertex AI REST API using organisation service account
credentials and AuthorizedSession. Handles ZScaler cert bypass,
rate limiting, retries, and token tracking.

Mirrors the proven pattern from bff_api_mapping/RAG/gemini_client.py.

Configuration:
  SA_KEY_PATH   — path to service account JSON key file
  CERT_FILE     — path to merged CA cert (ZScaler bypass)
  GCP_PROJECT   — GCP project ID (default: gcp-vpcx-acl)
  GCP_LOCATION  — GCP region (default: us-central1)
  GEMINI_MODEL  — model name (default: gemini-2.5-flash)

Usage:
    client = GeminiClient()                          # uses defaults
    client = GeminiClient.from_env()                 # reads env vars
    client = GeminiClient(sa_key_path="path/to/key.json")
    response = client.generate("Analyze this code...")
"""

import os
import time
import threading
from pathlib import Path
from typing import Optional, List


# ── Defaults (resolved from centralized config) ─────────────────────────────

try:
    from utils.ai_config import get_ai_config as _get_ai_cfg
    _ai = _get_ai_cfg()
except Exception:
    _ai = None

DEFAULT_SA_KEY_PATH = _ai.sa_key_path if _ai else ""
DEFAULT_CERT_FILE = _ai.cert_file if _ai else ""
DEFAULT_GCP_PROJECT = _ai.gcp_project if _ai else ""
DEFAULT_GCP_LOCATION = _ai.gcp_location if _ai else "us-central1"
DEFAULT_GEMINI_MODEL = _ai.gemini_model if _ai else "gemini-2.5-flash"
DEFAULT_MAX_RPM = _ai.max_rpm if _ai else 30


class GeminiClient:
    """Gemini API client via Vertex AI REST + service account auth."""

    def __init__(
        self,
        sa_key_path: Optional[str] = None,
        cert_file: Optional[str] = None,
        project: Optional[str] = None,
        location: Optional[str] = None,
        model: Optional[str] = None,
        max_rpm: int = DEFAULT_MAX_RPM,
    ):
        self.sa_key_path = sa_key_path or DEFAULT_SA_KEY_PATH
        self.cert_file = cert_file or DEFAULT_CERT_FILE
        self.project = project or DEFAULT_GCP_PROJECT
        self.location = location or DEFAULT_GCP_LOCATION
        self.model = model or DEFAULT_GEMINI_MODEL
        self.max_rpm = max_rpm

        self._session = None
        self._available = False
        self._lock = threading.Lock()
        self._request_times: list[float] = []
        self._total_requests = 0
        self._total_tokens = 0

        self._init_client()

    def _init_client(self):
        """Authenticate with service account and build Vertex AI URLs."""
        if not os.path.exists(self.sa_key_path):
            print(f"  [WARN] Service account key not found: {self.sa_key_path}")
            print(f"         GenAI features disabled.")
            return

        try:
            from google.oauth2 import service_account
            from google.auth.transport.requests import AuthorizedSession

            # ZScaler cert bypass
            if os.path.exists(self.cert_file):
                os.environ['REQUESTS_CA_BUNDLE'] = self.cert_file
                os.environ['GRPC_DEFAULT_SSL_ROOTS_FILE_PATH'] = self.cert_file

            self._creds = service_account.Credentials.from_service_account_file(
                self.sa_key_path,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
            self._session = AuthorizedSession(self._creds)

            if os.path.exists(self.cert_file):
                self._session.verify = self.cert_file

            # Vertex AI generateContent endpoint
            self._generate_url = (
                f"https://{self.location}-aiplatform.googleapis.com/v1/"
                f"projects/{self.project}/locations/{self.location}/"
                f"publishers/google/models/{self.model}:generateContent"
            )

            self._available = True
            print(f"  [OK] Gemini client initialized (project={self.project}, model={self.model})")

        except ImportError:
            print("  [WARN] google-auth not installed. GenAI features disabled.")
        except Exception as e:
            print(f"  [WARN] Gemini init failed: {e}. GenAI features disabled.")

    @classmethod
    def from_env(cls) -> "GeminiClient":
        """Create client from environment variables with org defaults."""
        return cls(
            sa_key_path=os.environ.get("SA_KEY_PATH", DEFAULT_SA_KEY_PATH),
            cert_file=os.environ.get("CERT_FILE_PATH", DEFAULT_CERT_FILE),
            project=os.environ.get("GCP_PROJECT", DEFAULT_GCP_PROJECT),
            location=os.environ.get("GCP_LOCATION", DEFAULT_GCP_LOCATION),
            model=os.environ.get("GEMINI_MODEL", DEFAULT_GEMINI_MODEL),
            max_rpm=int(os.environ.get("GEMINI_MAX_RPM", str(DEFAULT_MAX_RPM))),
        )

    @property
    def is_available(self) -> bool:
        return self._available and self._session is not None

    @property
    def model_name(self) -> str:
        return self.model

    # ── Rate limiting ────────────────────────────────────────────────────────

    def _wait_for_rate_limit(self):
        """Block until we're under the RPM limit."""
        with self._lock:
            now = time.time()
            self._request_times = [t for t in self._request_times if now - t < 60]
            if len(self._request_times) >= self.max_rpm:
                wait = 60 - (now - self._request_times[0]) + 0.5
                if wait > 0:
                    time.sleep(wait)
            self._request_times.append(time.time())

    # ── Core API call ────────────────────────────────────────────────────────

    def generate(self, prompt: str, max_retries: int = 4, temperature: float = 0.1) -> Optional[str]:
        """Send prompt to Gemini via Vertex AI REST. Returns text or None."""
        if not self.is_available:
            return None

        self._wait_for_rate_limit()

        payload = {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": 4096,
            },
        }

        last_err = None
        for attempt in range(max_retries):
            try:
                resp = self._session.post(
                    self._generate_url, json=payload, timeout=120
                )

                # Rate limited — back off
                if resp.status_code == 429:
                    time.sleep(min(60, 2 ** (attempt + 2)))
                    continue

                # Server error — retry
                if resp.status_code >= 500:
                    raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:300]}")

                resp.raise_for_status()

                result = resp.json()
                parts = result["candidates"][0]["content"]["parts"]
                text = parts[0]["text"].strip()

                with self._lock:
                    self._total_requests += 1
                    # Track tokens if available
                    usage = result.get("usageMetadata", {})
                    self._total_tokens += usage.get("totalTokenCount", 0)

                return text

            except Exception as e:
                last_err = e
                if attempt < max_retries - 1:
                    time.sleep(min(30, 1.6 ** attempt))

        print(f"  [WARN] Gemini call failed after {max_retries} attempts: {last_err}")
        return None

    # ── Stats ────────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        return {
            "model": self.model,
            "project": self.project,
            "available": self._available,
            "total_requests": self._total_requests,
            "total_tokens": self._total_tokens,
        }
