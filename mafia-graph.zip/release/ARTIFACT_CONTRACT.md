# MAFIA Phase 1 — Artifact Contract Document

## Overview

This document defines the 5 canonical artifacts that form the foundation of the entire MAFIA pipeline. Every pipeline stage — extraction, mapping, coverage auditing, AI enrichment, graph construction, vector indexing, and serving — reads from or writes to these artifacts.

**No downstream stage may invent its own schema.** All data flows through these 5 artifacts.

---

## The 5 Artifacts

| # | Artifact | Format | Produced By | Consumed By |
|---|----------|--------|-------------|-------------|
| 1 | `repo_manifest.json` | JSON | Phase 2: Repo Intake | All extractors (to know what to scan) |
| 2 | `entities.jsonl` | JSONL | Phase 4: Entity Extraction | Relation extraction, coverage audit, mapping, graph, vector index |
| 3 | `relations.jsonl` | JSONL | Phase 5: Relation Extraction | Coverage audit, mapping, graph, flow assembly, blast radius |
| 4 | `coverage_report.json` | JSON | Phase 6: Coverage Audit | Human review, pipeline gating |
| 5 | `mapping_confidence_report.json` | JSON | Phase 7: Mapping Evaluation | Human review, pipeline gating, AI enrichment decisions |

---

## Artifact 1: `repo_manifest.json`

**Purpose:** Describes what was discovered on disk. Every extractor reads this to know what repos exist, what type they are, and what stack they use.

**Key fields:**
- `repo_id` — folder name, used as foreign key everywhere
- `classification` — multi-label: `["ui"]`, `["bff"]`, `["api"]`, `["api", "db"]`
- `detected_stack` — drives extractor selection
- `classification_confidence` — how sure we are about the classification
- `detection_signals` — what evidence led to the classification

**Quality gate:** Every repo on disk must appear. Classification confidence must be ≥ 0.50 or flagged as `unknown`.

---

## Artifact 2: `entities.jsonl`

**Purpose:** Canonical list of every extracted node in the system. One line per entity.

**Key fields:**
- `id` — canonical format: `{layer}:{type}:{repo}:{qualifier}`
- `layer` — `ui | bff | api | db | config | shared`
- `type` — per-layer type (see `id_format.py`)
- `confidence` — 0.0 to 1.0
- `evidence` — MANDATORY: repo, file, line, snippet, extractor name, extraction method

**Entity types by layer:**

| Layer | Types |
|-------|-------|
| ui | component, hook, selector, route, fetch_def, env_var, module |
| bff | endpoint, controller, middleware, service, constant |
| api | endpoint, controller, service, repository, entity, dto, util, config |
| db | function, table, view, schema |
| config | env, toggle, property, secret |
| shared | library, module |

**Quality gate:** Every entity must have evidence. No entity may have confidence < 0.30 without a warning.

---

## Artifact 3: `relations.jsonl`

**Purpose:** Canonical list of every extracted edge between entities. One line per relation.

**Key fields:**
- `id` — format: `{source_id}--{type}-->{target_id}`
- `source` / `target` — must be valid entity IDs from `entities.jsonl`
- `type` — from the defined relation types
- `confidence` — 0.0 to 1.0
- `evidence` — MANDATORY
- `unresolved_target` — if target entity couldn't be resolved, store raw reference
- `candidates` — if ambiguous, store all candidate targets with scores

**Relation types:**

| Category | Types |
|----------|-------|
| Structural | defined_in, belongs_to_repo, belongs_to_layer, imports, exports |
| Behavioral | calls, invokes_http, routes_to, delegates_to, uses_repo |
| Data | reads_from, writes_to, calls_function, uses_table, entity_maps_to |
| Config | depends_on_config, validates_with |
| Cross-layer | fetches, calls_api |

**Quality gate:** Source entity must exist. Target entity must exist OR `unresolved_target` must be set. No relation without evidence.

---

## Artifact 4: `coverage_report.json`

**Purpose:** Measures extraction completeness. Tells you whether the artifacts are trustworthy enough for downstream use.

**Key sections:**
- `file_coverage` — files scanned vs parsed vs failed vs zero-extraction
- `entity_coverage` — counts by layer and type, low-confidence counts
- `relation_coverage` — unresolved targets, dangling references
- `gaps` — ranked list of critical/warning/info gaps

**Quality gate:** Parse rate must be ≥ 90%. Extraction rate must be ≥ 80%. Critical gaps must be zero before proceeding to flow generation.

---

## Artifact 5: `mapping_confidence_report.json`

**Purpose:** Measures cross-layer mapping quality. Tells you whether UI→BFF→API→DB chains are reliable.

**Key sections:**
- `layer_mappings.ui_to_bff` — exact/heuristic/inferred/unresolved counts
- `layer_mappings.bff_to_api` — same breakdown
- `layer_mappings.api_to_db` — same breakdown, plus function vs table confidence
- `hotspots` — specific mappings that are ambiguous or low-confidence
- `summary.ready_for_flow_gen` — boolean gate

**Quality gate:** `ready_for_flow_gen` must be `true` before AI enrichment or flow assembly runs.

---

## Confidence Scoring Rules

| Score | Label | Meaning | Example |
|-------|-------|---------|---------|
| 0.95 | exact | Deterministic match from AST or known pattern | `@GetMapping("/flagTypes")` → endpoint |
| 0.85 | strong | High-confidence heuristic with context | Naming convention + file location |
| 0.70 | inferred | Cross-file resolution, URL segment match | BFF `flagTypes_API` → API `/flagTypes` by last segment |
| 0.50 | weak | Partial evidence, some ambiguity | Multiple candidate targets |
| 0.30 | guess | Very low evidence, flagged for review | Dynamic dispatch, reflection |

---

## Evidence Format

Every entity and relation MUST have an evidence object:

```json
{
  "repo": "marvel_flags_bff",
  "file": "src/app/controller/controller.ts",
  "line_start": 28,
  "line_end": 65,
  "snippet": "async getFlagTypesAndCustomFlagLables(ctx: Context, next: Next) {",
  "extractor": "bff_entity_extractor",
  "method": "regex"
}
```

**Required fields:** `repo`, `file`, `extractor`
**Strongly recommended:** `line_start`, `snippet`, `method`
**Method values:** `ast`, `regex`, `heuristic`, `inferred`, `manual`

---

## What This Replaces From the Current System

| Current File | Replaced By | Notes |
|---|---|---|
| `bff_endpoints.json` | `entities.jsonl` (layer=bff) + `relations.jsonl` | Entities + routes_to relations |
| `api_endpoints.json` | `entities.jsonl` (layer=api) + `relations.jsonl` | Entities + delegates_to/uses_repo relations |
| `db_layer_mapping.json` | `entities.jsonl` (layer=db) + `relations.jsonl` | Entities + calls_function/uses_table relations |
| `ui_snapshot.json` | `entities.jsonl` (layer=ui) + `relations.jsonl` | Entities + calls/fetches relations |
| `bff_to_api_mapping.json` | `relations.jsonl` (type=calls_api) | Cross-layer relations with confidence |
| `ui_to_bff_mapping.json` | `relations.jsonl` (type=fetches) | Cross-layer relations with confidence |
| `e2e_flow.json` | Assembled from graph traversal of entities + relations | No longer a static file — computed on demand |
| `graph_structure.json` | Direct graph from entities + relations | No separate graph builder needed |

---

## File Locations

All artifacts live under: `MAFIA_Phase1_Execution/output/`

```
output/
├── repo_manifest.json
├── entities.jsonl
├── relations.jsonl
├── coverage_report.json
├── mapping_confidence_report.json
└── warnings.jsonl          (optional: extraction warnings)
```

---

## Checklist

- [x] Purpose of all 5 artifacts documented
- [x] Required fields defined for each
- [x] ID format defined (`id_format.py`)
- [x] Confidence scoring rules defined (5 levels)
- [x] Evidence format defined (mandatory on every record)
- [x] Example artifact samples created (`schemas/samples/`)
- [x] Emitter framework built (`emitter.py`)
- [x] Validator framework built (`validator.py`)
- [x] Mapping from current system to new artifacts documented
