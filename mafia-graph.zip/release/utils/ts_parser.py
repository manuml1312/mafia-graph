"""
MAFIA Utilities -- Tree-Sitter Parser Wrapper
================================================
Thin wrapper around tree-sitter for AST parsing. Handles import errors
gracefully -- all functions return None if tree-sitter is not installed.

Supports 19 languages: Java, TypeScript, JavaScript, Python, Go, Rust,
C#, Kotlin, Scala, Ruby, C, C++, PHP, Swift, Lua, Zig, PowerShell,
Elixir, Objective-C.

Usage:
    from utils.ts_parser import is_available, parse_file, find_node_at_line
    if is_available("java"):
        tree, source = parse_file("MyController.java", "java")
        node = find_node_at_line(tree, 42)
"""

import importlib
from pathlib import Path
from typing import Optional, Any


# -- Language configs ----------------------------------------------------------

LANG_CONFIGS = {
    "java": {
        "module": "tree_sitter_java",
        "fn": "language",
        "class_types": frozenset({"class_declaration", "interface_declaration", "enum_declaration"}),
        "method_types": frozenset({"method_declaration", "constructor_declaration"}),
        "call_types": frozenset({"method_invocation"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement", "try_with_resources_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_expression", "switch_block_statement_group"}),
        "annotation_types": frozenset({"marker_annotation", "annotation"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"import_declaration"}),
    },
    "typescript": {
        "module": "tree_sitter_typescript",
        "fn": "language_typescript",
        "class_types": frozenset({"class_declaration"}),
        "method_types": frozenset({"function_declaration", "method_definition", "arrow_function"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"statement_block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset({"decorator"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"import_statement"}),
    },
    "javascript": {
        "module": "tree_sitter_javascript",
        "fn": "language",
        "class_types": frozenset({"class_declaration"}),
        "method_types": frozenset({"function_declaration", "method_definition", "arrow_function"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"statement_block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset({"decorator"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"import_statement"}),
    },
    "python": {
        "module": "tree_sitter_python",
        "fn": "language",
        "class_types": frozenset({"class_definition"}),
        "method_types": frozenset({"function_definition"}),
        "call_types": frozenset({"call"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"except_clause"}),
        "throw_types": frozenset({"raise_statement"}),
        "switch_types": frozenset({"match_statement"}),
        "annotation_types": frozenset({"decorator"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"import_statement", "import_from_statement"}),
    },
    "go": {
        "module": "tree_sitter_go",
        "fn": "language",
        "class_types": frozenset({"type_declaration"}),
        "method_types": frozenset({"function_declaration", "method_declaration"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset(),
        "catch_types": frozenset(),
        "throw_types": frozenset(),
        "switch_types": frozenset({"expression_switch_statement", "type_switch_statement"}),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"import_declaration"}),
    },
    "rust": {
        "module": "tree_sitter_rust",
        "fn": "language",
        "class_types": frozenset({"struct_item", "enum_item", "trait_item", "impl_item"}),
        "method_types": frozenset({"function_item"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_expression"}),
        "try_types": frozenset(),
        "catch_types": frozenset(),
        "throw_types": frozenset(),
        "switch_types": frozenset({"match_expression"}),
        "annotation_types": frozenset({"attribute_item"}),
        "return_types": frozenset({"return_expression"}),
        "import_types": frozenset({"use_declaration"}),
    },
    "csharp": {
        "module": "tree_sitter_c_sharp",
        "fn": "language",
        "class_types": frozenset({"class_declaration", "interface_declaration", "struct_declaration", "record_declaration"}),
        "method_types": frozenset({"method_declaration", "constructor_declaration"}),
        "call_types": frozenset({"invocation_expression"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement", "throw_expression"}),
        "switch_types": frozenset({"switch_statement", "switch_expression"}),
        "annotation_types": frozenset({"attribute_list"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"using_directive"}),
    },
    "kotlin": {
        "module": "tree_sitter_kotlin",
        "fn": "language",
        "class_types": frozenset({"class_declaration", "object_declaration"}),
        "method_types": frozenset({"function_declaration"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"function_body", "class_body"}),
        "if_types": frozenset({"if_expression"}),
        "try_types": frozenset({"try_expression"}),
        "catch_types": frozenset({"catch_block"}),
        "throw_types": frozenset({"throw"}),
        "switch_types": frozenset({"when_expression"}),
        "annotation_types": frozenset({"annotation"}),
        "return_types": frozenset({"jump_expression"}),
        "import_types": frozenset({"import_header"}),
    },
    "scala": {
        "module": "tree_sitter_scala",
        "fn": "language",
        "class_types": frozenset({"class_definition", "object_definition", "trait_definition"}),
        "method_types": frozenset({"function_definition"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"template_body", "block"}),
        "if_types": frozenset({"if_expression"}),
        "try_types": frozenset({"try_expression"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_expression"}),
        "switch_types": frozenset({"match_expression"}),
        "annotation_types": frozenset({"annotation"}),
        "return_types": frozenset({"return_expression"}),
        "import_types": frozenset({"import_declaration"}),
    },
    "ruby": {
        "module": "tree_sitter_ruby",
        "fn": "language",
        "class_types": frozenset({"class", "module"}),
        "method_types": frozenset({"method", "singleton_method"}),
        "call_types": frozenset({"call", "method_call"}),
        "block_types": frozenset({"body_statement"}),
        "if_types": frozenset({"if", "unless"}),
        "try_types": frozenset({"begin"}),
        "catch_types": frozenset({"rescue"}),
        "throw_types": frozenset({"raise"}),
        "switch_types": frozenset({"case"}),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return"}),
        "import_types": frozenset(),
    },
    "c": {
        "module": "tree_sitter_c",
        "fn": "language",
        "class_types": frozenset({"struct_specifier", "enum_specifier", "union_specifier"}),
        "method_types": frozenset({"function_definition"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"compound_statement"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset(),
        "catch_types": frozenset(),
        "throw_types": frozenset(),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"preproc_include"}),
    },
    "cpp": {
        "module": "tree_sitter_cpp",
        "fn": "language",
        "class_types": frozenset({"class_specifier", "struct_specifier"}),
        "method_types": frozenset({"function_definition"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"compound_statement"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset({"attribute_declaration"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"preproc_include"}),
    },
    "php": {
        "module": "tree_sitter_php",
        "fn": "language_php",
        "class_types": frozenset({"class_declaration", "interface_declaration", "trait_declaration"}),
        "method_types": frozenset({"function_definition", "method_declaration"}),
        "call_types": frozenset({"function_call_expression", "member_call_expression"}),
        "block_types": frozenset({"compound_statement"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_expression"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset({"attribute_list"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"namespace_use_declaration"}),
    },
    "swift": {
        "module": "tree_sitter_swift",
        "fn": "language",
        "class_types": frozenset({"class_declaration", "protocol_declaration", "struct_declaration", "enum_declaration"}),
        "method_types": frozenset({"function_declaration", "init_declaration", "deinit_declaration"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"function_body", "class_body"}),
        "if_types": frozenset({"if_statement", "guard_statement"}),
        "try_types": frozenset({"do_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset({"attribute"}),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"import_declaration"}),
    },
    "lua": {
        "module": "tree_sitter_lua",
        "fn": "language",
        "class_types": frozenset(),
        "method_types": frozenset({"function_declaration", "function_definition"}),
        "call_types": frozenset({"function_call"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset(),
        "catch_types": frozenset(),
        "throw_types": frozenset(),
        "switch_types": frozenset(),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"variable_declaration"}),
    },
    "zig": {
        "module": "tree_sitter_zig",
        "fn": "language",
        "class_types": frozenset(),
        "method_types": frozenset({"function_declaration"}),
        "call_types": frozenset({"call_expression"}),
        "block_types": frozenset({"block"}),
        "if_types": frozenset({"if_expression"}),
        "try_types": frozenset(),
        "catch_types": frozenset({"catch"}),
        "throw_types": frozenset(),
        "switch_types": frozenset({"switch_expression"}),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return_expression"}),
        "import_types": frozenset({"variable_declaration"}),
    },
    "powershell": {
        "module": "tree_sitter_powershell",
        "fn": "language",
        "class_types": frozenset({"class_statement"}),
        "method_types": frozenset({"function_statement", "class_method_definition"}),
        "call_types": frozenset({"command"}),
        "block_types": frozenset({"script_block_body"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset(),
    },
    "elixir": {
        "module": "tree_sitter_elixir",
        "fn": "language",
        "class_types": frozenset(),
        "method_types": frozenset({"call"}),
        "call_types": frozenset({"call"}),
        "block_types": frozenset({"do_block"}),
        "if_types": frozenset({"call"}),
        "try_types": frozenset(),
        "catch_types": frozenset(),
        "throw_types": frozenset(),
        "switch_types": frozenset(),
        "annotation_types": frozenset(),
        "return_types": frozenset(),
        "import_types": frozenset({"call"}),
    },
    "objc": {
        "module": "tree_sitter_objc",
        "fn": "language",
        "class_types": frozenset({"class_interface", "class_implementation", "protocol_declaration"}),
        "method_types": frozenset({"method_declaration", "method_definition"}),
        "call_types": frozenset({"message_expression"}),
        "block_types": frozenset({"compound_statement"}),
        "if_types": frozenset({"if_statement"}),
        "try_types": frozenset({"try_statement"}),
        "catch_types": frozenset({"catch_clause"}),
        "throw_types": frozenset({"throw_statement"}),
        "switch_types": frozenset({"switch_statement"}),
        "annotation_types": frozenset(),
        "return_types": frozenset({"return_statement"}),
        "import_types": frozenset({"preproc_include"}),
    },
}

# Map file extensions to language keys
EXT_TO_LANG = {
    ".java": "java",
    ".ts": "typescript", ".tsx": "typescript",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".py": "python",
    ".go": "go",
    ".rs": "rust",
    ".cs": "csharp",
    ".kt": "kotlin", ".kts": "kotlin",
    ".scala": "scala", ".sc": "scala",
    ".rb": "ruby",
    ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".cxx": "cpp", ".hpp": "cpp",
    ".php": "php",
    ".swift": "swift",
    ".lua": "lua",
    ".zig": "zig",
    ".ps1": "powershell",
    ".ex": "elixir", ".exs": "elixir",
    ".m": "objc", ".mm": "objc",
}

# -- Availability cache --------------------------------------------------------

_available_cache: dict[str, bool] = {}
_parser_cache: dict[str, Any] = {}


def is_available(language: str = "java") -> bool:
    """Check if tree-sitter + language grammar is installed."""
    if language in _available_cache:
        return _available_cache[language]
    cfg = LANG_CONFIGS.get(language)
    if not cfg:
        _available_cache[language] = False
        return False
    try:
        importlib.import_module("tree_sitter")
        importlib.import_module(cfg["module"])
        _available_cache[language] = True
    except ImportError:
        _available_cache[language] = False
    return _available_cache[language]


def any_available() -> bool:
    """Check if tree-sitter core is installed at all."""
    try:
        importlib.import_module("tree_sitter")
        return True
    except ImportError:
        return False


def available_languages() -> list[str]:
    """Return list of languages with installed grammars."""
    return [lang for lang in LANG_CONFIGS if is_available(lang)]


def supported_languages() -> list[str]:
    """Return all 19 configured languages (whether installed or not)."""
    return list(LANG_CONFIGS.keys())


def supported_extensions() -> set[str]:
    """Return all file extensions we can potentially parse."""
    return set(EXT_TO_LANG.keys())


# -- Parsing -------------------------------------------------------------------

def _get_parser(language: str):
    """Get or create a cached parser for the given language."""
    if language in _parser_cache:
        return _parser_cache[language]
    cfg = LANG_CONFIGS.get(language)
    if not cfg:
        return None
    try:
        from tree_sitter import Language, Parser
        mod = importlib.import_module(cfg["module"])
        lang_fn = getattr(mod, cfg["fn"], None)
        if lang_fn is None:
            lang_fn = getattr(mod, "language", None)
        if lang_fn is None:
            return None
        lang_obj = Language(lang_fn())
        parser = Parser(lang_obj)
        _parser_cache[language] = parser
        return parser
    except Exception:
        return None


def parse_file(file_path: str, language: str = None) -> Optional[tuple]:
    """Parse a file with tree-sitter. Returns (tree, source_bytes) or None."""
    if language is None:
        ext = Path(file_path).suffix.lower()
        language = EXT_TO_LANG.get(ext)
    if not language or not is_available(language):
        return None
    parser = _get_parser(language)
    if not parser:
        return None
    try:
        source = Path(file_path).read_bytes()
        tree = parser.parse(source)
        return tree, source
    except Exception:
        return None


def parse_source(source: bytes, language: str) -> Optional[Any]:
    """Parse source bytes directly. Returns tree or None."""
    if not is_available(language):
        return None
    parser = _get_parser(language)
    if not parser:
        return None
    try:
        return parser.parse(source)
    except Exception:
        return None


# -- Node utilities ------------------------------------------------------------

def read_text(node, source: bytes) -> str:
    """Extract text from an AST node."""
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def find_node_at_line(tree, target_line: int, node_types: frozenset = None):
    """Find the smallest named node covering target_line (0-indexed).
    If node_types is given, only match those types."""
    best = None
    best_size = float("inf")

    def walk(node):
        nonlocal best, best_size
        if node.start_point[0] <= target_line <= node.end_point[0]:
            size = node.end_byte - node.start_byte
            if node.is_named and size < best_size:
                if node_types is None or node.type in node_types:
                    best = node
                    best_size = size
            for child in node.children:
                walk(child)

    walk(tree.root_node)
    return best


def find_enclosing_method(tree, target_line: int, language: str, search_window: int = 5):
    """Find the method/function node enclosing target_line.
    Uses a search window to handle annotation-vs-declaration offset:
    entity line may point to @GetMapping (line 42) while the method_declaration
    starts at line 44. Window searches target_line +/- search_window."""
    cfg = LANG_CONFIGS.get(language, {})
    method_types = cfg.get("method_types", frozenset())
    if not method_types:
        return None

    best = None
    best_size = float("inf")

    def walk(node):
        nonlocal best, best_size
        if node.type in method_types:
            if node.start_point[0] <= target_line <= node.end_point[0]:
                size = node.end_byte - node.start_byte
                if size < best_size:
                    best = node
                    best_size = size
            elif 0 < node.start_point[0] - target_line <= search_window:
                size = node.end_byte - node.start_byte
                if size < best_size:
                    best = node
                    best_size = size
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return best


def find_all_methods(tree, language: str) -> list:
    """Find all method/function nodes in the tree."""
    cfg = LANG_CONFIGS.get(language, {})
    method_types = cfg.get("method_types", frozenset())
    if not method_types:
        return []
    results = []

    def walk(node):
        if node.type in method_types:
            results.append(node)
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return results


def find_all_classes(tree, language: str) -> list:
    """Find all class/struct/interface nodes in the tree."""
    cfg = LANG_CONFIGS.get(language, {})
    class_types = cfg.get("class_types", frozenset())
    if not class_types:
        return []
    results = []

    def walk(node):
        if node.type in class_types:
            results.append(node)
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return results


def find_all_imports(tree, language: str) -> list:
    """Find all import/include/use nodes in the tree."""
    cfg = LANG_CONFIGS.get(language, {})
    import_types = cfg.get("import_types", frozenset())
    if not import_types:
        return []
    results = []

    def walk(node):
        if node.type in import_types:
            results.append(node)
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return results


def get_config(language: str) -> dict:
    """Get the language config dict."""
    return LANG_CONFIGS.get(language, {})
