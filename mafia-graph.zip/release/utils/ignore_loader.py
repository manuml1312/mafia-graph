"""
MAFIA Utilities — .mafiaignore Loader
========================================
Reads .mafiaignore files (gitignore syntax) from repo roots to exclude
unwanted paths from scanning and extraction. Eliminates noisy files
(bundles, vendor, .next output) without hardcoding paths everywhere.

Usage:
    from utils.ignore_loader import load_ignore_patterns, is_ignored
    patterns = load_ignore_patterns("/path/to/repo")
    if is_ignored("dist/bundle.js", patterns):
        skip()
"""

import fnmatch
import os
from pathlib import Path


IGNORE_FILENAME = ".mafiaignore"


def load_ignore_patterns(repo_root: str) -> list[str]:
    """Read .mafiaignore from repo root. Returns list of glob patterns.
    Lines starting with # are comments. Blank lines are ignored.
    Trailing / matches directories (we match both for simplicity).
    """
    ignore_file = Path(repo_root) / IGNORE_FILENAME
    if not ignore_file.exists():
        return []
    patterns = []
    try:
        for line in ignore_file.read_text(errors="ignore").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                patterns.append(line)
    except Exception:
        pass
    return patterns


def is_ignored(rel_path: str, patterns: list[str]) -> bool:
    """Check if rel_path matches any .mafiaignore pattern.
    Matches against full relative path, filename alone, and each path segment.
    """
    if not patterns:
        return False
    rel_path = rel_path.replace(os.sep, "/")
    parts = rel_path.split("/")
    filename = parts[-1] if parts else ""

    for pattern in patterns:
        p = pattern.strip("/")
        if not p:
            continue
        if fnmatch.fnmatch(rel_path, p):
            return True
        if fnmatch.fnmatch(filename, p):
            return True
        for i, part in enumerate(parts):
            if fnmatch.fnmatch(part, p):
                return True
            if fnmatch.fnmatch("/".join(parts[: i + 1]), p):
                return True
    return False
