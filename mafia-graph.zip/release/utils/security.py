"""
MAFIA Utilities — Security Helpers
=====================================
Sanitization and validation for user-facing outputs and file operations.
Prevents XSS in HTML visualizations, path traversal in file tools,
and prompt injection via entity labels.

Adapted from graphify's security.py patterns.

Usage:
    from utils.security import sanitize_label, validate_path
    safe = sanitize_label(entity_name)
    real = validate_path(user_path, allowed_root="/app/output")
"""

import html
import os
import re
from pathlib import Path


# ── Label sanitization ───────────────────────────────────────────────────────

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")


def sanitize_label(text: str, max_len: int = 256) -> str:
    """Strip control chars, cap length, HTML-escape.
    Safe for embedding in HTML attributes, vis.js labels, and LLM prompts.
    """
    if not text:
        return ""
    text = _CONTROL_CHARS.sub("", text)
    text = text[:max_len]
    return html.escape(text, quote=True)


# ── Path validation ──────────────────────────────────────────────────────────

def validate_path(path: str, allowed_root: str) -> str:
    """Resolve path and ensure it stays inside allowed_root.
    Raises ValueError on traversal attempt. Returns resolved absolute path.
    """
    resolved = Path(path).resolve()
    root = Path(allowed_root).resolve()
    if not str(resolved).startswith(str(root) + os.sep) and resolved != root:
        raise ValueError(
            f"Path traversal blocked: {path} resolves to {resolved}, "
            f"which is outside {root}"
        )
    return str(resolved)
