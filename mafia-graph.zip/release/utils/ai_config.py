"""
MAFIA — Centralized AI Configuration
=======================================
Single source of truth for all Gemini/AI credentials.
All AI consumers import from here instead of hardcoding paths.

Credential resolution order:
  1. Environment variables (MAFIA_SA_KEY_PATH, MAFIA_CERT_FILE, etc.)
  2. .mafia/ai_config.json in the project root (created by 'mafia configure-ai')
  3. ~/.mafia/ai_config.json in the user's home directory
  4. Disabled — AI features gracefully skip

Users configure AI with:
    mafia configure-ai --sa-key /path/to/key.json --project my-gcp-project

Or by setting environment variables:
    export MAFIA_SA_KEY_PATH=/path/to/sa-key.json
    export MAFIA_CERT_FILE=/path/to/ca-bundle.pem
    export MAFIA_GCP_PROJECT=my-gcp-project
    export MAFIA_GCP_LOCATION=us-central1
    export MAFIA_GEMINI_MODEL=gemini-2.5-flash
"""

import os
import json
from pathlib import Path
from typing import Optional


# ── Defaults (no hardcoded paths) ────────────────────────────────────────────

_DEFAULTS = {
    "sa_key_path": "",
    "cert_file": "",
    "gcp_project": "",
    "gcp_location": "us-central1",
    "gemini_model": "gemini-2.5-flash",
    "embedding_model": "text-embedding-004",
    "embedding_dimension": 768,
    "max_rpm": 30,
}

# ── Config file locations ────────────────────────────────────────────────────

def _find_config_file() -> Optional[Path]:
    """Search for ai_config.json in standard locations."""
    candidates = [
        Path.cwd() / ".mafia" / "ai_config.json",
        Path.home() / ".mafia" / "ai_config.json",
    ]
    # Walk up from cwd to find .mafia/ in a parent
    cur = Path.cwd()
    for _ in range(10):
        candidate = cur / ".mafia" / "ai_config.json"
        if candidate.exists():
            return candidate
        if cur.parent == cur:
            break
        cur = cur.parent
    for c in candidates:
        if c.exists():
            return c
    return None


def _load_file_config() -> dict:
    """Load ai_config.json if it exists."""
    path = _find_config_file()
    if path and path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


# ── Public API ───────────────────────────────────────────────────────────────

class AIConfig:
    """Resolved AI configuration. Reads env vars > config file > defaults."""

    def __init__(self):
        file_cfg = _load_file_config()
        self.sa_key_path = (
            os.environ.get("MAFIA_SA_KEY_PATH")
            or os.environ.get("SA_KEY_PATH")
            or os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
            or file_cfg.get("sa_key_path")
            or _DEFAULTS["sa_key_path"]
        )
        self.cert_file = (
            os.environ.get("MAFIA_CERT_FILE")
            or os.environ.get("CERT_FILE_PATH")
            or os.environ.get("REQUESTS_CA_BUNDLE")
            or file_cfg.get("cert_file")
            or _DEFAULTS["cert_file"]
        )
        self.gcp_project = (
            os.environ.get("MAFIA_GCP_PROJECT")
            or os.environ.get("GCP_PROJECT")
            or file_cfg.get("gcp_project")
            or _DEFAULTS["gcp_project"]
        )
        self.gcp_location = (
            os.environ.get("MAFIA_GCP_LOCATION")
            or os.environ.get("GCP_LOCATION")
            or file_cfg.get("gcp_location")
            or _DEFAULTS["gcp_location"]
        )
        self.gemini_model = (
            os.environ.get("MAFIA_GEMINI_MODEL")
            or os.environ.get("GEMINI_MODEL")
            or file_cfg.get("gemini_model")
            or _DEFAULTS["gemini_model"]
        )
        self.embedding_model = (
            os.environ.get("MAFIA_EMBEDDING_MODEL")
            or file_cfg.get("embedding_model")
            or _DEFAULTS["embedding_model"]
        )
        self.embedding_dimension = int(
            os.environ.get("MAFIA_EMBEDDING_DIM")
            or file_cfg.get("embedding_dimension")
            or _DEFAULTS["embedding_dimension"]
        )
        self.max_rpm = int(
            os.environ.get("MAFIA_MAX_RPM")
            or file_cfg.get("max_rpm")
            or _DEFAULTS["max_rpm"]
        )

    @property
    def ai_available(self) -> bool:
        """True if we have enough config to attempt AI calls."""
        return bool(self.sa_key_path and os.path.exists(self.sa_key_path) and self.gcp_project)

    @property
    def reason_unavailable(self) -> str:
        """Human-readable reason why AI is not available."""
        if not self.sa_key_path:
            return "No service account key configured. Set MAFIA_SA_KEY_PATH or run 'mafia configure-ai'."
        if not os.path.exists(self.sa_key_path):
            return f"Service account key not found: {self.sa_key_path}"
        if not self.gcp_project:
            return "No GCP project configured. Set MAFIA_GCP_PROJECT."
        return ""

    def to_dict(self) -> dict:
        return {
            "sa_key_path": self.sa_key_path,
            "cert_file": self.cert_file,
            "gcp_project": self.gcp_project,
            "gcp_location": self.gcp_location,
            "gemini_model": self.gemini_model,
            "embedding_model": self.embedding_model,
            "embedding_dimension": self.embedding_dimension,
            "max_rpm": self.max_rpm,
            "ai_available": self.ai_available,
        }

    def save(self, path: Optional[str] = None):
        """Save current config to ai_config.json."""
        if path is None:
            # Save to .mafia/ in cwd, or ~/.mafia/
            mafia_dir = Path.cwd() / ".mafia"
            if not mafia_dir.exists():
                mafia_dir = Path.home() / ".mafia"
            mafia_dir.mkdir(parents=True, exist_ok=True)
            path = str(mafia_dir / "ai_config.json")
        data = {
            "sa_key_path": self.sa_key_path,
            "cert_file": self.cert_file,
            "gcp_project": self.gcp_project,
            "gcp_location": self.gcp_location,
            "gemini_model": self.gemini_model,
            "embedding_model": self.embedding_model,
            "embedding_dimension": self.embedding_dimension,
            "max_rpm": self.max_rpm,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"  AI config saved to {path}")


# Singleton
_config = None

def get_ai_config() -> AIConfig:
    global _config
    if _config is None:
        _config = AIConfig()
    return _config
