"""
MAFIA Utilities — File-Level Extraction Cache
================================================
SHA256-based per-file cache that skips unchanged files on incremental runs.
Cache key includes both content and repo-aware path so renames/moves
invalidate correctly (MAFIA canonical IDs encode repo:path).

Adapted from graphify's cache.py pattern: atomic .tmp + os.replace writes,
cache directory beside output artifacts.

Usage:
    from utils.file_cache import FileCache
    cache = FileCache("output")
    hit = cache.get(fpath, repo_id, rel_path)
    if hit:
        # replay cached entities/relations
    else:
        # extract, then:
        cache.put(fpath, repo_id, rel_path, {"entities": [...], "relations": [...]})
"""

import hashlib
import json
import os
from pathlib import Path
from typing import Optional


class FileCache:
    """Per-file extraction cache keyed by content + repo-aware path."""

    def __init__(self, output_dir: str):
        self._cache_dir = Path(output_dir) / "cache"
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    # ── Cache key ────────────────────────────────────────────────────────────

    # Extractor code version — bump this whenever extractor logic changes
    # so stale cache entries are automatically invalidated.
    CACHE_VERSION = "v2"

    @staticmethod
    def _compute_key(file_path: str, repo_id: str, rel_path: str,
                     extractor_name: str = "") -> str:
        """SHA256(file_content + NUL + repo_id/rel_path + NUL + extractor_name + NUL + CACHE_VERSION).
        Including extractor_name ensures different extractors never share cache entries.
        """
        h = hashlib.sha256()
        try:
            h.update(Path(file_path).read_bytes())
        except OSError:
            return ""
        h.update(b"\x00")
        h.update(f"{repo_id}/{rel_path}".encode("utf-8"))
        h.update(b"\x00")
        h.update(extractor_name.encode("utf-8"))
        h.update(b"\x00")
        h.update(FileCache.CACHE_VERSION.encode("utf-8"))
        return h.hexdigest()

    def _entry_path(self, key: str) -> Path:
        return self._cache_dir / f"{key}.json"

    # ── Public API ───────────────────────────────────────────────────────────

    def get(self, file_path: str, repo_id: str, rel_path: str,
             extractor_name: str = "") -> Optional[dict]:
        """Return cached extraction result or None on miss."""
        key = self._compute_key(file_path, repo_id, rel_path, extractor_name)
        if not key:
            return None
        entry = self._entry_path(key)
        if not entry.exists():
            return None
        try:
            return json.loads(entry.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None

    def put(self, file_path: str, repo_id: str, rel_path: str, result: dict,
            extractor_name: str = "") -> None:
        """Store extraction result. Atomic write via .tmp + os.replace."""
        key = self._compute_key(file_path, repo_id, rel_path, extractor_name)
        if not key:
            return
        entry = self._entry_path(key)
        tmp = entry.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, entry)
        except Exception:
            tmp.unlink(missing_ok=True)

    def clear(self) -> int:
        """Delete all cache entries. Returns count of files removed."""
        count = 0
        for f in self._cache_dir.glob("*.json"):
            f.unlink(missing_ok=True)
            count += 1
        return count
