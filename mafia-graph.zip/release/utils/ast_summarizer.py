"""
MAFIA Utilities — AST Structural Summarizer
===============================================
Pure function: given a file path, language, and line range, produces a
structural summary of the code entity at that location.

Extracts: signature, parameters, annotations, calls (with conditional flag),
exception handling, config references, complexity metrics.

No file I/O inside — caller provides the parsed tree and source bytes.

Usage:
    from utils.ast_summarizer import summarize_entity
    from utils.ts_parser import parse_file
    result = parse_file("Controller.java", "java")
    if result:
        tree, source = result
        summary = summarize_entity(tree, source, "java", 42, 57, "api:controller:...")
"""

import re
from typing import Optional

from utils.ts_parser import (
    read_text, find_enclosing_method, get_config,
    LANG_CONFIGS,
)


def summarize_entity(
    tree,
    source: bytes,
    language: str,
    line_start: int,
    line_end: Optional[int],
    entity_id: str,
) -> Optional[dict]:
    """Produce a structural summary for the entity at line_start..line_end.
    Lines are 1-indexed (as stored in MAFIA entities). Returns None if no
    meaningful node found at that location.
    """
    cfg = get_config(language)
    if not cfg:
        return None

    # Convert to 0-indexed for tree-sitter
    target_line = line_start - 1 if line_start else 0

    # Find the enclosing method/function
    method_node = find_enclosing_method(tree, target_line, language)
    if not method_node:
        return None

    source_text = source.decode("utf-8", errors="replace")
    method_text = read_text(method_node, source)

    summary = {
        "entity_id": entity_id,
        "language": language,
        "line_start": method_node.start_point[0] + 1,
        "line_end": method_node.end_point[0] + 1,
        "evidence_method": "ast",
    }

    # ── Signature extraction ─────────────────────────────────────────────
    sig = _extract_signature(method_node, source, language, cfg)
    if sig:
        summary["signature"] = sig

    # ── Annotations ──────────────────────────────────────────────────────
    annotations = _extract_annotations(method_node, source, cfg)
    if annotations:
        summary["annotations"] = annotations

    # ── Calls in body ────────────────────────────────────────────────────
    calls = _extract_calls(method_node, source, language, cfg)
    if calls:
        summary["calls"] = calls

    # ── Exception handling ───────────────────────────────────────────────
    exceptions = _extract_exceptions(method_node, source, cfg)
    if exceptions:
        summary["exception_handling"] = exceptions

    # ── Config references ────────────────────────────────────────────────
    config_refs = _extract_config_refs(method_text, language)
    if config_refs:
        summary["config_refs"] = config_refs

    # ── Complexity ───────────────────────────────────────────────────────
    summary["complexity"] = _compute_complexity(method_node, cfg)

    # ── Confidence based on extraction completeness ──────────────────────
    has_sig = bool(sig and sig.get("name"))
    has_calls = bool(calls)
    has_params = bool(sig and sig.get("parameters"))
    if has_sig and has_calls and has_params:
        summary["confidence"] = 0.95
    elif has_sig and (has_calls or has_params):
        summary["confidence"] = 0.85
    elif has_sig:
        summary["confidence"] = 0.70
    else:
        summary["confidence"] = 0.50

    return summary


# ── Signature ────────────────────────────────────────────────────────────────

def _extract_signature(node, source: bytes, language: str, cfg: dict) -> Optional[dict]:
    """Extract method/function signature: name, return type, access, parameters."""
    sig = {}

    # Name
    name_node = node.child_by_field_name("name")
    if name_node:
        sig["name"] = read_text(name_node, source)
    else:
        # Fallback: first identifier child
        for child in node.children:
            if child.type == "identifier":
                sig["name"] = read_text(child, source)
                break

    if not sig.get("name"):
        return None

    # Return type (Java, TypeScript)
    type_node = node.child_by_field_name("type") or node.child_by_field_name("return_type")
    if type_node:
        sig["return_type"] = read_text(type_node, source).strip()

    # Access modifier (Java)
    if language == "java":
        for child in node.children:
            if child.type in ("public", "private", "protected"):
                sig["access"] = child.type
                break
            if child.type == "modifiers":
                for mod in child.children:
                    if mod.type in ("public", "private", "protected"):
                        sig["access"] = mod.type
                        break

    # Parameters
    params_node = node.child_by_field_name("parameters")
    if params_node:
        sig["parameters"] = _extract_parameters(params_node, source, language)

    return sig


def _extract_parameters(params_node, source: bytes, language: str) -> list[dict]:
    """Extract parameter list from a formal_parameters node."""
    params = []
    for child in params_node.children:
        if not child.is_named:
            continue
        param = {}

        if language == "java":
            # Java: formal_parameter has type + name + optional annotations
            if child.type == "formal_parameter" or child.type == "spread_parameter":
                annotations = []
                for sub in child.children:
                    if sub.type in ("marker_annotation", "annotation"):
                        annotations.append(read_text(sub, source))
                    elif sub.type == "identifier":
                        param["name"] = read_text(sub, source)
                type_node = child.child_by_field_name("type")
                if type_node:
                    param["type"] = read_text(type_node, source)
                if annotations:
                    param["annotations"] = annotations
        elif language in ("typescript", "javascript"):
            # TS/JS: required_parameter or optional_parameter
            if child.type in ("required_parameter", "optional_parameter"):
                pattern = child.child_by_field_name("pattern")
                if pattern:
                    param["name"] = read_text(pattern, source)
                type_ann = child.child_by_field_name("type")
                if type_ann:
                    param["type"] = read_text(type_ann, source).lstrip(": ").strip()
                if child.type == "optional_parameter":
                    param["optional"] = True
            elif child.type == "identifier":
                param["name"] = read_text(child, source)
        elif language == "python":
            if child.type == "identifier":
                param["name"] = read_text(child, source)
            elif child.type in ("typed_parameter", "default_parameter", "typed_default_parameter"):
                name_node = child.child_by_field_name("name")
                if name_node:
                    param["name"] = read_text(name_node, source)
                type_node = child.child_by_field_name("type")
                if type_node:
                    param["type"] = read_text(type_node, source)

        if param.get("name"):
            params.append(param)

    return params


# ── Annotations ──────────────────────────────────────────────────────────────

def _extract_annotations(node, source: bytes, cfg: dict) -> list[str]:
    """Extract annotations/decorators on the method node and its parent."""
    ann_types = cfg.get("annotation_types", frozenset())
    annotations = []

    # Check siblings before this node (annotations precede the method)
    if node.parent:
        found_self = False
        for sibling in reversed(list(node.parent.children)):
            if sibling == node:
                found_self = True
                continue
            if found_self and sibling.type in ann_types:
                annotations.append(read_text(sibling, source).strip())
            elif found_self and sibling.is_named and sibling.type not in ann_types:
                break

    # Also check direct children (some grammars nest annotations inside)
    for child in node.children:
        if child.type in ann_types:
            annotations.append(read_text(child, source).strip())
        if child.type == "modifiers":
            for sub in child.children:
                if sub.type in ann_types:
                    annotations.append(read_text(sub, source).strip())

    annotations.reverse()
    return annotations


# ── Calls ────────────────────────────────────────────────────────────────────

def _extract_calls(node, source: bytes, language: str, cfg: dict) -> list[dict]:
    """Extract method/function calls inside the body, with conditional flag."""
    call_types = cfg.get("call_types", frozenset())
    if_types = cfg.get("if_types", frozenset())
    method_types = cfg.get("method_types", frozenset())
    calls = []
    seen = set()

    def _is_inside_conditional(call_node) -> bool:
        """Walk up parents to check if this call is inside an if/switch/catch."""
        cur = call_node.parent
        while cur and cur != node:
            if cur.type in if_types or cur.type in cfg.get("switch_types", frozenset()) \
               or cur.type in cfg.get("catch_types", frozenset()):
                return True
            cur = cur.parent
        return False

    def _get_condition_text(call_node) -> Optional[str]:
        """Try to extract the condition expression for a conditional call."""
        cur = call_node.parent
        while cur and cur != node:
            if cur.type in if_types:
                cond = cur.child_by_field_name("condition")
                if cond:
                    text = read_text(cond, source).strip("() ")
                    return text[:80] if len(text) > 80 else text
            cur = cur.parent
        return None

    def walk(n):
        # Don't descend into nested method definitions
        if n != node and n.type in method_types:
            return
        if n.type in call_types:
            call_text = _resolve_call_name(n, source, language)
            if call_text and call_text not in seen:
                seen.add(call_text)
                conditional = _is_inside_conditional(n)
                entry = {
                    "target": call_text,
                    "line": n.start_point[0] + 1,
                    "conditional": conditional,
                }
                if conditional:
                    cond_text = _get_condition_text(n)
                    if cond_text:
                        entry["condition"] = cond_text
                calls.append(entry)
        for child in n.children:
            walk(child)

    # Find the body node
    body = node.child_by_field_name("body")
    if not body:
        for child in node.children:
            if child.type in cfg.get("block_types", frozenset()):
                body = child
                break
    if body:
        walk(body)

    return calls


def _resolve_call_name(call_node, source: bytes, language: str) -> Optional[str]:
    """Extract the callee name from a call expression node."""
    if language == "java":
        # method_invocation: object.method(args) or method(args)
        name_node = call_node.child_by_field_name("name")
        obj_node = call_node.child_by_field_name("object")
        if name_node:
            method = read_text(name_node, source)
            if obj_node:
                obj = read_text(obj_node, source)
                # Simplify: take last segment of chained calls
                obj = obj.split(".")[-1].split("(")[0]
                return f"{obj}.{method}"
            return method
    elif language in ("typescript", "javascript"):
        func_node = call_node.child_by_field_name("function")
        if func_node:
            if func_node.type == "member_expression":
                prop = func_node.child_by_field_name("property")
                obj = func_node.child_by_field_name("object")
                if prop:
                    method = read_text(prop, source)
                    if obj:
                        obj_text = read_text(obj, source).split(".")[-1].split("(")[0]
                        return f"{obj_text}.{method}"
                    return method
            elif func_node.type == "identifier":
                return read_text(func_node, source)
    elif language == "python":
        func_node = call_node.child_by_field_name("function")
        if func_node:
            if func_node.type == "attribute":
                attr = func_node.child_by_field_name("attribute")
                obj = func_node.child_by_field_name("object")
                if attr:
                    method = read_text(attr, source)
                    if obj:
                        obj_text = read_text(obj, source).split(".")[-1]
                        return f"{obj_text}.{method}"
                    return method
            elif func_node.type == "identifier":
                return read_text(func_node, source)
    return None


# ── Exception handling ───────────────────────────────────────────────────────

def _extract_exceptions(node, source: bytes, cfg: dict) -> list[dict]:
    """Extract try/catch/throw patterns from the method body."""
    exceptions = []
    catch_types = cfg.get("catch_types", frozenset())
    throw_types = cfg.get("throw_types", frozenset())

    def walk(n):
        if n.type in catch_types:
            # Extract the exception type
            exc_type = None
            for child in n.children:
                if child.type in ("catch_type", "catch_formal_parameter", "identifier"):
                    exc_type = read_text(child, source).strip()
                    break
                if child.type == "catch_formal_parameter":
                    type_node = child.child_by_field_name("type") or child.child_by_field_name("name")
                    if type_node:
                        exc_type = read_text(type_node, source).strip()
                    break
            # Look for what happens in the catch body
            body = n.child_by_field_name("body")
            action = "caught"
            if body:
                body_text = read_text(body, source)[:200].lower()
                if "throw" in body_text:
                    action = "rethrown"
                elif "log" in body_text:
                    action = "logged"
                elif "return" in body_text:
                    action = "return on error"
            exceptions.append({
                "type": exc_type or "Exception",
                "action": action,
                "line": n.start_point[0] + 1,
            })
        elif n.type in throw_types:
            thrown = None
            for child in n.children:
                if child.is_named:
                    thrown = read_text(child, source)[:60]
                    break
            exceptions.append({
                "type": thrown or "unknown",
                "action": "thrown",
                "line": n.start_point[0] + 1,
            })
        for child in n.children:
            walk(child)

    body = node.child_by_field_name("body")
    if body:
        walk(body)
    return exceptions


# ── Config references ────────────────────────────────────────────────────────

_CONFIG_PATTERNS = {
    "java": [
        re.compile(r'@Value\s*\(\s*"\$\{([^}]+)\}"'),           # @Value("${key}")
        re.compile(r'getProperty\s*\(\s*"([^"]+)"'),             # getProperty("key")
        re.compile(r'@ConfigurationProperties\s*\(\s*"([^"]+)"'),
    ],
    "typescript": [
        re.compile(r'process\.env\.(\w+)'),                       # process.env.KEY
        re.compile(r'config\s*\.\s*get\s*\(\s*["\']([^"\']+)'),  # config.get("key")
    ],
    "javascript": [
        re.compile(r'process\.env\.(\w+)'),
        re.compile(r'config\s*\.\s*get\s*\(\s*["\']([^"\']+)'),
    ],
    "python": [
        re.compile(r'os\.environ\s*\[\s*["\'](\w+)'),            # os.environ["KEY"]
        re.compile(r'os\.getenv\s*\(\s*["\'](\w+)'),             # os.getenv("KEY")
        re.compile(r'config\s*\[\s*["\']([^"\']+)'),             # config["key"]
    ],
}


def _extract_config_refs(method_text: str, language: str) -> list[str]:
    """Extract config/env references from method body text."""
    patterns = _CONFIG_PATTERNS.get(language, [])
    refs = []
    seen = set()
    for pat in patterns:
        for m in pat.finditer(method_text):
            key = m.group(1)
            if key not in seen:
                seen.add(key)
                refs.append(key)
    return refs


# ── Summarize any AST node directly (for discover mode) ─────────────────────

def summarize_node(
    method_node,
    source: bytes,
    language: str,
    file_path: str,
    repo_id: str,
) -> Optional[dict]:
    """Produce a structural summary for any method/function/class node.
    Used by discover mode — no entity_id needed, generates one from file+name+line."""
    cfg = get_config(language)
    if not cfg:
        return None

    method_text = read_text(method_node, source)
    line_start = method_node.start_point[0] + 1
    line_end = method_node.end_point[0] + 1

    sig = _extract_signature(method_node, source, language, cfg)
    name = sig.get("name", "") if sig else ""
    if not name:
        return None

    # Check if this is inside a class
    parent_class = None
    cur = method_node.parent
    while cur:
        if cur.type in cfg.get("class_types", frozenset()):
            cls_name_node = cur.child_by_field_name("name")
            if cls_name_node:
                parent_class = read_text(cls_name_node, source)
            break
        cur = cur.parent

    qualified_name = f"{parent_class}.{name}" if parent_class else name
    node_type = method_node.type

    summary = {
        "discovered_id": f"{repo_id}:{file_path}::{qualified_name}:L{line_start}",
        "name": name,
        "qualified_name": qualified_name,
        "parent_class": parent_class,
        "node_type": node_type,
        "language": language,
        "file": file_path,
        "repo": repo_id,
        "line_start": line_start,
        "line_end": line_end,
        "evidence_method": "ast",
    }

    if sig:
        summary["signature"] = sig

    annotations = _extract_annotations(method_node, source, cfg)
    if annotations:
        summary["annotations"] = annotations

    calls = _extract_calls(method_node, source, language, cfg)
    if calls:
        summary["calls"] = calls

    exceptions = _extract_exceptions(method_node, source, cfg)
    if exceptions:
        summary["exception_handling"] = exceptions

    config_refs = _extract_config_refs(method_text, language)
    if config_refs:
        summary["config_refs"] = config_refs

    summary["complexity"] = _compute_complexity(method_node, cfg)

    has_calls = bool(calls)
    has_params = bool(sig and sig.get("parameters"))
    if has_calls and has_params:
        summary["confidence"] = 0.95
    elif has_calls or has_params:
        summary["confidence"] = 0.85
    else:
        summary["confidence"] = 0.70

    return summary


def discover_all_methods(
    tree,
    source: bytes,
    language: str,
    file_path: str,
    repo_id: str,
) -> list[dict]:
    """Walk the entire AST and produce summaries for every method/function.
    Returns list of summary dicts."""
    cfg = get_config(language)
    if not cfg:
        return []

    method_types = cfg.get("method_types", frozenset())
    results = []

    def walk(node):
        if node.type in method_types:
            summary = summarize_node(node, source, language, file_path, repo_id)
            if summary:
                results.append(summary)
            # Still walk children — handles nested functions/methods
        for child in node.children:
            walk(child)

    walk(tree.root_node)
    return results


# ── Complexity ───────────────────────────────────────────────────────────────

def _compute_complexity(node, cfg: dict) -> dict:
    """Count branches, try/catch blocks, and lines."""
    branches = 0
    try_catch = 0
    lines = node.end_point[0] - node.start_point[0] + 1

    def walk(n):
        nonlocal branches, try_catch
        if n.type in cfg.get("if_types", frozenset()):
            branches += 1
        elif n.type in cfg.get("switch_types", frozenset()):
            branches += 1
        elif n.type in cfg.get("try_types", frozenset()):
            try_catch += 1
        for child in n.children:
            walk(child)

    walk(node)
    return {"branches": branches, "try_catch": try_catch, "lines": lines}
