"""
MAFIA Utilities — Fuzzy String Matching
==========================================
Pure-Python Jaro-Winkler similarity for cross-file resolution.
No external dependencies.

Usage:
    from utils.fuzzy import jaro_winkler, fuzzy_match_best
    score = jaro_winkler("flagService", "FlagServiceImpl")
    best, score = fuzzy_match_best("flagSvc", ["FlagServiceImpl", "FlagTypeService", "UserRepo"])
"""


def jaro(s1: str, s2: str) -> float:
    """Jaro similarity between two strings (0.0–1.0)."""
    if s1 == s2:
        return 1.0
    len1, len2 = len(s1), len(s2)
    if len1 == 0 or len2 == 0:
        return 0.0

    match_dist = max(len1, len2) // 2 - 1
    if match_dist < 0:
        match_dist = 0

    s1_matches = [False] * len1
    s2_matches = [False] * len2
    matches = 0
    transpositions = 0

    for i in range(len1):
        lo = max(0, i - match_dist)
        hi = min(i + match_dist + 1, len2)
        for j in range(lo, hi):
            if s2_matches[j] or s1[i] != s2[j]:
                continue
            s1_matches[i] = True
            s2_matches[j] = True
            matches += 1
            break

    if matches == 0:
        return 0.0

    k = 0
    for i in range(len1):
        if not s1_matches[i]:
            continue
        while not s2_matches[k]:
            k += 1
        if s1[i] != s2[k]:
            transpositions += 1
        k += 1

    return (matches / len1 + matches / len2 + (matches - transpositions / 2) / matches) / 3


def jaro_winkler(s1: str, s2: str, prefix_weight: float = 0.1) -> float:
    """Jaro-Winkler similarity (0.0–1.0). Boosts score for common prefixes."""
    j = jaro(s1, s2)
    prefix_len = 0
    for i in range(min(4, len(s1), len(s2))):
        if s1[i] == s2[i]:
            prefix_len += 1
        else:
            break
    return j + prefix_len * prefix_weight * (1 - j)


def fuzzy_match_best(query: str, candidates: list[str], threshold: float = 0.85) -> tuple:
    """
    Find the best fuzzy match for query among candidates.
    Returns (best_candidate, score) or (None, 0.0) if nothing meets threshold.
    """
    best_candidate, best_score = None, 0.0
    q = query.lower()
    for c in candidates:
        score = jaro_winkler(q, c.lower())
        if score > best_score:
            best_score = score
            best_candidate = c
    if best_score >= threshold:
        return best_candidate, best_score
    return None, 0.0
