"""
MAFIA Phase 9 — Graph Query Utilities (Spec-Complete)
=======================================================
Budgeted slicing, flow lookup, orphan convenience queries.
All slice returns enforce max_nodes=50 by default.

Usage:
    gq = GraphQuery("output/system_graph.json")
    gq.load_flows("output/e2e_flows.json")
"""

import json
from pathlib import Path
from collections import defaultdict, deque
from typing import Optional


class GraphQuery:
    def __init__(self, graph_path: Optional[str] = None, flows_path: Optional[str] = None):
        self.nodes = {}
        self.adj = defaultdict(list)
        self.rev = defaultdict(list)
        self._edges = {}
        self._flows = {}  # catalog_name -> [flows]

        if graph_path:
            self.load(graph_path)
        if flows_path:
            self.load_flows(flows_path)

    def load(self, graph_path: str):
        data = _load_json(graph_path)
        for n in data.get("nodes", []):
            self.nodes[n["id"]] = n
        for e in data.get("edges", []):
            src, tgt = e["source"], e["target"]
            self.adj[src].append(tgt)
            self.rev[tgt].append(src)
            self._edges[(src, tgt)] = e

    def load_flows(self, flows_path: str):
        data = _load_json(flows_path)
        self._flows = data.get("catalogs", {})

    # ── Node search (with filters) ───────────────────────────────────────────

    def find_by_name(self, query: str, layer: Optional[str] = None,
                     node_type: Optional[str] = None, repo: Optional[str] = None,
                     min_confidence: float = 0.0, evidence_method: Optional[str] = None,
                     limit: int = 20) -> list:
        q = query.lower()
        results = []
        for nid, n in self.nodes.items():
            if layer and n.get("layer") != layer:
                continue
            if node_type and n.get("type") != node_type:
                continue
            if repo and n.get("repo") != repo:
                continue
            if n.get("confidence", 0) < min_confidence:
                continue
            if evidence_method and n.get("evidence_method") != evidence_method:
                continue
            label = n.get("label", "").lower()
            if q in label or q in nid.lower():
                results.append({
                    "id": nid, "name": n.get("label", ""),
                    "layer": n.get("layer", ""), "type": n.get("type", ""),
                    "repo": n.get("repo", ""), "confidence": n.get("confidence", 0),
                    "evidence_method": n.get("evidence_method", ""),
                })
        results.sort(key=lambda x: (0 if x["name"].lower().startswith(q) else 1, -x["confidence"], len(x["name"])))
        return results[:limit]

    # ── Budgeted neighborhood slice ──────────────────────────────────────────

    def neighborhood(self, node_id: str, direction: str = "both",
                     depth: int = 2, node_budget: int = 50) -> dict:
        """
        Budgeted neighborhood slice. Returns at most node_budget nodes.
        Prioritizes: closer hops, higher confidence, cross-layer edges.
        """
        resolved = self._resolve(node_id)
        if not resolved:
            return {"error": f"Node not found: {node_id}", "nodes": [], "edges": [],
                    "truncated": False, "truncation_reason": None}

        seed = resolved[0]
        if direction == "downstream":
            graph = self.adj
        elif direction == "upstream":
            graph = self.rev
        else:
            graph = defaultdict(list)
            for k, v in self.adj.items():
                graph[k].extend(v)
            for k, v in self.rev.items():
                graph[k].extend(v)

        # BFS with budget
        visited = {seed: 0}
        queue = deque([(seed, 0)])
        collected = [seed]
        truncated = False

        while queue and len(collected) < node_budget:
            nid, d = queue.popleft()
            if d >= depth:
                continue
            neighbors = graph.get(nid, [])
            # Sort neighbors: cross-layer first, then higher confidence
            scored = []
            for nb in neighbors:
                if nb in visited:
                    continue
                nb_node = self.nodes.get(nb, {})
                src_layer = self.nodes.get(nid, {}).get("layer", "")
                tgt_layer = nb_node.get("layer", "")
                cross = 0 if src_layer != tgt_layer else 1
                conf = -(nb_node.get("confidence", 0))
                scored.append((cross, conf, nb))
            scored.sort()

            for _, _, nb in scored:
                if len(collected) >= node_budget:
                    truncated = True
                    break
                if nb not in visited:
                    visited[nb] = d + 1
                    queue.append((nb, d + 1))
                    collected.append(nb)

        collected_set = set(collected)
        slice_nodes = [self.nodes[nid] for nid in collected if nid in self.nodes]
        slice_edges = [e for (s, t), e in self._edges.items() if s in collected_set and t in collected_set]

        return {
            "seed": seed,
            "direction": direction,
            "depth": depth,
            "node_budget": node_budget,
            "nodes": slice_nodes,
            "edges": slice_edges,
            "node_count": len(slice_nodes),
            "edge_count": len(slice_edges),
            "truncated": truncated,
            "truncation_reason": f"Budget {node_budget} reached" if truncated else None,
        }

    # ── Path finding ─────────────────────────────────────────────────────────

    def find_path(self, source: str, target: str, max_depth: int = 15) -> Optional[dict]:
        src_ids = self._resolve(source)
        tgt_ids = set(self._resolve(target))
        if not src_ids or not tgt_ids:
            return None
        for start in src_ids:
            visited = {start: None}
            queue = deque([(start, 0)])
            while queue:
                nid, d = queue.popleft()
                if d > max_depth: continue
                if nid in tgt_ids:
                    path = []
                    cur = nid
                    while cur is not None:
                        path.append(cur)
                        cur = visited[cur]
                    path.reverse()
                    return self._format_path(path)
                for nb in self.adj.get(nid, []):
                    if nb not in visited:
                        visited[nb] = nid
                        queue.append((nb, d + 1))
        return None

    def _format_path(self, path_ids):
        hops = []
        for i, nid in enumerate(path_ids):
            n = self.nodes.get(nid, {})
            edge_next = None
            if i < len(path_ids) - 1:
                e = self._edges.get((nid, path_ids[i + 1]))
                if e:
                    edge_next = {"type": e.get("type", ""), "confidence": e.get("confidence", 0)}
            hops.append({"id": nid, "name": n.get("label", ""), "layer": n.get("layer", ""),
                         "type": n.get("type", ""), "edge_to_next": edge_next})
        layers = []
        for h in hops:
            if not layers or layers[-1] != h["layer"]:
                layers.append(h["layer"])
        return {"source": path_ids[0], "target": path_ids[-1], "hop_count": len(path_ids),
                "layers_crossed": layers, "hops": hops}

    # ── Flow lookup by node ──────────────────────────────────────────────────

    def flows_for_node(self, node_id: str, limit: int = 10) -> list:
        """Return top-k flows that contain this node."""
        resolved = self._resolve(node_id)
        if not resolved:
            return []
        target_ids = set(resolved)
        results = []
        for cat_name, cat_flows in self._flows.items():
            for flow in cat_flows:
                hop_ids = {h["id"] for h in flow.get("standard", [])}
                if hop_ids & target_ids:
                    results.append({
                        "catalog": cat_name,
                        "flow_id": flow.get("flow_id", ""),
                        "surface": flow.get("surface", {}),
                        "completeness": flow.get("completeness", ""),
                        "hop_count": flow.get("hop_count", 0),
                        "confidence_range": flow.get("confidence_range", {}),
                    })
        results.sort(key=lambda x: -x["hop_count"])
        return results[:limit]

    # ── Complete / Partial flow tabs ────────────────────────────────────────

    def complete_flows(self, layer: Optional[str] = None,
                       repo: Optional[str] = None, limit: int = 50) -> list:
        """Return complete flows (UI/BFF → DB) with optional filters."""
        return self._filter_flows("complete_flows", layer, repo, limit)

    def partial_flows(self, layer: Optional[str] = None,
                      repo: Optional[str] = None,
                      breakpoint_reason: Optional[str] = None,
                      limit: int = 50) -> list:
        """Return partial flows with optional breakpoint reason filter."""
        flows = self._filter_flows("partial_flows", layer, repo, limit=0)
        if breakpoint_reason:
            flows = [f for f in flows
                     if f.get("breakpoint", {}).get("reason_code") == breakpoint_reason]
        return flows[:limit] if limit else flows

    def flow_summary(self) -> dict:
        """Summary counts for complete vs partial, with breakpoint distribution."""
        complete = self._flows.get("complete_flows", [])
        partial = self._flows.get("partial_flows", [])
        bp_reasons = {}
        bp_layers = {}
        for f in partial:
            bp = f.get("breakpoint", {})
            rc = bp.get("reason_code", "UNKNOWN")
            bl = bp.get("layer", "unknown")
            bp_reasons[rc] = bp_reasons.get(rc, 0) + 1
            bp_layers[bl] = bp_layers.get(bl, 0) + 1
        return {
            "complete": len(complete),
            "partial": len(partial),
            "total": len(complete) + len(partial),
            "breakpoint_reasons": dict(sorted(bp_reasons.items(), key=lambda x: -x[1])),
            "breakpoint_layers": dict(sorted(bp_layers.items(), key=lambda x: -x[1])),
        }

    def _filter_flows(self, catalog: str, layer: Optional[str],
                      repo: Optional[str], limit: int) -> list:
        flows = self._flows.get(catalog, [])
        if layer:
            flows = [f for f in flows if f.get("entry", {}).get("layer") == layer]
        if repo:
            flows = [f for f in flows if repo in f.get("repos_involved", [])]
        return flows[:limit] if limit else flows

    # ── Orphan convenience queries ───────────────────────────────────────────

    def orphan_bff_no_ui(self) -> list:
        """BFF endpoints with no upstream UI callers (no fetches targeting them)."""
        bff_eps = {nid for nid, n in self.nodes.items() if n.get("layer") == "bff" and n.get("type") == "endpoint"}
        has_ui = set()
        for (s, t), e in self._edges.items():
            if e.get("type") == "fetches":
                has_ui.add(t)
        return [{"id": nid, **{k: self.nodes[nid].get(k, "") for k in ("label", "layer", "type", "repo")}}
                for nid in sorted(bff_eps - has_ui)]

    def orphan_api_no_bff(self) -> list:
        """API endpoints with no upstream BFF callers."""
        api_eps = {nid for nid, n in self.nodes.items() if n.get("layer") == "api" and n.get("type") == "endpoint"}
        has_bff = set()
        for (s, t), e in self._edges.items():
            if e.get("type") == "calls_api":
                has_bff.add(t)
        return [{"id": nid, **{k: self.nodes[nid].get(k, "") for k in ("label", "layer", "type", "repo")}}
                for nid in sorted(api_eps - has_bff)]

    def orphan_db_no_api(self) -> list:
        """DB functions with no upstream API callers."""
        db_fns = {nid for nid, n in self.nodes.items() if n.get("layer") == "db" and n.get("type") == "function"}
        has_api = set()
        for (s, t), e in self._edges.items():
            if e.get("type") in ("calls_function", "reads_from"):
                has_api.add(t)
        return [{"id": nid, **{k: self.nodes[nid].get(k, "") for k in ("label", "layer", "type", "repo")}}
                for nid in sorted(db_fns - has_api)]

    def orphan_ui_no_bff(self) -> list:
        """UI fetch_defs with no downstream BFF match."""
        ui_fds = {nid for nid, n in self.nodes.items() if n.get("layer") == "ui" and n.get("type") == "fetch_def"}
        has_bff = {e["source"] for (s, t), e in self._edges.items() if e.get("type") == "fetches"}
        return [{"id": nid, **{k: self.nodes[nid].get(k, "") for k in ("label", "layer", "type", "repo")}}
                for nid in sorted(ui_fds - has_bff)]

    def orphan_nodes(self) -> list:
        """All nodes with degree 0 in flow graph."""
        connected = set()
        for s in self.adj:
            connected.add(s)
            for t in self.adj[s]:
                connected.add(t)
        return [{"id": nid, "layer": n.get("layer",""), "type": n.get("type",""), "name": n.get("label","")}
                for nid, n in self.nodes.items() if nid not in connected]

    # ── Connected components ─────────────────────────────────────────────────

    def connected_components(self) -> list:
        visited = set()
        components = []
        undirected = defaultdict(set)
        for s, targets in self.adj.items():
            for t in targets:
                undirected[s].add(t)
                undirected[t].add(s)
        for nid in undirected:
            if nid in visited: continue
            comp = set()
            queue = deque([nid])
            while queue:
                node = queue.popleft()
                if node in visited: continue
                visited.add(node)
                comp.add(node)
                for nb in undirected[node]:
                    if nb not in visited:
                        queue.append(nb)
            layers = set(self.nodes.get(c, {}).get("layer", "") for c in comp)
            components.append({"size": len(comp), "layers": sorted(layers),
                               "sample_nodes": [self.nodes.get(c, {}).get("label", c) for c in sorted(comp)[:5]]})
        components.sort(key=lambda c: -c["size"])
        return components

    # ── Subgraph extraction ──────────────────────────────────────────────────

    def subgraph(self, node_ids: list, depth: int = 1, node_budget: int = 50) -> dict:
        seed = set()
        for nid in node_ids:
            seed.update(self._resolve(nid))
        expanded = set(seed)
        frontier = set(seed)
        for _ in range(depth):
            nxt = set()
            for nid in frontier:
                for t in self.adj.get(nid, []):
                    if t not in expanded and len(expanded) < node_budget:
                        nxt.add(t); expanded.add(t)
                for s in self.rev.get(nid, []):
                    if s not in expanded and len(expanded) < node_budget:
                        nxt.add(s); expanded.add(s)
            frontier = nxt
        truncated = len(expanded) >= node_budget
        sub_nodes = [self.nodes[nid] for nid in expanded if nid in self.nodes]
        sub_edges = [e for (s, t), e in self._edges.items() if s in expanded and t in expanded]
        return {"seed_nodes": list(seed), "depth": depth, "node_budget": node_budget,
                "nodes": sub_nodes, "edges": sub_edges,
                "node_count": len(sub_nodes), "edge_count": len(sub_edges),
                "truncated": truncated,
                "truncation_reason": f"Budget {node_budget} reached" if truncated else None}

    # ── Layer boundary edges ─────────────────────────────────────────────────

    def layer_boundary_edges(self) -> list:
        results = []
        for (s, t), e in self._edges.items():
            sl = self.nodes.get(s, {}).get("layer", "")
            tl = self.nodes.get(t, {}).get("layer", "")
            if sl and tl and sl != tl:
                results.append({"source": s, "target": t, "source_layer": sl,
                                "target_layer": tl, "type": e.get("type", ""),
                                "confidence": e.get("confidence", 0)})
        return results

    # ── Trace flow ───────────────────────────────────────────────────────────

    def trace_flow(self, entry_id: str, max_depth: int = 12) -> dict:
        resolved = self._resolve(entry_id)
        if not resolved:
            return {"entry": entry_id, "error": "not found", "chain": []}
        start = resolved[0]
        visited = set()
        chain = []
        def _dfs(nid, depth):
            if depth > max_depth or nid in visited: return
            visited.add(nid)
            n = self.nodes.get(nid, {})
            chain.append({"id": nid, "name": n.get("label",""), "layer": n.get("layer",""),
                          "type": n.get("type",""), "depth": depth, "branches": len(self.adj.get(nid,[]))})
            for t in self.adj.get(nid, []):
                if t not in visited: _dfs(t, depth + 1)
        _dfs(start, 0)
        terminal = chain[-1] if chain else {}
        return {"entry": start, "entry_name": self.nodes.get(start,{}).get("label",""),
                "terminal": terminal.get("id",""), "reaches_db": terminal.get("layer") == "db",
                "total_nodes": len(chain), "chain": chain}

    # ── Cross-scope helpers (v2) ──────────────────────────────────────────────

    def cross_scope_edges(self, boundary: str | None = None) -> list:
        """Return edges where source and target have different scope_path."""
        results = []
        for (s, t), e in self._edges.items():
            sn = self.nodes.get(s, {})
            tn = self.nodes.get(t, {})
            s_sp = sn.get("scope_path", sn.get("repo", ""))
            t_sp = tn.get("scope_path", tn.get("repo", ""))
            if s_sp and t_sp and s_sp != t_sp:
                edge_boundary = "repo" if sn.get("repo", "") != tn.get("repo", "") else "workspace"
                if boundary and edge_boundary != boundary:
                    continue
                results.append({"source": s, "target": t, "type": e.get("type", ""),
                                "boundary": edge_boundary, "confidence": e.get("confidence", 0)})
        return results

    def workspace_neighbors(self, workspace_id: str, direction: str = "both") -> list:
        """Return other workspaces connected to this one via cross-scope edges."""
        ws_nodes = {nid for nid, n in self.nodes.items()
                    if (n.get("scope_path", n.get("repo", "")) == workspace_id)}
        neighbor_ws = set()
        for nid in ws_nodes:
            targets = []
            if direction in ("downstream", "both"):
                targets.extend(self.adj.get(nid, []))
            if direction in ("upstream", "both"):
                targets.extend(self.rev.get(nid, []))
            for t in targets:
                tn = self.nodes.get(t, {})
                t_sp = tn.get("scope_path", tn.get("repo", ""))
                if t_sp and t_sp != workspace_id:
                    neighbor_ws.add(t_sp)
        return sorted(neighbor_ws)

    def shared_libs(self) -> list:
        """Return lib:package nodes connected to 2+ workspaces."""
        libs = {nid: n for nid, n in self.nodes.items()
                if n.get("layer") == "lib" and n.get("type") == "package"}
        results = []
        for lid, ln in libs.items():
            consumers = set()
            for t in self.adj.get(lid, []):
                tn = self.nodes.get(t, {})
                sp = tn.get("scope_path", tn.get("repo", ""))
                if sp:
                    consumers.add(sp)
            for s in self.rev.get(lid, []):
                sn = self.nodes.get(s, {})
                sp = sn.get("scope_path", sn.get("repo", ""))
                if sp:
                    consumers.add(sp)
            if len(consumers) >= 2:
                results.append({"id": lid, "name": ln.get("label", ""), "used_by": sorted(consumers)})
        return results

    def shared_tables(self) -> list:
        """Return db:table nodes referenced by 2+ workspaces."""
        tables = {nid: n for nid, n in self.nodes.items()
                  if n.get("layer") == "db" and n.get("type") == "table"}
        results = []
        for tid, tn in tables.items():
            ws = set()
            for s in self.rev.get(tid, []):
                sn = self.nodes.get(s, {})
                sp = sn.get("scope_path", sn.get("repo", ""))
                if sp:
                    ws.add(sp)
            if len(ws) >= 2:
                results.append({"id": tid, "name": tn.get("label", ""), "used_by": sorted(ws)})
        return results

    def shared_envs(self) -> list:
        """Return config:env nodes referenced by 2+ workspaces."""
        envs = {nid: n for nid, n in self.nodes.items()
                if n.get("layer") == "config" and n.get("type") == "env"}
        results = []
        for eid, en in envs.items():
            ws = set()
            for s in self.rev.get(eid, []):
                sn = self.nodes.get(s, {})
                sp = sn.get("scope_path", sn.get("repo", ""))
                if sp:
                    ws.add(sp)
            for t in self.adj.get(eid, []):
                tn = self.nodes.get(t, {})
                sp = tn.get("scope_path", tn.get("repo", ""))
                if sp:
                    ws.add(sp)
            if len(ws) >= 2:
                results.append({"id": eid, "name": en.get("label", ""), "used_by": sorted(ws)})
        return results

    # ── Resolution ───────────────────────────────────────────────────────────

    def _resolve(self, query: str) -> list:
        if query in self.nodes: return [query]
        q = query.lower()
        return [nid for nid in self.nodes if q in nid.lower() or q in self.nodes[nid].get("label","").lower()]


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    gq = GraphQuery(str(base / "output" / "system_graph.json"),
                    str(base / "output" / "e2e_flows.json"))
    print(f"Loaded: {len(gq.nodes)} nodes, {sum(len(v) for v in gq.adj.values())} edges")
    print(f"Flow catalogs: {list(gq._flows.keys())}")

    r = gq.find_by_name("flagTypes", min_confidence=0.5)
    print(f"\nSearch 'flagTypes' (conf>=0.5): {len(r)} results")

    nb = gq.neighborhood("bff:endpoint:marvel_flags_bff:/flagTypes", depth=2, node_budget=20)
    print(f"Neighborhood /flagTypes: {nb['node_count']} nodes, truncated={nb['truncated']}")

    fl = gq.flows_for_node("bff:endpoint:marvel_flags_bff:/flagTypes")
    print(f"Flows for /flagTypes: {len(fl)}")
    for f in fl[:3]:
        print(f"  {f['catalog']:15s} {f['flow_id'][:50]}")

    print(f"\nOrphan BFF (no UI): {len(gq.orphan_bff_no_ui())}")
    print(f"Orphan API (no BFF): {len(gq.orphan_api_no_bff())}")
    print(f"Orphan DB (no API): {len(gq.orphan_db_no_api())}")
    print(f"Orphan UI fd (no BFF): {len(gq.orphan_ui_no_bff())}")

    # Flow tabs
    summary = gq.flow_summary()
    print(f"\n{'='*50}")
    print(f"  Flow Summary")
    print(f"{'='*50}")
    print(f"  Complete flows: {summary['complete']}")
    print(f"  Partial flows:  {summary['partial']}")
    print(f"  Total:          {summary['total']}")
    if summary["breakpoint_reasons"]:
        print(f"  Breakpoint reasons:")
        for reason, cnt in summary["breakpoint_reasons"].items():
            print(f"    {reason:40s} {cnt:4d}")
    if summary["breakpoint_layers"]:
        print(f"  Breakpoint layers:")
        for layer, cnt in summary["breakpoint_layers"].items():
            print(f"    {layer:20s} {cnt:4d}")

    comp = gq.complete_flows(limit=3)
    print(f"\n  [Complete] Top 3:")
    for f in comp:
        print(f"    {f['surface']['entry']:40s} -> {f['surface']['terminal']}")

    part = gq.partial_flows(limit=3)
    print(f"  [Partial]  Top 3:")
    for f in part:
        bp = f.get('breakpoint', {})
        print(f"    {f['surface']['entry']:40s} BROKE at {bp.get('node_name','')} ({bp.get('reason_code','')})")