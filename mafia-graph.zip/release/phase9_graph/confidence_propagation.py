"""
MAFIA — Confidence Propagation Engine
=======================================
Propagates confidence scores across graph edges with decay,
computes flow-level aggregated confidence, and identifies
"confidence cliffs" where trust drops sharply.

Usage:
    engine = ConfidencePropagation(system_graph)
    flow = engine.propagate_flow(hops)
    cliffs = engine.find_cliffs(hops)
    zones = engine.trust_zones(system_graph)
"""

from collections import defaultdict

# Decay rate per hop — confidence drops by this factor each hop
HOP_DECAY = 0.92

# Edge-type reliability weights — some relation types are more trustworthy
EDGE_RELIABILITY = {
    "fetches": 0.95,
    "calls_api": 0.90,
    "routes_to": 0.95,
    "delegates_to": 0.92,
    "uses_repo": 0.90,
    "calls_function": 0.88,
    "reads_from": 0.85,
    "writes_to": 0.85,
    "entity_maps_to": 0.80,
    "calls": 0.85,
    "invokes_http": 0.88,
}

# Cliff threshold — a drop of this much between consecutive hops is a "cliff"
CLIFF_THRESHOLD = 0.15


def propagate_flow(hops: list) -> dict:
    """
    Compute propagated confidence for a flow's hop chain.

    Args:
        hops: list of hop dicts with 'confidence', 'next_relation' keys

    Returns:
        dict with per-hop propagated confidence, aggregated scores, cliffs
    """
    if not hops:
        return {"hops": [], "aggregated": {}, "cliffs": [], "trust_zone": "unknown"}

    propagated = []
    prev_conf = 1.0

    for i, hop in enumerate(hops):
        node_conf = hop.get("confidence", 0.5)

        # Edge confidence from the relation connecting to this hop
        edge_conf = 1.0
        if i > 0:
            prev_hop = hops[i - 1]
            rel = prev_hop.get("next_relation") or {}
            edge_conf = rel.get("confidence", 0.8)
            edge_type = rel.get("type", "")
            edge_reliability = EDGE_RELIABILITY.get(edge_type, 0.85)
            edge_conf = edge_conf * edge_reliability

        # Propagated = node confidence * edge confidence * decay from previous
        decayed = prev_conf * HOP_DECAY
        prop_conf = round(min(node_conf, decayed * edge_conf), 4)

        propagated.append({
            "id": hop.get("id", ""),
            "name": hop.get("name", ""),
            "layer": hop.get("layer", ""),
            "original_confidence": node_conf,
            "propagated_confidence": prop_conf,
            "hop_index": i,
            "decay_factor": round(HOP_DECAY ** i, 4),
        })
        prev_conf = prop_conf

    # Aggregated scores
    orig_confs = [h["original_confidence"] for h in propagated]
    prop_confs = [h["propagated_confidence"] for h in propagated]

    aggregated = {
        "min_original": round(min(orig_confs), 4),
        "avg_original": round(sum(orig_confs) / len(orig_confs), 4),
        "min_propagated": round(min(prop_confs), 4),
        "avg_propagated": round(sum(prop_confs) / len(prop_confs), 4),
        "weakest_link": round(min(prop_confs), 4),
        "end_to_end": round(prop_confs[-1], 4),
        "total_decay": round(prop_confs[-1] / prop_confs[0], 4) if prop_confs[0] > 0 else 0,
    }

    # Find confidence cliffs
    cliffs = []
    for i in range(1, len(prop_confs)):
        drop = prop_confs[i - 1] - prop_confs[i]
        if drop >= CLIFF_THRESHOLD:
            cliffs.append({
                "from_hop": i - 1,
                "to_hop": i,
                "from_id": propagated[i - 1]["id"],
                "to_id": propagated[i]["id"],
                "drop": round(drop, 4),
                "from_confidence": prop_confs[i - 1],
                "to_confidence": prop_confs[i],
            })

    # Trust zone classification
    wl = aggregated["weakest_link"]
    if wl >= 0.80:
        zone = "deterministic"
    elif wl >= 0.60:
        zone = "high_trust"
    elif wl >= 0.40:
        zone = "mixed"
    else:
        zone = "low_trust"

    return {
        "hops": propagated,
        "aggregated": aggregated,
        "cliffs": cliffs,
        "trust_zone": zone,
    }


def compute_graph_trust_zones(nodes: list, edges: list) -> dict:
    """
    Classify all nodes into trust zones based on their local
    neighborhood confidence.

    Returns:
        dict with zone counts and per-node zone assignments
    """
    # Build adjacency with edge confidence
    adj_conf = defaultdict(list)
    for e in edges:
        src = e.get("source", "")
        tgt = e.get("target", "")
        ec = e.get("confidence", 0.5)
        adj_conf[src].append(ec)
        adj_conf[tgt].append(ec)

    zones = {"deterministic": [], "high_trust": [], "mixed": [], "low_trust": []}
    node_zones = {}

    for n in nodes:
        nid = n.get("id", "")
        nc = n.get("confidence", 0.5)
        neighbor_confs = adj_conf.get(nid, [])
        if neighbor_confs:
            local_avg = (nc + sum(neighbor_confs)) / (1 + len(neighbor_confs))
        else:
            local_avg = nc

        if local_avg >= 0.80:
            z = "deterministic"
        elif local_avg >= 0.60:
            z = "high_trust"
        elif local_avg >= 0.40:
            z = "mixed"
        else:
            z = "low_trust"

        zones[z].append(nid)
        node_zones[nid] = {"zone": z, "local_confidence": round(local_avg, 4)}

    return {
        "zone_counts": {k: len(v) for k, v in zones.items()},
        "node_zones": node_zones,
    }
