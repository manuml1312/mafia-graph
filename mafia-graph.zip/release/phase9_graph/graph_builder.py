"""
MAFIA Phase 9 — Graph Builder (Spec-Complete)
================================================
Produces three artifacts:
  1. system_graph.json  — Flow edges only, meta with allowlist + counts
  2. e2e_flows.json     — Multi-catalog with breakpoints, confidence_range,
                          repos_involved, hop-level confidence/evidence
  3. graph_views.json   — Layer + repo pre-aggregations
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict, deque

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

FLOW_ALLOWLIST = {
    "fetches", "calls_api", "routes_to", "delegates_to", "uses_repo",
    "calls_function", "reads_from", "writes_to", "entity_maps_to",
    "uses_table", "calls", "invokes_http", "validates_with",
    # v2: cross-scope edges can extend flows
    "cross_workspace_import", "cross_repo_import",
}
STRUCTURAL = {"belongs_to_repo", "belongs_to_layer", "defined_in", "imports", "exports",
              "potential_shared_table",
              # v2: structural cross-scope edges
              "workspace_depends_on", "shared_lib_used_by", "consumes_artifact",
              "shares_table_with", "shares_env_with",
}
LAYER_ORDER = {"ui": 0, "bff": 1, "api": 2, "db": 3, "config": 4, "shared": 5,
               "code": 6, "lib": 7, "infra": 8, "test": 9, "doc": 10, "data": 3}

# Infrastructure endpoints — never real business logic flow terminals.
# Covers Flask, FastAPI, Django, Express, Spring Boot, Koa, Rails, etc.
# Pattern-based: exact names + common prefixes/suffixes.
_INFRA_ENDPOINT_NAMES = {
    # Static assets (Flask, Django, Rails, Express)
    "static", "staticfiles", "media", "assets", "public",
    # Health / readiness (Kubernetes, load balancers, all frameworks)
    "health", "healthz", "healthcheck", "health_check",
    "ready", "readyz", "readiness", "liveness", "alive",
    "ping", "pong", "status", "heartbeat",
    # Metadata / discovery
    "favicon", "favicon.ico", "robots", "robots.txt",
    "sitemap", "sitemap.xml", "manifest", "manifest.json",
    # API docs (FastAPI, Flask-RESTX, Swagger, OpenAPI)
    "docs", "redoc", "openapi", "openapi.json", "swagger",
    "swagger-ui", "api-docs", "api_docs", "spec",
    # Debug / dev tools
    "__debug__", "_debug_toolbar", "debug", "debugger",
    # Metrics / monitoring
    "metrics", "prometheus", "stats",
    # Auth infrastructure (not business logic)
    "login_redirect", "logout_redirect", "oauth_callback",
    "csrf", "csrf_token",
}

# Also skip endpoints whose path starts with these prefixes
_INFRA_PATH_PREFIXES = (
    "/static/", "/media/", "/assets/", "/favicon",
    "/_",  # Flask/Django internal routes
    "/health", "/ping", "/metrics", "/docs", "/openapi",
)

# ── Breakpoint reason codes ──────────────────────────────────────────────────
BREAK_REASONS = {
    ("bff", "endpoint"): ("NO_ROUTE_REGISTRATION", "BFF endpoint has no routes_to relation"),
    ("bff", "controller"): ("NO_TRACED_API_CALL", "BFF controller has no calls_api to API constant"),
    ("bff", "constant"): ("NO_MATCHED_API_ENDPOINT", "BFF constant path did not match any API endpoint"),
    ("api", "endpoint"): ("NO_CONTROLLER_LINK", "API endpoint has no routes_to controller"),
    ("api", "controller"): ("SERVICE_CALL_NOT_TRACED", "Controller body service calls could not be resolved"),
    ("api", "service"): ("REPOSITORY_NOT_TRACED", "Service to repository link missing"),
    ("api", "repository"): ("DB_LINEAGE_MISSING", "Repository has no calls_function or reads_from to DB"),
}


def _is_infra_endpoint(entity: dict) -> bool:
    """Return True if this entity is infrastructure noise, not business logic.
    Works across Flask, FastAPI, Django, Express, Spring Boot, Koa, Rails."""
    if entity.get("layer") != "api" or entity.get("type") != "endpoint":
        return False
    name = entity.get("name", "").lower().strip("/")
    if name in _INFRA_ENDPOINT_NAMES:
        return True
    # Check HTTP path stored in properties
    path = entity.get("properties", {}).get("http_path", "") or \
           entity.get("properties", {}).get("endpoint_path", "")
    if path:
        path_lower = path.lower()
        if any(path_lower.startswith(p) for p in _INFRA_PATH_PREFIXES):
            return True
    # Check qualifier (entity ID often encodes the path)
    qualifier = entity.get("id", "").lower()
    if ":flask:static" in qualifier or ":flask:favicon" in qualifier:
        return True
    return False


def build_graph(output_dir: str) -> dict:
    output = Path(output_dir)
    entities = _load_jsonl(output / "entities.jsonl")
    relations = _load_jsonl(output / "relations.jsonl")

    # Validate-before-build: reject malformed records inline (Change 3)
    entities, relations, dropped = _validate_before_build(entities, relations)
    if dropped:
        print(f"  [WARN] Dropped {dropped} malformed records before graph build")

    entity_map = {e["id"]: e for e in entities}
    flow_rels = [r for r in relations if r.get("type", "") in FLOW_ALLOWLIST]

    adj = defaultdict(list)
    rev = defaultdict(list)
    edge_map = {}
    for r in flow_rels:
        src, tgt = r.get("source", ""), r.get("target", "")
        if src in entity_map and tgt in entity_map:
            adj[src].append((tgt, r))
            rev[tgt].append((src, r))
            edge_map[(src, tgt)] = r

    # 1. system_graph.json
    sg = _build_system_graph(entities, flow_rels, entity_map)
    _write(output / "system_graph.json", sg)

    # 2. e2e_flows.json
    catalogs = _build_all_catalogs(entities, entity_map, adj, rev, edge_map)
    catalogs["id_format_version"] = 2
    _write(output / "e2e_flows.json", catalogs)

    # 3. graph_views.json
    views = _build_views(entities, flow_rels, entity_map, relations)
    _write(output / "graph_views.json", views)

    # 4. workspace_graph.json (v2)
    ws_graph = _build_workspace_graph(entities, relations)
    _write(output / "workspace_graph.json", ws_graph)

    # 5. shared_resources.json (v2)
    shared = _build_shared_resources(relations)
    _write(output / "shared_resources.json", shared)

    cat_summary = {k: len(v) for k, v in catalogs.get("catalogs", {}).items()}
    bp_sum = catalogs.get("breakpoint_summary", {})
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 9 -- Graph Construction")
    print(f"{'='*60}")
    print(f"  System graph:  {sg['meta']['node_count']} nodes, {sg['meta']['edge_count']} edges")
    print(f"  Flow catalogs:")
    for name, count in cat_summary.items():
        if name == "full_chains":
            print(f"    {name:20s} {count:5d} flows  ({bp_sum.get('total_complete',0)} complete, {bp_sum.get('total_partial',0)} partial)")
        elif name in ("complete_flows", "partial_flows"):
            continue
        else:
            print(f"    {name:20s} {count:5d} flows")
    if bp_sum.get("by_reason"):
        print(f"  Partial flow breakpoints:")
        for reason, cnt in bp_sum["by_reason"].items():
            print(f"    {reason:40s} {cnt:4d}")
    print(f"  Output: {output}")
    print(f"{'='*60}\n")
    return {"system_graph": sg["meta"], "catalogs": cat_summary, "breakpoint_summary": bp_sum}


# ── 1. System graph ──────────────────────────────────────────────────────────

def _build_system_graph(entities, flow_rels, entity_map):
    nodes = [{
        "id": e["id"], "label": e.get("name", ""), "layer": e.get("layer", ""),
        "type": e.get("type", ""), "repo": e.get("repo", ""),
        "scope_path": e.get("scope_path", e.get("repo", "")),
        "codebase": e.get("codebase", e.get("repo", "")),
        "workspace": e.get("workspace", e.get("repo", "")),
        "file": e.get("file"), "line": e.get("line"),
        "confidence": e.get("confidence", 0),
        "evidence_method": e.get("evidence", {}).get("method", ""),
        "properties": e.get("properties", {}),
        "warnings": e.get("warnings", []),
    } for e in entities]

    edges = [{
        "id": r["id"], "source": r.get("source", ""), "target": r.get("target", ""),
        "type": r.get("type", ""), "confidence": r.get("confidence", 0),
        "evidence_method": r.get("evidence", {}).get("method", ""),
        "properties": r.get("properties", {}),
    } for r in flow_rels if r.get("source", "") in entity_map and r.get("target", "") in entity_map]

    return {
        "id_format_version": 2,
        "meta": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "node_count": len(nodes),
            "edge_count": len(edges),
            "flow_edge_allowlist": sorted(FLOW_ALLOWLIST),
            "structural_excluded": sorted(STRUCTURAL),
        },
        "nodes": nodes,
        "edges": edges,
    }


# ── 2. Multi-catalog flow assembly ──────────────────────────────────────────

def _build_all_catalogs(entities, entity_map, adj, rev, edge_map):
    # Filter config.property noise AND infra endpoints
    fmap = {eid: e for eid, e in entity_map.items()
            if not (e.get("layer") == "config" and e.get("type") == "property")
            and not _is_infra_endpoint(e)}
    fadj = defaultdict(list)
    for src in adj:
        if src not in fmap:
            continue
        for tgt, r in adj[src]:
            if tgt in fmap:
                fadj[src].append((tgt, r))

    by_lt = defaultdict(list)
    for e in entities:
        if e["id"] in fmap:
            by_lt[(e.get("layer", ""), e.get("type", ""))].append(e)

    has_inbound = set()
    for src in fadj:
        for tgt, _ in fadj[src]:
            has_inbound.add(tgt)

    cats = {}
    cats["ui_to_bff"] = _catalog(by_lt[("ui","fetch_def")] + by_lt[("ui","component")], "bff", fmap, fadj, edge_map, 3)
    cats["ui_to_db"] = _catalog(by_lt[("ui","fetch_def")] + by_lt[("ui","component")] + by_lt[("ui","route")], "db", fmap, fadj, edge_map, 15)
    cats["bff_to_api"] = _catalog(by_lt[("bff","endpoint")], "api", fmap, fadj, edge_map, 6)
    cats["bff_to_db"] = _catalog(by_lt[("bff","endpoint")], "db", fmap, fadj, edge_map, 15)
    cats["api_to_db"] = _catalog(by_lt[("api","endpoint")], "db", fmap, fadj, edge_map, 10)
    cats["db_internal"] = _db_internal(by_lt[("db","function")], fmap, fadj, edge_map)

    # full_chains — start from UI components, fetch_defs, routes, and BFF endpoints
    entries = []
    seen_entries = set()
    for e in entities:
        key = (e.get("layer",""), e.get("type",""))
        eid = e["id"]
        if eid not in fmap or eid in seen_entries:
            continue
        # Include all UI entry points and BFF endpoints
        if key in {("ui","component"),("ui","fetch_def"),("ui","route"),("bff","endpoint")}:
            if eid in fadj:  # only if it has outgoing edges
                entries.append(e)
                seen_entries.add(eid)
        # Also include api:endpoint as entry if it has db-reachable paths
        # (catches Flask routes that call BigQueryService directly)
        elif key == ("api","endpoint") and eid in fadj:
            entries.append(e)
            seen_entries.add(eid)
    all_chains = _full_chains(entries, fmap, fadj, edge_map)
    cats["full_chains"] = all_chains
    cats["complete_flows"] = [f for f in all_chains if f.get("completeness") == "complete"]
    cats["partial_flows"] = [f for f in all_chains if f.get("completeness") == "partial"]

    # call_chains — trace from any root node (has outgoing but no incoming edges)
    # This captures intra-layer call graphs for single-layer projects
    cats["call_chains"] = _call_chains(fmap, fadj, edge_map, has_inbound)

    # ── Breakpoint summary for partial flows ─────────────────────────────
    bp_counts = defaultdict(int)
    bp_by_layer = defaultdict(int)
    for f in cats["partial_flows"]:
        bp = f.get("breakpoint", {})
        bp_counts[bp.get("reason_code", "UNKNOWN")] += 1
        bp_by_layer[bp.get("layer", "unknown")] += 1

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "catalogs": cats,
        "summary": {n: {"total": len(fl), "reached_target": sum(1 for f in fl if f.get("reached_target"))}
                    for n, fl in cats.items()},
        "breakpoint_summary": {
            "total_partial": len(cats["partial_flows"]),
            "total_complete": len(cats["complete_flows"]),
            "by_reason": dict(sorted(bp_counts.items(), key=lambda x: -x[1])),
            "by_layer": dict(sorted(bp_by_layer.items(), key=lambda x: -x[1])),
        },
    }


def _catalog(sources, target_layer, emap, adj, edge_map, max_depth):
    flows, seen = [], set()
    for src in sources:
        sid = src["id"]
        if sid in seen: continue
        seen.add(sid)
        visited, parent = _bfs(sid, adj, max_depth)
        targets = [(nid, d) for nid, d in visited.items()
                   if d > 0 and emap.get(nid, {}).get("layer", "") == target_layer]
        if not targets: continue
        targets.sort(key=lambda x: -x[1])
        chain = _path(sid, targets[0][0], parent)
        flows.append(_build_flow_record(
            f"{src.get('layer','')}_to_{target_layer}::{sid}",
            chain, emap, adj, edge_map, reached=True))
    flows.sort(key=lambda f: -f["hop_count"])
    return flows


def _db_internal(functions, emap, adj, edge_map):
    by_terminal = {}
    seen = set()
    for src in functions:
        sid = src["id"]
        if sid in seen: continue
        seen.add(sid)
        visited, parent = _bfs(sid, adj, 5)
        tables = [(nid, d) for nid, d in visited.items()
                  if d > 0 and emap.get(nid, {}).get("type", "") in ("table", "view")]
        if not tables: continue
        tables.sort(key=lambda x: -x[1])
        best = tables[0][0]
        chain = _path(sid, best, parent)
        existing = by_terminal.get(best)
        if existing and existing["hop_count"] >= len(chain): continue
        by_terminal[best] = _build_flow_record(f"db_internal::{sid}", chain, emap, adj, edge_map, reached=True)
    return sorted(by_terminal.values(), key=lambda f: -f["hop_count"])


def _full_chains(entries, emap, adj, edge_map):
    flows, seen = [], set()
    for entry in entries:
        eid = entry["id"]
        if eid in seen: continue
        seen.add(eid)
        visited, parent = _bfs(eid, adj, 15)

        # Prefer DB targets; skip infra-only endpoints as terminals
        db_targets = [(nid, d) for nid, d in visited.items()
                      if emap.get(nid, {}).get("layer") == "db" and d > 0]
        db_targets.sort(key=lambda x: -x[1])

        if db_targets:
            chain = _path(eid, db_targets[0][0], parent)
            rec = _build_flow_record(f"full::{eid}", chain, emap, adj, edge_map, reached=True)
            rec["completeness"] = "complete"
            rec["db_nodes_reachable"] = len(db_targets)
            rec["total_nodes_reachable"] = len(visited)
        else:
            # Find deepest non-infra node
            candidates = sorted(
                [(nid, d) for nid, d in visited.items() if d > 0],
                key=lambda x: -x[1]
            )
            # Skip infra endpoints (flask:static, health checks, etc.)
            deepest = None
            for nid, d in candidates:
                if _is_infra_endpoint(emap.get(nid, {})):
                    continue
                deepest = (nid, d)
                break
            # Fallback to absolute deepest if all are infra
            if deepest is None and candidates:
                deepest = candidates[0]
            if deepest is None:
                deepest = (eid, 0)

            chain = _path(eid, deepest[0], parent)
            rec = _build_flow_record(f"full::{eid}", chain, emap, adj, edge_map, reached=False)
            rec["completeness"] = "partial"
            rec["db_nodes_reachable"] = 0
            rec["total_nodes_reachable"] = len(visited)
            # Add breakpoint
            last_node = emap.get(chain[-1], {})
            lt = (last_node.get("layer", ""), last_node.get("type", ""))
            reason = BREAK_REASONS.get(lt, ("CHAIN_ENDED", f"Chain ended at {lt[0]}.{lt[1]}"))
            rec["breakpoint"] = {
                "layer": last_node.get("layer", ""),
                "node_id": chain[-1],
                "node_name": last_node.get("name", ""),
                "reason_code": reason[0],
                "message": reason[1],
            }
        if len(chain) < 2: continue
        layers_touched = sorted(set(emap.get(nid, {}).get("layer", "") for nid in chain),
                                key=lambda l: LAYER_ORDER.get(l, 9))
        rec["layers_touched"] = layers_touched
        # v2: cross-scope flags
        scopes_in_flow = set(emap.get(nid, {}).get("scope_path", emap.get(nid, {}).get("repo", "")) for nid in chain)
        scopes_in_flow.discard("")
        repos_in_flow = set(emap.get(nid, {}).get("repo", "") for nid in chain)
        repos_in_flow.discard("")
        rec["crosses_workspace"] = len(scopes_in_flow) > 1
        rec["crosses_repo"] = len(repos_in_flow) > 1
        flows.append(rec)
    flows.sort(key=lambda f: (0 if f.get("completeness") == "complete" else 1, -f["hop_count"]))
    return flows


def _call_chains(emap, adj, edge_map, has_inbound, max_depth=12, max_chains=200):
    """Trace call chains from root nodes (outgoing edges, no incoming).
    Captures intra-layer call graphs for single-layer projects."""
    roots = [eid for eid in adj if eid not in has_inbound and eid in emap]
    roots.sort(key=lambda eid: -len(adj.get(eid, [])))

    flows = []
    used_terminals = set()
    for eid in roots:
        if len(flows) >= max_chains:
            break
        visited, parent = _bfs(eid, adj, max_depth)
        if len(visited) < 2:
            continue
        deepest = max(((nid, d) for nid, d in visited.items() if d > 0),
                      key=lambda x: x[1], default=None)
        if not deepest:
            continue
        if deepest[0] in used_terminals:
            continue
        used_terminals.add(deepest[0])
        chain = _path(eid, deepest[0], parent)
        if len(chain) < 2:
            continue
        rec = _build_flow_record(f"call_chain::{eid}", chain, emap, adj, edge_map, reached=True)
        rec["completeness"] = "traced"
        rec["total_nodes_reachable"] = len(visited)
        layers_touched = sorted(set(emap.get(nid, {}).get("layer", "") for nid in chain),
                                key=lambda l: LAYER_ORDER.get(l, 9))
        rec["layers_touched"] = layers_touched
        flows.append(rec)

    flows.sort(key=lambda f: -f["hop_count"])
    return flows


# ── Flow record builder ──────────────────────────────────────────────────────

def _build_flow_record(flow_id, chain, emap, adj, edge_map, reached):
    """Build a single flow record with all spec-required fields."""
    hops = []
    confidences = []
    repos = set()
    for i, nid in enumerate(chain):
        e = emap.get(nid, {})
        repos.add(e.get("repo", ""))
        nxt = None
        hop_conf = e.get("confidence", 0)
        hop_ev = e.get("evidence", {}).get("method", "") if isinstance(e.get("evidence"), dict) else ""
        if i < len(chain) - 1:
            next_id = chain[i + 1]
            edge = edge_map.get((nid, next_id))
            if not edge:
                for tgt, r in adj.get(nid, []):
                    if tgt == next_id:
                        edge = r
                        break
            if edge:
                nxt = {"type": edge.get("type", ""), "target": next_id,
                       "confidence": edge.get("confidence", 0)}
                confidences.append(edge.get("confidence", 0))
        confidences.append(hop_conf)
        hops.append({
            "id": nid, "name": e.get("name", ""), "layer": e.get("layer", ""),
            "type": e.get("type", ""), "repo": e.get("repo", ""),
            "confidence": hop_conf, "evidence_method": hop_ev,
            "next_relation": nxt,
        })

    repos.discard("")
    entry = emap.get(chain[0], {})
    terminal = emap.get(chain[-1], {})
    layers_seq = []
    for nid in chain:
        layer = emap.get(nid, {}).get("layer", "")
        if not layers_seq or layers_seq[-1] != layer:
            layers_seq.append(layer)

    conf_range = {
        "min": round(min(confidences), 3) if confidences else 0,
        "max": round(max(confidences), 3) if confidences else 0,
        "avg": round(sum(confidences) / len(confidences), 3) if confidences else 0,
    }

    return {
        "flow_id": flow_id,
        "entry": _ns(entry),
        "terminal": _ns(terminal),
        "reached_target": reached,
        "hop_count": len(chain),
        "confidence_range": conf_range,
        "repos_involved": sorted(repos),
        "surface": {"path": " -> ".join(layers_seq).upper(),
                    "entry": entry.get("name", ""), "terminal": terminal.get("name", "")},
        "standard": hops,
    }


# ── BFS / path / helpers ─────────────────────────────────────────────────────

def _bfs(start, adj, max_depth):
    visited = {start: 0}
    parent = {start: None}
    queue = deque([(start, 0)])
    while queue:
        nid, depth = queue.popleft()
        if depth >= max_depth: continue
        for tgt, _ in adj.get(nid, []):
            if tgt not in visited:
                visited[tgt] = depth + 1
                parent[tgt] = nid
                queue.append((tgt, depth + 1))
    return visited, parent

def _path(start, end, parent):
    p = []
    cur = end
    while cur is not None:
        p.append(cur)
        cur = parent.get(cur)
    p.reverse()
    return p if p and p[0] == start else [start]

def _ns(e):
    return {"id": e.get("id",""), "name": e.get("name", ""), "layer": e.get("layer", ""),
            "type": e.get("type", ""), "repo": e.get("repo", "")}


# ── 3. Graph views ───────────────────────────────────────────────────────────

def _build_views(entities, flow_rels, entity_map, all_relations=None):
    if all_relations is None:
        all_relations = flow_rels
    layer_nodes = defaultdict(list)
    for e in entities:
        layer_nodes[e.get("layer", "unknown")].append({
            "id": e["id"], "name": e.get("name", ""),
            "type": e.get("type", ""), "repo": e.get("repo", ""),
        })
    cross = []
    for r in flow_rels:
        s, t = entity_map.get(r.get("source",""),{}), entity_map.get(r.get("target",""),{})
        sl, tl = s.get("layer",""), t.get("layer","")
        if sl and tl and sl != tl:
            cross.append({"source": r["source"], "target": r["target"],
                          "type": r.get("type",""), "source_layer": sl,
                          "target_layer": tl, "confidence": r.get("confidence",0)})
    repo_nodes = defaultdict(lambda: {"entities": 0, "by_type": defaultdict(int)})
    for e in entities:
        repo_nodes[e.get("repo","unknown")]["entities"] += 1
        repo_nodes[e.get("repo","unknown")]["by_type"][f"{e.get('layer','')}.{e.get('type','')}"] += 1
    inter = defaultdict(lambda: {"count": 0, "types": defaultdict(int)})
    for r in flow_rels:
        s, t = entity_map.get(r.get("source",""),{}), entity_map.get(r.get("target",""),{})
        sr, tr = s.get("repo",""), t.get("repo","")
        if sr and tr and sr != tr:
            inter[f"{sr}-->{tr}"]["count"] += 1
            inter[f"{sr}-->{tr}"]["types"][r.get("type","")] += 1
    # v2: by_workspace, by_codebase, cross_scope_summary
    ws_nodes = defaultdict(lambda: {"node_count": 0, "edge_count": 0, "layers_present": set()})
    cb_nodes = defaultdict(lambda: {"node_count": 0, "edge_count": 0})
    for e in entities:
        sp = e.get("scope_path", e.get("repo", "unknown"))
        cb = e.get("codebase", e.get("repo", "unknown"))
        ws_nodes[sp]["node_count"] += 1
        ws_nodes[sp]["layers_present"].add(e.get("layer", ""))
        cb_nodes[cb]["node_count"] += 1
    for r in flow_rels:
        s_sp = entity_map.get(r.get("source", ""), {}).get("scope_path", "")
        if s_sp:
            ws_nodes[s_sp]["edge_count"] += 1

    cross_scope_counts = defaultdict(int)
    for r in all_relations:
        if r.get("cross_scope"):
            cross_scope_counts[r.get("boundary", "unknown")] += 1

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "layer_view": {
            "layers": {l: {"node_count": len(n), "nodes": n[:200]}
                       for l, n in sorted(layer_nodes.items(), key=lambda x: LAYER_ORDER.get(x[0],9))},
            "cross_layer_edges": cross,
        },
        "repo_view": {
            "repos": {r: {"entities": d["entities"], "by_type": dict(d["by_type"])}
                      for r, d in sorted(repo_nodes.items())},
            "inter_repo_edges": [
                {"source_repo": k.split("-->")[0], "target_repo": k.split("-->")[1], **v, "types": dict(v["types"])}
                for k, v in sorted(inter.items(), key=lambda x: -x[1]["count"])
            ],
        },
        "by_workspace": {
            sp: {"node_count": d["node_count"], "edge_count": d["edge_count"],
                 "layers_present": sorted(d["layers_present"])}
            for sp, d in sorted(ws_nodes.items())
        },
        "by_codebase": {
            cb: {"node_count": d["node_count"], "edge_count": d["edge_count"]}
            for cb, d in sorted(cb_nodes.items())
        },
        "cross_scope_summary": dict(cross_scope_counts),
    }

# ── 4. Workspace graph ───────────────────────────────────────────────────────

def _build_workspace_graph(entities, relations):
    """Build workspace-level aggregated graph: nodes=workspaces, edges=cross-scope counts."""
    ws_set = set()
    for e in entities:
        sp = e.get("scope_path", e.get("repo", ""))
        if sp:
            ws_set.add(sp)

    edge_counts = defaultdict(lambda: defaultdict(int))  # (src_ws, tgt_ws) → {rel_type: count}
    for r in relations:
        if not r.get("cross_scope"):
            continue
        src_scope = _extract_scope_from_id(r.get("source", ""))
        tgt_scope = _extract_scope_from_id(r.get("target", ""))
        if src_scope and tgt_scope and src_scope != tgt_scope:
            key = (src_scope, tgt_scope) if src_scope < tgt_scope else (tgt_scope, src_scope)
            edge_counts[key][r.get("type", "unknown")] += 1

    nodes = [{"id": ws, "type": "workspace"} for ws in sorted(ws_set)]
    edges = []
    for (src, tgt), types in sorted(edge_counts.items()):
        edges.append({
            "source": src, "target": tgt,
            "total": sum(types.values()),
            "by_type": dict(types),
        })

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "node_count": len(nodes),
        "edge_count": len(edges),
        "nodes": nodes,
        "edges": edges,
    }


# ── 5. Shared resources ──────────────────────────────────────────────────────

def _build_shared_resources(relations):
    """Build shared_resources.json from cross-scope relation types."""
    shared_libs = defaultdict(set)
    shared_tables = defaultdict(set)
    shared_envs = defaultdict(set)

    for r in relations:
        rt = r.get("type", "")
        props = r.get("properties", {})
        if rt == "shared_lib_used_by":
            lib_name = props.get("lib_name", _extract_scope_from_id(r.get("source", "")))
            consumer = r.get("target", "").replace("workspace:", "")
            shared_libs[lib_name].add(consumer)
        elif rt == "shares_table_with":
            table_name = props.get("table_name", "unknown")
            shared_tables[table_name].add(r.get("source", "").replace("workspace:", ""))
            shared_tables[table_name].add(r.get("target", "").replace("workspace:", ""))
        elif rt == "shares_env_with":
            env_name = props.get("env_name", "unknown")
            shared_envs[env_name].add(r.get("source", "").replace("workspace:", ""))
            shared_envs[env_name].add(r.get("target", "").replace("workspace:", ""))

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "shared_libs": [
            {"name": name, "used_by": sorted(consumers)}
            for name, consumers in sorted(shared_libs.items())
        ],
        "shared_tables": [
            {"name": name, "used_by": sorted(consumers)}
            for name, consumers in sorted(shared_tables.items())
        ],
        "shared_envs": [
            {"name": name, "used_by": sorted(consumers)}
            for name, consumers in sorted(shared_envs.items())
        ],
    }


def _extract_scope_from_id(entity_id: str) -> str:
    """Extract scope_path from entity ID (3rd colon-separated segment)."""
    if entity_id.startswith("workspace:"):
        return entity_id[len("workspace:"):]
    parts = entity_id.split(":", 3)
    return parts[2] if len(parts) >= 3 else ""


def _write(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip(): items.append(json.loads(line.strip()))
    except Exception: pass
    return items


def _validate_before_build(entities: list, relations: list) -> tuple[list, list, int]:
    """Inline validation: reject malformed records before graph construction.
    Returns (clean_entities, clean_relations, dropped_count)."""
    dropped = 0
    clean_e = []
    for e in entities:
        eid = e.get("id", "")
        if not eid or len(eid.split(":")) < 4:
            dropped += 1
            continue
        conf = e.get("confidence", -1)
        if not isinstance(conf, (int, float)) or not (0.0 <= conf <= 1.0):
            dropped += 1
            continue
        if not e.get("layer") or not e.get("type"):
            dropped += 1
            continue
        clean_e.append(e)

    entity_ids = {e["id"] for e in clean_e}
    clean_r = []
    for r in relations:
        rid = r.get("id", "")
        if not rid or not r.get("source") or not r.get("target") or not r.get("type"):
            dropped += 1
            continue
        conf = r.get("confidence", -1)
        if not isinstance(conf, (int, float)) or not (0.0 <= conf <= 1.0):
            dropped += 1
            continue
        if r["source"] not in entity_ids:
            dropped += 1
            continue
        clean_r.append(r)

    return clean_e, clean_r, dropped

if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    build_graph(str(base / "output"))
