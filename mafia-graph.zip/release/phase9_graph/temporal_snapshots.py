"""
MAFIA — Temporal Graph Snapshots
==================================
Introduces time as a first-class dimension:
- Snapshot graph per pipeline run (tagged with timestamp/label)
- Diff two snapshots (added/removed nodes, changed edges, new/broken flows)
- Flow drift detection over time

Storage: snapshots/ directory under output, one JSON per snapshot.

Usage:
    ts = TemporalSnapshots(output_dir)
    ts.save_snapshot(label="v2.3.1")
    diff = ts.diff("v2.3.0", "v2.3.1")
    drift = ts.flow_drift("v2.3.0", "v2.3.1")
"""

import json
import shutil
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict


class TemporalSnapshots:
    """Manages graph snapshots over time."""

    def __init__(self, output_dir: str):
        self.output_dir = Path(output_dir)
        self.snapshots_dir = self.output_dir / "snapshots"
        self.snapshots_dir.mkdir(parents=True, exist_ok=True)
        self.index_path = self.snapshots_dir / "snapshot_index.json"
        self.index = self._load_index()

    def _load_index(self) -> list:
        if self.index_path.exists():
            try:
                with open(self.index_path, "r", encoding="utf-8") as f:
                    return json.load(f).get("snapshots", [])
            except Exception:
                pass
        return []

    def _save_index(self):
        data = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total": len(self.index),
            "snapshots": self.index,
        }
        with open(self.index_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def save_snapshot(self, label: str = None) -> dict:
        """
        Save current graph + flows as a timestamped snapshot.
        """
        ts = datetime.now(timezone.utc)
        snap_id = ts.strftime("%Y%m%d_%H%M%S")
        label = label or snap_id
        snap_dir = self.snapshots_dir / snap_id

        snap_dir.mkdir(parents=True, exist_ok=True)

        # Copy key artifacts
        artifacts = ["system_graph.json", "e2e_flows.json", "coverage_report.json",
                      "quality_gate_report.json", "repo_manifest.json"]
        copied = []
        for name in artifacts:
            src = self.output_dir / name
            if src.exists():
                shutil.copy2(str(src), str(snap_dir / name))
                copied.append(name)

        # Compute summary stats
        stats = self._compute_stats(snap_dir)

        entry = {
            "id": snap_id,
            "label": label,
            "timestamp": ts.isoformat(),
            "artifacts": copied,
            "stats": stats,
        }
        self.index.append(entry)
        self._save_index()
        return entry

    def list_snapshots(self) -> list:
        return self.index

    def diff(self, snap_a: str, snap_b: str) -> dict:
        """
        Diff two snapshots. Returns added/removed/changed nodes and edges.
        snap_a, snap_b: snapshot IDs or labels.
        """
        graph_a = self._load_snapshot_graph(snap_a)
        graph_b = self._load_snapshot_graph(snap_b)

        if not graph_a or not graph_b:
            return {"error": "One or both snapshots not found"}

        nodes_a = {n["id"]: n for n in graph_a.get("nodes", [])}
        nodes_b = {n["id"]: n for n in graph_b.get("nodes", [])}

        edges_a = {(e["source"], e["target"]): e for e in graph_a.get("edges", [])}
        edges_b = {(e["source"], e["target"]): e for e in graph_b.get("edges", [])}

        # Node diffs
        added_nodes = []
        for nid in set(nodes_b) - set(nodes_a):
            n = nodes_b[nid]
            added_nodes.append({
                "id": nid, "label": n.get("label", ""),
                "layer": n.get("layer", ""), "type": n.get("type", ""),
            })

        removed_nodes = []
        for nid in set(nodes_a) - set(nodes_b):
            n = nodes_a[nid]
            removed_nodes.append({
                "id": nid, "label": n.get("label", ""),
                "layer": n.get("layer", ""), "type": n.get("type", ""),
            })

        changed_nodes = []
        for nid in set(nodes_a) & set(nodes_b):
            a, b = nodes_a[nid], nodes_b[nid]
            changes = []
            if a.get("confidence") != b.get("confidence"):
                changes.append(f"confidence: {a.get('confidence')} → {b.get('confidence')}")
            if a.get("layer") != b.get("layer"):
                changes.append(f"layer: {a.get('layer')} → {b.get('layer')}")
            if changes:
                changed_nodes.append({"id": nid, "label": b.get("label", ""), "changes": changes})

        # Edge diffs
        added_edges = []
        for key in set(edges_b) - set(edges_a):
            e = edges_b[key]
            added_edges.append({
                "source": key[0], "target": key[1],
                "type": e.get("type", ""),
            })

        removed_edges = []
        for key in set(edges_a) - set(edges_b):
            e = edges_a[key]
            removed_edges.append({
                "source": key[0], "target": key[1],
                "type": e.get("type", ""),
            })

        return {
            "snapshot_a": snap_a,
            "snapshot_b": snap_b,
            "nodes": {
                "added": added_nodes,
                "removed": removed_nodes,
                "changed": changed_nodes,
                "added_count": len(added_nodes),
                "removed_count": len(removed_nodes),
                "changed_count": len(changed_nodes),
            },
            "edges": {
                "added": added_edges[:100],
                "removed": removed_edges[:100],
                "added_count": len(added_edges),
                "removed_count": len(removed_edges),
            },
            "summary": {
                "nodes_a": len(nodes_a),
                "nodes_b": len(nodes_b),
                "edges_a": len(edges_a),
                "edges_b": len(edges_b),
                "net_node_change": len(nodes_b) - len(nodes_a),
                "net_edge_change": len(edges_b) - len(edges_a),
                "churn_rate": round(
                    (len(added_nodes) + len(removed_nodes)) / max(len(nodes_a), 1) * 100, 1
                ),
            },
        }

    def flow_drift(self, snap_a: str, snap_b: str) -> dict:
        """
        Compare flows between two snapshots.
        Detects new flows, broken flows, and changed flows.
        """
        flows_a = self._load_snapshot_flows(snap_a)
        flows_b = self._load_snapshot_flows(snap_b)

        if flows_a is None or flows_b is None:
            return {"error": "One or both snapshots not found"}

        fmap_a = {f.get("flow_id"): f for f in flows_a}
        fmap_b = {f.get("flow_id"): f for f in flows_b}

        new_flows = []
        for fid in set(fmap_b) - set(fmap_a):
            f = fmap_b[fid]
            new_flows.append({
                "flow_id": fid,
                "surface": f.get("surface", {}).get("path", ""),
                "hop_count": f.get("hop_count", 0),
            })

        broken_flows = []
        for fid in set(fmap_a) - set(fmap_b):
            f = fmap_a[fid]
            broken_flows.append({
                "flow_id": fid,
                "surface": f.get("surface", {}).get("path", ""),
                "hop_count": f.get("hop_count", 0),
            })

        changed_flows = []
        for fid in set(fmap_a) & set(fmap_b):
            a, b = fmap_a[fid], fmap_b[fid]
            changes = []
            if a.get("hop_count") != b.get("hop_count"):
                changes.append(f"hops: {a.get('hop_count')} → {b.get('hop_count')}")
            if a.get("reached_target") != b.get("reached_target"):
                changes.append(f"completeness: {a.get('reached_target')} → {b.get('reached_target')}")
            ca = a.get("confidence_range", {}).get("avg", 0)
            cb = b.get("confidence_range", {}).get("avg", 0)
            if abs(ca - cb) > 0.05:
                changes.append(f"confidence: {ca:.2f} → {cb:.2f}")
            if changes:
                changed_flows.append({"flow_id": fid, "changes": changes})

        return {
            "snapshot_a": snap_a,
            "snapshot_b": snap_b,
            "new_flows": new_flows,
            "broken_flows": broken_flows,
            "changed_flows": changed_flows,
            "summary": {
                "flows_a": len(fmap_a),
                "flows_b": len(fmap_b),
                "new_count": len(new_flows),
                "broken_count": len(broken_flows),
                "changed_count": len(changed_flows),
                "drift_rate": round(
                    (len(new_flows) + len(broken_flows)) / max(len(fmap_a), 1) * 100, 1
                ),
            },
        }

    def _load_snapshot_graph(self, snap_ref: str) -> dict:
        """Load system_graph.json from a snapshot by ID or label."""
        snap_dir = self._resolve_snapshot(snap_ref)
        if not snap_dir:
            return None
        path = snap_dir / "system_graph.json"
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _load_snapshot_flows(self, snap_ref: str) -> list:
        snap_dir = self._resolve_snapshot(snap_ref)
        if not snap_dir:
            return None
        path = snap_dir / "e2e_flows.json"
        if not path.exists():
            return []
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Flatten catalogs
        flows = []
        for cat_flows in (data.get("catalogs", {}) or {}).values():
            flows.extend(cat_flows)
        flows.extend(data.get("flows", []))
        return flows

    def _resolve_snapshot(self, ref: str) -> Path:
        """Resolve snapshot by ID or label."""
        # Try direct ID
        d = self.snapshots_dir / ref
        if d.exists():
            return d
        # Try label match
        for entry in self.index:
            if entry.get("label") == ref or entry.get("id") == ref:
                d = self.snapshots_dir / entry["id"]
                if d.exists():
                    return d
        return None

    def _compute_stats(self, snap_dir: Path) -> dict:
        stats = {}
        graph_path = snap_dir / "system_graph.json"
        if graph_path.exists():
            with open(graph_path, "r", encoding="utf-8") as f:
                g = json.load(f)
            stats["nodes"] = len(g.get("nodes", []))
            stats["edges"] = len(g.get("edges", []))
        flows_path = snap_dir / "e2e_flows.json"
        if flows_path.exists():
            with open(flows_path, "r", encoding="utf-8") as f:
                fd = json.load(f)
            total = sum(len(v) for v in (fd.get("catalogs", {}) or {}).values())
            total += len(fd.get("flows", []))
            stats["flows"] = total
        return stats
