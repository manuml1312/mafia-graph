"""
MAFIA Phase 9 — Topology Analyzer
=====================================
Runs community detection on the system graph and produces topology insights:
  - Communities with layer alignment analysis
  - God nodes (highest-degree entities, excluding config noise)
  - Bridge nodes (high betweenness, cross-community connectors)
  - Surprising connections (layer-skipping, cross-repo, low-confidence cross-layer)

Requires networkx. Uses graspologic Leiden if available, falls back to
networkx Louvain. Produces output/topology_report.json.

Usage:
    from phase9_graph.topology_analyzer import analyze_topology
    report = analyze_topology("output")
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ── Helpers ──────────────────────────────────────────────────────────────────

def _load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


LAYER_ORDER = {"ui": 0, "bff": 1, "api": 2, "db": 3, "config": 4, "shared": 5}

# Config entity types that connect to everything mechanically — exclude from god nodes
_NOISE_TYPES = {("config", "property"), ("config", "env"), ("config", "secret")}


# ── Community detection ──────────────────────────────────────────────────────

def _partition(G):
    """Run Leiden (graspologic) or Louvain (networkx) on undirected projection."""
    UG = G.to_undirected()
    try:
        from graspologic.partition import leiden
        return leiden(UG)
    except ImportError:
        pass
    import networkx as nx
    communities = nx.community.louvain_communities(
        UG, seed=42, max_level=10, threshold=1e-4
    )
    return {node: cid for cid, nodes in enumerate(communities) for node in nodes}


_MAX_COMMUNITY_FRACTION = 0.25
_MIN_SPLIT_SIZE = 10


def _detect_communities(G) -> dict[int, list[str]]:
    """Run community detection. Returns {community_id: [node_ids]}."""
    import networkx as nx

    if G.number_of_nodes() == 0:
        return {}
    if G.number_of_edges() == 0:
        return {i: [n] for i, n in enumerate(sorted(G.nodes))}

    isolates = [n for n in G.nodes() if G.degree(n) == 0]
    connected = G.subgraph([n for n in G.nodes() if G.degree(n) > 0])

    raw: dict[int, list[str]] = {}
    if connected.number_of_nodes() > 0:
        partition = _partition(connected)
        for node, cid in partition.items():
            raw.setdefault(cid, []).append(node)

    next_cid = max(raw.keys(), default=-1) + 1
    for node in isolates:
        raw[next_cid] = [node]
        next_cid += 1

    # Split oversized communities
    max_size = max(_MIN_SPLIT_SIZE, int(G.number_of_nodes() * _MAX_COMMUNITY_FRACTION))
    final: list[list[str]] = []
    for nodes in raw.values():
        if len(nodes) > max_size:
            sub = G.subgraph(nodes).to_undirected()
            if sub.number_of_edges() > 0:
                try:
                    sp = _partition(sub)
                    subs: dict[int, list[str]] = {}
                    for n, c in sp.items():
                        subs.setdefault(c, []).append(n)
                    if len(subs) > 1:
                        final.extend(sorted(v) for v in subs.values())
                        continue
                except Exception:
                    pass
            final.append(sorted(nodes))
        else:
            final.append(sorted(nodes))

    final.sort(key=len, reverse=True)
    return {i: nodes for i, nodes in enumerate(final)}


# ── Cohesion ─────────────────────────────────────────────────────────────────

def _cohesion_score(G, community_nodes: list[str]) -> float:
    n = len(community_nodes)
    if n <= 1:
        return 1.0
    sub = G.subgraph(community_nodes)
    actual = sub.number_of_edges()
    possible = n * (n - 1)  # directed
    return round(actual / possible, 3) if possible > 0 else 0.0


# ── God nodes ────────────────────────────────────────────────────────────────

def _find_god_nodes(G, entity_map: dict, top_n: int = 15) -> list[dict]:
    results = []
    for nid in sorted(G.nodes(), key=lambda n: G.in_degree(n) + G.out_degree(n), reverse=True):
        e = entity_map.get(nid, {})
        lt = (e.get("layer", ""), e.get("type", ""))
        if lt in _NOISE_TYPES:
            continue
        results.append({
            "id": nid,
            "name": e.get("name", nid),
            "layer": e.get("layer", ""),
            "type": e.get("type", ""),
            "repo": e.get("repo", ""),
            "in_degree": G.in_degree(nid),
            "out_degree": G.out_degree(nid),
            "total_degree": G.in_degree(nid) + G.out_degree(nid),
        })
        if len(results) >= top_n:
            break
    return results


# ── Bridge nodes ─────────────────────────────────────────────────────────────

def _find_bridge_nodes(G, communities: dict, entity_map: dict, top_n: int = 10) -> list[dict]:
    import networkx as nx

    if G.number_of_edges() == 0:
        return []

    node_community = {n: cid for cid, nodes in communities.items() for n in nodes}
    betweenness = nx.betweenness_centrality(G, k=min(200, G.number_of_nodes()))

    candidates = []
    for nid, score in betweenness.items():
        if score <= 0:
            continue
        e = entity_map.get(nid, {})
        lt = (e.get("layer", ""), e.get("type", ""))
        if lt in _NOISE_TYPES:
            continue
        my_cid = node_community.get(nid)
        neighbor_cids = {
            node_community.get(nb)
            for nb in set(G.predecessors(nid)) | set(G.successors(nid))
            if node_community.get(nb) != my_cid
        }
        neighbor_cids.discard(None)
        if not neighbor_cids:
            continue
        candidates.append({
            "id": nid,
            "name": e.get("name", nid),
            "layer": e.get("layer", ""),
            "type": e.get("type", ""),
            "betweenness": round(score, 4),
            "communities_connected": sorted(neighbor_cids),
        })

    candidates.sort(key=lambda x: -x["betweenness"])
    return candidates[:top_n]


# ── Surprising connections ───────────────────────────────────────────────────

def _find_surprising_connections(G, communities: dict, entity_map: dict, top_n: int = 10) -> list[dict]:
    node_community = {n: cid for cid, nodes in communities.items() for n in nodes}
    results = []

    for u, v, data in G.edges(data=True):
        eu = entity_map.get(u, {})
        ev = entity_map.get(v, {})
        lu = eu.get("layer", "")
        lv = ev.get("layer", "")
        if not lu or not lv:
            continue

        score = 0
        reasons = []

        # Layer skip: ui→db without bff/api in between
        lo_u = LAYER_ORDER.get(lu, 9)
        lo_v = LAYER_ORDER.get(lv, 9)
        gap = abs(lo_u - lo_v)
        if gap >= 2 and lu != "config" and lv != "config":
            skipped = [l for l, o in LAYER_ORDER.items() if min(lo_u, lo_v) < o < max(lo_u, lo_v)]
            score += gap
            reasons.append(f"skips layers: {' → '.join(skipped)}")

        # Cross-repo
        if eu.get("repo") and ev.get("repo") and eu["repo"] != ev["repo"]:
            score += 1
            reasons.append("cross-repo edge")

        # Low confidence cross-layer
        conf = data.get("confidence", 1.0)
        if lu != lv and conf < 0.70:
            score += 2
            reasons.append(f"low confidence cross-layer ({conf:.2f})")

        # Cross-community
        cu = node_community.get(u)
        cv = node_community.get(v)
        if cu is not None and cv is not None and cu != cv:
            score += 1
            reasons.append(f"bridges community {cu} → {cv}")

        if score >= 2:
            results.append({
                "source": u,
                "source_name": eu.get("name", u),
                "target": v,
                "target_name": ev.get("name", v),
                "relation": data.get("type", ""),
                "confidence": conf,
                "source_layer": lu,
                "target_layer": lv,
                "score": score,
                "why": "; ".join(reasons),
            })

    results.sort(key=lambda x: -x["score"])
    for r in results:
        r.pop("score")
    return results[:top_n]


# ── Layer-community alignment ────────────────────────────────────────────────

def _detect_layer_alignment(communities: dict, entity_map: dict) -> dict:
    well_aligned = mixed = misaligned = 0
    details = []

    for cid, nodes in communities.items():
        layer_counts: dict[str, int] = defaultdict(int)
        for nid in nodes:
            e = entity_map.get(nid, {})
            layer_counts[e.get("layer", "unknown")] += 1

        total = sum(layer_counts.values())
        if total == 0:
            continue

        dominant_layer = max(layer_counts, key=layer_counts.get)
        dominant_pct = layer_counts[dominant_layer] / total
        distribution = {l: round(c / total, 2) for l, c in sorted(layer_counts.items(), key=lambda x: -x[1])}

        if dominant_pct >= 0.75:
            alignment = "well_aligned"
            well_aligned += 1
        elif dominant_pct >= 0.50:
            alignment = "mixed"
            mixed += 1
        else:
            alignment = "misaligned"
            misaligned += 1

        details.append({
            "community": cid,
            "size": len(nodes),
            "dominant_layer": dominant_layer,
            "dominant_pct": round(dominant_pct, 2),
            "layer_distribution": distribution,
            "alignment": alignment,
        })

    return {
        "well_aligned": well_aligned,
        "mixed": mixed,
        "misaligned": misaligned,
        "details": details,
    }


# ── Cross-scope bridge nodes ─────────────────────────────────────────────────

def _find_cross_scope_bridges(G, entity_map: dict, top_n: int = 15) -> list[dict]:
    """Nodes that span workspaces: degree > 2 within their workspace AND ≥1 cross-scope edge."""
    # Group nodes by scope_path
    ws_nodes: dict[str, set] = defaultdict(set)
    for nid in G.nodes():
        sp = entity_map.get(nid, {}).get("scope_path", entity_map.get(nid, {}).get("repo", ""))
        ws_nodes[sp].add(nid)

    results = []
    for nid in G.nodes():
        e = entity_map.get(nid, {})
        lt = (e.get("layer", ""), e.get("type", ""))
        if lt in _NOISE_TYPES:
            continue
        my_scope = e.get("scope_path", e.get("repo", ""))
        my_ws = ws_nodes.get(my_scope, set())

        # Count intra-workspace degree
        neighbors = set(G.predecessors(nid)) | set(G.successors(nid))
        intra = sum(1 for nb in neighbors if nb in my_ws)
        cross = [nb for nb in neighbors if nb not in my_ws]

        if intra > 2 and len(cross) >= 1:
            cross_scopes = set()
            for nb in cross:
                nb_scope = entity_map.get(nb, {}).get("scope_path", entity_map.get(nb, {}).get("repo", ""))
                if nb_scope and nb_scope != my_scope:
                    cross_scopes.add(nb_scope)
            results.append({
                "id": nid,
                "name": e.get("name", nid),
                "layer": e.get("layer", ""),
                "type": e.get("type", ""),
                "scope_path": my_scope,
                "intra_degree": intra,
                "cross_scope_degree": len(cross),
                "cross_scopes": sorted(cross_scopes),
            })

    results.sort(key=lambda x: -(x["intra_degree"] + x["cross_scope_degree"]))
    return results[:top_n]


# ── Main entry point ─────────────────────────────────────────────────────────

def analyze_topology(output_dir: str) -> dict:
    """Read system_graph.json, run topology analysis, write topology_report.json."""
    try:
        import networkx as nx
    except ImportError:
        print("  [SKIP] Topology analysis requires networkx. pip install networkx")
        return {"error": "networkx not installed", "community_count": 0, "god_nodes": []}

    output = Path(output_dir)
    sg = _load_json(output / "system_graph.json")
    if not sg:
        print("  [SKIP] No system_graph.json found")
        return {"error": "no system_graph.json", "community_count": 0, "god_nodes": []}

    # Build directed NetworkX graph
    G = nx.DiGraph()
    entity_map = {}
    for node in sg.get("nodes", []):
        nid = node["id"]
        G.add_node(nid, **{k: v for k, v in node.items() if k != "id"})
        entity_map[nid] = node
    for edge in sg.get("edges", []):
        G.add_edge(edge["source"], edge["target"], **{k: v for k, v in edge.items() if k not in ("source", "target")})

    # Run analysis
    communities = _detect_communities(G)
    god_nodes = _find_god_nodes(G, entity_map)
    bridge_nodes = _find_bridge_nodes(G, communities, entity_map)
    surprising = _find_surprising_connections(G, communities, entity_map)
    alignment = _detect_layer_alignment(communities, entity_map)

    # Build community summaries
    community_summaries = {}
    for cid, nodes in communities.items():
        layer_counts: dict[str, int] = defaultdict(int)
        for nid in nodes:
            layer_counts[entity_map.get(nid, {}).get("layer", "unknown")] += 1
        dominant = max(layer_counts, key=layer_counts.get) if layer_counts else "unknown"
        total = sum(layer_counts.values())
        community_summaries[str(cid)] = {
            "size": len(nodes),
            "dominant_layer": dominant,
            "layer_distribution": {l: round(c / total, 2) for l, c in layer_counts.items()} if total else {},
            "cohesion": _cohesion_score(G, nodes),
            "members_sample": nodes[:10],
        }

    # Cross-scope bridges (v2)
    cross_scope_bridges = _find_cross_scope_bridges(G, entity_map)

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "graph_stats": {
            "nodes": G.number_of_nodes(),
            "edges": G.number_of_edges(),
        },
        "community_count": len(communities),
        "communities": community_summaries,
        "god_nodes": god_nodes,
        "bridge_nodes": bridge_nodes,
        "cross_scope_bridges": cross_scope_bridges,
        "surprising_connections": surprising,
        "layer_alignment": alignment,
    }

    report_path = output / "topology_report.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 9 -- Topology Analysis")
    print(f"{'='*60}")
    print(f"  Nodes: {G.number_of_nodes()}, Edges: {G.number_of_edges()}")
    print(f"  Communities: {len(communities)}")
    print(f"  God nodes: {', '.join(g['name'] for g in god_nodes[:5])}")
    print(f"  Bridge nodes: {len(bridge_nodes)}")
    print(f"  Cross-scope bridges: {len(cross_scope_bridges)}")
    print(f"  Surprising connections: {len(surprising)}")
    print(f"  Layer alignment: {alignment['well_aligned']} aligned, {alignment['mixed']} mixed, {alignment['misaligned']} misaligned")
    print(f"  Output: {report_path}")
    print(f"{'='*60}\n")

    return report
