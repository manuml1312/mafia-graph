# MAFIA Phase 9 — Graph Construction, Flow Assembly, and Query Utilities
