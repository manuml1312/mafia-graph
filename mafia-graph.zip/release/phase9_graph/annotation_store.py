"""
MAFIA — Decision Annotation System
=====================================
Allows humans to annotate nodes, edges, and flows with:
- Why a dependency exists
- Known risks / intentional tech debt
- Architectural decisions (ADRs)

Annotations are first-class entities: searchable, RAG-groundable,
and displayed in the explorer UI.

Storage: annotations.json in the output directory.
"""

import json
import uuid
from pathlib import Path
from datetime import datetime, timezone


class AnnotationStore:
    """Manages human annotations on graph entities."""

    def __init__(self, output_dir: str):
        self.path = Path(output_dir) / "annotations.json"
        self.annotations = []
        self._by_target = {}  # target_id -> [annotations]
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                with open(self.path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.annotations = data.get("annotations", [])
            except Exception:
                self.annotations = []
        self._rebuild_index()

    def _rebuild_index(self):
        self._by_target = {}
        for a in self.annotations:
            tid = a.get("target_id", "")
            if tid not in self._by_target:
                self._by_target[tid] = []
            self._by_target[tid].append(a)

    def _save(self):
        data = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total": len(self.annotations),
            "annotations": self.annotations,
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def add(self, target_id: str, target_type: str, category: str,
            text: str, author: str = "anonymous", tags: list = None,
            severity: str = "info") -> dict:
        """
        Add an annotation.

        Args:
            target_id: node ID, edge key, or flow ID
            target_type: "node", "edge", "flow", "general"
            category: "decision", "risk", "debt", "context", "todo"
            text: the annotation content
            author: who wrote it
            tags: optional tags for search
            severity: "info", "warning", "critical"

        Returns:
            The created annotation dict
        """
        annotation = {
            "id": f"ann:{uuid.uuid4().hex[:12]}",
            "target_id": target_id,
            "target_type": target_type,
            "category": category,
            "text": text,
            "author": author,
            "tags": tags or [],
            "severity": severity,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "provenance": "human",
        }
        self.annotations.append(annotation)
        self._rebuild_index()
        self._save()
        return annotation

    def get_for_target(self, target_id: str) -> list:
        """Get all annotations for a specific target."""
        return self._by_target.get(target_id, [])

    def search(self, query: str = "", category: str = "",
               severity: str = "", limit: int = 50) -> list:
        """Search annotations by text, category, or severity."""
        results = self.annotations
        if query:
            q = query.lower()
            results = [a for a in results
                       if q in a["text"].lower()
                       or q in a["target_id"].lower()
                       or any(q in t.lower() for t in a.get("tags", []))]
        if category:
            results = [a for a in results if a["category"] == category]
        if severity:
            results = [a for a in results if a["severity"] == severity]
        return results[:limit]

    def delete(self, annotation_id: str) -> bool:
        """Delete an annotation by ID."""
        before = len(self.annotations)
        self.annotations = [a for a in self.annotations if a["id"] != annotation_id]
        if len(self.annotations) < before:
            self._rebuild_index()
            self._save()
            return True
        return False

    def stats(self) -> dict:
        by_cat = {}
        by_sev = {}
        for a in self.annotations:
            c = a.get("category", "unknown")
            s = a.get("severity", "info")
            by_cat[c] = by_cat.get(c, 0) + 1
            by_sev[s] = by_sev.get(s, 0) + 1
        return {
            "total": len(self.annotations),
            "by_category": by_cat,
            "by_severity": by_sev,
        }

    def as_rag_documents(self) -> list:
        """
        Convert annotations to RAG-indexable documents.
        These get mixed into the vector index so the AI can
        reference human decisions.
        """
        docs = []
        for a in self.annotations:
            text = (
                f"[HUMAN ANNOTATION] [{a['category'].upper()}] "
                f"Target: {a['target_id']} — {a['text']}"
            )
            if a.get("tags"):
                text += f" (tags: {', '.join(a['tags'])})"
            docs.append({
                "doc_id": a["id"],
                "doc_type": "annotation",
                "text": text,
                "metadata": {
                    "target_id": a["target_id"],
                    "target_type": a["target_type"],
                    "category": a["category"],
                    "severity": a["severity"],
                    "author": a["author"],
                    "provenance": "human",
                    "confidence": 1.0,
                },
            })
        return docs
