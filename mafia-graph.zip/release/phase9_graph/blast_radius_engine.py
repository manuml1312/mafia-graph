"""
MAFIA Phase 9 — Blast Radius Engine
======================================
Standalone engine that reads system_graph.json and computes the impact
of a change at any node. Traverses the graph bidirectionally (downstream
for "what breaks" and upstream for "what depends on this") with
severity scoring based on depth, layer criticality, fan-out, and usage.

Designed as a lego block: consumed by the RAG retriever, the developer
UI, and the AI enrichment layer independently.

Usage:
    engine = BlastRadiusEngine("output/system_graph.json")
    result = engine.compute("bff:endpoint:marvel_flags_bff:/flagTypes")
    result = engine.compute("db:function:pg:dre.get_flag_types", direction="upstream")
    components = engine.list_components()
"""

import json
from pathlib import Path
from collections import defaultdict, deque
from typing import Optional


# ── Severity model ───────────────────────────────────────────────────────────

LAYER_CRITICALITY = {
    "db": 1.0,
    "api": 0.85,
    "bff": 0.70,
    "ui": 0.50,
    "config": 0.60,
    "shared": 0.40,
}


def _severity_bucket(score: float) -> str:
    if score >= 75:
        return "critical"
    if score >= 50:
        return "high"
    if score >= 25:
        return "medium"
    return "low"


class BlastRadiusEngine:
    """Computes blast radius from any node in the system graph."""

    def __init__(self, graph_path: Optional[str] = None):
        self.nodes = {}          # id -> node dict
        self.adj = defaultdict(list)   # id -> [downstream ids]
        self.rev = defaultdict(list)   # id -> [upstream ids]
        self._edge_map = {}      # (src, tgt) -> edge dict

        if graph_path:
            self.load(graph_path)

    def load(self, graph_path: str):
        """Load system_graph.json using shared cache to avoid double-parsing (#11)."""
        try:
            from phase11_search.graph_retriever import get_cached_graph
            data = get_cached_graph(graph_path)
        except ImportError:
            data = _load_json(graph_path)
        for node in data.get("nodes", []):
            self.nodes[node["id"]] = node
        for edge in data.get("edges", []):
            src, tgt = edge["source"], edge["target"]
            self.adj[src].append(tgt)
            self.rev[tgt].append(src)
            self._edge_map[(src, tgt)] = edge

    # ── Core computation ─────────────────────────────────────────────────────

    def compute(
        self,
        component_id: str,
        direction: str = "downstream",
        change_type: str = "failure",
        max_depth: int = 6,
    ) -> dict:
        """
        Compute blast radius from a component.

        Args:
            component_id: entity ID or partial match string
            direction: "downstream" (what breaks), "upstream" (what depends),
                       or "both"
            change_type: "failure" | "degradation" | "contract" — affects severity
            max_depth: max traversal hops

        Returns:
            dict with origin, impacted nodes (severity-scored), counts, paths
        """
        resolved = self._resolve(component_id)
        if not resolved:
            return {
                "origin": component_id,
                "direction": direction,
                "change_type": change_type,
                "total_impacted": 0,
                "severity_counts": {"critical": 0, "high": 0, "medium": 0, "low": 0},
                "nodes": [],
                "error": f"Component not found: {component_id}",
            }

        # Choose adjacency based on direction
        if direction == "upstream":
            graph = self.rev
        elif direction == "both":
            graph = defaultdict(list)
            for k, v in self.adj.items():
                graph[k].extend(v)
            for k, v in self.rev.items():
                graph[k].extend(v)
        else:
            graph = self.adj

        # BFS traversal
        visited = {}
        queue = deque()
        paths = {}  # node_id -> path from origin

        for r in resolved:
            queue.append((r, 0, [r]))
            visited[r] = 0
            paths[r] = [r]

        impacted = []
        while queue:
            node_id, depth, path = queue.popleft()
            if depth > max_depth:
                continue

            if depth > 0:
                score = self._compute_severity(node_id, depth, change_type)
                node = self.nodes.get(node_id, {})
                bucket = _severity_bucket(score)

                # Find the edge connecting to this node
                edge_type = ""
                if len(path) >= 2:
                    prev = path[-2]
                    edge = self._edge_map.get((prev, node_id)) or self._edge_map.get((node_id, prev))
                    edge_type = edge.get("type", "") if edge else ""

                impacted.append({
                    "id": node_id,
                    "label": node.get("label", ""),
                    "layer": node.get("layer", ""),
                    "type": node.get("type", ""),
                    "repo": node.get("repo", ""),
                    "depth": depth,
                    "severity": score,
                    "bucket": bucket,
                    "relation_from_parent": edge_type,
                    "fan_out": len(self.adj.get(node_id, [])),
                    "upstream_count": len(self.rev.get(node_id, [])),
                    "path": path,
                    "file": node.get("file"),
                    "confidence": node.get("confidence", 0),
                    "warnings": node.get("warnings", []),
                })

            for neighbor in graph.get(node_id, []):
                if neighbor not in visited:
                    visited[neighbor] = depth + 1
                    new_path = path + [neighbor]
                    queue.append((neighbor, depth + 1, new_path))
                    paths[neighbor] = new_path

        impacted.sort(key=lambda x: -x["severity"])

        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for n in impacted:
            counts[n["bucket"]] += 1

        # Group by layer for summary
        by_layer = defaultdict(list)
        for n in impacted:
            by_layer[n["layer"]].append(n["label"])

        origin_node = self.nodes.get(resolved[0], {})

        return {
            "origin": component_id,
            "origin_resolved": resolved,
            "origin_label": origin_node.get("label", ""),
            "origin_layer": origin_node.get("layer", ""),
            "direction": direction,
            "change_type": change_type,
            "total_impacted": len(impacted),
            "severity_counts": counts,
            "by_layer": {layer: len(nodes) for layer, nodes in by_layer.items()},
            "highest_severity_node": impacted[0] if impacted else None,
            "nodes": impacted,
        }

    # ── Severity scoring ─────────────────────────────────────────────────────

    def _compute_severity(self, node_id: str, depth: int, change_type: str) -> float:
        depth_score = max(10, 100 - (depth - 1) * 15)
        layer = self.nodes.get(node_id, {}).get("layer", "shared")
        crit = LAYER_CRITICALITY.get(layer, 0.5) * 100
        fan_out = len(self.adj.get(node_id, []))
        prop_score = min(100, fan_out * 15)
        usage = len(self.rev.get(node_id, []))
        usage_score = min(100, usage * 12)
        sensitivity = {"failure": 1.0, "degradation": 0.75, "contract": 0.85}.get(change_type, 1.0)

        raw = (
            depth_score * 0.30 +
            crit * 0.25 +
            prop_score * 0.20 +
            usage_score * 0.15 +
            (sensitivity * 100) * 0.10
        )
        return round(min(100, raw), 1)

    # ── Component resolution ─────────────────────────────────────────────────

    def _resolve(self, component_id: str) -> list:
        """Match component_id against node IDs — exact, then partial."""
        if component_id in self.nodes:
            return [component_id]
        cid = component_id.lower()
        return [
            nid for nid in self.nodes
            if cid in nid.lower() or cid in self.nodes[nid].get("label", "").lower()
        ]

    # ── Public queries ───────────────────────────────────────────────────────

    def list_components(self, layer: Optional[str] = None) -> list:
        """List all searchable components, optionally filtered by layer."""
        items = []
        for nid, node in self.nodes.items():
            nlayer = node.get("layer", "")
            if layer and nlayer != layer:
                continue
            # Skip config properties — too noisy for component search
            if nlayer == "config" and node.get("type") == "property":
                continue
            items.append({
                "id": nid,
                "label": node.get("label", ""),
                "layer": nlayer,
                "type": node.get("type", ""),
                "repo": node.get("repo", ""),
                "fan_out": len(self.adj.get(nid, [])),
                "upstream_count": len(self.rev.get(nid, [])),
            })
        items.sort(key=lambda x: (
            {"ui": 0, "bff": 1, "api": 2, "db": 3, "config": 4}.get(x["layer"], 9),
            x["label"],
        ))
        return items

    # ── Flow blast radius ─────────────────────────────────────────────────

    def compute_flow_blast(
        self,
        flow_hops: list,
        flow_id: str = "",
        direction: str = "both",
        change_type: str = "failure",
        max_depth: int = 4,
        all_flows: list = None,
    ) -> dict:
        """
        Compute blast radius for an entire flow.

        Args:
            flow_hops: list of node IDs in the flow
            flow_id: identifier for the flow
            direction: traversal direction
            change_type: failure/degradation/contract
            max_depth: max hops from any flow node
            all_flows: list of all flow dicts (with 'standard' hop arrays)
                       used to find collateral flows

        Returns:
            dict with impacted external nodes + collateral flows
        """
        flow_node_ids = set()
        for h in flow_hops:
            nid = h if isinstance(h, str) else h.get("id", "")
            if nid and nid in self.nodes:
                flow_node_ids.add(nid)

        if not flow_node_ids:
            return {"error": f"No valid nodes found in flow {flow_id}", "flow_id": flow_id,
                    "total_impacted": 0, "nodes": [], "collateral_flows": []}

        # Choose adjacency
        if direction == "upstream":
            graph = self.rev
        elif direction == "both":
            graph = defaultdict(list)
            for k, v in self.adj.items():
                graph[k].extend(v)
            for k, v in self.rev.items():
                graph[k].extend(v)
        else:
            graph = self.adj

        # BFS from ALL flow nodes simultaneously
        visited = {}
        queue = deque()
        for nid in flow_node_ids:
            queue.append((nid, 0))
            visited[nid] = 0

        external_nodes = []
        while queue:
            node_id, depth = queue.popleft()
            if depth > max_depth:
                continue
            # Only report nodes OUTSIDE the flow
            if depth > 0 and node_id not in flow_node_ids:
                score = self._compute_severity(node_id, depth, change_type)
                node = self.nodes.get(node_id, {})
                external_nodes.append({
                    "id": node_id,
                    "label": node.get("label", ""),
                    "layer": node.get("layer", ""),
                    "type": node.get("type", ""),
                    "repo": node.get("repo", ""),
                    "depth": depth,
                    "severity": score,
                    "bucket": _severity_bucket(score),
                    "fan_out": len(self.adj.get(node_id, [])),
                    "confidence": node.get("confidence", 0),
                })
            for neighbor in graph.get(node_id, []):
                if neighbor not in visited:
                    visited[neighbor] = depth + 1
                    queue.append((neighbor, depth + 1))

        external_nodes.sort(key=lambda x: -x["severity"])

        # Deduplicate (BFS guarantees shortest path, but just in case)
        seen = set()
        deduped = []
        for n in external_nodes:
            if n["id"] not in seen:
                seen.add(n["id"])
                deduped.append(n)
        external_nodes = deduped

        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        for n in external_nodes:
            counts[n["bucket"]] += 1

        by_layer = defaultdict(int)
        for n in external_nodes:
            by_layer[n["layer"]] += 1

        # Find collateral flows — other flows sharing impacted nodes
        impacted_ids = set(n["id"] for n in external_nodes) | flow_node_ids
        collateral_flows = []
        if all_flows:
            for f in all_flows:
                fid = f.get("flow_id", "")
                if fid == flow_id:
                    continue
                hops = f.get("standard", f.get("hops", []))
                hop_ids = set()
                for h in hops:
                    hid = h if isinstance(h, str) else h.get("id", "")
                    if hid:
                        hop_ids.add(hid)
                shared = hop_ids & impacted_ids
                if shared:
                    collateral_flows.append({
                        "flow_id": fid,
                        "surface": f.get("surface", {}).get("path", fid),
                        "shared_node_count": len(shared),
                        "shared_nodes": list(shared)[:10],
                        "hop_count": f.get("hop_count", len(hops)),
                        "completeness": "complete" if f.get("reached_target") else "partial",
                    })
            collateral_flows.sort(key=lambda x: -x["shared_node_count"])

        return {
            "flow_id": flow_id,
            "flow_node_count": len(flow_node_ids),
            "flow_node_ids": list(flow_node_ids),
            "direction": direction,
            "change_type": change_type,
            "total_impacted": len(external_nodes),
            "severity_counts": counts,
            "by_layer": dict(by_layer),
            "nodes": external_nodes,
            "collateral_flows": collateral_flows,
            "total_collateral_flows": len(collateral_flows),
        }

    def get_node(self, node_id: str) -> Optional[dict]:
        """Get full node details."""
        return self.nodes.get(node_id)

    def get_neighbors(self, node_id: str) -> dict:
        """Get immediate downstream and upstream neighbors."""
        return {
            "downstream": [
                {"id": nid, **{k: self.nodes.get(nid, {}).get(k, "") for k in ("label", "layer", "type")}}
                for nid in self.adj.get(node_id, [])
            ],
            "upstream": [
                {"id": nid, **{k: self.nodes.get(nid, {}).get(k, "") for k in ("label", "layer", "type")}}
                for nid in self.rev.get(node_id, [])
            ],
        }

    def stats(self) -> dict:
        return {
            "nodes": len(self.nodes),
            "edges": sum(len(v) for v in self.adj.values()),
            "by_layer": {
                layer: sum(1 for n in self.nodes.values() if n.get("layer") == layer)
                for layer in ("ui", "bff", "api", "db", "config", "shared")
            },
        }


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    engine = BlastRadiusEngine(str(base / "output" / "system_graph.json"))
    print(f"Graph: {engine.stats()}")
    comps = engine.list_components()
    print(f"Components: {len(comps)}")
    # Test with first BFF endpoint
    bff_comps = [c for c in comps if c["layer"] == "bff" and c["type"] == "endpoint"]
    if bff_comps:
        test = bff_comps[0]
        print(f"\nBlast radius for: {test['label']}")
        result = engine.compute(test["id"])
        print(f"  Impacted: {result['total_impacted']}")
        print(f"  Severity: {result['severity_counts']}")
        for n in result["nodes"][:5]:
            print(f"    [{n['bucket']:8s}] {n['severity']:5.1f} | {n['layer']:6s} | {n['label'][:50]}")
