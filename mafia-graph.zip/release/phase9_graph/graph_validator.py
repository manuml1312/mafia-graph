"""
MAFIA Phase 9 — Graph Validator
==================================
Runs after graph build. Produces graph_validation_report.json with:
  - Orphan nodes by layer (degree 0 in flow graph)
  - Disconnected components summary
  - Dangling edges (missing node IDs)
  - Low-confidence hotspots (<0.5) by layer/type
  - GenAI entity count by layer
  - Edge type distribution (ensure allowlist correctness)
  - Partial chain breakpoint distribution (from e2e_flows.json)
  - Orphan queries: BFF no UI callers, API no BFF callers, DB no API callers

Usage:
    python -m phase9_graph.graph_validator
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict, deque, Counter


def validate_graph(output_dir: str) -> dict:
    output = Path(output_dir)
    sg = _load_json(output / "system_graph.json")
    flows = _load_json(output / "e2e_flows.json")

    nodes = {n["id"]: n for n in sg.get("nodes", [])}
    edges = sg.get("edges", [])

    report = {"generated_at": datetime.now(timezone.utc).isoformat()}

    # ── 1. Dangling edges ────────────────────────────────────────────────────
    dangling = []
    for e in edges:
        if e["source"] not in nodes:
            dangling.append({"edge_id": e["id"], "missing": "source", "node_id": e["source"]})
        if e["target"] not in nodes:
            dangling.append({"edge_id": e["id"], "missing": "target", "node_id": e["target"]})
    report["dangling_edges"] = {"count": len(dangling), "details": dangling[:50]}

    # ── 2. Orphan nodes (degree 0 in flow graph) ────────────────────────────
    connected = set()
    for e in edges:
        connected.add(e["source"])
        connected.add(e["target"])
    orphans_by_layer = defaultdict(int)
    orphan_samples = defaultdict(list)
    for nid, n in nodes.items():
        if nid not in connected:
            layer = n.get("layer", "unknown")
            orphans_by_layer[layer] += 1
            if len(orphan_samples[layer]) < 5:
                orphan_samples[layer].append({"id": nid, "name": n.get("label", ""), "type": n.get("type", "")})
    report["orphan_nodes"] = {
        "total": sum(orphans_by_layer.values()),
        "by_layer": dict(orphans_by_layer),
        "samples": {k: v for k, v in orphan_samples.items()},
    }

    # ── 3. Disconnected components ───────────────────────────────────────────
    undirected = defaultdict(set)
    for e in edges:
        undirected[e["source"]].add(e["target"])
        undirected[e["target"]].add(e["source"])
    visited = set()
    components = []
    for nid in undirected:
        if nid in visited:
            continue
        comp = set()
        queue = deque([nid])
        while queue:
            node = queue.popleft()
            if node in visited:
                continue
            visited.add(node)
            comp.add(node)
            for nb in undirected[node]:
                if nb not in visited:
                    queue.append(nb)
        layers = set(nodes.get(c, {}).get("layer", "") for c in comp)
        components.append({"size": len(comp), "layers": sorted(layers),
                           "sample": [nodes.get(c, {}).get("label", c) for c in sorted(comp)[:3]]})
    components.sort(key=lambda c: -c["size"])
    report["disconnected_components"] = {
        "count": len(components),
        "largest": components[0] if components else None,
        "single_node": sum(1 for c in components if c["size"] == 1),
        "components": components[:20],
    }

    # ── 4. Low-confidence hotspots ───────────────────────────────────────────
    low_conf_nodes = defaultdict(int)
    low_conf_edges = defaultdict(int)
    genai_by_layer = defaultdict(int)
    for n in nodes.values():
        if n.get("confidence", 1) < 0.5:
            low_conf_nodes[f"{n.get('layer','')}.{n.get('type','')}"] += 1
        if n.get("evidence_method") == "genai":
            genai_by_layer[n.get("layer", "")] += 1
    for e in edges:
        if e.get("confidence", 1) < 0.5:
            low_conf_edges[e.get("type", "")] += 1
    report["low_confidence_hotspots"] = {
        "nodes_below_0.5": dict(low_conf_nodes),
        "edges_below_0.5": dict(low_conf_edges),
        "genai_entities_by_layer": dict(genai_by_layer),
    }

    # ── 5. Edge type distribution ────────────────────────────────────────────
    edge_dist = Counter(e.get("type", "") for e in edges)
    structural_leaked = {t for t in edge_dist if t in
                         {"belongs_to_repo", "belongs_to_layer", "defined_in", "imports", "exports"}}
    report["edge_type_distribution"] = {
        "types": dict(edge_dist.most_common()),
        "structural_leaked": list(structural_leaked),
        "clean": len(structural_leaked) == 0,
    }

    # ── 6. Layer sanity ──────────────────────────────────────────────────────
    unusual = []
    for e in edges:
        sl = nodes.get(e["source"], {}).get("layer", "")
        tl = nodes.get(e["target"], {}).get("layer", "")
        if sl == "ui" and tl == "db":
            unusual.append({"edge": e["id"][:80], "type": e["type"], "note": "UI directly to DB"})
        if sl == "db" and tl == "ui":
            unusual.append({"edge": e["id"][:80], "type": e["type"], "note": "DB directly to UI"})
    report["layer_sanity"] = {"unusual_edges": unusual[:20], "count": len(unusual)}

    # ── 7. Breakpoint distribution (from flows) ─────────────────────────────
    breakpoint_dist = Counter()
    full_chains = flows.get("catalogs", {}).get("full_chains", [])
    for f in full_chains:
        bp = f.get("breakpoint", {})
        if bp:
            breakpoint_dist[bp.get("reason_code", "UNKNOWN")] += 1
    report["breakpoint_distribution"] = dict(breakpoint_dist.most_common())

    # ── 8. Orphan queries ────────────────────────────────────────────────────
    # BFF endpoints with no upstream UI callers
    bff_eps = {nid for nid, n in nodes.items() if n.get("layer") == "bff" and n.get("type") == "endpoint"}
    ui_targets = set()
    for e in edges:
        if e["type"] == "fetches":
            ui_targets.add(e["target"])
    bff_no_ui = sorted(bff_eps - ui_targets)

    # API endpoints with no upstream BFF callers
    api_eps = {nid for nid, n in nodes.items() if n.get("layer") == "api" and n.get("type") == "endpoint"}
    bff_api_targets = set()
    for e in edges:
        if e["type"] == "calls_api":
            bff_api_targets.add(e["target"])
    api_no_bff = sorted(api_eps - bff_api_targets)

    # DB functions with no upstream API callers
    db_fns = {nid for nid, n in nodes.items() if n.get("layer") == "db" and n.get("type") == "function"}
    api_db_targets = set()
    for e in edges:
        if e["type"] in ("calls_function", "reads_from"):
            api_db_targets.add(e["target"])
    db_no_api = sorted(db_fns - api_db_targets)

    # UI fetch_defs with no downstream BFF match
    ui_fds = {nid for nid, n in nodes.items() if n.get("layer") == "ui" and n.get("type") == "fetch_def"}
    ui_fd_sources = {e["source"] for e in edges if e["type"] == "fetches"}
    ui_no_bff = sorted(ui_fds - ui_fd_sources)

    report["orphan_queries"] = {
        "bff_endpoints_no_ui_callers": {"count": len(bff_no_ui), "ids": bff_no_ui[:20]},
        "api_endpoints_no_bff_callers": {"count": len(api_no_bff), "ids": api_no_bff[:20]},
        "db_functions_no_api_callers": {"count": len(db_no_api), "ids": db_no_api[:20]},
        "ui_fetch_defs_no_bff_match": {"count": len(ui_no_bff), "ids": ui_no_bff[:20]},
    }

    # ── Write ────────────────────────────────────────────────────────────────
    report_path = output / "graph_validation_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 9 -- Graph Validation")
    print(f"{'='*60}")
    print(f"  Dangling edges:        {report['dangling_edges']['count']}")
    print(f"  Orphan nodes:          {report['orphan_nodes']['total']} ({dict(orphans_by_layer)})")
    print(f"  Components:            {report['disconnected_components']['count']}")
    print(f"  Low-conf nodes (<0.5): {sum(low_conf_nodes.values())}")
    print(f"  Low-conf edges (<0.5): {sum(low_conf_edges.values())}")
    print(f"  GenAI entities:        {sum(genai_by_layer.values())}")
    print(f"  Structural leaked:     {'NONE' if not structural_leaked else structural_leaked}")
    print(f"  Unusual layer edges:   {len(unusual)}")
    print(f"  Orphan BFF (no UI):    {len(bff_no_ui)}")
    print(f"  Orphan API (no BFF):   {len(api_no_bff)}")
    print(f"  Orphan DB (no API):    {len(db_no_api)}")
    print(f"  Orphan UI fd (no BFF): {len(ui_no_bff)}")
    print(f"  Report: {report_path}")
    print(f"{'='*60}\n")

    return report


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    validate_graph(str(base / "output"))
