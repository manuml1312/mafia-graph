"""
MAFIA Phase 9 — Interactive Graph Visualizer
================================================
Generates a self-contained HTML file from system_graph.json using vis.js.
Color by architectural layer, edge style by confidence, click-to-inspect
with full evidence panel.

Usage:
    from phase9_graph.graph_visualizer import generate_html
    generate_html("output")
    # produces output/system_graph.html
"""

import json
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from utils.security import sanitize_label


# ── Layer colors ─────────────────────────────────────────────────────────────

LAYER_COLORS = {
    "ui": "#4E79A7",
    "bff": "#F28E2B",
    "api": "#59A14F",
    "db": "#B07AA1",
    "config": "#BAB0AC",
    "shared": "#9C755F",
}
DEFAULT_COLOR = "#76B7B2"

MAX_NODES = 100_000


def _load_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def generate_html(output_dir: str) -> str:
    """Generate interactive HTML visualization. Returns output path."""
    output = Path(output_dir)
    sg = _load_json(output / "system_graph.json")
    topo = _load_json(output / "topology_report.json")

    nodes_raw = sg.get("nodes", [])
    edges_raw = sg.get("edges", [])

    if not nodes_raw:
        print("  [SKIP] No nodes in system_graph.json — skipping HTML generation")
        return ""

    if len(nodes_raw) > MAX_NODES:
        print(f"  [WARN] Graph has {len(nodes_raw)} nodes — truncating to {MAX_NODES} highest-degree for visualization")
        degree = {}
        for e in edges_raw:
            degree[e.get("source", "")] = degree.get(e.get("source", ""), 0) + 1
            degree[e.get("target", "")] = degree.get(e.get("target", ""), 0) + 1
        nodes_raw = sorted(nodes_raw, key=lambda n: -degree.get(n["id"], 0))[:MAX_NODES]
        keep = {n["id"] for n in nodes_raw}
        edges_raw = [e for e in edges_raw if e.get("source") in keep and e.get("target") in keep]

    # Compute degree for sizing
    degree = {}
    for e in edges_raw:
        degree[e.get("source", "")] = degree.get(e.get("source", ""), 0) + 1
        degree[e.get("target", "")] = degree.get(e.get("target", ""), 0) + 1
    max_deg = max(degree.values()) if degree else 1

    # Build vis.js node data
    vis_nodes = []
    for n in nodes_raw:
        nid = n["id"]
        layer = n.get("layer", "")
        color = LAYER_COLORS.get(layer, DEFAULT_COLOR)
        deg = degree.get(nid, 1)
        size = 8 + 25 * (deg / max_deg)
        font_size = 11 if deg >= max_deg * 0.12 else 0
        label = sanitize_label(n.get("label", n.get("name", nid)), max_len=60)

        vis_nodes.append({
            "id": nid,
            "label": label,
            "color": {"background": color, "border": color,
                      "highlight": {"background": "#ffffff", "border": color}},
            "size": round(size, 1),
            "font": {"size": font_size, "color": "#ffffff"},
            "title": label,
            "_layer": layer,
            "_type": n.get("type", ""),
            "_repo": sanitize_label(n.get("repo", ""), 100),
            "_file": sanitize_label(n.get("file", "") or "", 120),
            "_line": n.get("line"),
            "_confidence": n.get("confidence", 0),
            "_evidence_method": n.get("evidence_method", ""),
            "_degree": deg,
        })

    # Build vis.js edge data
    vis_edges = []
    for e in edges_raw:
        conf = e.get("confidence", 1.0)
        rel = e.get("type", "")
        if conf >= 0.85:
            dashes = False
            width = 2
        elif conf >= 0.50:
            dashes = [5, 5]
            width = 1.5
        else:
            dashes = [2, 4]
            width = 1

        vis_edges.append({
            "from": e["source"],
            "to": e["target"],
            "title": sanitize_label(f"{rel} [{conf:.2f}]"),
            "dashes": dashes,
            "width": width,
            "color": {"opacity": 0.6 if conf >= 0.85 else 0.35},
        })

    # Layer legend
    layers_present = sorted({n.get("layer", "") for n in nodes_raw if n.get("layer")},
                            key=lambda l: {"ui": 0, "bff": 1, "api": 2, "db": 3, "config": 4, "shared": 5}.get(l, 9))
    legend = [{"layer": l, "color": LAYER_COLORS.get(l, DEFAULT_COLOR),
               "count": sum(1 for n in nodes_raw if n.get("layer") == l)} for l in layers_present]

    nodes_json = json.dumps(vis_nodes)
    edges_json = json.dumps(vis_edges)
    legend_json = json.dumps(legend)
    stats = f"{len(vis_nodes)} nodes &middot; {len(vis_edges)} edges"

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>MAFIA System Graph</title>
<script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
<style>
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ background: #0f0f1a; color: #e0e0e0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; display: flex; height: 100vh; overflow: hidden; }}
#graph {{ flex: 1; }}
#sidebar {{ width: 300px; background: #1a1a2e; border-left: 1px solid #2a2a4e; display: flex; flex-direction: column; overflow: hidden; }}
#search-wrap {{ padding: 12px; border-bottom: 1px solid #2a2a4e; }}
#search {{ width: 100%; background: #0f0f1a; border: 1px solid #3a3a5e; color: #e0e0e0; padding: 7px 10px; border-radius: 6px; font-size: 13px; outline: none; }}
#search:focus {{ border-color: #4E79A7; }}
#search-results {{ max-height: 140px; overflow-y: auto; padding: 4px 12px; border-bottom: 1px solid #2a2a4e; display: none; }}
.sr {{ padding: 4px 6px; cursor: pointer; border-radius: 4px; font-size: 12px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }}
.sr:hover {{ background: #2a2a4e; }}
#info {{ padding: 14px; flex: 1; overflow-y: auto; }}
#info h3 {{ font-size: 13px; color: #aaa; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.05em; }}
#info-content {{ font-size: 13px; color: #ccc; line-height: 1.7; }}
#info-content .f {{ margin-bottom: 4px; }}
#info-content .f b {{ color: #e0e0e0; }}
#info-content .empty {{ color: #555; font-style: italic; }}
#legend-wrap {{ padding: 12px; border-top: 1px solid #2a2a4e; }}
#legend-wrap h3 {{ font-size: 13px; color: #aaa; margin-bottom: 8px; text-transform: uppercase; }}
.li {{ display: flex; align-items: center; gap: 8px; padding: 3px 0; cursor: pointer; font-size: 12px; }}
.li:hover {{ background: #2a2a4e; padding-left: 4px; border-radius: 4px; }}
.li.dim {{ opacity: 0.3; }}
.li.solo {{ background: rgba(255,255,255,0.08); border-radius: 4px; padding-left: 4px; outline: 1px solid rgba(255,255,255,0.2); }}
.ld {{ width: 12px; height: 12px; border-radius: 50%; flex-shrink: 0; }}
.lc {{ color: #666; font-size: 11px; margin-left: auto; }}
#stats {{ padding: 10px 14px; border-top: 1px solid #2a2a4e; font-size: 11px; color: #555; }}
#conf-wrap {{ padding: 8px 12px; border-top: 1px solid #2a2a4e; }}
#conf-wrap label {{ font-size: 11px; color: #888; }}
#conf-slider {{ width: 100%; margin-top: 4px; }}
</style>
</head>
<body>
<div id="graph"></div>
<div id="sidebar">
  <div id="search-wrap">
    <input id="search" type="text" placeholder="Search nodes..." autocomplete="off">
    <div id="search-results"></div>
  </div>
  <div id="info">
    <h3>Node Info</h3>
    <div id="info-content"><span class="empty">Click a node to inspect</span></div>
  </div>
  <div id="conf-wrap">
    <label>Max nodes: </label>
    <select id="node-limit" style="background:#0f0f1a;color:#e0e0e0;border:1px solid #3a3a5e;border-radius:4px;padding:3px 6px;font-size:12px;margin-bottom:6px;width:100%">
      <option value="1000">1,000</option>
      <option value="5000" selected>5,000</option>
      <option value="10000">10,000</option>
      <option value="25000">25,000</option>
      <option value="100000">100,000 (All)</option>
    </select>
    <label>Min confidence: <span id="conf-val">0.00</span></label>
    <input id="conf-slider" type="range" min="0" max="100" value="0">
  </div>
  <div id="legend-wrap">
    <h3>Layers <span style="font-size:10px;color:#555;font-weight:400">click=toggle · dblclick=solo</span></h3>
    <div id="legend"></div>
  </div>
  <div id="stats">{stats}</div>
</div>
<script>
const RN={nodes_json};
const RE={edges_json};
const LEG={legend_json};
const nDS=new vis.DataSet(RN.map(n=>({{id:n.id,label:n.label,color:n.color,size:n.size,font:n.font,title:n.title,
  _layer:n._layer,_type:n._type,_repo:n._repo,_file:n._file,_line:n._line,_confidence:n._confidence,_evidence_method:n._evidence_method,_degree:n._degree}})));
const eDS=new vis.DataSet(RE.map((e,i)=>({{id:i,from:e.from,to:e.to,title:e.title,dashes:e.dashes,width:e.width,color:e.color,
  arrows:{{to:{{enabled:true,scaleFactor:0.5}}}}}})));
const container=document.getElementById('graph');
const network=new vis.Network(container,{{nodes:nDS,edges:eDS}},{{
  physics:{{enabled:true,solver:'forceAtlas2Based',forceAtlas2Based:{{gravitationalConstant:-50,centralGravity:0.005,springLength:100,springConstant:0.08,damping:0.4,avoidOverlap:0.7}},stabilization:{{iterations:200,fit:true}}}},
  interaction:{{hover:true,tooltipDelay:100,hideEdgesOnDrag:true}},
  nodes:{{shape:'dot',borderWidth:1.5}},
  edges:{{smooth:{{type:'continuous',roundness:0.2}},selectionWidth:3}}
}});
network.once('stabilizationIterationsDone',()=>{{network.setOptions({{physics:{{enabled:false}}}});}});

function showInfo(id){{
  const n=nDS.get(id);if(!n)return;
  const nb=network.getConnectedNodes(id);
  document.getElementById('info-content').innerHTML=`
    <div class="f"><b>${{n.label}}</b></div>
    <div class="f">Layer: ${{n._layer}} &middot; Type: ${{n._type}}</div>
    <div class="f">Repo: ${{n._repo}}</div>
    <div class="f">File: ${{n._file}}${{n._line?' L'+n._line:''}}</div>
    <div class="f">Confidence: ${{n._confidence}} (${{n._evidence_method}})</div>
    <div class="f">Degree: ${{n._degree}}</div>
    <div class="f" style="margin-top:8px;color:#aaa;font-size:11px">Neighbors (${{nb.length}})</div>
    ${{nb.slice(0,20).map(nid=>{{const nb2=nDS.get(nid);return nb2?`<div class="sr" onclick="focusN('${{nid}}')" style="border-left:3px solid ${{nb2.color.background}};padding-left:6px">${{nb2.label}}</div>`:''}}).join('')}}
  `;
}}
function focusN(id){{network.focus(id,{{scale:1.4,animation:true}});network.selectNodes([id]);showInfo(id);}}
network.on('click',p=>{{if(p.nodes.length)showInfo(p.nodes[0]);else document.getElementById('info-content').innerHTML='<span class="empty">Click a node to inspect</span>';}});

const si=document.getElementById('search'),sr=document.getElementById('search-results');
si.addEventListener('input',()=>{{
  const q=si.value.toLowerCase().trim();sr.innerHTML='';
  if(!q){{sr.style.display='none';return;}}
  const m=RN.filter(n=>n.label.toLowerCase().includes(q)).slice(0,15);
  if(!m.length){{sr.style.display='none';return;}}
  sr.style.display='block';
  m.forEach(n=>{{const el=document.createElement('div');el.className='sr';el.textContent=n.label;
    el.style.borderLeft='3px solid '+n.color.background;el.style.paddingLeft='8px';
    el.onclick=()=>{{focusN(n.id);sr.style.display='none';si.value='';}};sr.appendChild(el);}});
}});

const hiddenLayers=new Set();
let soloLayer=null;
const legEl=document.getElementById('legend');

function applyLayerVisibility(){{
  const min=parseFloat(document.getElementById('conf-slider').value)/100;
  nDS.update(RN.map(n=>{{
    let hide=false;
    if(soloLayer!==null)hide=n._layer!==soloLayer;
    else hide=hiddenLayers.has(n._layer);
    if(n._confidence<min)hide=true;
    return{{id:n.id,hidden:hide}};
  }}));
}}

LEG.forEach(l=>{{
  const it=document.createElement('div');it.className='li';
  it.innerHTML=`<div class="ld" style="background:${{l.color}}"></div><span>${{l.layer}}</span><span class="lc">${{l.count}}</span>`;
  it.title='Click to toggle · Double-click to solo';
  // Single click: toggle hidden
  it.addEventListener('click',function(e){{
    if(soloLayer!==null){{soloLayer=null;document.querySelectorAll('.li').forEach(x=>x.classList.remove('solo','dim'));}}
    if(hiddenLayers.has(l.layer)){{hiddenLayers.delete(l.layer);it.classList.remove('dim');}}
    else{{hiddenLayers.add(l.layer);it.classList.add('dim');}}
    applyLayerVisibility();
  }});
  // Double-click: solo this layer (hide all others)
  it.addEventListener('dblclick',function(e){{
    e.stopPropagation();
    if(soloLayer===l.layer){{// un-solo
      soloLayer=null;hiddenLayers.clear();
      document.querySelectorAll('.li').forEach(x=>x.classList.remove('solo','dim'));
    }}else{{
      soloLayer=l.layer;hiddenLayers.clear();
      document.querySelectorAll('.li').forEach(x=>{{x.classList.remove('solo');x.classList.add('dim');}});
      it.classList.remove('dim');it.classList.add('solo');
    }}
    applyLayerVisibility();
  }});
  legEl.appendChild(it);
}});

// Sort nodes by degree descending for limit filtering
const nodesByDegree=RN.slice().sort((a,b)=>b._degree-a._degree).map(n=>n.id);
const nlSel=document.getElementById('node-limit');
nlSel.addEventListener('change',()=>{{applyLayerVisibility();}});

const cs=document.getElementById('conf-slider'),cv=document.getElementById('conf-val');
cs.addEventListener('input',()=>{{
  cv.textContent=(cs.value/100).toFixed(2);
  applyLayerVisibility();
}});

// Apply initial node limit
function getNodeLimit(){{return parseInt(nlSel.value)||100000;}}
// Patch applyLayerVisibility to also respect node limit
const _origApply=applyLayerVisibility;
window._applyLayerVisibility=function(){{
  const min=parseFloat(cs.value)/100;
  const limit=getNodeLimit();
  const allowedSet=new Set(nodesByDegree.slice(0,limit));
  nDS.update(RN.map(n=>{{
    let hide=false;
    if(soloLayer!==null)hide=n._layer!==soloLayer;
    else hide=hiddenLayers.has(n._layer);
    if(n._confidence<min)hide=true;
    if(!allowedSet.has(n.id))hide=true;
    return{{id:n.id,hidden:hide}};
  }}));
  document.getElementById('stats').textContent=allowedSet.size+' of '+RN.length+' nodes · '+RE.length+' edges';
}};
applyLayerVisibility=window._applyLayerVisibility;
applyLayerVisibility();
</script>
</body>
</html>"""

    out_path = output / "system_graph.html"
    out_path.write_text(html_content, encoding="utf-8")
    print(f"  HTML visualization: {out_path}")
    return str(out_path)
