"""
MAFIA — Change Simulation Engine
===================================
Simulates structural changes before they happen:
- Node removal (what if we delete this service?)
- Contract change (what if this DTO/schema changes?)
- Failure injection (what if this component fails?)

Outputs affected flows, severity scores, and confidence-weighted risk.

Usage:
    sim = ChangeSimulator(blast_engine, e2e_flows)
    result = sim.simulate_removal("api:service:UserService")
    result = sim.simulate_contract_change("api:dto:UserDTO", ["field_removed:email"])
    result = sim.simulate_failure("bff:endpoint:/users", duration="transient")
"""

from collections import defaultdict


class ChangeSimulator:
    """Design-time chaos simulator for the system graph."""

    def __init__(self, blast_engine, flows: list = None):
        """
        Args:
            blast_engine: BlastRadiusEngine instance (loaded with graph)
            flows: list of flow dicts from e2e_flows.json (flattened)
        """
        self.blast = blast_engine
        self.flows = flows or []
        self._flow_index = self._build_flow_index()

    def _build_flow_index(self) -> dict:
        """Map node_id -> [flow dicts that contain it]."""
        idx = defaultdict(list)
        for f in self.flows:
            hops = f.get("standard", f.get("hops", []))
            for h in hops:
                hid = h if isinstance(h, str) else h.get("id", "")
                if hid:
                    idx[hid].append(f)
        return idx

    def simulate_removal(self, node_id: str) -> dict:
        """
        Simulate removing a node entirely.
        Returns: affected flows, impacted nodes, risk assessment.
        """
        resolved = self.blast._resolve(node_id)
        if not resolved:
            return {"error": f"Node not found: {node_id}", "simulation": "removal"}

        target_id = resolved[0]
        target_node = self.blast.nodes.get(target_id, {})

        # Blast radius from this node (both directions)
        blast = self.blast.compute(target_id, direction="both", change_type="failure", max_depth=5)

        # Flows that pass through this node
        broken_flows = []
        for f in self._flow_index.get(target_id, []):
            broken_flows.append({
                "flow_id": f.get("flow_id", ""),
                "surface": f.get("surface", {}).get("path", ""),
                "hop_count": f.get("hop_count", 0),
                "impact": "broken",
                "reason": f"Node {target_node.get('label', target_id)} removed from chain",
            })

        # Nodes that lose their only path
        orphaned = []
        for n in blast.get("nodes", []):
            if n["depth"] == 1:
                # Check if this node has alternative upstream paths
                upstream = self.blast.rev.get(n["id"], [])
                alternatives = [u for u in upstream if u != target_id]
                if not alternatives:
                    orphaned.append({
                        "id": n["id"],
                        "label": n["label"],
                        "layer": n["layer"],
                        "reason": "No alternative upstream path",
                    })

        # Risk score
        risk = self._compute_risk(blast, broken_flows, orphaned, target_node)

        return {
            "simulation": "removal",
            "target": target_id,
            "target_label": target_node.get("label", ""),
            "target_layer": target_node.get("layer", ""),
            "blast_radius": {
                "total_impacted": blast["total_impacted"],
                "severity_counts": blast["severity_counts"],
                "by_layer": blast.get("by_layer", {}),
            },
            "broken_flows": broken_flows,
            "orphaned_nodes": orphaned,
            "risk": risk,
            "impacted_nodes": blast.get("nodes", [])[:50],
        }

    def simulate_contract_change(self, node_id: str, changes: list = None) -> dict:
        """
        Simulate a contract/schema change on a node.
        changes: list of strings like "field_removed:email", "type_changed:status"
        """
        resolved = self.blast._resolve(node_id)
        if not resolved:
            return {"error": f"Node not found: {node_id}", "simulation": "contract_change"}

        target_id = resolved[0]
        target_node = self.blast.nodes.get(target_id, {})
        changes = changes or ["schema_modified"]

        # Contract changes propagate upstream (consumers break)
        blast = self.blast.compute(target_id, direction="upstream", change_type="contract", max_depth=4)

        # Affected flows
        affected_flows = []
        for f in self._flow_index.get(target_id, []):
            affected_flows.append({
                "flow_id": f.get("flow_id", ""),
                "surface": f.get("surface", {}).get("path", ""),
                "impact": "degraded",
                "reason": f"Contract change at {target_node.get('label', target_id)}: {', '.join(changes)}",
            })

        risk = self._compute_risk(blast, affected_flows, [], target_node, severity_factor=0.7)

        return {
            "simulation": "contract_change",
            "target": target_id,
            "target_label": target_node.get("label", ""),
            "target_layer": target_node.get("layer", ""),
            "changes": changes,
            "blast_radius": {
                "total_impacted": blast["total_impacted"],
                "severity_counts": blast["severity_counts"],
                "by_layer": blast.get("by_layer", {}),
            },
            "affected_flows": affected_flows,
            "risk": risk,
            "impacted_nodes": blast.get("nodes", [])[:50],
        }

    def simulate_failure(self, node_id: str, duration: str = "transient") -> dict:
        """
        Simulate a runtime failure at a node.
        duration: "transient" (retry-recoverable) or "persistent" (hard down)
        """
        resolved = self.blast._resolve(node_id)
        if not resolved:
            return {"error": f"Node not found: {node_id}", "simulation": "failure"}

        target_id = resolved[0]
        target_node = self.blast.nodes.get(target_id, {})

        severity_factor = 1.0 if duration == "persistent" else 0.6
        blast = self.blast.compute(target_id, direction="downstream",
                                   change_type="failure", max_depth=5)

        # Cascading failures — nodes that depend on this AND have high fan-out
        cascaders = []
        for n in blast.get("nodes", []):
            if n["depth"] <= 2 and n["fan_out"] >= 3:
                cascaders.append({
                    "id": n["id"],
                    "label": n["label"],
                    "layer": n["layer"],
                    "fan_out": n["fan_out"],
                    "cascade_risk": "high" if n["fan_out"] >= 5 else "medium",
                })

        broken_flows = []
        for f in self._flow_index.get(target_id, []):
            broken_flows.append({
                "flow_id": f.get("flow_id", ""),
                "surface": f.get("surface", {}).get("path", ""),
                "impact": "broken" if duration == "persistent" else "degraded",
                "reason": f"{duration.title()} failure at {target_node.get('label', target_id)}",
            })

        risk = self._compute_risk(blast, broken_flows, [], target_node, severity_factor)

        return {
            "simulation": "failure",
            "target": target_id,
            "target_label": target_node.get("label", ""),
            "target_layer": target_node.get("layer", ""),
            "duration": duration,
            "blast_radius": {
                "total_impacted": blast["total_impacted"],
                "severity_counts": blast["severity_counts"],
                "by_layer": blast.get("by_layer", {}),
            },
            "cascading_nodes": cascaders,
            "broken_flows": broken_flows,
            "risk": risk,
            "impacted_nodes": blast.get("nodes", [])[:50],
        }

    def _compute_risk(self, blast, flows, orphaned, target_node,
                      severity_factor=1.0) -> dict:
        sc = blast.get("severity_counts", {})
        critical = sc.get("critical", 0)
        high = sc.get("high", 0)
        total = blast.get("total_impacted", 0)
        flow_count = len(flows)

        raw_score = (
            critical * 25 +
            high * 15 +
            total * 2 +
            flow_count * 10 +
            len(orphaned) * 20
        ) * severity_factor

        score = min(100, raw_score)

        if score >= 75:
            level = "critical"
            recommendation = "Do not proceed without mitigation. Multiple critical dependencies affected."
        elif score >= 50:
            level = "high"
            recommendation = "Proceed with caution. Create rollback plan and notify dependent teams."
        elif score >= 25:
            level = "medium"
            recommendation = "Moderate risk. Test affected flows before deploying."
        else:
            level = "low"
            recommendation = "Low risk. Standard deployment process is sufficient."

        return {
            "score": round(score, 1),
            "level": level,
            "recommendation": recommendation,
            "factors": {
                "critical_nodes": critical,
                "high_nodes": high,
                "total_impacted": total,
                "broken_flows": flow_count,
                "orphaned_nodes": len(orphaned),
            },
        }
