"""
MAFIA — Weak-Point Detection Engine
======================================
Identifies structural vulnerabilities in the system graph:
- Fragile bridges (high betweenness + low redundancy)
- Single points of failure (removal disconnects subgraphs)
- Cascading failure risk (blast radius from every bridge)
- God nodes (already in topology_analyzer, re-exposed here)

Usage:
    engine = WeakPointDetector(system_graph_path)
    report = engine.analyze()
"""

import json
from pathlib import Path
from collections import defaultdict


class WeakPointDetector:
    """Detects structural weak points in the system graph."""

    def __init__(self, graph_path: str = None):
        self.nodes = {}
        self.adj = defaultdict(set)
        self.rev = defaultdict(set)
        self.edges = []
        if graph_path:
            self.load(graph_path)

    def load(self, graph_path: str):
        try:
            from phase11_search.graph_retriever import get_cached_graph
            data = get_cached_graph(graph_path)
        except ImportError:
            with open(graph_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        for n in data.get("nodes", []):
            self.nodes[n["id"]] = n
        for e in data.get("edges", []):
            src, tgt = e["source"], e["target"]
            self.adj[src].add(tgt)
            self.rev[tgt].add(src)
            self.edges.append(e)

    def analyze(self) -> dict:
        """Run full weak-point analysis. Returns a report dict."""
        bridges = self._find_bridges()
        spofs = self._find_spofs()
        fragile = self._find_fragile_bridges(bridges)
        cascade = self._compute_cascade_risk(fragile[:20])
        god_nodes = self._find_god_nodes()

        return {
            "bridges": bridges[:50],
            "single_points_of_failure": spofs[:30],
            "fragile_bridges": fragile[:30],
            "cascade_risks": cascade,
            "god_nodes": god_nodes[:20],
            "summary": {
                "total_bridges": len(bridges),
                "total_spofs": len(spofs),
                "total_fragile": len(fragile),
                "total_god_nodes": len(god_nodes),
                "risk_level": self._overall_risk(bridges, spofs, fragile),
            },
        }

    def _find_bridges(self) -> list:
        """
        Find bridge edges — edges whose removal disconnects the graph.
        Uses Tarjan's bridge-finding algorithm.
        """
        all_ids = list(self.nodes.keys())
        if not all_ids:
            return []

        visited = set()
        disc = {}
        low = {}
        parent = {}
        bridges = []
        timer = [0]

        # Build undirected adjacency
        undirected = defaultdict(set)
        for e in self.edges:
            undirected[e["source"]].add(e["target"])
            undirected[e["target"]].add(e["source"])

        def dfs(u):
            visited.add(u)
            disc[u] = low[u] = timer[0]
            timer[0] += 1
            for v in undirected.get(u, set()):
                if v not in visited:
                    parent[v] = u
                    dfs(v)
                    low[u] = min(low[u], low[v])
                    if low[v] > disc[u]:
                        src_node = self.nodes.get(u, {})
                        tgt_node = self.nodes.get(v, {})
                        bridges.append({
                            "source": u,
                            "target": v,
                            "source_label": src_node.get("label", ""),
                            "target_label": tgt_node.get("label", ""),
                            "source_layer": src_node.get("layer", ""),
                            "target_layer": tgt_node.get("layer", ""),
                            "cross_layer": src_node.get("layer") != tgt_node.get("layer"),
                        })
                elif v != parent.get(u):
                    low[u] = min(low[u], disc[v])

        # Run DFS from each unvisited node (handles disconnected components)
        import sys
        old_limit = sys.getrecursionlimit()
        sys.setrecursionlimit(max(old_limit, len(all_ids) + 100))
        try:
            for nid in all_ids:
                if nid not in visited:
                    parent[nid] = None
                    dfs(nid)
        except RecursionError:
            pass  # Graph too deep for recursive DFS, return what we have
        finally:
            sys.setrecursionlimit(old_limit)

        # Sort: cross-layer bridges first (more critical)
        bridges.sort(key=lambda b: (not b["cross_layer"], b["source"]))
        return bridges

    def _find_spofs(self) -> list:
        """
        Find single points of failure — nodes whose removal
        increases the number of connected components.
        Uses articulation point detection.
        """
        all_ids = list(self.nodes.keys())
        if len(all_ids) < 3:
            return []

        undirected = defaultdict(set)
        for e in self.edges:
            undirected[e["source"]].add(e["target"])
            undirected[e["target"]].add(e["source"])

        visited = set()
        disc = {}
        low = {}
        parent = {}
        ap = set()
        timer = [0]

        import sys
        old_limit = sys.getrecursionlimit()
        sys.setrecursionlimit(max(old_limit, len(all_ids) + 100))

        def dfs(u):
            children = 0
            visited.add(u)
            disc[u] = low[u] = timer[0]
            timer[0] += 1
            for v in undirected.get(u, set()):
                if v not in visited:
                    children += 1
                    parent[v] = u
                    dfs(v)
                    low[u] = min(low[u], low[v])
                    if parent.get(u) is None and children > 1:
                        ap.add(u)
                    if parent.get(u) is not None and low[v] >= disc[u]:
                        ap.add(u)
                elif v != parent.get(u):
                    low[u] = min(low[u], disc[v])

        try:
            for nid in all_ids:
                if nid not in visited:
                    parent[nid] = None
                    dfs(nid)
        except RecursionError:
            pass
        finally:
            sys.setrecursionlimit(old_limit)

        results = []
        for nid in ap:
            n = self.nodes.get(nid, {})
            fan_out = len(self.adj.get(nid, set()))
            fan_in = len(self.rev.get(nid, set()))
            results.append({
                "id": nid,
                "label": n.get("label", ""),
                "layer": n.get("layer", ""),
                "type": n.get("type", ""),
                "fan_out": fan_out,
                "fan_in": fan_in,
                "total_connections": fan_out + fan_in,
                "confidence": n.get("confidence", 0),
            })
        results.sort(key=lambda x: -x["total_connections"])
        return results

    def _find_fragile_bridges(self, bridges: list) -> list:
        """
        Fragile bridges = bridge edges where neither endpoint has
        redundant connections (low alternative paths).
        """
        fragile = []
        for b in bridges:
            src_alts = len(self.adj.get(b["source"], set())) + len(self.rev.get(b["source"], set()))
            tgt_alts = len(self.adj.get(b["target"], set())) + len(self.rev.get(b["target"], set()))
            redundancy = min(src_alts, tgt_alts)
            fragile.append({
                **b,
                "source_connections": src_alts,
                "target_connections": tgt_alts,
                "redundancy_score": redundancy,
                "fragility": "critical" if redundancy <= 2 else "high" if redundancy <= 4 else "medium",
            })
        fragile.sort(key=lambda x: x["redundancy_score"])
        return fragile

    def _compute_cascade_risk(self, fragile_bridges: list) -> list:
        """
        For each fragile bridge, estimate how many nodes become
        unreachable if the bridge breaks.
        """
        results = []
        for fb in fragile_bridges:
            # Simulate removing this edge and count reachable nodes from source
            removed = (fb["source"], fb["target"])
            reachable = set()
            queue = [fb["source"]]
            visited = {fb["source"]}
            while queue:
                nid = queue.pop(0)
                reachable.add(nid)
                for tgt in self.adj.get(nid, set()):
                    if tgt not in visited and (nid, tgt) != removed:
                        visited.add(tgt)
                        queue.append(tgt)
                for src in self.rev.get(nid, set()):
                    if src not in visited and (src, nid) != removed:
                        visited.add(src)
                        queue.append(src)

            isolated = len(self.nodes) - len(reachable)
            results.append({
                "bridge": f"{fb['source_label']} → {fb['target_label']}",
                "source": fb["source"],
                "target": fb["target"],
                "fragility": fb["fragility"],
                "nodes_isolated": isolated,
                "pct_isolated": round(isolated / max(len(self.nodes), 1) * 100, 1),
                "cross_layer": fb.get("cross_layer", False),
            })
        results.sort(key=lambda x: -x["nodes_isolated"])
        return results

    def _find_god_nodes(self) -> list:
        """Nodes with disproportionately high connectivity."""
        results = []
        for nid, n in self.nodes.items():
            fan_out = len(self.adj.get(nid, set()))
            fan_in = len(self.rev.get(nid, set()))
            total = fan_out + fan_in
            if total >= 10:
                results.append({
                    "id": nid,
                    "label": n.get("label", ""),
                    "layer": n.get("layer", ""),
                    "type": n.get("type", ""),
                    "fan_out": fan_out,
                    "fan_in": fan_in,
                    "total_connections": total,
                })
        results.sort(key=lambda x: -x["total_connections"])
        return results

    def _overall_risk(self, bridges, spofs, fragile) -> str:
        critical_fragile = sum(1 for f in fragile if f.get("fragility") == "critical")
        if critical_fragile >= 5 or len(spofs) >= 10:
            return "high"
        if critical_fragile >= 2 or len(spofs) >= 5:
            return "medium"
        return "low"
