"""
MAFIA Phase 10 — Provenance Contract
=======================================
Every AI-generated statement must be labeled with its provenance category.
This module defines the schema and validation for provenance-tagged responses.

Categories:
  OBSERVED  — directly from extracted evidence (file, line, snippet)
  DERIVED   — computed from graph traversal (upstream/downstream, blast radius)
  INFERRED  — LLM inference (business intent, why-it-exists)
  UNKNOWN   — information not found in evidence or graph

Usage:
    from phase10_intelligence.provenance import ProvenanceStatement, validate_response
"""

from dataclasses import dataclass, field, asdict
from typing import Optional


PROVENANCE_CATEGORIES = {"observed", "derived", "inferred", "unknown"}


@dataclass
class ProvenanceStatement:
    """A single statement with provenance label."""
    text: str
    provenance: str  # observed | derived | inferred | unknown
    evidence_ids: list[str] = field(default_factory=list)  # entity/relation IDs backing this
    confidence: float = 0.0

    def __post_init__(self):
        assert self.provenance in PROVENANCE_CATEGORIES, \
            f"Invalid provenance '{self.provenance}'. Must be one of {PROVENANCE_CATEGORIES}"

    def to_dict(self):
        return asdict(self)


@dataclass
class IntelligenceResponse:
    """Standard response envelope for all Phase 10 outputs."""
    entity_id: str
    statements: list[ProvenanceStatement] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self):
        return {
            "entity_id": self.entity_id,
            "statements": [s.to_dict() for s in self.statements],
            "warnings": self.warnings,
        }


def validate_response(response: dict, known_node_ids: set, known_files: set,
                       known_tables: set) -> list[str]:
    """
    Hallucination guardrails. Returns list of violations found.
    Checks:
      1. File paths cited must exist in known_files
      2. Node IDs cited must exist in known_node_ids
      3. Table/function names must exist in known_tables
      4. Every statement must have a provenance category
    """
    violations = []

    for stmt in response.get("statements", []):
        # Check provenance exists
        prov = stmt.get("provenance", "")
        if prov not in PROVENANCE_CATEGORIES:
            violations.append(f"Missing/invalid provenance: '{prov}'")

        text = stmt.get("text", "")

        # Check for file paths not in evidence
        for eid in stmt.get("evidence_ids", []):
            if eid.startswith("file:") and eid not in known_files:
                violations.append(f"Unknown file reference: {eid}")
            elif ":" in eid and eid not in known_node_ids:
                # Could be an entity ID — check if it exists
                if not any(eid in nid for nid in known_node_ids):
                    violations.append(f"Unknown entity reference: {eid[:80]}")

    return violations
