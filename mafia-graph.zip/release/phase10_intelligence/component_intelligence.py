"""
MAFIA Phase 10 — Component Intelligence Generator
====================================================
For each key entity, generates grounded intelligence:
  - what_it_does (observed from evidence snippets + properties)
  - where_used (derived from graph)
  - why_it_exists (inferred by LLM, or deterministic from context)
  - impact_if_changed (derived from blast radius)

All outputs carry provenance labels. Hallucination guardrails enforced.

Usage:
    python -m phase10_intelligence.component_intelligence
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase10_intelligence.provenance import ProvenanceStatement, validate_response, PROVENANCE_CATEGORIES


# ── Prompt for component intelligence ────────────────────────────────────────

COMPONENT_PROMPT = """You are generating developer documentation for a code entity.
You MUST follow these rules:
1. Label every statement with its provenance: [OBSERVED], [DERIVED], or [INFERRED]
2. [OBSERVED] = directly visible in the code evidence provided
3. [DERIVED] = computed from the dependency graph (callers, callees, flows)
4. [INFERRED] = your interpretation of business purpose — always mark clearly
5. If you don't know something, say [UNKNOWN] — never invent
6. Do NOT invent file paths, function names, or table names not in the evidence
7. Return ONLY valid JSON

Entity: {entity_id}
Name: {name}
Layer: {layer}
Type: {type}
Repo: {repo}
File: {file}
Line: {line}
Confidence: {confidence}
Evidence method: {evidence_method}

Code evidence:
{evidence_snippet}

Upstream callers (who calls this):
{upstream}

Downstream dependencies (what this calls):
{downstream}

Related flows:
{flows}

Return JSON:
{{
  "summary_surface": "<1-2 line summary, [OBSERVED] or [DERIVED]>",
  "what_it_does": "<grounded description of what this entity does, [OBSERVED]>",
  "where_used": "<who calls it and what it calls, [DERIVED]>",
  "why_it_exists": "<business purpose interpretation, [INFERRED]>",
  "impact_if_changed": "<what breaks if this changes, [DERIVED]>",
  "likely_change_points": "<where a developer would modify this, [INFERRED]>",
  "warnings": ["<any caveats>"]
}}"""


def generate_component_intelligence(
    output_dir: str,
    gemini_client=None,
    max_components: int = 500,
) -> dict:
    """Generate component_intelligence.json for key entities."""
    output = Path(output_dir)

    # Load graph data
    sg = _load_json(output / "system_graph.json")
    flows_data = _load_json(output / "e2e_flows.json")
    nodes = {n["id"]: n for n in sg.get("nodes", [])}
    edges = sg.get("edges", [])

    # Load entity evidence from entities.jsonl (graph nodes don't carry snippets)
    entity_evidence = _load_entity_evidence(output / "entities.jsonl")

    # Load AST summaries if available (enrichment from phase10_ast)
    ast_summaries = _load_ast_summaries(output / "ast_summaries.jsonl")

    # Build adjacency
    adj = defaultdict(list)
    rev = defaultdict(list)
    for e in edges:
        adj[e["source"]].append(e)
        rev[e["target"]].append(e)

    # Build flow index: node_id -> [flow summaries]
    flow_index = defaultdict(list)
    for cat_name, cat_flows in flows_data.get("catalogs", {}).items():
        for flow in cat_flows:
            for hop in flow.get("standard", []):
                flow_index[hop["id"]].append({
                    "catalog": cat_name,
                    "flow_id": flow.get("flow_id", ""),
                    "surface": flow.get("surface", {}).get("path", ""),
                })

    # Select key entities to enrich
    targets = _select_targets(nodes, adj, rev, flow_index, max_components)

    results = []
    known_ids = set(nodes.keys())
    known_files = {n.get("file", "") for n in nodes.values() if n.get("file")}
    known_tables = {n.get("label", "") for n in nodes.values()
                    if n.get("layer") == "db" and n.get("type") in ("table", "function")}

    for node in targets:
        nid = node["id"]
        evidence = entity_evidence.get(nid, {})

        # Build context packet
        upstream = _format_neighbors(rev.get(nid, []), nodes, "upstream", limit=10)
        downstream = _format_neighbors(adj.get(nid, []), nodes, "downstream", limit=10)
        related_flows = _format_flows(flow_index.get(nid, []), limit=5)
        snippet = evidence.get("snippet", "")

        # Include AST summary in context if available
        ast_ctx = ""
        ast_data = ast_summaries.get(nid)
        if ast_data:
            ast_ctx = _format_ast_context(ast_data)

        if gemini_client and gemini_client.is_available:
            prompt = COMPONENT_PROMPT.format(
                entity_id=nid, name=node.get("label", ""), layer=node.get("layer", ""),
                type=node.get("type", ""), repo=node.get("repo", ""),
                file=node.get("file", ""), line=node.get("line", ""),
                confidence=node.get("confidence", 0),
                evidence_method=node.get("evidence_method", ""),
                evidence_snippet=snippet[:2000] + ("\n\nAST Structure:\n" + ast_ctx if ast_ctx else ""),
                upstream=upstream, downstream=downstream, flows=related_flows,
            )
            response_text = gemini_client.generate(prompt)
            parsed = _safe_parse_json(response_text) if response_text else None
        else:
            parsed = None

        # Build intelligence record
        intel = _build_intelligence(nid, node, adj, rev, flow_index, nodes, entity_evidence, parsed)

        # Attach AST summary reference if available
        if ast_data:
            intel["has_ast_summary"] = True
            intel["ast_complexity"] = ast_data.get("complexity", {})
            intel["ast_call_count"] = len(ast_data.get("calls", []))
        else:
            intel["has_ast_summary"] = False

        # Validate guardrails
        violations = validate_response(intel, known_ids, known_files, known_tables)
        if violations:
            intel["warnings"] = intel.get("warnings", []) + violations

        results.append(intel)

    # Write output
    output_data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_components": len(results),
        "genai_enriched": sum(1 for r in results if r.get("genai_enriched")),
        "components": results,
    }

    out_path = output / "component_intelligence.json"
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 10 -- Component Intelligence")
    print(f"{'='*60}")
    print(f"  Components enriched: {len(results)}")
    print(f"  GenAI enriched:      {output_data['genai_enriched']}")
    print(f"  Output: {out_path}")
    print(f"{'='*60}\n")

    return output_data


def _select_targets(nodes, adj, rev, flow_index, max_count):
    """Select the most important entities to enrich."""
    scored = []
    for nid, n in nodes.items():
        layer = n.get("layer", "")
        ntype = n.get("type", "")
        if layer == "config" and ntype == "property":
            continue
        flow_count = len(flow_index.get(nid, []))
        fan_in = len(rev.get(nid, []))
        fan_out = len(adj.get(nid, []))
        type_bonus = 3 if ntype in ("endpoint", "controller", "function") else 1
        score = (flow_count * 5 + fan_in * 2 + fan_out * 2) * type_bonus
        if score > 0:
            scored.append((score, nid, n))

    scored.sort(key=lambda x: -x[0])
    return [item[2] for item in scored[:max_count]]


# ── Deterministic what_it_does from evidence ─────────────────────────────────

def _build_what_it_does(node, evidence, adj, rev, nodes):
    """
    Build a grounded what_it_does description from evidence snippet + properties.
    No LLM needed — purely from extracted data.
    """
    layer = node.get("layer", "")
    ntype = node.get("type", "")
    name = node.get("label", "")
    props = node.get("properties", {})
    snippet = evidence.get("snippet", "")
    ev_props = evidence.get("properties", {})
    nid = node["id"]

    # Merge properties from graph node and entity evidence
    all_props = {**ev_props, **props}

    # ── BFF endpoint ─────────────────────────────────────────────────────
    if layer == "bff" and ntype == "endpoint":
        var = all_props.get("variable_name", "")
        path = all_props.get("endpoint_path", name)
        return f"BFF endpoint at '{path}' (constant: {var}). Receives incoming HTTP requests from the UI layer and routes them to a controller handler."

    # ── BFF controller ───────────────────────────────────────────────────
    if layer == "bff" and ntype == "controller":
        method = all_props.get("http_method", "")
        const_ref = all_props.get("constant_ref", "")
        api_consts = all_props.get("api_constants", [])
        desc = f"BFF controller method '{name}' handling {method} requests" if method else f"BFF controller method '{name}'"
        if const_ref:
            desc += f", registered via route constant {const_ref}"
        if api_consts:
            desc += f". Calls downstream API(s) via: {', '.join(api_consts[:5])}"
        return desc

    # ── BFF constant ─────────────────────────────────────────────────────
    if layer == "bff" and ntype == "constant":
        path = all_props.get("endpoint_path", "")
        return f"Constant holding the downstream API URL path '{path}'. Used by BFF controllers to make HTTP calls to the API layer."

    # ── BFF middleware ────────────────────────────────────────────────────
    if layer == "bff" and ntype == "middleware":
        return f"Middleware function '{name}' that validates or transforms requests before they reach the controller."

    # ── BFF service ──────────────────────────────────────────────────────
    if layer == "bff" and ntype == "service":
        return f"BFF service helper '{name}' that orchestrates API calls or data transformation."

    # ── API endpoint ─────────────────────────────────────────────────────
    if layer == "api" and ntype == "endpoint":
        method = all_props.get("http_method", "")
        path = all_props.get("endpoint_path", name)
        handler = all_props.get("handler_method", "")
        desc = f"API endpoint {method} '{path}'"
        if handler:
            desc += f", handled by method {handler}"
        if snippet:
            desc += f". Declared as: {snippet[:100]}"
        return desc

    # ── API controller ───────────────────────────────────────────────────
    if layer == "api" and ntype == "controller":
        method = all_props.get("http_method", "")
        # Find what services it delegates to
        downstream_svcs = [
            nodes.get(e["target"], {}).get("label", "")
            for e in adj.get(nid, [])
            if e.get("type") in ("delegates_to", "uses_repo")
        ]
        desc = f"Controller method '{name}'"
        if method:
            desc += f" handling {method} requests"
        if downstream_svcs:
            desc += f". Delegates to: {', '.join(downstream_svcs[:5])}"
        return desc

    # ── API service ──────────────────────────────────────────────────────
    if layer == "api" and ntype == "service":
        field = all_props.get("field", "")
        method = all_props.get("method", "")
        downstream_repos = [
            nodes.get(e["target"], {}).get("label", "")
            for e in adj.get(nid, [])
            if e.get("type") == "uses_repo"
        ]
        desc = f"Service method '{name}' containing business logic"
        if downstream_repos:
            desc += f". Queries data via: {', '.join(downstream_repos[:5])}"
        return desc

    # ── API repository ───────────────────────────────────────────────────
    if layer == "api" and ntype == "repository":
        downstream_db = [
            nodes.get(e["target"], {}).get("label", "")
            for e in adj.get(nid, [])
            if nodes.get(e["target"], {}).get("layer") == "db"
        ]
        desc = f"Repository method '{name}' that executes the database query"
        if snippet:
            desc += f". Query: {snippet[:150]}"
        elif downstream_db:
            desc += f". Accesses: {', '.join(downstream_db[:5])}"
        return desc

    # ── API entity ───────────────────────────────────────────────────────
    if layer == "api" and ntype == "entity":
        table = all_props.get("table", "")
        schema = all_props.get("schema", "")
        desc = f"JPA entity class '{name}'"
        if table:
            desc += f" mapped to database table {table}"
        return desc

    # ── API DTO ──────────────────────────────────────────────────────────
    if layer == "api" and ntype == "dto":
        return f"Data transfer object '{name}' used for request/response shaping between layers."

    # ── DB function ──────────────────────────────────────────────────────
    if layer == "db" and ntype == "function":
        downstream_tables = [
            nodes.get(e["target"], {}).get("label", "")
            for e in adj.get(nid, [])
            if nodes.get(e["target"], {}).get("type") == "table"
        ]
        desc = f"Database stored function '{name}'"
        if snippet:
            desc += f". SQL: {snippet[:150]}"
        if downstream_tables:
            desc += f". Reads from tables: {', '.join(downstream_tables[:5])}"
        return desc

    # ── DB table ─────────────────────────────────────────────────────────
    if layer == "db" and ntype == "table":
        upstream_fns = [
            nodes.get(e["source"], {}).get("label", "")
            for e in rev.get(nid, [])
            if nodes.get(e["source"], {}).get("type") in ("function", "repository")
        ]
        desc = f"Database table '{name}'"
        db_type = all_props.get("db_type", "")
        if db_type:
            desc += f" ({db_type})"
        if upstream_fns:
            desc += f". Accessed by: {', '.join(upstream_fns[:5])}"
        return desc

    # ── DB view ──────────────────────────────────────────────────────────
    if layer == "db" and ntype == "view":
        desc = f"Database view '{name}' that aggregates data from underlying tables"
        if snippet:
            desc += f". Definition: {snippet[:150]}"
        return desc

    # ── UI component ─────────────────────────────────────────────────────
    if layer == "ui" and ntype == "component":
        downstream_hooks = [
            nodes.get(e["target"], {}).get("label", "")
            for e in adj.get(nid, [])
            if nodes.get(e["target"], {}).get("type") == "hook"
        ]
        downstream_fetches = [
            nodes.get(e["target"], {}).get("label", "")
            for e in adj.get(nid, [])
            if nodes.get(e["target"], {}).get("type") == "fetch_def"
        ]
        desc = f"React component '{name}' that renders part of the user interface"
        if downstream_hooks:
            desc += f". Uses hooks: {', '.join(downstream_hooks[:5])}"
        if downstream_fetches:
            desc += f". Fetches data via: {', '.join(downstream_fetches[:5])}"
        return desc

    # ── UI fetch_def ─────────────────────────────────────────────────────
    if layer == "ui" and ntype == "fetch_def":
        path_suffix = all_props.get("path_suffix", "")
        env_var = all_props.get("env_var", "")
        http_method = all_props.get("http_method", "GET")
        desc = f"API call definition '{name}'"
        if path_suffix:
            desc += f" that constructs {http_method} request to '{path_suffix}'"
        if env_var:
            desc += f" using base URL from {env_var}"
        return desc

    # ── UI hook ──────────────────────────────────────────────────────────
    if layer == "ui" and ntype == "hook":
        return f"Custom React hook '{name}' managing state or side effects for UI components."

    # ── UI selector ──────────────────────────────────────────────────────
    if layer == "ui" and ntype == "selector":
        return f"Recoil state selector '{name}' that derives computed state from atoms."

    # ── Config ───────────────────────────────────────────────────────────
    if layer == "config":
        value = all_props.get("value", "")
        if ntype == "env":
            return f"Environment variable '{name}'" + (f" = {value[:60]}" if value and value != "<redacted>" else "")
        if ntype == "toggle":
            return f"Feature toggle '{name}' controlling runtime behavior" + (f" (current: {value})" if value else "")
        if ntype == "secret":
            return f"Secret '{name}' — value redacted for security."
        return f"Configuration property '{name}'" + (f" = {value[:60]}" if value and value != "<redacted>" else "")

    # ── Fallback ─────────────────────────────────────────────────────────
    desc = f"{layer.upper()} {ntype} '{name}'"
    if snippet:
        desc += f". Evidence: {snippet[:120]}"
    return desc


def _build_intelligence(nid, node, adj, rev, flow_index, nodes, entity_evidence, genai_parsed):
    """Build intelligence record with provenance labels."""
    layer = node.get("layer", "")
    ntype = node.get("type", "")
    name = node.get("label", "")
    repo = node.get("repo", "")
    evidence = entity_evidence.get(nid, {})

    # Upstream/downstream (DERIVED)
    upstream_edges = rev.get(nid, [])
    downstream_edges = adj.get(nid, [])
    upstream_names = [nodes.get(e["source"], {}).get("label", "") for e in upstream_edges][:10]
    downstream_names = [nodes.get(e["target"], {}).get("label", "") for e in downstream_edges][:10]
    related = flow_index.get(nid, [])[:5]

    statements = []

    if genai_parsed:
        for field, prov in [
            ("summary_surface", "observed"), ("what_it_does", "observed"),
            ("where_used", "derived"), ("why_it_exists", "inferred"),
            ("impact_if_changed", "derived"), ("likely_change_points", "inferred"),
        ]:
            text = genai_parsed.get(field, "")
            if text:
                actual_prov = prov
                for tag in ("[OBSERVED]", "[DERIVED]", "[INFERRED]", "[UNKNOWN]"):
                    if tag in text:
                        actual_prov = tag.strip("[]").lower()
                        text = text.replace(tag, "").strip()
                        break
                statements.append(ProvenanceStatement(
                    text=text, provenance=actual_prov,
                    evidence_ids=[nid], confidence=node.get("confidence", 0),
                ).to_dict())
        genai_enriched = True
        warnings = genai_parsed.get("warnings", [])
    else:
        # what_it_does (OBSERVED — from evidence)
        what = _build_what_it_does(node, evidence, adj, rev, nodes)
        statements.append(ProvenanceStatement(
            text=what, provenance="observed", evidence_ids=[nid],
            confidence=node.get("confidence", 0),
        ).to_dict())

        # where_used (DERIVED — from graph)
        if upstream_names:
            up_detail = []
            for e in upstream_edges[:5]:
                src = nodes.get(e["source"], {})
                up_detail.append(f"{src.get('label','')} ({src.get('layer','')}.{src.get('type','')})")
            statements.append(ProvenanceStatement(
                text=f"Called by: {', '.join(up_detail)}",
                provenance="derived", evidence_ids=[nid],
            ).to_dict())

        if downstream_names:
            dn_detail = []
            for e in downstream_edges[:5]:
                tgt = nodes.get(e["target"], {})
                dn_detail.append(f"{tgt.get('label','')} ({tgt.get('layer','')}.{tgt.get('type','')})")
            statements.append(ProvenanceStatement(
                text=f"Depends on: {', '.join(dn_detail)}",
                provenance="derived", evidence_ids=[nid],
            ).to_dict())

        # impact_if_changed (DERIVED — fan-out + flow count)
        total_downstream = len(downstream_edges)
        flow_count = len(flow_index.get(nid, []))
        if total_downstream > 0 or flow_count > 0:
            statements.append(ProvenanceStatement(
                text=f"Changing this affects {total_downstream} direct dependents and {flow_count} end-to-end flows.",
                provenance="derived", evidence_ids=[nid],
            ).to_dict())

        # Part of flows (DERIVED)
        if related:
            flow_paths = [f.get("surface", "") for f in related[:3]]
            statements.append(ProvenanceStatement(
                text=f"Part of flows: {'; '.join(flow_paths)}",
                provenance="derived", evidence_ids=[nid],
            ).to_dict())

        genai_enriched = False
        warnings = []

    return {
        "entity_id": nid,
        "name": name,
        "layer": layer,
        "type": ntype,
        "repo": repo,
        "file": node.get("file"),
        "confidence": node.get("confidence", 0),
        "evidence_method": node.get("evidence_method", ""),
        "what_it_does": statements[0]["text"] if statements else "",
        "genai_enriched": genai_enriched,
        "statements": statements,
        "upstream_count": len(upstream_edges),
        "downstream_count": len(downstream_edges),
        "flow_count": len(flow_index.get(nid, [])),
        "warnings": warnings,
    }


def _format_neighbors(edges, nodes, direction, limit=10):
    lines = []
    for e in edges[:limit]:
        nid = e["source"] if direction == "upstream" else e["target"]
        n = nodes.get(nid, {})
        lines.append(f"  {n.get('layer','')}.{n.get('type','')}: {n.get('label','')} --{e.get('type','')}--> ")
    return "\n".join(lines) if lines else "  (none)"


def _format_flows(flow_refs, limit=5):
    lines = []
    for f in flow_refs[:limit]:
        lines.append(f"  [{f.get('catalog','')}] {f.get('surface','')}")
    return "\n".join(lines) if lines else "  (none)"


def _safe_parse_json(text):
    if not text: return None
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            try: return json.loads(text[start:end])
            except: pass
    return None


def _load_entity_evidence(path):
    """Load entities.jsonl and extract evidence snippets + properties keyed by ID."""
    lookup = {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                e = json.loads(line)
                eid = e.get("id", "")
                lookup[eid] = {
                    "snippet": (e.get("evidence", {}).get("snippet", "") or ""),
                    "properties": e.get("properties", {}),
                }
    except Exception:
        pass
    return lookup


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except: return {}


def _load_ast_summaries(path) -> dict:
    """Load ast_summaries.jsonl into a dict keyed by entity_id."""
    lookup = {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    s = json.loads(line)
                    eid = s.get("entity_id", "")
                    if eid:
                        lookup[eid] = s
    except Exception:
        pass
    return lookup


def _format_ast_context(ast_data: dict) -> str:
    """Format AST summary as text context for AI prompts."""
    parts = []
    sig = ast_data.get("signature", {})
    if sig:
        params = ", ".join(
            f"{p.get('type', '?')} {p.get('name', '?')}" for p in sig.get("parameters", [])
        )
        ret = sig.get("return_type", "void")
        parts.append(f"Signature: {sig.get('access', '')} {ret} {sig.get('name', '?')}({params})")

    anns = ast_data.get("annotations", [])
    if anns:
        parts.append(f"Annotations: {', '.join(anns[:5])}")

    calls = ast_data.get("calls", [])
    if calls:
        call_strs = []
        for c in calls[:10]:
            cond = " [conditional]" if c.get("conditional") else ""
            call_strs.append(f"{c['target']}{cond}")
        parts.append(f"Calls: {', '.join(call_strs)}")

    exc = ast_data.get("exception_handling", [])
    if exc:
        parts.append(f"Exception handling: {', '.join(e['type'] + ' (' + e['action'] + ')' for e in exc[:5])}")

    config = ast_data.get("config_refs", [])
    if config:
        parts.append(f"Config refs: {', '.join(config[:5])}")

    comp = ast_data.get("complexity", {})
    if comp:
        parts.append(f"Complexity: {comp.get('branches', 0)} branches, {comp.get('try_catch', 0)} try/catch, {comp.get('lines', 0)} lines")

    return "\n".join(parts)


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    generate_component_intelligence(str(base / "output"))
