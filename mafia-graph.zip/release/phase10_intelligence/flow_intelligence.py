"""
MAFIA Phase 10 — Flow Intelligence Generator
===============================================
For each flow in e2e_flows.json, generates:
  - surface_summary (one line, DERIVED)
  - standard_summary (30-second read, DERIVED + INFERRED)
  - data_flow (DERIVED from hop chain)
  - business_intent (INFERRED by LLM)
  - failure_points (DERIVED from breakpoints + low confidence)
  - blast_radius_hint (DERIVED)

Usage:
    python -m phase10_intelligence.flow_intelligence
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase10_intelligence.provenance import ProvenanceStatement


FLOW_PROMPT = """You are generating developer documentation for an end-to-end flow.
Rules:
1. Label every statement: [OBSERVED], [DERIVED], or [INFERRED]
2. Do NOT invent file paths, APIs, or table names not in the evidence
3. If unknown, say [UNKNOWN]
4. Return ONLY valid JSON

Flow: {flow_id}
Path: {surface_path}
Entry: {entry_name} ({entry_layer}.{entry_type})
Terminal: {terminal_name} ({terminal_layer}.{terminal_type})
Completeness: {completeness}
Hops: {hop_count}
Confidence range: {conf_min}-{conf_max} (avg {conf_avg})
Repos: {repos}

Hop chain:
{hop_chain}

{breakpoint_info}

Return JSON:
{{
  "surface_summary": "<one line, what this flow does>",
  "standard_summary": "<2-3 sentences, 30-second read>",
  "data_flow": "<what data moves from where to where, [DERIVED]>",
  "business_intent": "<why this flow exists from a user perspective, [INFERRED]>",
  "failure_points": ["<where this flow is most likely to break, [DERIVED]>"],
  "blast_radius_hint": "<if entry point changes, what's affected, [DERIVED]>"
}}"""


# ── Relation type → human-readable verb ──────────────────────────────────────

RELATION_VERBS = {
    "calls":            "calls",
    "fetches":          "fetches from",
    "routes_to":        "routes to handler",
    "calls_api":        "calls downstream API via",
    "delegates_to":     "delegates to",
    "uses_repo":        "queries via",
    "calls_function":   "executes DB function",
    "reads_from":       "reads from",
    "writes_to":        "writes to",
    "entity_maps_to":   "maps to table",
    "uses_table":       "accesses table",
    "depends_on_config":"depends on config",
    "validates_with":   "validates with",
    "invokes_http":     "makes HTTP call to",
    "imports":          "imports",
    "exports":          "exports",
}

# ── Node type → role description ─────────────────────────────────────────────

TYPE_ROLES = {
    ("ui", "component"):   "UI component that renders the user interface",
    ("ui", "hook"):        "React hook managing state or side effects",
    ("ui", "selector"):    "state selector reading from the store",
    ("ui", "fetch_def"):   "API call definition that constructs the HTTP request",
    ("ui", "route"):       "page route in the application",
    ("ui", "env_var"):     "environment variable used by the UI",
    ("bff", "endpoint"):   "BFF endpoint that receives the incoming request",
    ("bff", "controller"): "BFF controller method that handles the request logic",
    ("bff", "constant"):   "constant holding the downstream API URL path",
    ("bff", "middleware"):  "middleware that validates or transforms the request",
    ("bff", "service"):    "BFF service helper that orchestrates API calls",
    ("api", "endpoint"):   "API endpoint exposed by the backend service",
    ("api", "controller"): "API controller method that processes the request",
    ("api", "service"):    "service layer method containing business logic",
    ("api", "repository"): "repository method that executes the database query",
    ("api", "entity"):     "JPA entity class mapped to a database table",
    ("api", "dto"):        "data transfer object for request/response shaping",
    ("db", "function"):    "database stored function that runs the SQL logic",
    ("db", "table"):       "database table where the data is stored",
    ("db", "view"):        "database view that aggregates underlying tables",
    ("config", "env"):     "environment configuration variable",
    ("config", "toggle"):  "feature toggle controlling behavior",
}


def generate_flow_intelligence(
    output_dir: str,
    gemini_client=None,
    resume: bool = False,
) -> dict:
    """
    Generate flow_intelligence.json for ALL full_chain flows (complete + partial)
    with per-hop narration explaining what each component does in the flow.

    Sub-catalogs (ui_to_bff, bff_to_api, etc.) are skipped — they are subsets
    of full_chains and would produce duplicate intelligence.

    resume=False by default since we're regenerating with hop_narration.
    """
    output = Path(output_dir)
    flows_data = _load_json(output / "e2e_flows.json")
    sg = _load_json(output / "system_graph.json")
    nodes = {n["id"]: n for n in sg.get("nodes", [])}

    # Load component intelligence for richer per-hop descriptions
    comp_intel = _load_json(output / "component_intelligence.json")
    comp_lookup = {}
    for c in comp_intel.get("components", []):
        comp_lookup[c["entity_id"]] = c

    # Only process full_chains — sub-catalogs are redundant partial views
    all_flows = [
        ("full_chains", flow)
        for flow in flows_data.get("catalogs", {}).get("full_chains", [])
    ]

    # Also include sub-catalog flows that aren't already covered by a full_chain
    # This ensures UI→API→DB partial chains are visible when no full chain exists
    full_chain_entry_ids = {f.get("entry", {}).get("id", "") for _, f in all_flows}
    for cat_name in ("ui_to_bff", "bff_to_api", "api_to_db", "ui_to_api", "ui_to_db"):
        for flow in flows_data.get("catalogs", {}).get(cat_name, []):
            entry_id = flow.get("entry", {}).get("id", "")
            if entry_id not in full_chain_entry_ids:
                all_flows.append((cat_name, flow))

    # Resume: load existing results and skip already-processed flow_ids
    existing_results = []
    existing_ids = set()
    if resume:
        prev = _load_json(output / "flow_intelligence.json")
        for fl in prev.get("flows", []):
            existing_results.append(fl)
            existing_ids.add(fl.get("flow_id", ""))
        if existing_ids:
            print(f"  [RESUME] {len(existing_ids)} flows already processed, continuing...")

    results = list(existing_results)
    new_count = 0
    for cat_name, flow in all_flows:
        fid = flow.get("flow_id", "")
        if fid in existing_ids:
            continue
        intel = _build_flow_intel(cat_name, flow, nodes, comp_lookup, gemini_client)
        results.append(intel)
        new_count += 1

    # Separate complete vs partial for stats
    complete = [r for r in results if r.get("completeness") == "complete"]
    partial = [r for r in results if r.get("completeness") != "complete"]

    output_data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_flows": len(results),
        "complete_flows": len(complete),
        "partial_flows": len(partial),
        "genai_enriched": sum(1 for r in results if r.get("genai_enriched")),
        "flows": results,
    }

    out_path = output / "flow_intelligence.json"
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 10 -- Flow Intelligence")
    print(f"{'='*60}")
    print(f"  Total flows:     {len(results)} ({len(complete)} complete, {len(partial)} partial)")
    print(f"  New this run:    {new_count}")
    print(f"  Resumed:         {len(existing_ids)}")
    print(f"  GenAI enriched:  {output_data['genai_enriched']}")
    print(f"  Output: {out_path}")
    print(f"{'='*60}\n")

    return output_data


def _build_flow_intel(cat_name, flow, nodes, comp_lookup, gemini_client):
    fid = flow.get("flow_id", "")
    entry = flow.get("entry", {})
    terminal = flow.get("terminal", {})
    hops = flow.get("standard", [])
    conf = flow.get("confidence_range", {})
    completeness = flow.get("completeness", "complete" if flow.get("reached_target") else "partial")
    breakpoint = flow.get("breakpoint", {})
    repos = flow.get("repos_involved", [])

    # Build hop chain text
    hop_lines = []
    for h in hops:
        rel = h.get("next_relation", {})
        rel_str = f" --{rel.get('type','')}--> " if rel else ""
        hop_lines.append(f"  [{h.get('layer',''):6s}] {h.get('type',''):15s} {h.get('name','')[:40]}{rel_str}")
    hop_chain = "\n".join(hop_lines)

    bp_info = ""
    if breakpoint:
        bp_info = f"BREAKPOINT: Chain stops at {breakpoint.get('layer','')}.{breakpoint.get('node_name','')} — {breakpoint.get('message','')}"

    # Deterministic intelligence (always available)
    surface = flow.get("surface", {}).get("path", "")
    entry_name = entry.get("name", "")
    terminal_name = terminal.get("name", "")

    # Surface summary (DERIVED)
    surface_summary = f"{entry_name} -> {terminal_name} ({surface})"

    # Data flow (DERIVED)
    layers_in_chain = []
    for h in hops:
        l = h.get("layer", "")
        if not layers_in_chain or layers_in_chain[-1] != l:
            layers_in_chain.append(l)
    data_flow = f"Data flows from {layers_in_chain[0].upper() if layers_in_chain else '?'} through {' -> '.join(l.upper() for l in layers_in_chain)} layer{'s' if len(layers_in_chain) > 1 else ''}"

    # Failure points (DERIVED)
    failure_points = []
    for h in hops:
        if h.get("confidence", 1) < 0.7:
            failure_points.append(f"Low confidence ({h.get('confidence',0):.2f}) at {h.get('layer','')}.{h.get('name','')[:30]}")
    if breakpoint:
        failure_points.append(f"Chain breaks at {breakpoint.get('reason_code','')}: {breakpoint.get('message','')}")

    # Blast radius hint (DERIVED)
    blast_hint = f"Changing {entry_name} may affect {len(hops)} components across {len(repos)} repos"

    statements = [
        ProvenanceStatement(text=surface_summary, provenance="derived", evidence_ids=[fid]).to_dict(),
        ProvenanceStatement(text=data_flow, provenance="derived", evidence_ids=[fid]).to_dict(),
        ProvenanceStatement(text=blast_hint, provenance="derived", evidence_ids=[fid]).to_dict(),
    ]

    genai_enriched = False
    standard_summary = f"Flow from {entry.get('layer','')}.{entry.get('type','')} '{entry_name}' to {terminal.get('layer','')}.{terminal.get('type','')} '{terminal_name}' across {len(hops)} hops."
    business_intent = ""

    # GenAI enrichment if available
    if gemini_client and gemini_client.is_available and len(hops) >= 3:
        prompt = FLOW_PROMPT.format(
            flow_id=fid, surface_path=surface,
            entry_name=entry_name, entry_layer=entry.get("layer",""),
            entry_type=entry.get("type",""),
            terminal_name=terminal_name, terminal_layer=terminal.get("layer",""),
            terminal_type=terminal.get("type",""),
            completeness=completeness, hop_count=len(hops),
            conf_min=conf.get("min",0), conf_max=conf.get("max",0), conf_avg=conf.get("avg",0),
            repos=", ".join(repos), hop_chain=hop_chain, breakpoint_info=bp_info,
        )
        response = gemini_client.generate(prompt)
        parsed = _safe_parse_json(response) if response else None
        if parsed:
            genai_enriched = True
            standard_summary = parsed.get("standard_summary", standard_summary)
            business_intent = parsed.get("business_intent", "")
            if parsed.get("failure_points"):
                failure_points = parsed["failure_points"]
            if parsed.get("blast_radius_hint"):
                blast_hint = parsed["blast_radius_hint"]

            statements.append(ProvenanceStatement(
                text=standard_summary, provenance="derived", evidence_ids=[fid]).to_dict())
            if business_intent:
                statements.append(ProvenanceStatement(
                    text=business_intent, provenance="inferred", evidence_ids=[fid]).to_dict())

    # ── Per-hop narration ────────────────────────────────────────────────────
    hop_narration = _build_hop_narration(hops, nodes, comp_lookup)

    return {
        "flow_id": fid,
        "catalog": cat_name,
        "entry": entry,
        "terminal": terminal,
        "completeness": completeness,
        "hop_count": len(hops),
        "confidence_range": conf,
        "repos_involved": repos,
        "surface_summary": surface_summary,
        "standard_summary": standard_summary,
        "data_flow": data_flow,
        "business_intent": business_intent,
        "failure_points": failure_points,
        "blast_radius_hint": blast_hint,
        "hop_narration": hop_narration,
        "genai_enriched": genai_enriched,
        "statements": statements,
    }


def _build_hop_narration(hops, nodes, comp_lookup):
    """
    Generate per-hop narration explaining what each component does in the flow
    and how it connects to the next hop.
    """
    narration = []
    for i, hop in enumerate(hops):
        hid = hop.get("id", "")
        name = hop.get("name", "")
        layer = hop.get("layer", "")
        htype = hop.get("type", "")
        conf = hop.get("confidence", 0)
        rel = hop.get("next_relation", {})
        rel_type = rel.get("type", "") if rel else ""

        # 1. Role description from type
        role = TYPE_ROLES.get((layer, htype), f"{layer} {htype}")

        # 2. Check component intelligence for richer description
        comp = comp_lookup.get(hid, {})
        comp_desc = ""
        provenance = "derived"
        if comp:
            # Find the first 'observed' statement as the what_it_does
            for stmt in comp.get("statements", []):
                if stmt.get("provenance") == "observed" and len(stmt.get("text", "")) > 20:
                    comp_desc = stmt["text"]
                    break

        # 3. Build the narration line
        # What this hop does
        if comp_desc:
            what = comp_desc[:200]
            provenance = "observed"
        else:
            what = f"{role} '{name}'"

        # How it connects to the next hop
        transition = ""
        if rel_type and i < len(hops) - 1:
            next_hop = hops[i + 1]
            verb = RELATION_VERBS.get(rel_type, rel_type.replace("_", " "))
            transition = f", then {verb} {next_hop.get('name', '')}" if next_hop.get("name") else ""

        # Confidence flag
        conf_flag = ""
        if conf < 0.7:
            conf_flag = f" [low confidence: {conf:.2f}]"

        entry = {
            "step": i + 1,
            "id": hid,
            "name": name,
            "layer": layer,
            "type": htype,
            "role": role,
            "description": what + transition + conf_flag,
            "relation_to_next": rel_type,
            "confidence": conf,
            "provenance": provenance,
        }
        narration.append(entry)

    return narration


def _safe_parse_json(text):
    if not text: return None
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try: return json.loads(text)
    except:
        s, e = text.find("{"), text.rfind("}") + 1
        if s >= 0 and e > s:
            try: return json.loads(text[s:e])
            except: pass
    return None

def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}

if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    generate_flow_intelligence(str(base / "output"))
