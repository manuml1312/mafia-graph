"""
MAFIA Phase 10 — Issue Diagnosis Guidance
============================================
Given issue text, identifies likely flows, change points, and evidence.
All outputs carry provenance labels.

Usage:
    from phase10_intelligence.issue_diagnosis import diagnose_issue
    result = diagnose_issue("API endpoint /flagTypes returning 500", output_dir)
"""

import json, re
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase10_intelligence.provenance import ProvenanceStatement


DIAGNOSIS_PROMPT = """You are a support engineer diagnosing a production issue.
Given the issue description and the system evidence below, identify:
1. Which flows are likely affected
2. Which components are likely change points
3. Where the chain breaks (if partial)
4. Evidence hotspots to investigate

Rules:
- Label every statement: [OBSERVED], [DERIVED], or [INFERRED]
- Do NOT invent file paths or component names not in the evidence
- If unsure, say [UNKNOWN]
- Return ONLY valid JSON

Issue: {issue_text}

Matching components found in the system:
{matching_components}

Related flows:
{related_flows}

Blast radius from top match:
{blast_radius}

Return JSON:
{{
  "likely_flows": ["<flow surface descriptions, [DERIVED]>"],
  "likely_change_points": [
    {{"component": "<name>", "layer": "<layer>", "reason": "<why, [DERIVED] or [INFERRED]>"}}
  ],
  "chain_breaks": ["<where partial flows break, [DERIVED]>"],
  "evidence_hotspots": [
    {{"file": "<path>", "line": "<line>", "confidence": <float>, "note": "<what to look at>"}}
  ],
  "summary": "<1-2 sentence diagnosis, [INFERRED]>"
}}"""


def diagnose_issue(
    issue_text: str,
    output_dir: str,
    gemini_client=None,
) -> dict:
    """Diagnose an issue using graph search + flow catalogs."""
    output = Path(output_dir)
    sg = _load_json(output / "system_graph.json")
    flows_data = _load_json(output / "e2e_flows.json")
    nodes = {n["id"]: n for n in sg.get("nodes", [])}
    edges = sg.get("edges", [])

    # Step 1: Extract keywords from issue text
    keywords = _extract_keywords(issue_text)

    # Step 2: Search graph for matching nodes
    matches = []
    for nid, n in nodes.items():
        label = n.get("label", "").lower()
        for kw in keywords:
            if kw in label or kw in nid.lower():
                matches.append(n)
                break
    matches.sort(key=lambda n: -(len([e for e in edges if e["source"] == n["id"] or e["target"] == n["id"]])))
    matches = matches[:20]

    # Step 3: Find related flows
    related_flows = []
    match_ids = {m["id"] for m in matches}
    for cat_name, cat_flows in flows_data.get("catalogs", {}).items():
        for flow in cat_flows:
            hop_ids = {h["id"] for h in flow.get("standard", [])}
            if hop_ids & match_ids:
                related_flows.append({
                    "catalog": cat_name,
                    "flow_id": flow.get("flow_id", ""),
                    "surface": flow.get("surface", {}).get("path", ""),
                    "entry": flow.get("entry", {}).get("name", ""),
                    "terminal": flow.get("terminal", {}).get("name", ""),
                    "completeness": flow.get("completeness", ""),
                    "breakpoint": flow.get("breakpoint", {}),
                })
    related_flows = related_flows[:10]

    # Step 4: Compute blast radius for top match
    blast_summary = ""
    if matches:
        from phase9_graph.blast_radius_engine import BlastRadiusEngine
        engine = BlastRadiusEngine(str(output / "system_graph.json"))
        br = engine.compute(matches[0]["id"], direction="both", max_depth=3)
        blast_summary = f"Impacted: {br['total_impacted']} nodes, severity: {br['severity_counts']}"

    # Step 5: Build deterministic diagnosis
    statements = []

    # Likely flows (DERIVED)
    for fl in related_flows[:5]:
        statements.append(ProvenanceStatement(
            text=f"Flow: {fl['entry']} -> {fl['terminal']} ({fl['surface']})",
            provenance="derived",
            evidence_ids=[fl["flow_id"]],
        ).to_dict())

    # Likely change points (DERIVED)
    change_points = []
    for m in matches[:5]:
        change_points.append({
            "component": m.get("label", ""),
            "layer": m.get("layer", ""),
            "type": m.get("type", ""),
            "file": m.get("file"),
            "confidence": m.get("confidence", 0),
            "provenance": "derived",
        })

    # Chain breaks (DERIVED)
    chain_breaks = []
    for fl in related_flows:
        bp = fl.get("breakpoint", {})
        if bp:
            chain_breaks.append(f"{bp.get('reason_code','')}: {bp.get('message','')} at {bp.get('node_name','')}")

    # Evidence hotspots
    evidence_hotspots = []
    for m in matches[:5]:
        if m.get("file"):
            evidence_hotspots.append({
                "file": m["file"], "line": m.get("line"),
                "confidence": m.get("confidence", 0),
                "note": f"{m.get('layer','')}.{m.get('type','')} '{m.get('label','')}'",
            })

    # GenAI enrichment if available
    genai_enriched = False
    summary = f"Issue likely involves {len(matches)} components across {len(set(m.get('layer','') for m in matches))} layers"

    if gemini_client and gemini_client.is_available and matches:
        matching_text = "\n".join(
            f"  [{m.get('layer',''):6s}] {m.get('type',''):15s} {m.get('label','')[:40]} (conf={m.get('confidence',0):.2f})"
            for m in matches[:10]
        )
        flows_text = "\n".join(
            f"  {fl['surface']:30s} {fl['entry']} -> {fl['terminal']}"
            for fl in related_flows[:5]
        )
        prompt = DIAGNOSIS_PROMPT.format(
            issue_text=issue_text,
            matching_components=matching_text,
            related_flows=flows_text,
            blast_radius=blast_summary,
        )
        response = gemini_client.generate(prompt)
        parsed = _safe_parse_json(response) if response else None
        if parsed:
            genai_enriched = True
            summary = parsed.get("summary", summary)
            if parsed.get("likely_change_points"):
                for cp in parsed["likely_change_points"]:
                    cp["provenance"] = "inferred"
                change_points.extend(parsed["likely_change_points"])

    return {
        "issue_text": issue_text,
        "keywords_extracted": keywords,
        "matching_components": len(matches),
        "related_flows": related_flows,
        "likely_change_points": change_points,
        "chain_breaks": chain_breaks,
        "evidence_hotspots": evidence_hotspots,
        "blast_radius": blast_summary,
        "summary": summary,
        "genai_enriched": genai_enriched,
        "statements": statements,
    }


def _extract_keywords(text):
    """Extract meaningful keywords from issue text."""
    # Remove common words, keep technical terms
    stop = {"the","a","an","is","are","was","were","be","been","being","have","has","had",
            "do","does","did","will","would","could","should","may","might","shall","can",
            "not","no","but","or","and","if","then","else","when","where","how","what","which",
            "this","that","these","those","it","its","i","we","you","they","he","she","my","our",
            "your","their","from","to","in","on","at","by","for","with","about","into","through",
            "during","before","after","above","below","between","out","off","over","under","again",
            "further","once","here","there","all","each","every","both","few","more","most","other",
            "some","such","only","own","same","so","than","too","very","just","because","as","until",
            "while","of","error","issue","problem","bug","broken","failing","returns","returning"}
    words = re.findall(r'[a-zA-Z_]\w+', text.lower())
    return [w for w in words if w not in stop and len(w) > 2][:15]


def _safe_parse_json(text):
    if not text: return None
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        lines = [l for l in lines if not l.strip().startswith("```")]
        text = "\n".join(lines)
    try: return json.loads(text)
    except:
        s, e = text.find("{"), text.rfind("}") + 1
        if s >= 0 and e > s:
            try: return json.loads(text[s:e])
            except: pass
    return None

def generate_issue_diagnosis_samples(output_dir: str) -> dict:
    """
    Generate issue_diagnosis_samples.json with diagnoses for common issue patterns.
    Extracts sample issues from the graph: top endpoints, DB functions, and known
    breakpoints from e2e_flows.
    """
    output = Path(output_dir)
    sg = _load_json(output / "system_graph.json")
    flows_data = _load_json(output / "e2e_flows.json")
    nodes = {n["id"]: n for n in sg.get("nodes", [])}
    edges = sg.get("edges", [])

    # Build sample issue texts from the actual system
    sample_issues = []

    # 1. Top BFF endpoints — "endpoint X returning 500"
    bff_eps = [n for n in nodes.values() if n.get("layer") == "bff" and n.get("type") == "endpoint"]
    fan_in = defaultdict(int)
    for e in edges:
        fan_in[e["target"]] += 1
    bff_eps.sort(key=lambda n: -fan_in.get(n["id"], 0))
    for ep in bff_eps[:5]:
        sample_issues.append(f"BFF endpoint {ep.get('label','')} returning 500 error")

    # 2. Top API endpoints — "API X timeout"
    api_eps = [n for n in nodes.values() if n.get("layer") == "api" and n.get("type") == "endpoint"]
    api_eps.sort(key=lambda n: -fan_in.get(n["id"], 0))
    for ep in api_eps[:5]:
        sample_issues.append(f"API endpoint {ep.get('label','')} timing out")

    # 3. DB functions — "function X returning wrong data"
    db_fns = [n for n in nodes.values() if n.get("layer") == "db" and n.get("type") == "function"]
    db_fns.sort(key=lambda n: -fan_in.get(n["id"], 0))
    for fn in db_fns[:3]:
        sample_issues.append(f"DB function {fn.get('label','')} returning incorrect results")

    # 4. Breakpoint-derived issues from partial flows
    for flow in flows_data.get("catalogs", {}).get("full_chains", [])[:50]:
        bp = flow.get("breakpoint", {})
        if bp and bp.get("node_name"):
            sample_issues.append(f"Flow breaks at {bp.get('node_name','')} — {bp.get('message','unknown error')}")
            if len(sample_issues) >= 20:
                break

    # Deduplicate
    seen = set()
    unique_issues = []
    for issue in sample_issues:
        key = issue.lower()[:60]
        if key not in seen:
            seen.add(key)
            unique_issues.append(issue)

    # Run diagnosis for each
    results = []
    for issue_text in unique_issues[:20]:
        try:
            diag = diagnose_issue(issue_text, output_dir)
            results.append(diag)
            match_count = diag.get("matching_components", 0)
            flow_count = len(diag.get("related_flows", []))
            print(f"  [OK] {issue_text[:60]:60s} -> {match_count} components, {flow_count} flows")
        except Exception as e:
            print(f"  [FAIL] {issue_text[:60]:60s} -> {e}")
            results.append({
                "issue_text": issue_text,
                "error": str(e),
                "matching_components": 0,
                "related_flows": [],
                "likely_change_points": [],
                "chain_breaks": [],
                "evidence_hotspots": [],
                "blast_radius": "",
                "summary": f"Diagnosis failed: {e}",
                "genai_enriched": False,
                "statements": [],
            })

    output_data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_diagnoses": len(results),
        "diagnoses": results,
    }

    out_path = output / "issue_diagnosis_samples.json"
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 10 -- Issue Diagnosis Samples")
    print(f"{'='*60}")
    print(f"  Diagnoses generated: {len(results)}")
    print(f"  With matches:        {sum(1 for r in results if r.get('matching_components', 0) > 0)}")
    print(f"  With flows:          {sum(1 for r in results if r.get('related_flows'))}")
    print(f"  Output: {out_path}")
    print(f"{'='*60}\n")

    return output_data


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f: return json.load(f)
    except: return {}


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    generate_issue_diagnosis_samples(str(base / "output"))
