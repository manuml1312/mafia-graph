# MAFIA — Multi-Artifact Flow Intelligence Architecture

## First-Time Setup

```bash
cd MAFIA_Phase1_Execution
setup.bat              # creates venv, installs deps, validates imports
setup.bat --extras     # also installs 9 extra language grammars
```

## What This Is

Automated codebase analysis pipeline: scans repos → extracts entities → builds system graph → assembles e2e flows → serves interactive explorer with AI search and blast radius.

## Commands (run from MAFIA_Phase1_Execution/)

```bash
python -m phase2_repo_intake.repo_scanner --source-roots /path    # scan repos
python -m phase3_extraction_framework.run_extraction               # incremental extraction
python -m phase3_extraction_framework.run_extraction --full        # full re-extraction
python -m phase3_extraction_framework.run_extraction --from-phase 9  # rebuild graph only
python -m phase10_ast.run_ast_summaries --discover                 # AST summaries
python -m phase11_search.vector_index --incremental                # search index
python -m phase11_search.search_api1                               # start server :5001
```

## Architecture

```
UI (React) → BFF (Koa/Express) → API (Spring Boot) → DB (Postgres/Databricks)
```

Entities: `{layer}:{type}:{repo}:{qualifier}` (e.g. `api:endpoint:flags_api:GET:/flagTypes`)
Relations: `{source}--{type}-->{target}` (e.g. `delegates_to`, `calls_api`, `reads_from`)

## Key Files

| File | Purpose |
|------|---------|
| `phase3_extraction_framework/run_extraction.py` | Main pipeline entry point |
| `phase3_extraction_framework/base_extractor.py` | Extractor ABC |
| `phase3_extraction_framework/dispatcher.py` | Routes repos to extractors |
| `phase4_extractors/` | All extractors by layer |
| `schemas/id_format.py` | Valid layers, types, relations |
| `schemas/emitter.py` | Thread-safe entity/relation emission |
| `phase9_graph/graph_builder.py` | Graph + flow assembly |
| `phase9_graph/blast_radius_engine.py` | Impact analysis |
| `phase11_search/search_api1.py` | Flask API server |
| `phase12_ui/` | Web UI (served by Flask) |
| `output/` | All generated artifacts |

## Output Artifacts

- `entities.jsonl` / `relations.jsonl` — extracted entities and edges
- `system_graph.json` — full graph with nodes and edges
- `e2e_flows.json` — end-to-end flows across 6 catalogs
- `ast_summaries.jsonl` — method-level structural summaries
- `coverage_report.json` / `quality_gate_report.json` — health metrics

## API Endpoints (localhost:5001)

- `GET /search?q=...&layer=...` — vector + graph search
- `GET /node/{id}` — node profile with relations
- `GET /flows` / `GET /flow/{id}` — flow listing and detail
- `POST /blast_radius` — impact analysis
- `POST /chat` — RAG-grounded AI chat
- `GET /coverage` — extraction coverage stats
- `GET /inventory` — full entity inventory
- `GET /codetree` — repo → file → entity tree
- `POST /simulate` — change simulation

## Coding Conventions

- Extractors subclass `BaseExtractor`, implement `extract_file()`
- All emission through `self.emitter.emit_entity()` / `self.emitter.emit_relation()`
- Confidence scores: 0.95 (exact), 0.85 (strong), 0.70 (inferred), 0.50 (weak), 0.30 (guess)
- GenAI entities capped at 0.70 confidence
- File-level caching via SHA256 fingerprints
- Incremental mode via repo fingerprinting in `run_state.json`

## For full capabilities reference, see skills.md
