"""
MAFIA Phase 7 — Mapping Confidence Evaluation
===============================================
Reads entities.jsonl + relations.jsonl and evaluates cross-layer mapping quality.
Produces mapping_confidence_report.json (artifact 5 of 5).

Evaluates:
  - UI -> BFF: fetch_def -> bff endpoint via fetches/depends_on_config
  - BFF -> API: controller -> api endpoint via calls_api
  - API -> DB: repository -> db function/table via calls_function/reads_from

Usage:
    python -m phase7_mapping.mapping_evaluator
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def build_mapping_confidence_report(output_dir: str) -> dict:
    output = Path(output_dir)
    entities = _load_jsonl(output / "entities.jsonl")
    relations = _load_jsonl(output / "relations.jsonl")

    entity_map = {e["id"]: e for e in entities}

    # ── Classify relations by cross-layer hop ────────────────────────────────
    ui_to_bff_rels = []    # fetches, depends_on_config from ui -> bff/config
    bff_to_api_rels = []   # calls_api from bff -> api
    api_to_db_rels = []    # calls_function, reads_from, entity_maps_to, uses_table

    for r in relations:
        rtype = r.get("type", "")
        src = entity_map.get(r.get("source", ""), {})
        tgt = entity_map.get(r.get("target", ""), {})
        src_layer = src.get("layer", "")
        tgt_layer = tgt.get("layer", "")

        if rtype == "fetches" or (rtype == "depends_on_config" and src_layer == "ui"):
            ui_to_bff_rels.append(r)
        elif rtype == "calls_api" and src_layer == "bff":
            bff_to_api_rels.append(r)
        elif rtype in ("calls_function", "reads_from", "entity_maps_to", "uses_table") and tgt_layer == "db":
            api_to_db_rels.append(r)

    # ── Evaluate each hop ────────────────────────────────────────────────────
    ui_bff = _evaluate_hop("ui_to_bff", ui_to_bff_rels, entity_map, entities, "ui", "bff")
    bff_api = _evaluate_hop("bff_to_api", bff_to_api_rels, entity_map, entities, "bff", "api")
    api_db = _evaluate_hop("api_to_db", api_to_db_rels, entity_map, entities, "api", "db")

    # API->DB extra: separate function vs table confidence
    fn_rels = [r for r in api_to_db_rels if r.get("type") == "calls_function"]
    tbl_rels = [r for r in api_to_db_rels if r.get("type") in ("reads_from", "entity_maps_to", "uses_table")]
    api_db["function_confidence"] = round(sum(r.get("confidence", 0) for r in fn_rels) / max(len(fn_rels), 1), 3)
    api_db["table_confidence"] = round(sum(r.get("confidence", 0) for r in tbl_rels) / max(len(tbl_rels), 1), 3)

    # ── Hotspot detection ────────────────────────────────────────────────────
    hotspots = []

    # BFF endpoints with no UI caller
    bff_endpoints = [e for e in entities if e.get("layer") == "bff" and e.get("type") == "endpoint"]
    ui_targets = {r.get("target", "") for r in ui_to_bff_rels}
    for ep in bff_endpoints:
        if ep["id"] not in ui_targets:
            hotspots.append({
                "type": "unresolved",
                "layer_hop": "ui_to_bff",
                "source": "no_ui_caller",
                "target_raw": ep["id"],
                "candidates": 0,
                "confidence": 0.0,
                "reason": f"BFF endpoint {ep.get('name', '')} has no UI fetch mapping",
            })

    # BFF controllers with calls_api but unresolved target
    for r in bff_to_api_rels:
        if r.get("unresolved_target"):
            hotspots.append({
                "type": "unresolved",
                "layer_hop": "bff_to_api",
                "source": r.get("source", ""),
                "target_raw": r.get("unresolved_target", ""),
                "candidates": len(r.get("candidates", [])),
                "confidence": r.get("confidence", 0),
                "reason": "BFF->API call could not resolve target API endpoint",
            })

    # API endpoints with no DB lineage
    api_endpoints = [e for e in entities if e.get("layer") == "api" and e.get("type") == "endpoint"]
    api_with_db = set()
    # Walk: endpoint -> controller -> service -> repository -> db
    routes_to = {r["source"]: r["target"] for r in relations if r["type"] == "routes_to"}
    delegates = defaultdict(list)
    for r in relations:
        if r["type"] == "delegates_to":
            delegates[r["source"]].append(r["target"])
    uses_repos = defaultdict(list)
    for r in relations:
        if r["type"] == "uses_repo":
            uses_repos[r["source"]].append(r["target"])
    calls_fns = {r["source"] for r in relations if r["type"] in ("calls_function", "reads_from")}

    for ep in api_endpoints:
        ctrl = routes_to.get(ep["id"])
        if not ctrl:
            continue
        for svc in delegates.get(ctrl, []):
            for repo in uses_repos.get(svc, []):
                if repo in calls_fns:
                    api_with_db.add(ep["id"])

    for ep in api_endpoints:
        if ep["id"] not in api_with_db:
            hotspots.append({
                "type": "missing_evidence",
                "layer_hop": "api_to_db",
                "source": ep["id"],
                "target_raw": "",
                "candidates": 0,
                "confidence": 0.0,
                "reason": f"API endpoint {ep.get('name', '')} has no traced DB lineage",
            })

    # Low-confidence cross-layer relations
    for r in ui_to_bff_rels + bff_to_api_rels + api_to_db_rels:
        if r.get("confidence", 1.0) < 0.50:
            src_layer = entity_map.get(r.get("source", ""), {}).get("layer", "?")
            tgt_layer = entity_map.get(r.get("target", ""), {}).get("layer", "?")
            hotspots.append({
                "type": "low_confidence",
                "layer_hop": f"{src_layer}_to_{tgt_layer}",
                "source": r.get("source", ""),
                "target_raw": r.get("target", ""),
                "candidates": 0,
                "confidence": r.get("confidence", 0),
                "reason": f"Cross-layer relation confidence {r.get('confidence', 0):.2f} < 0.50",
            })

    hotspots.sort(key=lambda h: h.get("confidence", 0))

    # ── Summary ──────────────────────────────────────────────────────────────
    all_confs = [r.get("confidence", 0) for r in ui_to_bff_rels + bff_to_api_rels + api_to_db_rels]
    overall_conf = round(sum(all_confs) / max(len(all_confs), 1), 3)

    hop_avgs = {
        "ui_to_bff": ui_bff.get("avg_confidence", 0),
        "bff_to_api": bff_api.get("avg_confidence", 0),
        "api_to_db": api_db.get("avg_confidence", 0),
    }
    weakest = min(hop_avgs, key=hop_avgs.get) if hop_avgs else "unknown"

    total_unresolved = ui_bff["unresolved"] + bff_api["unresolved"] + api_db["unresolved"]
    total_ambiguous = ui_bff["ambiguous"] + bff_api["ambiguous"] + api_db["ambiguous"]

    # Gate: ready if no critical gaps and overall confidence > 0.60
    ready = overall_conf > 0.60 and total_unresolved < (len(all_confs) * 0.30) if all_confs else False

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "layer_mappings": {
            "ui_to_bff": ui_bff,
            "bff_to_api": bff_api,
            "api_to_db": api_db,
        },
        "hotspots": hotspots[:50],  # cap at 50 for readability
        "summary": {
            "overall_confidence": overall_conf,
            "weakest_hop": weakest,
            "total_unresolved": total_unresolved,
            "total_ambiguous": total_ambiguous,
            "ready_for_flow_gen": ready,
        },
    }

    report_path = output / "mapping_confidence_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 7 -- Mapping Confidence Report")
    print(f"{'='*60}")
    print(f"  UI->BFF:  {ui_bff['total_mappings']} mappings, avg conf {ui_bff['avg_confidence']:.2f}, {ui_bff['unresolved']} unresolved")
    print(f"  BFF->API: {bff_api['total_mappings']} mappings, avg conf {bff_api['avg_confidence']:.2f}, {bff_api['unresolved']} unresolved")
    print(f"  API->DB:  {api_db['total_mappings']} mappings, avg conf {api_db['avg_confidence']:.2f}, {api_db['unresolved']} unresolved")
    print(f"            fn_conf={api_db['function_confidence']:.2f}, tbl_conf={api_db['table_confidence']:.2f}")
    print(f"  Overall:  {overall_conf:.2f}  |  Weakest: {weakest}")
    print(f"  Hotspots: {len(hotspots)} ({sum(1 for h in hotspots if h['type']=='unresolved')} unresolved, "
          f"{sum(1 for h in hotspots if h['type']=='low_confidence')} low-conf)")
    print(f"  Ready for flow gen: {'YES' if ready else 'NO'}")
    print(f"  Report: {report_path}")
    print(f"{'='*60}\n")

    return report


def _evaluate_hop(hop_name, rels, entity_map, all_entities, src_layer, tgt_layer):
    """Evaluate one cross-layer hop."""
    total = len(rels)
    exact = sum(1 for r in rels if r.get("confidence", 0) >= 0.90)
    heuristic = sum(1 for r in rels if 0.70 <= r.get("confidence", 0) < 0.90)
    inferred = sum(1 for r in rels if 0.50 <= r.get("confidence", 0) < 0.70)
    unresolved = sum(1 for r in rels if r.get("unresolved_target"))
    ambiguous = sum(1 for r in rels if r.get("candidates") and len(r.get("candidates", [])) > 1)
    avg_conf = round(sum(r.get("confidence", 0) for r in rels) / max(total, 1), 3)

    # Unresolved details: source entities with no cross-layer relation
    src_entities = [e for e in all_entities if e.get("layer") == src_layer]
    src_with_rel = {r.get("source", "") for r in rels}
    unresolved_details = [
        e["id"] for e in src_entities
        if e["id"] not in src_with_rel and e.get("type") in ("fetch_def", "controller", "endpoint", "repository")
    ][:20]

    return {
        "total_mappings": total,
        "exact_matches": exact,
        "heuristic_matches": heuristic,
        "inferred_matches": inferred,
        "unresolved": unresolved,
        "ambiguous": ambiguous,
        "avg_confidence": avg_conf,
        "unresolved_details": unresolved_details,
    }


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    build_mapping_confidence_report(str(base / "output"))
