@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  MAFIA - First-Time Setup (Windows)
:: ============================================================
::  Usage:
::    setup.bat              Full setup (venv + deps + validate)
::    setup.bat --extras     Also install 9 extra language grammars
::    setup.bat --skip-venv  Skip venv creation (CI / containers)
:: ============================================================

set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

set "EXTRAS=0"
set "SKIPVENV=0"

:parse_args
if "%~1"=="" goto done_args
if /i "%~1"=="--extras" set "EXTRAS=1"
if /i "%~1"=="--skip-venv" set "SKIPVENV=1"
shift
goto parse_args
:done_args

echo.
echo ============================================================
echo   MAFIA -- First-Time Setup
echo ============================================================
echo.

:: -- Step 1: Check Python --
echo [..] Checking Python...
where python >nul 2>&1
if errorlevel 1 (
    echo [XX] Python not found. Install Python 3.10+ from https://python.org
    exit /b 1
)

for /f "tokens=*" %%i in ('python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}')"') do set "PYVER=%%i"
echo [OK] Python %PYVER%

for /f "tokens=*" %%i in ('python -c "import sys; print(1 if sys.version_info >= (3,10) else 0)"') do set "PYOK=%%i"
if "%PYOK%"=="0" (
    echo [XX] Python 3.10+ required. You have %PYVER%.
    exit /b 1
)

:: -- Step 2: Virtual Environment --
set "PY=python"

if "%SKIPVENV%"=="1" (
    echo [!!] Skipping venv creation
    goto install_deps
)

python -c "import sys; exit(0 if hasattr(sys,'real_prefix') or (hasattr(sys,'base_prefix') and sys.base_prefix!=sys.prefix) else 1)" >nul 2>&1
if not errorlevel 1 (
    echo [OK] Already in a virtual environment
    goto install_deps
)

if exist "%ROOT%\.venv\Scripts\python.exe" (
    echo [OK] Virtual environment exists
) else (
    echo [..] Creating virtual environment...
    python -m venv "%ROOT%\.venv"
    if errorlevel 1 (
        echo [XX] Failed to create virtual environment
        exit /b 1
    )
    echo [OK] Virtual environment created
)

set "PY=%ROOT%\.venv\Scripts\python.exe"

:: -- Step 3: Install Dependencies --
:install_deps
echo [..] Upgrading pip...
%PY% -m pip install --upgrade pip -q >nul 2>&1

echo [..] Installing dependencies from requirements.txt...
%PY% -m pip install -r "%ROOT%\requirements.txt" -q
if errorlevel 1 (
    echo [XX] Dependency installation failed
    exit /b 1
)
echo [OK] Core dependencies installed

if "%EXTRAS%"=="1" (
    echo [..] Installing extra tree-sitter grammars...
    %PY% -m pip install tree-sitter-go tree-sitter-rust tree-sitter-c-sharp tree-sitter-kotlin tree-sitter-scala tree-sitter-ruby tree-sitter-c tree-sitter-cpp tree-sitter-php -q
    echo [OK] Extra grammars installed
)

:: -- Step 4: Create Directories --
if not exist "%ROOT%\output" mkdir "%ROOT%\output"
if not exist "%ROOT%\workspace" mkdir "%ROOT%\workspace"
echo [OK] Directories ready: output\, workspace\

:: -- Step 5: Fix __init__.py --
set "IC=0"
for /d %%d in ("%ROOT%\phase*") do (
    if not exist "%%d\__init__.py" (
        type nul > "%%d\__init__.py"
        set /a IC+=1
    )
)
if not exist "%ROOT%\schemas\__init__.py" if exist "%ROOT%\schemas" (
    type nul > "%ROOT%\schemas\__init__.py"
    set /a IC+=1
)
if not exist "%ROOT%\utils\__init__.py" if exist "%ROOT%\utils" (
    type nul > "%ROOT%\utils\__init__.py"
    set /a IC+=1
)
if %IC% gtr 0 (
    echo [OK] Created %IC% missing __init__.py files
) else (
    echo [OK] All __init__.py files present
)

:: -- Step 6: Validate Imports --
echo [..] Validating core imports...
%PY% -c "import flask,numpy,pandas,requests,networkx; print('[OK] Core: flask, numpy, pandas, requests, networkx')"
if errorlevel 1 echo [!!] Some core imports failed

%PY% -c "import tree_sitter; print('[OK] tree-sitter available')" 2>nul
if errorlevel 1 echo [!!] tree-sitter not available (AST features disabled)

echo [..] Validating MAFIA modules...
cd /d "%ROOT%"
%PY% -c "import sys; sys.path.insert(0,'.'); from schemas.id_format import LAYERS; from schemas.emitter import CanonicalEmitter; from phase3_extraction_framework.base_extractor import BaseExtractor; print('[OK] MAFIA modules verified')"
if errorlevel 1 echo [!!] Some MAFIA module imports failed

:: -- Done --
echo.
echo ============================================================
echo   MAFIA Setup Complete
echo ============================================================
echo.
echo   Next steps:
echo.
if exist "%ROOT%\.venv\Scripts\activate.bat" (
    echo     .venv\Scripts\activate
    echo.
)
echo     # Option A: Point at local repos and run
echo     python -m phase2_repo_intake.repo_scanner --source-roots C:\path\to\repos
echo     python -m phase3_extraction_framework.run_extraction --full
echo     python -m phase11_search.search_api1
echo.
echo     # Option B: Start the server and upload via browser
echo     python -m MAFIA_Phase1_Execution
echo     #   Open http://localhost:5001
echo.
echo     # Option C: Let your AI agent handle it
echo     #   Open in Kiro / Claude Code / Amazon Q
echo     #   Agent reads skills.md and knows all commands
echo.

endlocal
