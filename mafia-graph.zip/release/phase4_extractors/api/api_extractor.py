"""
MAFIA Phase 4+5 — Java API Entity and Relation Extractor
==========================================================
Extracts from Java Spring Boot API repos:
  Entities: endpoint, controller, service, repository, entity, dto, db.function, db.table
  Relations: delegates_to, uses_repo, calls_function, entity_maps_to, reads_from
Uses before_repo to build a file index for cross-file field→class resolution.
"""

import os
import re
import threading
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult, SKIP_DIRS
from utils.fuzzy import fuzzy_match_best


class ApiExtractor(BaseExtractor):
    name = "api_extractor"
    supported_extensions = {'.java'}

    def __init__(self):
        super().__init__()
        self._file_index = {}      # filename -> {rel_path, content, file_type, entity_table}
        self._entity_by_class = {} # ClassName -> schema.table
        self._idx_lock = threading.Lock()

    # ── Pre-scan: build file index for cross-file resolution ─────────────────

    def before_repo(self, repo_id, repo_path, repo_meta):
        self._file_index = {}
        self._entity_by_class = {}

        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                if not fname.endswith('.java'):
                    continue
                fpath = os.path.join(root, fname)
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except Exception:
                    continue

                # Classify file type
                ftype = 'unknown'
                entity_table = None
                if fname.endswith('Controller.java') or fname.endswith('Resource.java'):
                    ftype = 'controller'
                elif fname.endswith('ServiceImpl.java'):
                    ftype = 'service_impl'
                elif fname.endswith('Service.java'):
                    ftype = 'service'
                elif fname.endswith('Repository.java'):
                    ftype = 'repository'
                    jpa_m = re.search(r'extends\s+JpaRepository\s*<\s*(\w+)\s*,', content)
                    if jpa_m:
                        entity_table = self._entity_by_class.get(jpa_m.group(1))
                elif '@Entity' in content:
                    ftype = 'entity'
                    entity_table = self._extract_table_from_entity(content)
                    cls_m = re.search(r'public\s+class\s+(\w+)', content)
                    if entity_table and cls_m:
                        self._entity_by_class[cls_m.group(1)] = entity_table
                elif 'Request' in fname or 'Response' in fname or 'Dto' in fname or 'DTO' in fname:
                    ftype = 'dto'
                elif 'Util' in fname or 'Helper' in fname:
                    ftype = 'util'
                elif 'Config' in fname or 'Configuration' in fname:
                    ftype = 'config'

                self._file_index[fname] = {
                    "rel_path": rel, "content": content,
                    "file_type": ftype, "entity_table": entity_table,
                }

        # Second pass: resolve repository entity tables now that all entities are indexed
        for fname, info in self._file_index.items():
            if info["file_type"] == "repository" and not info["entity_table"]:
                jpa_m = re.search(r'extends\s+JpaRepository\s*<\s*(\w+)\s*,', info["content"])
                if jpa_m:
                    info["entity_table"] = self._entity_by_class.get(jpa_m.group(1))

        # Third pass: build @Autowired field map so _resolve_field_to_file
        # can find injected services even when not referenced in method body text.
        self._autowired_fields = {}  # field_name -> file_info
        _aw_pat = re.compile(
            r'@Autowired[\s\S]{0,200}?(?:private|protected|public)\s+(\w+)\s+(\w+)\s*;'
        )
        for fname, info in self._file_index.items():
            for aw in _aw_pat.finditer(info["content"]):
                cls_name, field_name = aw.group(1), aw.group(2)
                resolved = (self._file_index.get(cls_name + "Impl.java")
                            or self._file_index.get(cls_name + ".java"))
                if resolved:
                    self._autowired_fields[field_name] = resolved

    def _extract_table_from_entity(self, content):
        if '@Entity' not in content:
            return None
        table_m = re.search(r'@Table\s*\([^)]*name\s*=\s*"([^"]+)"', content)
        if not table_m:
            return None
        table = table_m.group(1)
        schema_m = re.search(r'@Table\s*\([^)]*schema\s*=\s*"([^"]+)"', content)
        schema = schema_m.group(1) if schema_m else 'dre'
        return f"{schema}.{table}"

    def _resolve_field_to_file(self, field_name):
        """Resolve camelCase field to PascalCase file. e.g. flagService -> FlagServiceImpl.java"""
        class_name = field_name[0].upper() + field_name[1:]
        # Tier 1: exact PascalCase match
        for suffix in ('Impl.java', '.java'):
            candidate = class_name + suffix
            if candidate in self._file_index:
                return self._file_index[candidate]
        # Tier 2: case-insensitive exact
        for fname, info in self._file_index.items():
            stem = fname.lower().replace('.java', '')
            if stem == field_name.lower() or stem == field_name.lower() + 'impl':
                return info
        # Tier 3: @Autowired field map (populated in before_repo)
        if hasattr(self, "_autowired_fields") and field_name in self._autowired_fields:
            return self._autowired_fields[field_name]
        # Tier 4: Jaro-Winkler fuzzy match (confidence capped at 0.70)
        stems = {fname.replace('.java', ''): fname for fname in self._file_index}
        best, score = fuzzy_match_best(class_name, list(stems.keys()), threshold=0.85)
        if best:
            matched_fname = stems[best]
            info = self._file_index[matched_fname]
            info["_fuzzy_resolved"] = True
            info["_fuzzy_score"] = score
            return info
        return None

    def _extract_method_body(self, content, method_name):
        idx = 0
        while True:
            pos = content.find(method_name + '(', idx)
            if pos == -1:
                return None
            before = content[max(0, pos - 300):pos].rstrip()
            if re.search(r'(?:public|private|protected)\s+.*$', before, re.DOTALL):
                brace = content.find('{', pos)
                if brace == -1:
                    return None
                depth, i = 1, brace + 1
                while i < len(content) and depth > 0:
                    if content[i] == '{': depth += 1
                    elif content[i] == '}': depth -= 1
                    i += 1
                return content[brace + 1:i - 1]
            idx = pos + 1

    def _find_method_line(self, content, method_name):
        if not method_name:
            return None
        idx = 0
        while True:
            pos = content.find(method_name + '(', idx)
            if pos == -1:
                return None
            before = content[max(0, pos - 300):pos]
            if re.search(r'(?:public|private|protected|@\w+)\s', before):
                return content[:pos].count('\n') + 1
            idx = pos + 1

    # ── Main extraction ──────────────────────────────────────────────────────

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0
        fname = Path(rel_path).name
        file_info = self._file_index.get(fname, {})
        ftype = file_info.get("file_type", "unknown")

        # ── Endpoints (@XxxMapping) ──────────────────────────────────────────
        if ftype == 'controller':
            class_mapping = ""
            cm = re.search(r'@RequestMapping\s*\(\s*["\']([^"\']+)["\']', content)
            if cm:
                class_mapping = cm.group(1)

            patterns = [
                (r'@(Get|Post|Put|Delete|Patch)Mapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', None),
                (r'@RequestMapping\s*\([^)]*value\s*=\s*["\']([^"\']+)["\'][^)]*method\s*=\s*RequestMethod\.(\w+)', 'swap'),
            ]

            for pat, mode in patterns:
                for m in re.finditer(pat, content, re.DOTALL):
                    if mode == 'swap':
                        path, http_method = m.group(1), m.group(2).upper()
                    else:
                        http_method, path = m.group(1).upper(), m.group(2)
                    full_path = class_mapping + path if class_mapping else path
                    line = content[:m.start()].count('\n') + 1

                    after = content[m.end():m.end() + 300]
                    method_m = re.search(r'public\s+\w+(?:<[^>]+>)?\s+(\w+)\s*\(', after)
                    handler = method_m.group(1) if method_m else "unknown"

                    ep_id = self.emitter.emit_entity(
                        layer="api", entity_type="endpoint", repo=repo_id,
                        qualifier=f"{http_method}:{full_path}", name=f"{http_method} {full_path}",
                        file=rel_path, line=line, confidence=0.95,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                        properties={"http_method": http_method, "endpoint_path": full_path, "handler_method": handler},
                    )
                    entities += 1

                    # Controller entity
                    ctrl_id = self.emitter.emit_entity(
                        layer="api", entity_type="controller", repo=repo_id,
                        qualifier=f"{rel_path}::{handler}", name=f"{fname}::{handler}",
                        file=rel_path, line=self._find_method_line(content, handler),
                        confidence=0.95,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=self._find_method_line(content, handler),
                        properties={"http_method": http_method},
                    )
                    entities += 1

                    # Relation: endpoint -> controller (routes_to)
                    self.emitter.emit_relation(
                        source_id=ep_id, target_id=ctrl_id,
                        relation_type="routes_to", confidence=0.95,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line,
                        properties={"http_method": http_method},
                    )
                    relations += 1

                    # Trace: controller -> service calls
                    body = self._extract_method_body(content, handler)
                    if body:
                        found_service = False
                        for sc in re.finditer(r'(\w+(?:Service|Repository|Helper|Manager|Client|Dao|Access|Facade|Delegate|Provider|Handler|Adapter)\w*)\.\s*(\w+)\s*\(', body):
                            field, method = sc.group(1), sc.group(2)
                            svc_file = self._resolve_field_to_file(field)
                            if svc_file:
                                found_service = True
                                svc_type = "service" if svc_file["file_type"] in ("service", "service_impl") else "repository"
                                svc_conf = 0.70 if svc_file.get("_fuzzy_resolved") else 0.90
                                svc_method = "heuristic" if svc_file.get("_fuzzy_resolved") else "regex"
                                svc_id = self.emitter.emit_entity(
                                    layer="api", entity_type=svc_type, repo=repo_id,
                                    qualifier=f"{svc_file['rel_path']}::{method}",
                                    name=f"{field}.{method}",
                                    file=svc_file["rel_path"],
                                    line=self._find_method_line(svc_file["content"], method),
                                    confidence=svc_conf,
                                    evidence_file=rel_path, evidence_method=svc_method,
                                    evidence_line_start=self._find_method_line(content, handler),
                                    evidence_snippet=sc.group(0)[:200],
                                    properties={"field": field, "method": method},
                                    warnings=[f"Fuzzy-resolved ({svc_file.get('_fuzzy_score',0):.2f})"] if svc_file.get("_fuzzy_resolved") else None,
                                )
                                entities += 1

                                rel_type = "delegates_to" if svc_type == "service" else "uses_repo"
                                self.emitter.emit_relation(
                                    source_id=ctrl_id, target_id=svc_id,
                                    relation_type=rel_type, confidence=svc_conf,
                                    evidence_file=rel_path, evidence_method=svc_method,
                                    evidence_line_start=self._find_method_line(content, handler),
                                    evidence_snippet=sc.group(0)[:200],
                                    properties={"field": field, "method": method},
                                )
                                relations += 1

                                # If service, trace further to repository
                                if svc_type == "service":
                                    svc_body = self._extract_method_body(svc_file["content"], method)
                                    if svc_body:
                                        for rc in re.finditer(r'(\w+(?:Repository|Dao|Access)\w*)\.\s*(\w+)\s*\(', svc_body):
                                            repo_field, repo_method = rc.group(1), rc.group(2)
                                            repo_file = self._resolve_field_to_file(repo_field)
                                            if repo_file:
                                                repo_eid = self.emitter.emit_entity(
                                                    layer="api", entity_type="repository", repo=repo_id,
                                                    qualifier=f"{repo_file['rel_path']}::{repo_method}",
                                                    name=f"{repo_field}.{repo_method}",
                                                    file=repo_file["rel_path"],
                                                    line=self._find_method_line(repo_file["content"], repo_method),
                                                    confidence=0.90,
                                                    evidence_file=svc_file["rel_path"], evidence_method="regex",
                                                    evidence_snippet=rc.group(0)[:200],
                                                )
                                                entities += 1
                                                self.emitter.emit_relation(
                                                    source_id=svc_id, target_id=repo_eid,
                                                    relation_type="uses_repo", confidence=0.90,
                                                    evidence_file=svc_file["rel_path"], evidence_method="regex",
                                                    evidence_snippet=rc.group(0)[:200],
                                                )
                                                relations += 1

                                                # Repository -> DB function/table
                                                e, r = self._extract_db_from_repo(repo_file, repo_method, repo_eid, repo_id)
                                                entities += e
                                                relations += r

                        # If no service call was resolved, request GenAI assist
                        if not found_service and body.strip():
                            service_refs = re.findall(r'(\w+(?:Service|Repository|Helper|Manager|Client|Dao|Access|Facade|Delegate|Provider|Handler|Adapter)\w*)\.\s*(\w+)\s*\(', body)
                            if service_refs:
                                self.request_assist(
                                    request_type="unresolved_call_chain",
                                    file=rel_path, line=self._find_method_line(content, handler),
                                    what_i_tried=f"PascalCase file lookup for fields: {[s[0] for s in service_refs]}",
                                    what_i_need="Which service/repository classes these fields resolve to and what methods they call",
                                    code_snippet=body[:4000],
                                    extra={"method_name": handler, "unresolved_fields": [s[0] for s in service_refs[:5]]},
                                )
                            else:
                                # Controller body has no Service/Repository pattern at all
                                self.request_assist(
                                    request_type="complex_body_parse",
                                    file=rel_path, line=self._find_method_line(content, handler),
                                    what_i_tried="regex for fieldName.methodName() with Service/Repository suffix",
                                    what_i_need="What service or data access calls this controller method makes",
                                    code_snippet=body[:4000],
                                    extra={"method_name": handler},
                                )

        # ── JPA Entity + DB Table ────────────────────────────────────────────
        if ftype == 'entity' and '@Entity' in content:
            table_m = re.search(r'@Table\s*\([^)]*name\s*=\s*"([^"]+)"', content)
            schema_m = re.search(r'@Table\s*\([^)]*schema\s*=\s*"([^"]+)"', content)
            class_m = re.search(r'public\s+class\s+(\w+)', content)
            if table_m and class_m:
                table = table_m.group(1)
                schema = schema_m.group(1) if schema_m else 'dre'
                full_table = f"{schema}.{table}"
                line = content[:table_m.start()].count('\n') + 1

                entity_id = self.emitter.emit_entity(
                    layer="api", entity_type="entity", repo=repo_id,
                    qualifier=f"{fname}::{class_m.group(1)}", name=class_m.group(1),
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=table_m.group(0)[:200],
                    properties={"table": full_table, "schema": schema},
                )
                entities += 1

                table_id = self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=full_table, name=full_table,
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="inferred",
                    evidence_line_start=line,
                    evidence_snippet=f'@Table(name="{table}", schema="{schema}")',
                    properties={"schema": schema, "table_name": table, "db_type": "postgres"},
                )
                entities += 1

                self.emitter.emit_relation(
                    source_id=entity_id, target_id=table_id,
                    relation_type="entity_maps_to", confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    properties={"schema": schema, "table": table},
                )
                relations += 1

        # ── Repository @Query -> DB function (standalone, not traced from controller) ─
        if ftype == 'repository':
            for m in re.finditer(r'@Query\s*\(\s*(?:value\s*=\s*)?("(?:[^"\\]|\\.)*"(?:\s*\+\s*"(?:[^"\\]|\\.)*")*)', content, re.DOTALL):
                query_block = m.group(1)
                query_text = ' '.join(re.findall(r'"([^"]*)"', query_block))
                line = content[:m.start()].count('\n') + 1

                fn_m = re.search(r'\bfrom\s+(?:\w+\.)?(\w+)\s*\(', query_text, re.IGNORECASE)
                if fn_m:
                    fn_name = fn_m.group(1)
                    self.emitter.emit_entity(
                        layer="db", entity_type="function", repo=repo_id,
                        qualifier=f"pg:{fn_name}", name=fn_name,
                        file=rel_path, line=line, confidence=0.85,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line, evidence_snippet=query_text[:200],
                        properties={"db_type": "postgres"},
                    )
                    entities += 1
                else:
                    # Direct table references
                    for tm in re.finditer(r'\b(?:FROM|JOIN)\s+(?:"?(\w+)"?\."?(\w+)"?|"?([a-z_]\w*)"?)', query_text, re.IGNORECASE):
                        if tm.group(1) and tm.group(2):
                            tbl = f"{tm.group(1)}.{tm.group(2)}"
                        elif tm.group(3):
                            tbl = tm.group(3)
                        else:
                            continue
                        self.emitter.emit_entity(
                            layer="db", entity_type="table", repo=repo_id,
                            qualifier=tbl, name=tbl,
                            file=rel_path, line=line, confidence=0.80,
                            evidence_file=rel_path, evidence_method="regex",
                            evidence_line_start=line, evidence_snippet=query_text[:200],
                            properties={"db_type": "postgres", "source": "direct_query"},
                        )
                        entities += 1

        # ── DTO classes ──────────────────────────────────────────────────────
        if ftype == 'dto':
            class_m = re.search(r'public\s+class\s+(\w+)', content)
            if class_m:
                line = content[:class_m.start()].count('\n') + 1
                self.emitter.emit_entity(
                    layer="api", entity_type="dto", repo=repo_id,
                    qualifier=f"{fname}::{class_m.group(1)}", name=class_m.group(1),
                    file=rel_path, line=line, confidence=0.90,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    properties={"class_name": class_m.group(1)},
                )
                entities += 1

        # ── Java model/DTO by directory convention (no annotation needed) ────
        if ftype == 'unknown' and entities == 0:
            rel_lower = rel_path.lower()
            is_model_dir = any(seg in rel_lower for seg in ('/dto/', '/model/', '/payload/', '/request/', '/response/', '/domain/'))
            if is_model_dir:
                class_m = re.search(r'public\s+class\s+(\w+)', content)
                if class_m:
                    line = content[:class_m.start()].count('\n') + 1
                    self.emitter.emit_entity(
                        layer="api", entity_type="dto", repo=repo_id,
                        qualifier=f"{fname}::{class_m.group(1)}", name=class_m.group(1),
                        file=rel_path, line=line, confidence=0.80,
                        evidence_file=rel_path, evidence_method="heuristic",
                        evidence_line_start=line,
                        evidence_snippet=class_m.group(0)[:200],
                        properties={"class_name": class_m.group(1), "source": "directory_convention"},
                    )
                    entities += 1

        # ── Java @Configuration / @Bean classes ───────────────────────────
        if ftype in ('config', 'unknown') and entities == 0:
            if re.search(r'@Configuration', content):
                class_m = re.search(r'public\s+class\s+(\w+)', content)
                if class_m:
                    line = content[:class_m.start()].count('\n') + 1
                    bean_names = [m.group(1) for m in re.finditer(r'@Bean[^}]*public\s+\w+(?:<[^>]+>)?\s+(\w+)\s*\(', content)]
                    self.emitter.emit_entity(
                        layer="api", entity_type="config", repo=repo_id,
                        qualifier=f"{fname}::{class_m.group(1)}", name=class_m.group(1),
                        file=rel_path, line=line, confidence=0.90,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line,
                        evidence_snippet=f"@Configuration class {class_m.group(1)}",
                        properties={"class_name": class_m.group(1), "beans": bean_names[:10]},
                    )
                    entities += 1

        # ── Java utility classes ─────────────────────────────────────────
        if ftype == 'util' and entities == 0:
            class_m = re.search(r'public\s+class\s+(\w+)', content)
            if class_m:
                line = content[:class_m.start()].count('\n') + 1
                self.emitter.emit_entity(
                    layer="api", entity_type="util", repo=repo_id,
                    qualifier=f"{fname}::{class_m.group(1)}", name=class_m.group(1),
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="heuristic",
                    evidence_line_start=line,
                    properties={"class_name": class_m.group(1)},
                )
                entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    def _extract_db_from_repo(self, repo_file, repo_method, repo_eid, repo_id):
        """Extract DB function/table from a repository method's @Query."""
        entities = 0
        relations = 0
        content = repo_file["content"]
        rel_path = repo_file["rel_path"]

        pos = content.find(repo_method + '(')
        if pos == -1:
            return entities, relations

        before = content[:pos]
        q_start = before.rfind('@Query')
        if q_start == -1:
            # JPA method -- use entity table
            entity_table = repo_file.get("entity_table")
            if entity_table:
                tbl_id = self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=entity_table, name=entity_table,
                    file=rel_path, line=content[:pos].count('\n') + 1,
                    confidence=0.75,
                    evidence_file=rel_path, evidence_method="inferred",
                    evidence_line_start=content[:pos].count('\n') + 1,
                    properties={"db_type": "postgres", "source": "jpa_entity"},
                )
                entities += 1
                self.emitter.emit_relation(
                    source_id=repo_eid, target_id=tbl_id,
                    relation_type="reads_from", confidence=0.75,
                    evidence_file=rel_path, evidence_method="inferred",
                )
                relations += 1
            return entities, relations

        block = content[q_start:pos]
        query_text = ' '.join(re.findall(r'"([^"]*)"', block))
        line = content[:q_start].count('\n') + 1

        fn_m = re.search(r'\bfrom\s+(?:\w+\.)?(\w+)\s*\(', query_text, re.IGNORECASE)
        if fn_m:
            fn_name = fn_m.group(1)
            fn_id = self.emitter.emit_entity(
                layer="db", entity_type="function", repo=repo_id,
                qualifier=f"pg:{fn_name}", name=fn_name,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=query_text[:200],
                properties={"db_type": "postgres"},
            )
            entities += 1
            self.emitter.emit_relation(
                source_id=repo_eid, target_id=fn_id,
                relation_type="calls_function", confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=query_text[:200],
            )
            relations += 1

        # Detect writes: INSERT/UPDATE/DELETE in @Query
        write_ops = re.findall(r'\b(INSERT\s+INTO|UPDATE|DELETE\s+FROM)\s+(?:"?(\w+)"?\."?(\w+)"?|"?([a-z_]\w*)"?)', query_text, re.IGNORECASE)
        for op_match in write_ops:
            op = op_match[0].strip().upper()
            if op_match[1] and op_match[2]:
                tbl = f"{op_match[1]}.{op_match[2]}"
            elif op_match[3]:
                tbl = op_match[3]
            else:
                continue
            tbl_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=tbl, name=tbl,
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=query_text[:200],
                properties={"db_type": "postgres"},
            )
            entities += 1
            self.emitter.emit_relation(
                source_id=repo_eid, target_id=tbl_id,
                relation_type="writes_to", confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=query_text[:200],
                properties={"operation": op},
            )
            relations += 1

        # Detect uses_table: direct SELECT FROM table (no function call)
        if not fn_m:
            for tm in re.finditer(r'\b(?:FROM|JOIN)\s+(?:"?(\w+)"?\."?(\w+)"?|"?([a-z_]\w*)"?)', query_text, re.IGNORECASE):
                if tm.group(1) and tm.group(2):
                    tbl = f"{tm.group(1)}.{tm.group(2)}"
                elif tm.group(3):
                    tbl = tm.group(3)
                else:
                    continue
                tbl_id = self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=tbl, name=tbl,
                    file=rel_path, line=line, confidence=0.80,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=query_text[:200],
                    properties={"db_type": "postgres"},
                )
                entities += 1
                self.emitter.emit_relation(
                    source_id=repo_eid, target_id=tbl_id,
                    relation_type="uses_table", confidence=0.80,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=query_text[:200],
                )
                relations += 1

        return entities, relations
