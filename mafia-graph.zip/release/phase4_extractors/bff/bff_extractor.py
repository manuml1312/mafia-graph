"""
MAFIA Phase 4+5 — BFF Entity and Relation Extractor
=====================================================
Extracts from TypeScript/JS BFF repos:
  Entities: endpoint, constant, controller, middleware, service
  Relations: routes_to, calls_api, validates_with, calls
"""

import os
import re
import threading
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult
from utils.fuzzy import jaro_winkler


class BffExtractor(BaseExtractor):
    name = "bff_extractor"
    supported_extensions = {'.ts', '.js'}

    def __init__(self):
        super().__init__()
        self._const_lookup = {}   # var_name -> {path, line, repo_id}
        self._endpoint_ids = {}   # var_name -> entity_id (for relation linking)
        self._controller_ids = {} # handler_name -> entity_id
        self._idx_lock = threading.Lock()

    def before_repo(self, repo_id, repo_path, repo_meta):
        self._const_lookup = {}
        self._endpoint_ids = {}
        self._controller_ids = {}

    def after_repo(self, repo_id, repo_path, repo_meta):
        """Emit cross-file relations now that all entities are indexed."""
        # routes_to: endpoint -> controller (via constant_ref matching)
        for handler_name, ctrl_data in self._controller_ids.items():
            ctrl_id = ctrl_data["id"]
            const_ref = ctrl_data.get("constant_ref", "")
            ep_id = self._endpoint_ids.get(const_ref)
            # Fuzzy fallback: try Jaro-Winkler if exact match fails
            if not ep_id and const_ref:
                best_score, best_key = 0.0, None
                for key in self._endpoint_ids:
                    score = jaro_winkler(const_ref.lower(), key.lower())
                    if score > best_score:
                        best_score, best_key = score, key
                if best_score >= 0.85 and best_key:
                    ep_id = self._endpoint_ids[best_key]
            if ep_id:
                conf = 0.95 if const_ref in self._endpoint_ids else 0.70
                self.emitter.emit_relation(
                    source_id=ep_id, target_id=ctrl_id,
                    relation_type="routes_to", confidence=conf,
                    evidence_file=ctrl_data["file"], evidence_method="regex" if conf > 0.70 else "heuristic",
                    evidence_line_start=ctrl_data["line"],
                    evidence_snippet=ctrl_data.get("snippet", ""),
                    properties={"http_method": ctrl_data.get("http_method", "")},
                )

        # calls_api: controller -> downstream API constant
        for handler_name, ctrl_data in self._controller_ids.items():
            ctrl_id = ctrl_data["id"]
            for api_const in ctrl_data.get("api_constants", []):
                api_const_data = self._const_lookup.get(api_const)
                # Fuzzy fallback for API constant lookup
                if not api_const_data and api_const:
                    best_score, best_key = 0.0, None
                    for key in self._const_lookup:
                        score = jaro_winkler(api_const.lower(), key.lower())
                        if score > best_score:
                            best_score, best_key = score, key
                    if best_score >= 0.85 and best_key:
                        api_const_data = self._const_lookup[best_key]
                if api_const_data:
                    conf = 0.85 if api_const in self._const_lookup else 0.70
                    self.emitter.emit_relation(
                        source_id=ctrl_id,
                        target_id=api_const_data["id"],
                        relation_type="calls_api", confidence=conf,
                        evidence_file=ctrl_data["file"], evidence_method="regex" if conf > 0.70 else "heuristic",
                        evidence_line_start=ctrl_data["line"],
                        properties={"constant": api_const, "endpoint_path": api_const_data.get("path", "")},
                    )

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0

        # ── Static constants: static xxx_bff = "/path" ──────────────────────
        for m in re.finditer(r'static\s+(?:readonly\s+)?(\w+)\s*=\s*["\'](/[^"\']+)["\']', content):
            var_name, path_val = m.group(1), m.group(2)
            line = content[:m.start()].count('\n') + 1
            snippet = m.group(0)[:200]

            if '_bff' in var_name.lower():
                eid = self.emitter.emit_entity(
                    layer="bff", entity_type="endpoint", repo=repo_id,
                    qualifier=path_val, name=path_val,
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=snippet,
                    properties={"variable_name": var_name, "endpoint_path": path_val},
                )
                with self._idx_lock:
                    self._endpoint_ids[var_name] = eid
                entities += 1

            elif '_api' in var_name.lower() or '_API' in var_name:
                eid = self.emitter.emit_entity(
                    layer="bff", entity_type="constant", repo=repo_id,
                    qualifier=f"{rel_path}::{var_name}", name=var_name,
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=snippet,
                    properties={"variable_name": var_name, "endpoint_path": path_val, "type": "api_ref"},
                )
                with self._idx_lock:
                    self._const_lookup[var_name] = {"id": eid, "path": path_val, "file": rel_path, "line": line}
                entities += 1

        # ── Dedicated pass: static _API members without readonly/type annotation ──
        # Handles the marvel pattern: static flagTypes_API = "/flag/getFlagTypes";
        _api_member_pat = re.compile(
            r'static\s+(?:readonly\s+)?(\w+_API)\s*=\s*(["\'])(/[^"\']+)\2'
        )
        for m in _api_member_pat.finditer(content):
            var_name, path_val = m.group(1), m.group(3)
            line = content[:m.start()].count('\n') + 1
            if var_name not in self._const_lookup:
                eid = self.emitter.emit_entity(
                    layer="bff", entity_type="constant", repo=repo_id,
                    qualifier=f"{rel_path}::{var_name}", name=var_name,
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                    properties={"variable_name": var_name,
                                "endpoint_path": path_val, "type": "api_ref"},
                )
                with self._idx_lock:
                    self._const_lookup[var_name] = {
                        "id": eid, "path": path_val,
                        "file": rel_path, "line": line,
                    }
                entities += 1

        # ── Route registrations: router.get(Constant.xxx, controller.yyy) ────
        for m in re.finditer(r'router\.(get|post|put|delete|patch)\s*\(\s*\w+\.(\w+)\s*,\s*\w+\.(\w+)', content, re.IGNORECASE):
            http_method = m.group(1).upper()
            const_ref = m.group(2)
            handler = m.group(3)
            line = content[:m.start()].count('\n') + 1
            snippet = m.group(0)[:200]

            eid = self.emitter.emit_entity(
                layer="bff", entity_type="controller", repo=repo_id,
                qualifier=f"{rel_path}::{handler}", name=handler,
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=snippet,
                properties={"http_method": http_method, "constant_ref": const_ref},
            )
            entities += 1

            # Index for after_repo cross-file linking
            with self._idx_lock:
                self._controller_ids[handler] = {
                    "id": eid, "file": rel_path, "line": line,
                    "http_method": http_method, "constant_ref": const_ref,
                    "snippet": snippet, "api_constants": [],
                }

        # ── Plain JS route: .get('/path', ...middlewares, handler) ────────────
        for m in re.finditer(r'\.(get|post|put|delete|patch)\s*\(\s*[\'"]([^\'"]+)[\'"]\s*,\s*(?:[\w.]+\s*,\s*)*(\w+)\s*\)', content, re.IGNORECASE):
            http_method = m.group(1).upper()
            path_val = m.group(2)
            handler = m.group(3)
            line = content[:m.start()].count('\n') + 1
            snippet = m.group(0)[:200]

            ep_id = self.emitter.emit_entity(
                layer="bff", entity_type="endpoint", repo=repo_id,
                qualifier=path_val, name=f"{http_method} {path_val}",
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=snippet,
                properties={"http_method": http_method, "endpoint_path": path_val, "pattern": "js_literal"},
            )
            entities += 1

            ctrl_id = self.emitter.emit_entity(
                layer="bff", entity_type="controller", repo=repo_id,
                qualifier=f"{rel_path}::{handler}", name=handler,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=snippet,
                properties={"http_method": http_method, "pattern": "js_literal"},
            )
            entities += 1

            self.emitter.emit_relation(
                source_id=ep_id, target_id=ctrl_id,
                relation_type="routes_to", confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=snippet,
                properties={"http_method": http_method},
            )
            relations += 1

        # ── Controller method bodies: find downstream API constant refs ──────
        # Pattern 1: TS typed — async xxx(ctx: Context)
        for m in re.finditer(r'async\s+(\w+)\s*\(\s*ctx\s*:\s*Context', content):
            method_name = m.group(1)
            method_line = content[:m.start()].count('\n') + 1

            # Extract method body
            brace_start = content.find('{', m.end())
            if brace_start == -1:
                continue
            depth, i = 1, brace_start + 1
            while i < len(content) and depth > 0:
                if content[i] == '{': depth += 1
                elif content[i] == '}': depth -= 1
                i += 1
            body = content[brace_start:i]

            # Find Constant.xxx_API references directly in this method body
            api_refs = list(dict.fromkeys(re.findall(r'Constant\.(\w+_API)\b', body)))

            # Find this.xxx() internal calls and recurse into their bodies
            internal_calls = []
            for ic in re.finditer(r'this\.(\w+)\s*\(', body):
                internal_calls.append(ic.group(1))
                # Recurse: find Constant._API refs inside the helper method
                hname = ic.group(1)
                hpat = re.compile(
                    r'(?:async\s+)' + re.escape(hname) + r'\s*\([^)]*\)[^{]*\{'
                )
                hm = hpat.search(content)
                if hm:
                    hbrace = content.find('{', hm.end() - 1)
                    if hbrace != -1:
                        hd, hi = 1, hbrace + 1
                        while hi < len(content) and hd > 0:
                            if content[hi] == '{': hd += 1
                            elif content[hi] == '}': hd -= 1
                            hi += 1
                        for ref in re.findall(r'Constant\.(\w+_API)\b', content[hbrace:hi]):
                            if ref not in api_refs:
                                api_refs.append(ref)

            # Update controller index with API constants
            with self._idx_lock:
                if method_name in self._controller_ids:
                    self._controller_ids[method_name]["api_constants"] = api_refs
                else:
                    # Controller found in body but not in route registration
                    eid = self.emitter.emit_entity(
                        layer="bff", entity_type="controller", repo=repo_id,
                        qualifier=f"{rel_path}::{method_name}", name=method_name,
                        file=rel_path, line=method_line, confidence=0.85,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=method_line,
                        evidence_snippet=f"async {method_name}(ctx: Context",
                        properties={"api_constants": api_refs, "internal_calls": internal_calls},
                        warnings=["Controller method found but no route registration matched"],
                    )
                    self._controller_ids[method_name] = {
                        "id": eid, "file": rel_path, "line": method_line,
                        "api_constants": api_refs, "snippet": f"async {method_name}(ctx: Context",
                    }
                    entities += 1

        # Pattern 2: Plain JS — async function xxx(ctx, next)
        for m in re.finditer(r'async\s+function\s+(\w+)\s*\(\s*ctx\s*(?:,|\))', content):
            func_name = m.group(1)
            if func_name in self._controller_ids:
                continue
            line = content[:m.start()].count('\n') + 1
            eid = self.emitter.emit_entity(
                layer="bff", entity_type="controller", repo=repo_id,
                qualifier=f"{rel_path}::{func_name}", name=func_name,
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                properties={"pattern": "js_async_function"},
            )
            with self._idx_lock:
                if func_name not in self._controller_ids:
                    self._controller_ids[func_name] = {
                        "id": eid, "file": rel_path, "line": line,
                        "snippet": m.group(0)[:200], "api_constants": [],
                    }
            entities += 1

        # ── Middleware: exported validation/auth functions ────────────────────
        # Pattern 1: TS export
        for m in re.finditer(r'export\s+(?:async\s+)?function\s+(\w+)\s*\(', content):
            func_name = m.group(1)
            line = content[:m.start()].count('\n') + 1

            if any(kw in func_name.lower() for kw in ('validate', 'middleware', 'auth', 'guard', 'check')):
                self.emitter.emit_entity(
                    layer="bff", entity_type="middleware", repo=repo_id,
                    qualifier=f"{rel_path}::{func_name}", name=func_name,
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                )
                entities += 1

                # Check which endpoints this middleware validates
                # Look for Constant.xxx_bff references in the function body
                brace_start = content.find('{', m.end())
                if brace_start != -1:
                    depth, i = 1, brace_start + 1
                    while i < len(content) and depth > 0:
                        if content[i] == '{': depth += 1
                        elif content[i] == '}': depth -= 1
                        i += 1
                    body = content[brace_start:i]
                    bff_refs = re.findall(r'Constant\.(\w+_bff)\b', body, re.IGNORECASE)
                    if bff_refs:
                        mw_id = f"bff:middleware:{repo_id}:{rel_path}::{func_name}"
                        for bff_ref in bff_refs:
                            ep_id = self._endpoint_ids.get(bff_ref)
                            if ep_id:
                                self.emitter.emit_relation(
                                    source_id=ep_id, target_id=mw_id,
                                    relation_type="validates_with", confidence=0.85,
                                    evidence_file=rel_path, evidence_method="regex",
                                    evidence_line_start=line,
                                    properties={"validates_endpoint_ref": bff_ref},
                                )
                                relations += 1

        # Pattern 2: Plain JS middleware — function with validate/auth/header keywords
        for m in re.finditer(r'(?:async\s+)?function\s+(\w+)\s*\(', content):
            func_name = m.group(1)
            if func_name in self._controller_ids:
                continue
            line = content[:m.start()].count('\n') + 1
            if any(kw in func_name.lower() for kw in ('validate', 'middleware', 'auth', 'guard', 'check', 'header', 'verify')):
                self.emitter.emit_entity(
                    layer="bff", entity_type="middleware", repo=repo_id,
                    qualifier=f"{rel_path}::{func_name}", name=func_name,
                    file=rel_path, line=line, confidence=0.80,
                    evidence_file=rel_path, evidence_method="heuristic",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                    properties={"pattern": "js_function"},
                )
                entities += 1

        # ── BFF service helpers: non-controller exported async functions ──────
        for m in re.finditer(r'(?:export\s+)?(?:const|let|var|function)\s+(\w+)\s*=?\s*(?:async\s*)?\(', content):
            func_name = m.group(1)
            if func_name in self._controller_ids:
                continue
            line = content[:m.start()].count('\n') + 1
            # Only emit if it looks like a service helper (calls API, transforms data)
            after = content[m.start():min(m.start()+2000, len(content))]
            if re.search(r'(?:apiCall|fetch|axios|request|http)', after, re.IGNORECASE):
                self.emitter.emit_entity(
                    layer="bff", entity_type="service", repo=repo_id,
                    qualifier=f"{rel_path}::{func_name}", name=func_name,
                    file=rel_path, line=line, confidence=0.70,
                    evidence_file=rel_path, evidence_method="heuristic",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                    properties={"pattern": "api_call_helper"},
                )
                entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)
