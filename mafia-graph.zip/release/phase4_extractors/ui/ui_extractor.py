"""
MAFIA Phase 4+5 — UI Entity and Relation Extractor
====================================================
Extracts from React/Next.js/TS/JS UI repos:
  Entities: component, hook, selector, fetch_def, route, env_var, module
  Relations: calls, fetches, depends_on_config
"""

import os
import re
import threading
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult, SKIP_DIRS
from utils.fuzzy import jaro_winkler

# ── Compiled patterns ────────────────────────────────────────────────────────
RE_IMPORT_BLOCK   = re.compile(r'import\s*\{([^}]+)\}\s*from\s*[\'"][^\'"]+[\'"]')
RE_EXPORTED_FUNC  = re.compile(r'export\s+(?:default\s+)?(?:const|let|var|function)\s+(\w+)')
RE_FUNC_DEF       = re.compile(r'(?:export\s+)?(?:const|let|var|function)\s+(\w+)\s*=?\s*(?:async\s*)?')
RE_BFF_URL_CONST  = re.compile(r'(?:const|let|var)\s+(\w+)\s*=\s*process\.env\.(\w+)')
RE_SELECTOR_DEF   = re.compile(r'export\s+const\s+(\w+)\s*=\s*(?:selector|selectorFamily)\s*\(')
RE_USE_RECOIL     = re.compile(r'useRecoil\w+\s*\(\s*(\w+)\b')
RE_FETCH_CALL     = re.compile(r'fetch\s*\(\s*(\w+)\b')
RE_METHOD         = re.compile(r"method\s*:\s*['\"](\w+)['\"]")
RE_HOOK_PATTERN   = re.compile(r'(?:export\s+)?(?:const|function)\s+(use[A-Z]\w+)')
RE_COMPONENT_JSX  = re.compile(r'(?:export\s+(?:default\s+)?)?(?:const|function)\s+([A-Z]\w+)\s*[=(]')
RE_REACT_HOOKS    = re.compile(r'(?:useState|useEffect|useContext|useReducer|useRef|useMemo|useCallback)\s*\(')
RE_ENV_LINE       = re.compile(r'^(NEXT_PUBLIC_\w+)\s*=\s*(.+)$', re.IGNORECASE | re.MULTILINE)


class UiExtractor(BaseExtractor):
    name = "ui_extractor"
    supported_extensions = {'.ts', '.tsx', '.js', '.jsx', '.scss', '.css', '.html'}

    def __init__(self):
        super().__init__()
        # Cross-file indexes built during extraction
        self._fetch_defs = {}      # const_name -> {entity_id, path_suffix, env_var, file}
        self._hook_ids = {}        # hook_name -> entity_id
        self._selector_ids = {}    # selector_name -> {entity_id, api_func}
        self._idx_lock = threading.Lock()

    def before_repo(self, repo_id, repo_path, repo_meta):
        self._fetch_defs = {}
        self._hook_ids = {}
        self._selector_ids = {}
        self._all_emitted_ids = []   # track all entity IDs for dead-code detection
        self._repo_id = repo_id

        # Extract .env vars as config entities
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                if fname.startswith('.env'):
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                    try:
                        with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        for m in RE_ENV_LINE.finditer(content):
                            key, value = m.group(1), m.group(2).strip().strip('"').strip("'")
                            line = content[:m.start()].count('\n') + 1
                            self.emitter.emit_entity(
                                layer="config", entity_type="env", repo=repo_id,
                                qualifier=key, name=key,
                                file=rel, line=line, confidence=0.95,
                                evidence_file=rel, evidence_method="regex",
                                evidence_line_start=line,
                                evidence_snippet=m.group(0)[:200],
                                properties={"value": value},
                            )
                    except Exception:
                        pass

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0

        ext = Path(rel_path).suffix.lower()

        # ── CSS/SCSS: emit stylesheet module entity ─────────────────────────
        if ext in ('.scss', '.css'):
            module_name = Path(rel_path).stem
            self.emitter.emit_entity(
                layer="ui", entity_type="module", repo=repo_id,
                qualifier=f"{rel_path}::{module_name}", name=module_name,
                file=rel_path, line=1, confidence=0.90,
                evidence_file=rel_path, evidence_method="heuristic",
                evidence_line_start=1,
                evidence_snippet=f"Stylesheet: {rel_path}",
                properties={"file_type": ext.lstrip('.'), "module_type": "stylesheet"},
            )
            return FileResult(file_path=rel_path, status="ok", entities_emitted=1)

        # ── HTML templates (Flask/Jinja/Django/plain HTML) ───────────────────
        if ext == '.html':
            return self._extract_html_template(rel_path, content, repo_id)

        # ── JS/TS files in templates/ or static/ — treat fetch() as direct http_path ─
        # Plain JS served alongside HTML templates (e.g. approved_collab.js)
        # has fetch('/api/...') calls that should be captured as fetch_def entities.
        _rel_lower = rel_path.lower().replace('\\', '/')
        _in_template_dir = any(seg in _rel_lower.split('/')
                               for seg in ('templates', 'static', 'assets', 'public'))
        if _in_template_dir and ext in ('.js', '.jsx'):
            return self._extract_template_js(rel_path, content, repo_id)

        # ── BFF URL base vars: const xxx = process.env.NEXT_PUBLIC_YYY ───────
        base_vars = {}
        for m in RE_BFF_URL_CONST.finditer(content):
            base_vars[m.group(1)] = m.group(2)

        # ── Endpoint constant definitions: const xxx = baseUrl + "/path" ─────
        # Pattern 1: baseUrl from process.env
        if base_vars:
            for base_var, env_var in base_vars.items():
                pattern = rf'(?:const|let|var)\s+(\w+)\s*=\s*{re.escape(base_var)}\s*\+\s*[\'"]([^\'"]+)[\'"]'
                for m in re.finditer(pattern, content):
                    const_name = m.group(1)
                    path_suffix = m.group(2)
                    line = content[:m.start()].count('\n') + 1

                    eid = self.emitter.emit_entity(
                        layer="ui", entity_type="fetch_def", repo=repo_id,
                        qualifier=f"{rel_path}::{const_name}", name=const_name,
                        file=rel_path, line=line, confidence=0.95,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line,
                        evidence_snippet=m.group(0)[:200],
                        properties={"path_suffix": path_suffix, "env_var": env_var, "base_var": base_var},
                    )
                    entities += 1
                    self._all_emitted_ids.append(eid)

                    with self._idx_lock:
                        self._fetch_defs[const_name] = {
                            "entity_id": eid, "path_suffix": path_suffix,
                            "env_var": env_var, "file": rel_path,
                        }

                    # Relation: fetch_def depends_on_config env_var
                    config_id = f"config:env:{repo_id}:{env_var}"
                    self.emitter.emit_relation(
                        source_id=eid, target_id=config_id,
                        relation_type="depends_on_config", confidence=0.95,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line,
                        evidence_snippet=f"process.env.{env_var}",
                    )
                    relations += 1

        # Pattern 2: const XXX = anyVar + "/path" (broader — catches non-env base vars)
        for m in re.finditer(r'(?:const|let|var|export\s+const)\s+(\w+)\s*=\s*(\w+)\s*\+\s*[\'"](\/[^\'"]+)[\'"]', content):
            const_name = m.group(1)
            base_var = m.group(2)
            path_suffix = m.group(3)
            if const_name in self._fetch_defs:
                continue  # already captured by Pattern 1
            if base_var in base_vars:
                continue  # already captured by Pattern 1
            line = content[:m.start()].count('\n') + 1
            eid = self.emitter.emit_entity(
                layer="ui", entity_type="fetch_def", repo=repo_id,
                qualifier=f"{rel_path}::{const_name}", name=const_name,
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={"path_suffix": path_suffix.lstrip('/'), "base_var": base_var},
            )
            entities += 1
            self._all_emitted_ids.append(eid)
            with self._idx_lock:
                self._fetch_defs[const_name] = {
                    "entity_id": eid, "path_suffix": path_suffix.lstrip('/'),
                    "env_var": "", "file": rel_path,
                }

        # Pattern 3: const XXX = `${baseVar}/path` (template literal)
        for m in re.finditer(r'(?:const|let|var|export\s+const)\s+(\w+)\s*=\s*`\$\{(\w+)\}(\/[^`]+)`', content):
            const_name = m.group(1)
            base_var = m.group(2)
            path_suffix = m.group(3)
            if const_name in self._fetch_defs:
                continue
            line = content[:m.start()].count('\n') + 1
            eid = self.emitter.emit_entity(
                layer="ui", entity_type="fetch_def", repo=repo_id,
                qualifier=f"{rel_path}::{const_name}", name=const_name,
                file=rel_path, line=line, confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={"path_suffix": path_suffix.lstrip('/'), "base_var": base_var},
            )
            entities += 1
            self._all_emitted_ids.append(eid)
            with self._idx_lock:
                self._fetch_defs[const_name] = {
                    "entity_id": eid, "path_suffix": path_suffix.lstrip('/'),
                    "env_var": "", "file": rel_path,
                }

        # ── fetch() calls inside functions ───────────────────────────────────
        for m in RE_FETCH_CALL.finditer(content):
            const_name = m.group(1)
            line = content[:m.start()].count('\n') + 1
            enclosing = self._find_enclosing_function(content, m.start())

            ctx = content[m.start():m.start() + 500]
            method_m = RE_METHOD.search(ctx)
            http_method = method_m.group(1).upper() if method_m else "GET"

            if enclosing:
                # The enclosing function is a fetch wrapper — emit as fetch_def if not already
                func_eid = self.emitter.emit_entity(
                    layer="ui", entity_type="fetch_def", repo=repo_id,
                    qualifier=f"{rel_path}::{enclosing}", name=enclosing,
                    file=rel_path, line=line, confidence=0.90,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    evidence_snippet=m.group(0)[:200],
                    properties={"http_method": http_method, "fetches_constant": const_name},
                )
                entities += 1

        # ── Recoil selectors ─────────────────────────────────────────────────
        for m in RE_SELECTOR_DEF.finditer(content):
            sel_name = m.group(1)
            line = content[:m.start()].count('\n') + 1

            eid = self.emitter.emit_entity(
                layer="ui", entity_type="selector", repo=repo_id,
                qualifier=f"{rel_path}::{sel_name}", name=sel_name,
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
            )
            entities += 1
            self._all_emitted_ids.append(eid)
            with self._idx_lock:
                self._selector_ids[sel_name] = {"entity_id": eid}

        # ── Custom hooks: useXxx ─────────────────────────────────────────────
        for m in RE_HOOK_PATTERN.finditer(content):
            hook_name = m.group(1)
            line = content[:m.start()].count('\n') + 1

            eid = self.emitter.emit_entity(
                layer="ui", entity_type="hook", repo=repo_id,
                qualifier=f"{rel_path}::{hook_name}", name=hook_name,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
            )
            entities += 1
            self._all_emitted_ids.append(eid)
            with self._idx_lock:
                self._hook_ids[hook_name] = eid

        # ── React components: PascalCase exports with JSX ────────────────────
        for m in RE_COMPONENT_JSX.finditer(content):
            comp_name = m.group(1)
            # Verify it's actually a component (has JSX return or uses hooks)
            after = content[m.start():min(m.start() + 3000, len(content))]
            if not (RE_REACT_HOOKS.search(after) or re.search(r'return\s*\(?\s*<', after)):
                continue

            line = content[:m.start()].count('\n') + 1
            comp_eid = self.emitter.emit_entity(
                layer="ui", entity_type="component", repo=repo_id,
                qualifier=f"{rel_path}::{comp_name}", name=comp_name,
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="heuristic",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={"file": rel_path},
            )
            entities += 1
            self._all_emitted_ids.append(comp_eid)

            # Detect hook calls inside this component
            for hm in re.finditer(r'(use[A-Z]\w+)\s*\(', after):
                hook_call = hm.group(1)
                call_line = line + after[:hm.start()].count('\n')
                hook_target = self._hook_ids.get(hook_call)
                if hook_target:
                    comp_id = f"ui:component:{repo_id}:{rel_path}::{comp_name}"
                    self.emitter.emit_relation(
                        source_id=comp_id, target_id=hook_target,
                        relation_type="calls", confidence=0.85,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=call_line,
                        evidence_snippet=hm.group(0)[:200],
                    )
                    relations += 1

        # ── useRecoilValue(selectorName) calls ───────────────────────────────
        for m in RE_USE_RECOIL.finditer(content):
            sel_name = m.group(1)
            line = content[:m.start()].count('\n') + 1
            enclosing = self._find_enclosing_function(content, m.start())

            sel_data = self._selector_ids.get(sel_name)
            if sel_data and enclosing:
                # The enclosing function uses this selector
                caller_id = self._hook_ids.get(enclosing)
                if caller_id:
                    self.emitter.emit_relation(
                        source_id=caller_id, target_id=sel_data["entity_id"],
                        relation_type="calls", confidence=0.85,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line,
                        evidence_snippet=m.group(0)[:200],
                    )
                    relations += 1

        # ── Page routes (Next.js convention: pages/xxx.tsx -> /xxx) ───────────
        if '/pages/' in rel_path and not rel_path.endswith('_app.tsx') and not rel_path.endswith('_document.tsx'):
            # Convert file path to route
            route = rel_path.split('/pages/')[-1]
            route = '/' + route.rsplit('.', 1)[0]  # remove extension
            route = route.replace('/index', '').replace('[', ':').replace(']', '')
            if not route:
                route = '/'

            self.emitter.emit_entity(
                layer="ui", entity_type="route", repo=repo_id,
                qualifier=route, name=route,
                file=rel_path, line=1, confidence=0.90,
                evidence_file=rel_path, evidence_method="heuristic",
                evidence_line_start=1,
                evidence_snippet=f"pages/ convention: {rel_path}",
                properties={"page_file": rel_path},
            )
            entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    def after_repo(self, repo_id, repo_path, repo_meta):
        """Post-extraction: connect components to fetch_defs + dead-code detection."""
        # ── Component → fetch_def call tracing (Fix 2) ───────────────────────
        # Strategy: if a component imports from a file that contains fetch_defs,
        # connect the component to those fetch_defs. Also match by direct name call.
        if self._fetch_defs:
            # Build file → fetch_def index
            file_to_fds = {}
            for fd_name, fd_data in self._fetch_defs.items():
                fd_file = fd_data.get("file", "")
                if fd_file:
                    file_to_fds.setdefault(fd_file, []).append((fd_name, fd_data))

            comp_entities = [
                (eid, self.emitter._entities[eid])
                for eid in self._all_emitted_ids
                if eid in self.emitter._entities and self.emitter._entities[eid].get("type") == "component"
            ]
            for comp_id, comp in comp_entities:
                comp_file = comp.get("file", "")
                if not comp_file:
                    continue
                full_path = os.path.join(repo_path, comp_file)
                try:
                    with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except Exception:
                    continue

                connected_fds = set()

                # Method 1: direct name match — component calls fd_name()
                for fd_name, fd_data in self._fetch_defs.items():
                    if fd_name in connected_fds:
                        continue
                    if re.search(rf'\b{re.escape(fd_name)}\s*\(', content):
                        self.emitter.emit_relation(
                            source_id=comp_id, target_id=fd_data["entity_id"],
                            relation_type="calls", confidence=0.80,
                            evidence_file=comp_file, evidence_method="heuristic",
                            evidence_line_start=comp.get("line"),
                            evidence_snippet=f"{comp.get('name','')} calls {fd_name}()",
                        )
                        connected_fds.add(fd_name)

                # Method 2: import-path match — component imports from a file
                # that contains fetch_defs (exact stem match + fuzzy fallback)
                for m in re.finditer(r'import\s*\{[^}]+\}\s*from\s*[\'"]([^\'"]+)[\'"]', content):
                    import_path = m.group(1)
                    for fd_file, fds in file_to_fds.items():
                        fd_stem = Path(fd_file).stem
                        # Exact stem match
                        matched = fd_stem and fd_stem in import_path
                        # Fuzzy fallback on import path's last segment
                        if not matched and fd_stem:
                            import_stem = import_path.rsplit('/', 1)[-1].replace('.ts', '').replace('.js', '')
                            if jaro_winkler(fd_stem.lower(), import_stem.lower()) >= 0.85:
                                matched = True
                        if matched:
                            for fd_name, fd_data in fds:
                                if fd_name in connected_fds:
                                    continue
                                conf = 0.70 if fd_stem not in import_path else 0.70
                                self.emitter.emit_relation(
                                    source_id=comp_id, target_id=fd_data["entity_id"],
                                    relation_type="calls", confidence=conf,
                                    evidence_file=comp_file, evidence_method="heuristic",
                                    evidence_line_start=comp.get("line"),
                                    evidence_snippet=f"{comp.get('name','')} imports from {fd_stem}",
                                    properties={"match_method": "import_path", "import_source": import_path},
                                )
                                connected_fds.add(fd_name)

        # ── Dead-code detection ───────────────────────────────────────────
        targets = set()
        for rid, rel in self.emitter._relations.items():
            targets.add(rel.get("target", ""))

        for eid in self._all_emitted_ids:
            entity = self.emitter._entities.get(eid)
            if not entity:
                continue
            etype = entity.get("type", "")
            if etype not in ("component", "hook", "selector", "fetch_def"):
                continue
            if eid not in targets:
                existing_warnings = entity.get("warnings", [])
                existing_warnings.append("dead_code_candidate: no inbound relations detected")
                entity["warnings"] = existing_warnings

    def _extract_html_template(self, rel_path, content, repo_id):
        """Extract UI entities from HTML templates (Flask/Jinja/Django)."""
        entities = 0
        relations = 0
        template_name = Path(rel_path).stem

        tpl_id = self.emitter.emit_entity(
            layer="ui", entity_type="component", repo=repo_id,
            qualifier=f"{rel_path}::{template_name}", name=template_name,
            file=rel_path, line=1, confidence=0.88,
            evidence_file=rel_path, evidence_method="heuristic",
            evidence_line_start=1,
            evidence_snippet=f"HTML template: {rel_path}",
            properties={
                "template_engine": "jinja2" if ('{%' in content or '{{' in content) else "html",
                "file": rel_path,
            },
        )
        entities += 1
        self._all_emitted_ids.append(tpl_id)

        # Jinja2 extends/include
        for m in re.finditer(r"{%-?\s*(?:extends|include)\s+['\"]([^'\"]+)['\"]\s*-?%}", content):
            parent_name = m.group(1)
            line = content[:m.start()].count('\n') + 1
            parent_id = self.emitter.emit_entity(
                layer="ui", entity_type="component", repo=repo_id,
                qualifier=f"templates/{parent_name}::{Path(parent_name).stem}",
                name=Path(parent_name).stem,
                file=f"templates/{parent_name}", line=1, confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                properties={"template_engine": "jinja2"},
            )
            entities += 1
            rel_type = "calls" if "include" in m.group(0) else "delegates_to"
            self.emitter.emit_relation(
                source_id=tpl_id, target_id=parent_id,
                relation_type=rel_type, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
            )
            relations += 1

        # fetch('/api/...') calls in inline JS
        for m in re.finditer(r"fetch\s*\(['\"]([^'\"]+)['\"]", content):
            api_path = m.group(1)
            line = content[:m.start()].count('\n') + 1
            fetch_id = self.emitter.emit_entity(
                layer="ui", entity_type="fetch_def", repo=repo_id,
                qualifier=f"{rel_path}::fetch::{api_path}",
                name=f"fetch:{api_path}",
                file=rel_path, line=line, confidence=0.82,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:100],
                properties={"http_path": api_path},
            )
            entities += 1
            self.emitter.emit_relation(
                source_id=tpl_id, target_id=fetch_id,
                relation_type="fetches", confidence=0.82,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
            )
            relations += 1

        # url_for('route_fn') — links template to Flask route
        # Use arch_profile route_to_function_map to find existing endpoint entity
        # instead of creating a duplicate. Falls back to emitting a stub.
        from phase2_repo_intake.arch_detector import load_arch_profile as _lap
        _arch = _lap(self.emitter.extractor_name.replace('ui_extractor', '') or '.')
        _route_map = _arch.get('extraction_hints', {}).get('route_to_function_map', {})

        for m in re.finditer(r"url_for\s*\(['\"]([^'\"]+)['\"]", content):
            route_fn = m.group(1)
            line = content[:m.start()].count('\n') + 1
            # Try to find existing endpoint entity by function name
            # (avoids creating duplicate entities for the same Flask route)
            existing_ep_id = None
            for _ep in [e for e in (self.emitter._entities or {}).values()
                        if e.get('layer') == 'api' and e.get('type') == 'endpoint'
                        and e.get('name', '').lower() == route_fn.lower()]:
                existing_ep_id = _ep['id']
                break
            if existing_ep_id:
                route_id = existing_ep_id
                conf = 0.90
            else:
                route_id = self.emitter.emit_entity(
                    layer="api", entity_type="endpoint", repo=repo_id,
                    qualifier=f"flask:{route_fn}", name=route_fn,
                    file=rel_path, line=line, confidence=0.78,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    evidence_snippet=m.group(0)[:100],
                    properties={"framework": "flask", "source": "url_for"},
                )
                entities += 1
                conf = 0.78
            self.emitter.emit_relation(
                source_id=tpl_id, target_id=route_id,
                relation_type="fetches", confidence=conf,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
            )
            relations += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    def _extract_template_js(self, rel_path, content, repo_id):
        """Extract fetch_def entities from plain JS files in templates/static dirs.
        These files use fetch('/api/literal') directly, not process.env base vars."""
        entities = 0
        relations = 0
        file_stem = Path(rel_path).stem

        # Emit the JS file itself as a UI component
        js_id = self.emitter.emit_entity(
            layer="ui", entity_type="component", repo=repo_id,
            qualifier=f"{rel_path}::{file_stem}", name=file_stem,
            file=rel_path, line=1, confidence=0.82,
            evidence_file=rel_path, evidence_method="heuristic",
            evidence_line_start=1,
            evidence_snippet=f"Template JS: {rel_path}",
            properties={"file_type": "template_js", "file": rel_path},
        )
        entities += 1
        self._all_emitted_ids.append(js_id)

        # fetch('/api/path') or fetch(`/api/path`)
        for m in re.finditer(r'fetch\s*\(\s*[\'"`]([^\'"` \t\n]+)[\'"`]', content):
            api_path = m.group(1)
            if any(api_path.startswith(p) for p in ('/static', '/favicon', '/health', '/_')):
                continue
            line = content[:m.start()].count('\n') + 1
            fetch_id = self.emitter.emit_entity(
                layer="ui", entity_type="fetch_def", repo=repo_id,
                qualifier=f"{rel_path}::fetch::{api_path}",
                name=f"fetch:{api_path}",
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:100],
                properties={"http_path": api_path},
            )
            entities += 1
            self._all_emitted_ids.append(fetch_id)
            self.emitter.emit_relation(
                source_id=js_id, target_id=fetch_id,
                relation_type="fetches", confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
            )
            relations += 1

        # axios.get/post('/api/path')
        for m in re.finditer(
            r'axios\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*[\'"`]([^\'"` \t\n]+)[\'"`]',
            content
        ):
            api_path = m.group(1)
            line = content[:m.start()].count('\n') + 1
            fetch_id = self.emitter.emit_entity(
                layer="ui", entity_type="fetch_def", repo=repo_id,
                qualifier=f"{rel_path}::axios::{api_path}",
                name=f"axios:{api_path}",
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:100],
                properties={"http_path": api_path},
            )
            entities += 1
            self._all_emitted_ids.append(fetch_id)
            self.emitter.emit_relation(
                source_id=js_id, target_id=fetch_id,
                relation_type="fetches", confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
            )
            relations += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    def _find_enclosing_function(self, content, char_pos):
        before = content[:char_pos]
        candidates = [(m.start(), m.end(), m.group(1)) for m in RE_FUNC_DEF.finditer(before)]
        for _, end, name in reversed(candidates):
            brace_start = content.find('{', end)
            if brace_start == -1 or brace_start > char_pos:
                continue
            depth = 0
            for i in range(brace_start, min(char_pos + 1, len(content))):
                if content[i] == '{':
                    depth += 1
                elif content[i] == '}':
                    depth -= 1
                    if depth == 0:
                        break
            if depth > 0:
                return name
        return None
