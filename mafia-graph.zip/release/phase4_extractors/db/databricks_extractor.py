"""
MAFIA Phase 4+5 — Databricks / Spark Data Extractor
=====================================================
Extracts from Python/notebook files that use Spark/Databricks:
  Entities: db.table (databricks), db.function, db.schema
  Relations: reads_from, writes_to
Detects: pyspark imports, spark.sql(), spark.read.table(), spark.table(),
         databricks notebook %sql cells, delta table references
"""

import re
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult


class DatabricksExtractor(BaseExtractor):
    name = "databricks_extractor"
    supported_extensions = {'.py', '.ipynb', '.sql'}

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0

        ext = Path(rel_path).suffix.lower()

        # For .ipynb, extract code cells
        if ext == '.ipynb':
            content = self._extract_notebook_code(content)

        # Only process if file has spark/databricks indicators
        if not re.search(r'(?:pyspark|databricks|spark\.|SparkSession|delta)', content, re.IGNORECASE):
            if ext != '.sql':
                return FileResult(file_path=rel_path, status="no_entities")

        # Build a file-level context entity for relation sourcing
        file_ctx_id = self._emit_file_context(rel_path, content, repo_id)

        # ── spark.sql("SELECT ... FROM table") ──────────────────────────────
        for m in re.finditer(r'spark\s*\.\s*sql\s*\(\s*(?:f?["\']|""")(.*?)(?:["\']|""")\s*\)', content, re.DOTALL):
            sql_text = m.group(1)
            line = content[:m.start()].count('\n') + 1
            is_write = bool(re.search(r'\b(?:INSERT|UPDATE|DELETE|MERGE|CREATE)\b', sql_text, re.IGNORECASE))
            tables = self._extract_tables_from_sql(sql_text)
            for tbl in tables:
                tbl_id = self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=f"databricks:{tbl}", name=tbl,
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    evidence_snippet=sql_text[:200],
                    properties={"db_type": "databricks", "source": "spark.sql"},
                )
                entities += 1
                src = self._find_enclosing_function_id(content, m.start(), rel_path, repo_id) or file_ctx_id
                if src:
                    rtype = "writes_to" if is_write else "reads_from"
                    self.emitter.emit_relation(
                        source_id=src, target_id=tbl_id,
                        relation_type=rtype, confidence=0.80,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line,
                        evidence_snippet=sql_text[:200],
                    )
                    relations += 1

        # ── spark.read.table("xxx") / spark.table("xxx") ────────────────────
        for m in re.finditer(r'spark\s*\.\s*(?:read\s*\.\s*)?table\s*\(\s*["\']([^"\']+)["\']', content):
            tbl_name = m.group(1)
            line = content[:m.start()].count('\n') + 1
            tbl_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=f"databricks:{tbl_name}", name=tbl_name,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={"db_type": "databricks", "source": "spark.table"},
            )
            entities += 1
            src = self._find_enclosing_function_id(content, m.start(), rel_path, repo_id) or file_ctx_id
            if src:
                self.emitter.emit_relation(
                    source_id=src, target_id=tbl_id,
                    relation_type="reads_from", confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    evidence_snippet=m.group(0)[:200],
                )
                relations += 1

        # ── spark.read.format("delta").load("path") ─────────────────────────
        for m in re.finditer(r'\.format\s*\(\s*["\']delta["\']\s*\)\s*\.load\s*\(\s*["\']([^"\']+)["\']', content):
            delta_path = m.group(1)
            line = content[:m.start()].count('\n') + 1
            self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=f"databricks:delta:{delta_path}", name=f"delta:{delta_path}",
                file=rel_path, line=line, confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={"db_type": "databricks", "format": "delta", "path": delta_path},
            )
            entities += 1

        # ── .write.saveAsTable("xxx") / .write.insertInto("xxx") ────────────
        for m in re.finditer(r'\.\s*(?:saveAsTable|insertInto)\s*\(\s*["\']([^"\']+)["\']', content):
            tbl_name = m.group(1)
            line = content[:m.start()].count('\n') + 1
            tbl_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=f"databricks:{tbl_name}", name=tbl_name,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={"db_type": "databricks", "access": "write"},
            )
            entities += 1
            src = self._find_enclosing_function_id(content, m.start(), rel_path, repo_id) or file_ctx_id
            if src:
                self.emitter.emit_relation(
                    source_id=src, target_id=tbl_id,
                    relation_type="writes_to", confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    evidence_snippet=m.group(0)[:200],
                )
                relations += 1

        # ── Unity Catalog 3-part references: catalog.schema.table ─────────
        for m in re.finditer(
            r'(?:spark\.sql|spark\.table|spark\.read\.table)\s*\(\s*["\']'
            r'(\w+)\.(\w+)\.(\w+)["\']',
            content
        ):
            catalog, schema, table = m.group(1), m.group(2), m.group(3)
            full_ref = f"{catalog}.{schema}.{table}"
            line = content[:m.start()].count('\n') + 1
            self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=f"databricks:{full_ref}", name=full_ref,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={
                    "db_type": "databricks", "source": "unity_catalog",
                    "catalog": catalog, "schema": schema, "table": table,
                },
            )
            entities += 1

        # ── Unity Catalog SQL references in string literals ──────────────────
        for m in re.finditer(
            r'\b(?:FROM|JOIN|INTO|TABLE)\s+`?(\w+)`?\.`?(\w+)`?\.`?(\w+)`?',
            content, re.IGNORECASE
        ):
            catalog, schema, table = m.group(1), m.group(2), m.group(3)
            if catalog.lower() in ('select', 'where', 'set', 'values', 'as'):
                continue
            full_ref = f"{catalog}.{schema}.{table}"
            line = content[:m.start()].count('\n') + 1
            self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=f"databricks:{full_ref}", name=full_ref,
                file=rel_path, line=line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:200],
                properties={
                    "db_type": "databricks", "source": "unity_catalog_sql",
                    "catalog": catalog, "schema": schema, "table": table,
                },
            )
            entities += 1

        # ── Raw SQL files ────────────────────────────────────────────────────
        if ext == '.sql':
            tables = self._extract_tables_from_sql(content)
            for tbl in tables:
                line = 1
                self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=f"databricks:{tbl}", name=tbl,
                    file=rel_path, line=line, confidence=0.80,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    evidence_snippet=content[:200],
                    properties={"db_type": "sql_file"},
                )
                entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    def _emit_file_context(self, rel_path, content, repo_id):
        """Emit a db.function entity for the file-level context (notebook/script)."""
        # Use the filename as the function name for notebooks/scripts
        name = Path(rel_path).stem
        return self.emitter.emit_entity(
            layer="db", entity_type="function", repo=repo_id,
            qualifier=f"databricks:{rel_path}::{name}", name=f"databricks:{name}",
            file=rel_path, line=1, confidence=0.80,
            evidence_file=rel_path, evidence_method="heuristic",
            evidence_line_start=1,
            evidence_snippet=f"Databricks script/notebook: {rel_path}",
            properties={"db_type": "databricks", "source": "file_context"},
        )

    def _find_enclosing_function_id(self, content, char_pos, rel_path, repo_id):
        """Find the enclosing Python def and return its entity ID if emittable."""
        before = content[:char_pos]
        # Find last 'def xxx(' before this position
        for m in reversed(list(re.finditer(r'def\s+(\w+)\s*\(', before))):
            fn_name = m.group(1)
            # Verify we're inside this function (simple indent check)
            fn_line = before[:m.start()].count('\n') + 1
            current_line = before.count('\n') + 1
            if current_line - fn_line < 200:  # reasonable function length
                return self.emitter.emit_entity(
                    layer="db", entity_type="function", repo=repo_id,
                    qualifier=f"databricks:{rel_path}::{fn_name}", name=fn_name,
                    file=rel_path, line=fn_line, confidence=0.80,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=fn_line,
                    evidence_snippet=m.group(0)[:200],
                    properties={"db_type": "databricks", "source": "python_function"},
                )
        return None

    def _extract_tables_from_sql(self, sql_text):
        """Extract table names from SQL text (FROM/JOIN/INTO clauses)."""
        tables = []
        seen = set()
        for m in re.finditer(
            r'\b(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+(?:`?(\w+)`?\.`?(\w+)`?\.`?(\w+)`?|`?(\w+)`?\.`?(\w+)`?|`?([a-z_]\w*)`?)',
            sql_text, re.IGNORECASE
        ):
            if m.group(1) and m.group(2) and m.group(3):
                tbl = f"{m.group(1)}.{m.group(2)}.{m.group(3)}"
            elif m.group(4) and m.group(5):
                tbl = f"{m.group(4)}.{m.group(5)}"
            elif m.group(6):
                tbl = m.group(6)
            else:
                continue
            if tbl.lower() not in seen and tbl.lower() not in ('select', 'where', 'set', 'values', 'as', 'on', 'and', 'or'):
                seen.add(tbl.lower())
                tables.append(tbl)
        return tables

    def _extract_notebook_code(self, content):
        """Extract code from Jupyter notebook JSON."""
        try:
            import json
            nb = json.loads(content)
            cells = nb.get("cells", [])
            code_parts = []
            for cell in cells:
                if cell.get("cell_type") == "code":
                    source = cell.get("source", [])
                    if isinstance(source, list):
                        code_parts.append("".join(source))
                    else:
                        code_parts.append(str(source))
            return "\n".join(code_parts)
        except Exception:
            return content
