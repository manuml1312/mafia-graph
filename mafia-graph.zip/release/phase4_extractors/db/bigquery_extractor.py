"""
MAFIA Phase 4 — BigQuery Python Extractor
==========================================
Extracts DB-layer entities and API→DB relations from Python files that use
google.cloud.bigquery:

  Entities:
    db.table    — BigQuery tables referenced in DDL strings or query strings
    db.service  — BigQueryService class methods (insert, query, update, etc.)
    db.query    — bq_client.query() / client.query() call sites

  Relations:
    api→db  calls_function  — Flask route → BigQueryService method
    api→db  uses_table      — Flask route → BigQuery table
    db→db   calls_function  — BigQueryService method → table

Registered for classification "api", "shared", "*" in the dispatcher.
"""

import re
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult


# ── Patterns ─────────────────────────────────────────────────────────────────

# BigQuery table references in f-strings / DDL strings
# Matches: `project.dataset.table` or `dataset.table`
RE_BQ_TABLE = re.compile(
    r'[`\'"](?:[\w-]+\.)?(\w+)\.(\w+)[`\'"]',
    re.IGNORECASE,
)

# BigQueryService class definition
RE_CLASS_DEF = re.compile(r'^class\s+(\w+)\s*[\(:]', re.MULTILINE)

# Method definitions inside a class
RE_METHOD_DEF = re.compile(r'^\s{4}def\s+(\w+)\s*\(self', re.MULTILINE)

# bq_client.query() / self.client.query() / client.query()
RE_CLIENT_QUERY = re.compile(
    r'(?:self\.client|bq_client|bq\.client|client)\s*\.\s*(?:query|insert_rows_json|insert_rows|list_tables|get_table|create_table|delete_table|create_dataset)\s*\(',
    re.IGNORECASE,
)

# _get_bq_service() call — marks API→DB bridge
RE_GET_BQ_SERVICE = re.compile(r'_get_bq_service\s*\(\s*\)', re.IGNORECASE)

# bq.method() or bq_service.method() calls
RE_BQ_METHOD_CALL = re.compile(
    r'\bbq\s*\.\s*(\w+)\s*\(|bq_service\s*\.\s*(\w+)\s*\(',
    re.IGNORECASE,
)

# Flask route decorator
RE_FLASK_ROUTE = re.compile(
    r'@app\.route\s*\(\s*[\'"]([^\'"]+)[\'"].*?\)\s*\n(?:@\w+[^\n]*\n)*\s*(?:async\s+)?def\s+(\w+)\s*\(',
    re.DOTALL,
)

# BigQueryService instantiation: BigQueryService(...)
RE_BQ_SERVICE_INIT = re.compile(r'BigQueryService\s*\(')

# dataset_id / table_id string assignments
RE_DATASET_TABLE_ASSIGN = re.compile(
    r'(?:BIGQUERY_DATASET_ID|BIGQUERY_TABLE_ID|dataset_id|table_id)\s*=\s*[\'"](\w+)[\'"]'
)

# Known BigQueryService method names that represent DB operations
BQ_DB_METHODS = {
    'get_all_dtas', 'get_dta_by_id', 'get_dtas_by_status',
    'insert_dta_record', 'update_dta', 'update_dta_status',
    'add_comment', 'create_schema_if_not_exists', 'create_flags_table',
    'create_flag_replies_table', 'create_docx_summary_table',
    'insert_docx_summary', 'get_docx_summary', 'delete_bigquery_resources',
    'get_all_users', 'get_user_by_username',
}


class BigQueryExtractor(BaseExtractor):
    name = "bigquery_extractor"
    supported_extensions = {'.py'}

    def before_repo(self, repo_id, repo_path, repo_meta):
        self._bq_service_methods = {}   # method_name → entity_id
        self._bq_tables = {}            # table_name → entity_id
        self._dataset_ids = set()
        self._table_ids = set()

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        # Only process files that actually use BigQuery
        if not self._is_bq_file(content):
            return FileResult(file_path=rel_path, status="no_entities",
                              entities_emitted=0, relations_emitted=0)

        entities = 0
        relations = 0

        # ── Collect dataset/table name constants ─────────────────────────────
        for m in RE_DATASET_TABLE_ASSIGN.finditer(content):
            name = m.group(1)
            if 'DATASET' in content[max(0, m.start()-5):m.start()+50].upper():
                self._dataset_ids.add(name)
            else:
                self._table_ids.add(name)

        # ── BigQueryService class methods → db.service entities ──────────────
        for cls_m in RE_CLASS_DEF.finditer(content):
            cls_name = cls_m.group(1)
            if 'bigquery' not in cls_name.lower() and 'bq' not in cls_name.lower():
                continue

            cls_line = content[:cls_m.start()].count('\n') + 1
            cls_id = self.emitter.emit_entity(
                layer='db', entity_type='service', repo=repo_id,
                qualifier=cls_name, name=cls_name,
                file=rel_path, line=cls_line, confidence=0.92,
                evidence_file=rel_path, evidence_method='ast',
                evidence_line_start=cls_line,
                evidence_snippet=cls_m.group(0)[:100],
                properties={'db_type': 'bigquery', 'source': 'class_definition'},
            )
            entities += 1

            # Extract methods of this class
            # Find the class body (from class def to next class def or EOF)
            next_cls = RE_CLASS_DEF.search(content, cls_m.end())
            cls_body_end = next_cls.start() if next_cls else len(content)
            cls_body = content[cls_m.end():cls_body_end]

            for meth_m in RE_METHOD_DEF.finditer(cls_body):
                meth_name = meth_m.group(1)
                if meth_name.startswith('_') and meth_name not in ('__init__',):
                    continue  # skip private helpers
                meth_line = content[:cls_m.end()].count('\n') + cls_body[:meth_m.start()].count('\n') + 1

                meth_id = self.emitter.emit_entity(
                    layer='db', entity_type='function', repo=repo_id,
                    qualifier=f'{cls_name}.{meth_name}', name=f'{cls_name}.{meth_name}',
                    file=rel_path, line=meth_line, confidence=0.90,
                    evidence_file=rel_path, evidence_method='ast',
                    evidence_line_start=meth_line,
                    properties={'db_type': 'bigquery', 'class': cls_name},
                )
                entities += 1
                self._bq_service_methods[meth_name] = meth_id

                # Relation: class → method
                self.emitter.emit_relation(
                    source_id=cls_id, target_id=meth_id,
                    relation_type='delegates_to', confidence=0.90,
                    evidence_file=rel_path, evidence_method='ast',
                    evidence_line_start=meth_line,
                )
                relations += 1

        # ── BigQuery table references in DDL strings ──────────────────────────
        for m in RE_BQ_TABLE.finditer(content):
            dataset = m.group(1)
            table = m.group(2)
            # Skip if it looks like a Python import or variable
            if table.lower() in {'self', 'none', 'true', 'false', 'str', 'int', 'dict', 'list'}:
                continue
            full_name = f'{dataset}.{table}'
            line = content[:m.start()].count('\n') + 1

            tbl_id = self.emitter.emit_entity(
                layer='db', entity_type='table', repo=repo_id,
                qualifier=full_name, name=full_name,
                file=rel_path, line=line, confidence=0.88,
                evidence_file=rel_path, evidence_method='regex',
                evidence_line_start=line,
                evidence_snippet=m.group(0)[:100],
                properties={'db_type': 'bigquery', 'dataset': dataset, 'table': table},
            )
            entities += 1
            self._bq_tables[full_name] = tbl_id

        # ── Flask routes that call BigQuery → api→db relations ────────────────
        for route_m in RE_FLASK_ROUTE.finditer(content):
            route_path = route_m.group(1)
            fn_name = route_m.group(2)
            route_line = content[:route_m.start()].count('\n') + 1

            # Find the function body
            fn_start = content.find('def ' + fn_name, route_m.start())
            if fn_start < 0:
                continue
            fn_body_start = content.find(':', fn_start) + 1
            # Find end of function (next def at same indent level or EOF)
            next_def = re.search(r'\n(?:@app\.|def |class )', content[fn_body_start:])
            fn_body_end = fn_body_start + next_def.start() if next_def else len(content)
            fn_body = content[fn_body_start:fn_body_end]

            # Emit the Flask route as api.endpoint
            route_id = self.emitter.emit_entity(
                layer='api', entity_type='endpoint', repo=repo_id,
                qualifier=f'flask:{route_path}', name=fn_name,
                file=rel_path, line=route_line, confidence=0.95,
                evidence_file=rel_path, evidence_method='regex',
                evidence_line_start=route_line,
                evidence_snippet=route_m.group(0)[:150],
                properties={'http_path': route_path, 'framework': 'flask'},
            )
            entities += 1

            # Check if this route uses BigQuery
            uses_bq = bool(RE_GET_BQ_SERVICE.search(fn_body) or RE_BQ_METHOD_CALL.search(fn_body))
            if not uses_bq:
                continue

            # Relation: route → BigQueryService methods called
            for bq_call in RE_BQ_METHOD_CALL.finditer(fn_body):
                called = bq_call.group(1) or bq_call.group(2)
                if not called:
                    continue
                call_line = route_line + fn_body[:bq_call.start()].count('\n')

                # Find or create the target db entity
                target_id = self._bq_service_methods.get(called)
                if not target_id:
                    target_id = self.emitter.emit_entity(
                        layer='db', entity_type='function', repo=repo_id,
                        qualifier=f'BigQueryService.{called}', name=f'BigQueryService.{called}',
                        file=rel_path, line=call_line, confidence=0.82,
                        evidence_file=rel_path, evidence_method='regex',
                        evidence_line_start=call_line,
                        properties={'db_type': 'bigquery', 'source': 'call_site'},
                    )
                    entities += 1
                    self._bq_service_methods[called] = target_id

                self.emitter.emit_relation(
                    source_id=route_id, target_id=target_id,
                    relation_type='calls_function', confidence=0.85,
                    evidence_file=rel_path, evidence_method='regex',
                    evidence_line_start=call_line,
                    evidence_snippet=bq_call.group(0)[:100],
                )
                relations += 1

            # Relation: route → tables referenced in query strings in this function
            for tbl_m in RE_BQ_TABLE.finditer(fn_body):
                dataset = tbl_m.group(1)
                table = tbl_m.group(2)
                if table.lower() in {'self', 'none', 'true', 'false'}:
                    continue
                full_name = f'{dataset}.{table}'
                tbl_id = self._bq_tables.get(full_name)
                if not tbl_id:
                    tbl_line = route_line + fn_body[:tbl_m.start()].count('\n')
                    tbl_id = self.emitter.emit_entity(
                        layer='db', entity_type='table', repo=repo_id,
                        qualifier=full_name, name=full_name,
                        file=rel_path, line=tbl_line, confidence=0.85,
                        evidence_file=rel_path, evidence_method='regex',
                        evidence_line_start=tbl_line,
                        properties={'db_type': 'bigquery', 'dataset': dataset, 'table': table},
                    )
                    entities += 1
                    self._bq_tables[full_name] = tbl_id

                self.emitter.emit_relation(
                    source_id=route_id, target_id=tbl_id,
                    relation_type='uses_table', confidence=0.82,
                    evidence_file=rel_path, evidence_method='regex',
                    evidence_line_start=route_line,
                )
                relations += 1

        status = 'ok' if entities > 0 else 'no_entities'
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    def _is_bq_file(self, content: str) -> bool:
        """Quick check: does this file use BigQuery at all?"""
        return bool(
            'bigquery' in content.lower() or
            'BigQueryService' in content or
            '_get_bq_service' in content or
            'bq_client' in content.lower()
        )
