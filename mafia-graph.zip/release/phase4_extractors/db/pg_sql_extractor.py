"""
MAFIA Phase 4+5 — PostgreSQL SQL File Extractor
=================================================
Extracts from standalone .sql files in DB/API repos:
  Entities: db.function, db.table, db.view
  Relations: calls_function, uses_table, reads_from, writes_to

Incorporates patterns from schema_relationships.py:
  - Global table registry built in before_repo (columns, PKs across all files)
  - Foreign key extraction (inline + ALTER TABLE)
  - Function body parsing with all dollar-quote variants
  - Function-to-function dependency tracing
  - INSERT...SELECT, UPDATE...FROM data flow detection

Usage:
    Registered for classification "api" and "db" in the dispatcher.
"""

import os
import re
import json
import threading
from pathlib import Path
from collections import defaultdict

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult, SKIP_DIRS


# ── Noise words — never real table/function names ────────────────────────────

SQL_NOISE = frozenset({
    'select', 'where', 'set', 'values', 'as', 'on', 'and', 'or', 'not',
    'null', 'true', 'false', 'case', 'when', 'then', 'else', 'end',
    'in', 'is', 'like', 'between', 'exists', 'having', 'group', 'order',
    'limit', 'offset', 'union', 'all', 'distinct', 'cast', 'coalesce',
    'table', 'index', 'view', 'function', 'procedure', 'trigger', 'schema',
    'database', 'dual', 'unnest', 'generate_series', 'jsonb_array_elements',
    'jsonb_array_elements_text', 'json_array_elements', 'jsonb_each',
    'json_each', 'jsonb_object_keys', 'lateral', 'temp', 'excluded',
    'new', 'old', 'inserted', 'deleted', 'information_schema', 'pg_catalog',
})

# ── Compiled patterns ────────────────────────────────────────────────────────

RE_CREATE_FUNCTION = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+'
    r'(?:"?(\w+)"?\.)?"?(\w+)"?\s*\(',
    re.IGNORECASE
)
RE_CREATE_TABLE = re.compile(
    r'CREATE\s+(?:(?:TEMP|TEMPORARY|UNLOGGED|FOREIGN)\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?'
    r'(?:"?(\w+)"?\.)?"?(\w+)"?',
    re.IGNORECASE
)
RE_CREATE_VIEW = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:MATERIALIZED\s+)?VIEW\s+'
    r'(?:"?(\w+)"?\.)?"?(\w+)"?',
    re.IGNORECASE
)
RE_FK_INLINE = re.compile(
    r'FOREIGN\s+KEY\s*\(\s*(\w+)\s*\)\s*REFERENCES\s+(?:(\w+)\.)?(\w+)\s*\(\s*(\w+)\s*\)',
    re.IGNORECASE
)
RE_ALTER_FK = re.compile(
    r'ALTER\s+TABLE\s+(?:(\w+)\.)?(\w+)\s+ADD\s+(?:CONSTRAINT\s+\w+\s+)?'
    r'FOREIGN\s+KEY\s*\(\s*(\w+)\s*\)\s*REFERENCES\s+(?:(\w+)\.)?(\w+)\s*\(\s*(\w+)\s*\)',
    re.IGNORECASE
)
RE_PK_CONSTRAINT = re.compile(r'PRIMARY\s+KEY\s*\(([^)]+)\)', re.IGNORECASE)
RE_PK_INLINE = re.compile(r'^\s*(\w+)\s+\S.*?\bPRIMARY\s+KEY\b', re.IGNORECASE)
RE_CONSTRAINT_LINE = re.compile(
    r'^\s*(CONSTRAINT|PRIMARY|FOREIGN|UNIQUE|CHECK|INDEX|REFERENCES|ON\s+DELETE|ON\s+UPDATE|NOT\s+VALID)\b',
    re.IGNORECASE
)
RE_TABLE_REF = re.compile(
    r'\b(?:FROM|JOIN|INTO|UPDATE)\s+(?:"?(\w+)"?\."?(\w+)"?|"?([a-z_]\w*)"?)',
    re.IGNORECASE
)
RE_INSERT_INTO = re.compile(
    r'INSERT\s+INTO\s+(?:"?(\w+)"?\."?(\w+)"?|"?([a-z_]\w*)"?)',
    re.IGNORECASE
)
RE_FUNCTION_CALL_IN_BODY = re.compile(
    r'(?:FROM|SELECT)\s+(?:"?(\w+)"?\.)?("?\w+"?)\s*\(',
    re.IGNORECASE
)


class PgSqlExtractor(BaseExtractor):
    name = "pg_sql_extractor"
    supported_extensions = {'.sql'}

    def __init__(self):
        super().__init__()
        self._table_registry = {}   # qualified_name -> {schema, table, columns, pk}
        self._defined_fns = {}      # fn_name.lower() -> entity_id
        self._fk_relations = []     # collected during extract, emitted in after_repo
        self._idx_lock = threading.Lock()

    # ── before_repo: build global table registry ─────────────────────────────

    def before_repo(self, repo_id, repo_path, repo_meta):
        self._table_registry = {}
        self._defined_fns = {}
        self._fk_relations = []
        self._build_table_registry(repo_path)

    def _build_table_registry(self, repo_path):
        """Scan all SQL files to build a global table registry with columns and PKs."""
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                if not fname.endswith('.sql'):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except Exception:
                    continue

                cleaned = self._clean_sql(content)
                for m in RE_CREATE_TABLE.finditer(cleaned):
                    schema = m.group(1) or "dre"
                    tname = m.group(2)
                    qname = f"{schema}.{tname}"
                    body = self._extract_paren_body(cleaned, m.end() - 1)
                    if not body:
                        continue
                    columns, pk = self._parse_table_body(body)
                    self._table_registry[qname] = {
                        "schema": schema, "table": tname,
                        "columns": columns, "pk": pk,
                    }

    def _clean_sql(self, text):
        """Remove comments and dollar-quoted PL/pgSQL bodies."""
        text = re.sub(r'--[^\n]*', '', text)
        text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
        # Strip dollar-quoted blocks iteratively per tag
        tags = set(re.findall(r'\$([A-Za-z_]\w*)?\$', text))
        for tag in sorted(tags, key=lambda t: (t == '', t)):
            escaped = re.escape('$' + (tag or '') + '$')
            pat = re.compile(escaped + r'.*?' + escaped, re.DOTALL | re.IGNORECASE)
            prev = None
            while prev != text:
                prev = text
                text = pat.sub(' ', text)
        return text

    def _extract_paren_body(self, sql, start):
        """Return content between matching parentheses starting at index start."""
        depth, i = 0, start
        while i < len(sql):
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
                if depth == 0:
                    return sql[start + 1:i]
            i += 1
        return None

    def _parse_table_body(self, body):
        """Extract column names and primary key from CREATE TABLE body."""
        columns = []
        pk = None
        for line in body.splitlines():
            line = line.strip().rstrip(',')
            if not line:
                continue
            pk_m = RE_PK_CONSTRAINT.search(line)
            if pk_m:
                pk = pk_m.group(1).split(',')[0].strip()
                continue
            if RE_CONSTRAINT_LINE.match(line):
                continue
            pk_inline = RE_PK_INLINE.match(line)
            if pk_inline:
                pk = pk_inline.group(1)
                columns.append(pk_inline.group(1))
                continue
            col_m = re.match(r'(\w+)\s+\S', line)
            if col_m:
                columns.append(col_m.group(1))
        return columns, pk

    # ── after_repo: emit FK relations ────────────────────────────────────────

    def after_repo(self, repo_id, repo_path, repo_meta):
        """Emit collected FK relations now that all tables are registered."""
        for fk in self._fk_relations:
            src_id = fk["src_id"]
            tgt_table = fk["ref_table"]
            tgt_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=tgt_table, name=tgt_table,
                file=fk["file"], line=fk["line"], confidence=0.90,
                evidence_file=fk["file"], evidence_method="regex",
                evidence_line_start=fk["line"],
                properties={
                    "db_type": "postgres", "source": "fk_reference",
                    "columns": self._table_registry.get(tgt_table, {}).get("columns", []),
                },
            )
            self.emitter.emit_relation(
                source_id=src_id, target_id=tgt_id,
                relation_type="reads_from", confidence=0.90,
                evidence_file=fk["file"], evidence_method="regex",
                evidence_line_start=fk["line"],
                evidence_snippet=fk["snippet"][:200],
                properties={
                    "fk_column": fk["fk_col"],
                    "ref_column": fk["ref_col"],
                    "relationship": "foreign_key",
                },
            )

    # ── Main extraction ──────────────────────────────────────────────────────

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0

        # ── CREATE FUNCTION ──────────────────────────────────────────────────
        for m in RE_CREATE_FUNCTION.finditer(content):
            schema = m.group(1) or "dre"
            fn_name = m.group(2)
            full_name = f"{schema}.{fn_name}"
            line = content[:m.start()].count('\n') + 1

            # Extract function parameters
            params = self._extract_function_params(content, m.end())

            # Extract function body
            body = self._extract_function_body(content, m.end())

            props = {
                "db_type": "postgres", "schema": schema, "source": "sql_file",
                "parameters": params[:500] if params else "",
            }

            fn_id = self.emitter.emit_entity(
                layer="db", entity_type="function", repo=repo_id,
                qualifier=f"pg:{full_name}", name=full_name,
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                properties=props,
            )
            entities += 1
            with self._idx_lock:
                self._defined_fns[fn_name.lower()] = fn_id
                self._defined_fns[full_name.lower()] = fn_id

            if body:
                e, r = self._extract_from_body(body, fn_id, schema, rel_path, line, repo_id)
                entities += e
                relations += r

        # ── CREATE TABLE with columns, PK, FK ────────────────────────────────
        for m in RE_CREATE_TABLE.finditer(content):
            schema = m.group(1) or "dre"
            table_name = m.group(2)
            full_table = f"{schema}.{table_name}"
            line = content[:m.start()].count('\n') + 1

            # Get column metadata from registry
            reg = self._table_registry.get(full_table, {})
            columns = reg.get("columns", [])
            pk = reg.get("pk", "")

            tbl_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=full_table, name=full_table,
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                properties={
                    "db_type": "postgres", "schema": schema, "source": "sql_file",
                    "columns": columns, "primary_key": pk,
                    "column_count": len(columns),
                },
            )
            entities += 1

            # Extract inline FKs from the CREATE TABLE body
            paren_start = content.find('(', m.end() - 1)
            if paren_start >= 0:
                body = self._extract_paren_body(content, paren_start)
                if body:
                    for fk in RE_FK_INLINE.finditer(body):
                        ref_schema = fk.group(2) or schema
                        ref_table = f"{ref_schema}.{fk.group(3)}"
                        with self._idx_lock:
                            self._fk_relations.append({
                                "src_id": tbl_id, "ref_table": ref_table,
                                "fk_col": fk.group(1), "ref_col": fk.group(4),
                                "file": rel_path, "line": line,
                                "snippet": fk.group(0),
                            })

        # ── ALTER TABLE ... ADD FOREIGN KEY ───────────────────────────────────
        for m in RE_ALTER_FK.finditer(content):
            src_schema = m.group(1) or "dre"
            src_table = f"{src_schema}.{m.group(2)}"
            ref_schema = m.group(4) or "dre"
            ref_table = f"{ref_schema}.{m.group(5)}"
            line = content[:m.start()].count('\n') + 1

            src_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=src_table, name=src_table,
                file=rel_path, line=line, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line,
                properties={"db_type": "postgres", "source": "alter_fk"},
            )
            entities += 1
            with self._idx_lock:
                self._fk_relations.append({
                    "src_id": src_id, "ref_table": ref_table,
                    "fk_col": m.group(3), "ref_col": m.group(6),
                    "file": rel_path, "line": line,
                    "snippet": m.group(0),
                })

        # ── CREATE VIEW ──────────────────────────────────────────────────────
        for m in RE_CREATE_VIEW.finditer(content):
            schema = m.group(1) or "dre"
            view_name = m.group(2)
            full_view = f"{schema}.{view_name}"
            line = content[:m.start()].count('\n') + 1

            view_id = self.emitter.emit_entity(
                layer="db", entity_type="view", repo=repo_id,
                qualifier=full_view, name=full_view,
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                properties={"db_type": "postgres", "schema": schema, "source": "sql_file"},
            )
            entities += 1

            # Extract tables referenced in the view definition
            view_body = content[m.end():content.find(';', m.end()) + 1] if ';' in content[m.end():] else content[m.end():]
            for tm in RE_TABLE_REF.finditer(view_body):
                tbl = self._resolve_ref(tm, schema)
                if not tbl:
                    continue
                tbl_id = self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=tbl, name=tbl,
                    file=rel_path, line=line, confidence=0.80,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                    properties={"db_type": "postgres", "source": "view_definition"},
                )
                entities += 1
                self.emitter.emit_relation(
                    source_id=view_id, target_id=tbl_id,
                    relation_type="reads_from", confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line,
                )
                relations += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)

    # ── Function body analysis ───────────────────────────────────────────────

    def _extract_from_body(self, body, fn_id, default_schema, rel_path, fn_line, repo_id):
        """Extract function calls, table refs, and write ops from a function body."""
        entities = 0
        relations = 0

        # Function-to-function calls
        for fc in RE_FUNCTION_CALL_IN_BODY.finditer(body):
            called_schema = fc.group(1) or default_schema
            called_fn = fc.group(2).strip('"')
            if called_fn.lower() in SQL_NOISE:
                continue
            called_full = f"{called_schema}.{called_fn}"
            called_id = self.emitter.emit_entity(
                layer="db", entity_type="function", repo=repo_id,
                qualifier=f"pg:{called_full}", name=called_full,
                file=rel_path, line=fn_line, confidence=0.75,
                evidence_file=rel_path, evidence_method="inferred",
                evidence_line_start=fn_line,
                evidence_snippet=fc.group(0)[:200],
                properties={"db_type": "postgres", "source": "called_from_function"},
            )
            entities += 1
            self.emitter.emit_relation(
                source_id=fn_id, target_id=called_id,
                relation_type="calls_function", confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=fn_line,
                evidence_snippet=fc.group(0)[:200],
            )
            relations += 1

        # Table reads (FROM/JOIN) — only emit if table is in registry or looks real
        for tm in RE_TABLE_REF.finditer(body):
            tbl = self._resolve_ref(tm, default_schema)
            if not tbl or not self._is_real_table(tbl):
                continue
            tbl_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=tbl, name=tbl,
                file=rel_path, line=fn_line, confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=fn_line,
                properties={
                    "db_type": "postgres", "source": "function_body",
                    "columns": self._table_registry.get(tbl, {}).get("columns", []),
                },
            )
            entities += 1
            self.emitter.emit_relation(
                source_id=fn_id, target_id=tbl_id,
                relation_type="uses_table", confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=fn_line,
            )
            relations += 1

        # Write operations (INSERT INTO) — same validation
        for wm in RE_INSERT_INTO.finditer(body):
            tbl = self._resolve_ref(wm, default_schema)
            if not tbl or not self._is_real_table(tbl):
                continue
            tbl_id = self.emitter.emit_entity(
                layer="db", entity_type="table", repo=repo_id,
                qualifier=tbl, name=tbl,
                file=rel_path, line=fn_line, confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=fn_line,
                properties={"db_type": "postgres", "access": "write"},
            )
            entities += 1
            self.emitter.emit_relation(
                source_id=fn_id, target_id=tbl_id,
                relation_type="writes_to", confidence=0.85,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=fn_line,
            )
            relations += 1

        return entities, relations

    # ── Table validation ─────────────────────────────────────────────────────

    def _is_real_table(self, qualified_name):
        """Check if a qualified name is likely a real table, not a variable or column.
        Uses the table registry as ground truth, with heuristic fallback."""
        # If it's in the registry, it's definitely real
        if qualified_name in self._table_registry:
            return True
        # Heuristic: real table names are lowercase with underscores, no camelCase
        parts = qualified_name.split(".")
        name = parts[-1] if parts else ""
        schema = parts[0] if len(parts) > 1 else ""
        # Reject camelCase (variables like studyVersionID, assetTypeId)
        if re.search(r'[a-z][A-Z]', name):
            return False
        # Reject PL/pgSQL keywords and common variable prefixes
        if name.lower() in {'strict', 'volatile', 'stable', 'immutable', 'security',
                             'definer', 'invoker', 'cost', 'rows', 'parallel',
                             'safe', 'unsafe', 'restricted', 'language', 'plpgsql',
                             'begin', 'declare', 'exception', 'return', 'returns',
                             'record', 'void', 'text', 'integer', 'boolean',
                             'uuid', 'jsonb', 'json', 'timestamp', 'varchar',
                             'bigint', 'smallint', 'numeric', 'real', 'double'}:
            return False
        # Reject if name starts with v_ (variable) or p_ / in_ / out_ (parameter)
        if re.match(r'^(v_|p_|in_|out_|r_|l_|x_)', name.lower()):
            return False
        # Reject single-word names that are too short (likely aliases)
        if len(name) <= 2:
            return False
        # Accept if schema is a known schema
        if schema.lower() in {'dre', 'idqm', 'idqm_source', 'public',
                               'dre_datareview_views', 'cdr'}:
            return True
        # Accept if name looks like a table (lowercase, underscored, 3+ chars)
        if re.match(r'^[a-z][a-z0-9_]+$', name) and len(name) >= 4:
            return True
        return False

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _extract_function_body(self, content, after_pos):
        """Extract PL/pgSQL function body between dollar-quote delimiters."""
        rest = content[after_pos:]
        # Find all dollar-quote tags in the rest
        for m in re.finditer(r'(\$[A-Za-z_]*\$)', rest):
            tag = m.group(1)
            start = m.end()
            end_pos = rest.find(tag, start)
            if end_pos > start:
                return rest[start:end_pos]
        # Fallback: AS 'body'
        m = re.search(r"AS\s+'(.*?)'", rest, re.DOTALL)
        if m:
            return m.group(1)
        return None

    def _extract_function_params(self, content, paren_pos):
        """Extract function parameter list from CREATE FUNCTION ... (params)."""
        body = self._extract_paren_body(content, paren_pos - 1)
        return body.strip() if body else ""

    def _resolve_ref(self, match, default_schema):
        """Resolve a table reference match to a qualified name."""
        if match.group(1) and match.group(2):
            tbl = f"{match.group(1)}.{match.group(2)}"
        elif match.group(3):
            name = match.group(3)
            if name.lower() in SQL_NOISE:
                return None
            tbl = f"{default_schema}.{name}" if default_schema else name
        else:
            return None
        return tbl
