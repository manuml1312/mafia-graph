"""
MAFIA Generic AST Extractor
============================
Always-on floor extractor. Runs on every workspace regardless of stack.
Produces code:module, code:function, code:class entities with imports/exports/calls.
Guarantees the graph is non-empty for any input.

Uses utils/ts_parser when tree-sitter is available; falls back to regex for
import detection when it's not.
"""

import os
import re
from pathlib import Path
from typing import Optional

from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult

# Extension → language mapping (subset we handle)
_EXT_LANG = {
    ".py": "python", ".ts": "typescript", ".tsx": "typescript",
    ".js": "javascript", ".jsx": "javascript", ".mjs": "javascript",
    ".java": "java", ".go": "go", ".rs": "rust", ".cs": "csharp",
    ".rb": "ruby", ".php": "php", ".cpp": "cpp", ".c": "c",
    ".kt": "kotlin", ".scala": "scala",
}

# Max entities per file (spec §22 mitigation)
_MAX_ENTITIES_PER_FILE = 500

# Max file size for inner structure (>2MB = module-only)
_MAX_SIZE_FOR_STRUCTURE = 2 * 1024 * 1024


class GenericAstExtractor(BaseExtractor):
    name = "generic_ast"
    supported_extensions = set(_EXT_LANG.keys())

    def extract_file(
        self,
        file_path: str,
        rel_path: str,
        content: str,
        repo_id: str,
        repo_meta: dict,
    ) -> FileResult:
        scope_path = repo_id  # may be overridden by active scope
        if self._active_scope:
            scope_path = self._active_scope.path

        entities = 0
        relations = 0
        ext = Path(file_path).suffix.lower()
        lang = _EXT_LANG.get(ext, "")

        # Always emit module entity
        mod_id = self.emitter.emit_entity(
            layer="code", entity_type="module", repo=scope_path,
            qualifier=rel_path, name=Path(rel_path).name,
            confidence=0.95, evidence_file=rel_path,
            evidence_method="ast",
        )
        entities += 1

        # If file too large or unsupported language, module-only
        if len(content) > _MAX_SIZE_FOR_STRUCTURE or not lang:
            return FileResult(
                file_path=rel_path, status="ok" if entities > 0 else "no_entities",
                entities_emitted=entities, relations_emitted=relations,
            )

        # Try tree-sitter first
        ts_result = self._extract_with_treesitter(
            file_path, rel_path, content, lang, scope_path, mod_id
        )
        if ts_result is not None:
            entities += ts_result[0]
            relations += ts_result[1]
        else:
            # Fallback: regex-based import detection
            relations += self._extract_imports_regex(
                content, lang, rel_path, scope_path, mod_id
            )

        return FileResult(
            file_path=rel_path,
            status="ok" if entities > 0 else "no_entities",
            entities_emitted=entities,
            relations_emitted=relations,
        )

    def _extract_with_treesitter(
        self, file_path, rel_path, content, lang, scope_path, mod_id
    ) -> Optional[tuple[int, int]]:
        """Try tree-sitter extraction. Returns (entities, relations) or None."""
        try:
            from utils.ts_parser import (
                is_available, parse_source, find_all_methods,
                find_all_classes, find_all_imports, read_text,
            )
        except ImportError:
            return None

        if not is_available(lang):
            return None

        tree = parse_source(content.encode("utf-8"), lang)
        if tree is None:
            return None

        source_bytes = content.encode("utf-8")
        entities = 0
        relations = 0
        entity_count = 0

        # Classes
        for cls_node in find_all_classes(tree, lang):
            if entity_count >= _MAX_ENTITIES_PER_FILE:
                break
            cls_name = self._get_node_name(cls_node, source_bytes)
            if not cls_name:
                continue
            qualifier = f"{rel_path}::{cls_name}"
            cls_id = self.emitter.emit_entity(
                layer="code", entity_type="class", repo=scope_path,
                qualifier=qualifier, name=cls_name,
                confidence=0.95, evidence_file=rel_path,
                evidence_method="ast",
                line=cls_node.start_point[0] + 1,
            )
            entities += 1
            entity_count += 1
            self.emitter.emit_relation(
                source_id=cls_id, target_id=mod_id,
                relation_type="defined_in", confidence=0.95,
                evidence_file=rel_path, evidence_method="ast",
            )
            relations += 1

        # Functions/methods
        func_ids = {}
        for func_node in find_all_methods(tree, lang):
            if entity_count >= _MAX_ENTITIES_PER_FILE:
                break
            func_name = self._get_node_name(func_node, source_bytes)
            if not func_name:
                continue
            qualifier = f"{rel_path}::{func_name}"
            func_id = self.emitter.emit_entity(
                layer="code", entity_type="function", repo=scope_path,
                qualifier=qualifier, name=func_name,
                confidence=0.95, evidence_file=rel_path,
                evidence_method="ast",
                line=func_node.start_point[0] + 1,
            )
            entities += 1
            entity_count += 1
            func_ids[func_name] = func_id
            self.emitter.emit_relation(
                source_id=func_id, target_id=mod_id,
                relation_type="defined_in", confidence=0.95,
                evidence_file=rel_path, evidence_method="ast",
            )
            relations += 1

        # Imports
        for imp_node in find_all_imports(tree, lang):
            imp_text = read_text(imp_node, source_bytes).strip()
            spec = self._parse_import_spec(imp_text, lang)
            if spec:
                target_id = f"code:module:_unresolved:{spec}"
                self.emitter.emit_relation(
                    source_id=mod_id, target_id=target_id,
                    relation_type="imports", confidence=0.70,
                    evidence_file=rel_path, evidence_method="ast",
                    unresolved_target=spec,
                )
                relations += 1

        # Same-file calls (best-effort)
        relations += self._extract_same_file_calls(
            tree, lang, source_bytes, func_ids, rel_path
        )

        return entities, relations

    def _extract_same_file_calls(self, tree, lang, source_bytes, func_ids, rel_path):
        """Detect calls between functions defined in the same file."""
        try:
            from utils.ts_parser import get_config, read_text
        except ImportError:
            return 0

        cfg = get_config(lang)
        call_types = cfg.get("call_types", frozenset())
        if not call_types or not func_ids:
            return 0

        relations = 0
        calls_found = set()

        def walk(node):
            nonlocal relations
            if node.type in call_types:
                call_text = read_text(node, source_bytes)
                for fname, fid in func_ids.items():
                    if fname in call_text and (fname, fid) not in calls_found:
                        # Find which function this call is inside
                        for caller_name, caller_id in func_ids.items():
                            if caller_name != fname and caller_id != fid:
                                calls_found.add((fname, fid))
                                self.emitter.emit_relation(
                                    source_id=caller_id, target_id=fid,
                                    relation_type="calls", confidence=0.70,
                                    evidence_file=rel_path, evidence_method="ast",
                                )
                                relations += 1
                                break
            for child in node.children:
                walk(child)

        walk(tree.root_node)
        return relations

    def _extract_imports_regex(self, content, lang, rel_path, scope_path, mod_id):
        """Regex fallback for import detection when tree-sitter unavailable."""
        relations = 0
        patterns = {
            "python": [r'^(?:from\s+(\S+)\s+import|import\s+(\S+))'],
            "typescript": [r'''import\s+.*?from\s+['"](.*?)['"]'''],
            "javascript": [r'''import\s+.*?from\s+['"](.*?)['"]''',
                          r'''require\s*\(\s*['"](.*?)['"]\s*\)'''],
            "java": [r'^import\s+([\w.]+);'],
            "go": [r'"([\w./]+)"'],
            "rust": [r'^use\s+([\w:]+)'],
            "csharp": [r'^using\s+([\w.]+);'],
        }
        for pat in patterns.get(lang, []):
            for m in re.finditer(pat, content, re.MULTILINE):
                spec = m.group(1) or (m.group(2) if m.lastindex >= 2 else "")
                if spec:
                    target_id = f"code:module:_unresolved:{spec}"
                    self.emitter.emit_relation(
                        source_id=mod_id, target_id=target_id,
                        relation_type="imports", confidence=0.70,
                        evidence_file=rel_path, evidence_method="regex",
                        unresolved_target=spec,
                    )
                    relations += 1
        return relations

    @staticmethod
    def _get_node_name(node, source_bytes) -> str:
        """Extract the name identifier from an AST node."""
        for child in node.children:
            if child.type in ("identifier", "name", "type_identifier",
                              "property_identifier"):
                return source_bytes[child.start_byte:child.end_byte].decode(
                    "utf-8", errors="replace"
                )
        return ""

    @staticmethod
    def _parse_import_spec(imp_text: str, lang: str) -> str:
        """Extract the import specifier from an import statement text."""
        if lang in ("typescript", "javascript"):
            m = re.search(r'''from\s+['"](.*?)['"]''', imp_text)
            if m:
                return m.group(1)
            m = re.search(r'''require\s*\(\s*['"](.*?)['"]\s*\)''', imp_text)
            if m:
                return m.group(1)
        elif lang == "python":
            m = re.match(r'(?:from\s+(\S+)\s+import|import\s+(\S+))', imp_text)
            if m:
                return m.group(1) or m.group(2)
        elif lang == "java":
            m = re.match(r'import\s+([\w.]+)', imp_text)
            if m:
                return m.group(1)
        elif lang == "go":
            m = re.search(r'"([\w./]+)"', imp_text)
            if m:
                return m.group(1)
        elif lang == "rust":
            m = re.match(r'use\s+([\w:]+)', imp_text)
            if m:
                return m.group(1)
        elif lang == "csharp":
            m = re.match(r'using\s+([\w.]+)', imp_text)
            if m:
                return m.group(1)
        return ""
