"""
MAFIA Phase 4+5 — Config, Env, and Toggle Extractor
=====================================================
Runs on ALL repos. Extracts:
  Entities: config.env, config.property, config.toggle, config.secret
  Relations: (none directly — depends_on_config emitted by other extractors)
"""

import os
import re
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult, SKIP_DIRS


class ConfigExtractor(BaseExtractor):
    name = "config_extractor"
    supported_extensions = {'.properties', '.yml', '.yaml'}

    def discover_files(self, repo_path):
        """Override: also pick up .env* dotfiles."""
        files = super().discover_files(repo_path)
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                if fname.startswith('.env'):
                    fpath = os.path.join(root, fname)
                    if fpath not in files and os.path.getsize(fpath) < 500_000:
                        files.append(fpath)
        return files

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        fname = Path(rel_path).name

        if fname.startswith('.env'):
            entities += self._extract_env(content, rel_path, repo_id)
        elif fname.endswith('.properties'):
            entities += self._extract_properties(content, rel_path, repo_id)
        elif fname.endswith(('.yml', '.yaml')):
            entities += self._extract_yaml_keys(content, rel_path, repo_id)

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status, entities_emitted=entities)

    def _extract_env(self, content, rel_path, repo_id):
        count = 0
        for line_num, line_text in enumerate(content.splitlines(), 1):
            line_text = line_text.strip()
            if not line_text or line_text.startswith('#'):
                continue
            m = re.match(r'^([A-Z_][A-Z0-9_]*)\s*=\s*(.*)$', line_text)
            if not m:
                continue
            key = m.group(1)
            value = m.group(2).strip().strip('"').strip("'")

            # Classify
            is_secret = any(kw in key.lower() for kw in ('secret', 'key', 'password', 'token', 'credential'))
            is_toggle = any(kw in key.lower() for kw in ('enable', 'disable', 'feature', 'toggle', 'flag'))
            if is_secret:
                etype = "secret"
                value = "<redacted>"
            elif is_toggle:
                etype = "toggle"
            else:
                etype = "env"

            self.emitter.emit_entity(
                layer="config", entity_type=etype, repo=repo_id,
                qualifier=key, name=key,
                file=rel_path, line=line_num, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line_num, evidence_snippet=line_text[:200],
                properties={"value": value, "source_file": rel_path},
            )
            count += 1
        return count

    def _extract_properties(self, content, rel_path, repo_id):
        count = 0
        for line_num, line_text in enumerate(content.splitlines(), 1):
            line_text = line_text.strip()
            if not line_text or line_text.startswith('#'):
                continue
            m = re.match(r'^([\w.\-]+)\s*=\s*(.*)$', line_text)
            if not m:
                continue
            key = m.group(1)
            value = m.group(2).strip()

            is_secret = any(kw in key.lower() for kw in ('secret', 'password', 'token', 'credential'))
            self.emitter.emit_entity(
                layer="config", entity_type="property", repo=repo_id,
                qualifier=f"{rel_path}::{key}", name=key,
                file=rel_path, line=line_num, confidence=0.90,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line_num, evidence_snippet=line_text[:200],
                properties={"value": "<redacted>" if is_secret else value},
            )
            count += 1
        return count

    def _extract_yaml_keys(self, content, rel_path, repo_id):
        """Extract top-level and important nested YAML keys (simple regex, not full parser)."""
        count = 0
        for line_num, line_text in enumerate(content.splitlines(), 1):
            # Look for key: value patterns (not deeply nested)
            m = re.match(r'^(\s{0,4})([\w.\-]+)\s*:\s*(.+)$', line_text)
            if not m:
                continue
            indent = len(m.group(1))
            key = m.group(2)
            value = m.group(3).strip()

            # Skip structural keys (no value, just nesting)
            if not value or value == '|' or value == '>':
                continue

            is_secret = any(kw in key.lower() for kw in ('secret', 'password', 'token', 'credential'))
            self.emitter.emit_entity(
                layer="config", entity_type="property", repo=repo_id,
                qualifier=f"{rel_path}::{key}", name=key,
                file=rel_path, line=line_num, confidence=0.80,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line_num, evidence_snippet=line_text[:200],
                properties={"value": "<redacted>" if is_secret else value, "format": "yaml"},
            )
            count += 1
        return count
