"""
MAFIA Phase 4 — Tree-Sitter Universal Extractor
===================================================
AST-first extractor that runs on ALL repos regardless of classification.
Parses every source file with tree-sitter, discovers classes/methods/functions,
infers layer from AST patterns (annotations, decorators, imports, naming),
and emits entities + call-graph relations.

KEY DESIGN: if no layer can be inferred, entities go into the "shared" layer
as class/function/module. This guarantees that ANY parseable codebase —
a Django app, a plain Python script, an HTML+JS site, a Go CLI tool —
always produces visible code structures in the graph, even without
recognized framework patterns.

Runs as a `*` extractor (every repo). Regex extractors still run and win
on confidence for their known patterns; tree-sitter fills the gaps.

Usage:
    dispatcher.register("*", TreeSitterExtractor)
"""

import os
import re
from pathlib import Path
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult, SKIP_DIRS
from utils.ts_parser import (
    is_available, any_available, parse_file, read_text,
    find_all_methods, find_all_classes, find_all_imports,
    get_config, EXT_TO_LANG,
)


# ── Layer inference rules ────────────────────────────────────────────────────

_JAVA_ANNOTATION_MAP = {
    "RestController": ("api", "controller"), "Controller": ("api", "controller"),
    "Service": ("api", "service"), "Repository": ("api", "repository"),
    "Entity": ("api", "entity"), "Table": ("api", "entity"),
    "Configuration": ("api", "config"), "Component": ("api", "service"),
    "GetMapping": ("api", "endpoint"), "PostMapping": ("api", "endpoint"),
    "PutMapping": ("api", "endpoint"), "DeleteMapping": ("api", "endpoint"),
    "PatchMapping": ("api", "endpoint"), "RequestMapping": ("api", "endpoint"),
}

_TS_IMPORT_LAYER_HINTS = {
    "react": "ui", "next": "ui", "recoil": "ui", "redux": "ui", "@reduxjs": "ui",
    "koa": "bff", "express": "bff", "fastify": "bff", "hapi": "bff",
}

_PY_IMPORT_LAYER_HINTS = {
    "flask": "api", "fastapi": "api", "django": "api", "starlette": "api",
    "pyspark": "db", "databricks": "db", "sqlalchemy": "db",
    "google.cloud.bigquery": "db", "google.cloud.firestore": "db",
    "google.cloud.datastore": "db", "pymongo": "db", "psycopg2": "db",
    "pymysql": "db", "cx_oracle": "db", "pyodbc": "db",
    "redis": "db", "elasticsearch": "db", "cassandra": "db",
}

_PY_DECORATOR_MAP = {
    "app.route": ("api", "endpoint"), "app.get": ("api", "endpoint"),
    "app.post": ("api", "endpoint"), "app.put": ("api", "endpoint"),
    "app.delete": ("api", "endpoint"), "router.get": ("api", "endpoint"),
    "router.post": ("api", "endpoint"),
}

# Language → default (layer, class_type, function_type) when nothing else matches
_LANG_DEFAULTS = {
    "java":       ("shared", "class", "function"),
    "typescript":  ("shared", "class", "function"),
    "javascript":  ("shared", "class", "function"),
    "python":      ("shared", "class", "function"),
    "go":          ("shared", "class", "function"),
    "rust":        ("shared", "class", "function"),
    "csharp":      ("shared", "class", "function"),
    "kotlin":      ("shared", "class", "function"),
    "scala":       ("shared", "class", "function"),
    "ruby":        ("shared", "class", "function"),
    "c":           ("shared", "class", "function"),
    "cpp":         ("shared", "class", "function"),
    "php":         ("shared", "class", "function"),
    "swift":       ("shared", "class", "function"),
    "lua":         ("shared", "module", "function"),
    "zig":         ("shared", "module", "function"),
    "powershell":  ("shared", "class", "function"),
    "elixir":      ("shared", "module", "function"),
    "objc":        ("shared", "class", "function"),
}


class TreeSitterExtractor(BaseExtractor):
    name = "treesitter_extractor"
    supported_extensions = set(EXT_TO_LANG.keys())

    def __init__(self):
        super().__init__()
        self._file_layer_cache: dict[str, str] = {}

    def before_repo(self, repo_id, repo_path, repo_meta):
        self._file_layer_cache = {}

    def discover_files(self, repo_path: str) -> list[str]:
        if not any_available():
            return []
        from utils.ignore_loader import load_ignore_patterns, is_ignored
        patterns = load_ignore_patterns(repo_path)
        files = []
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                ext = Path(fname).suffix.lower()
                lang = EXT_TO_LANG.get(ext)
                if not lang or not is_available(lang):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    if os.path.getsize(fpath) > 2 * 1024 * 1024:
                        continue
                except OSError:
                    continue
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                if not is_ignored(rel, patterns):
                    files.append(fpath)
        return files

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        ext = Path(rel_path).suffix.lower()
        language = EXT_TO_LANG.get(ext)
        if not language or not is_available(language):
            return FileResult(file_path=rel_path, status="skipped")

        result = parse_file(file_path, language)
        if not result:
            return FileResult(file_path=rel_path, status="skipped")

        tree, source = result
        cfg = get_config(language)
        entities = 0
        relations = 0

        file_layer = self._infer_file_layer(tree, source, language, rel_path, cfg)
        self._file_layer_cache[rel_path] = file_layer
        defaults = _LANG_DEFAULTS.get(language, ("shared", "class", "function"))

        # ── Classes ──────────────────────────────────────────────────────
        class_nodes = find_all_classes(tree, language)
        class_map = {}

        for cls_node in class_nodes:
            name_node = cls_node.child_by_field_name("name")
            if not name_node:
                continue
            cls_name = read_text(name_node, source)
            if not cls_name:
                continue
            line = cls_node.start_point[0] + 1

            layer, etype = self._classify_class(cls_node, source, language, cfg, file_layer, cls_name)
            # FALLBACK: always emit, even if no layer inferred
            if not layer:
                layer, etype = defaults[0], defaults[1]

            eid = self.emitter.emit_entity(
                layer=layer, entity_type=etype, repo=repo_id,
                qualifier=f"{rel_path}::{cls_name}", name=cls_name,
                file=rel_path, line=line, confidence=0.70 if layer != "shared" else 0.60,
                evidence_file=rel_path, evidence_method="ast",
                evidence_line_start=line,
                evidence_line_end=cls_node.end_point[0] + 1,
                evidence_snippet=read_text(cls_node, source)[:300],
                properties={"language": language, "node_type": cls_node.type,
                             "ast_inferred_layer": layer},
            )
            entities += 1
            class_map[cls_name] = (layer, etype, eid)

        # ── Methods / functions ──────────────────────────────────────────
        method_nodes = find_all_methods(tree, language)
        method_ids = {}

        for method_node in method_nodes:
            name_node = method_node.child_by_field_name("name")
            if not name_node:
                for child in method_node.children:
                    if child.type == "identifier":
                        name_node = child
                        break
            if not name_node:
                continue

            method_name = read_text(name_node, source)
            if not method_name:
                continue
            # Skip dunder/private in Python, but keep everything else
            if language == "python" and method_name.startswith("__") and method_name.endswith("__"):
                continue
            line = method_node.start_point[0] + 1

            parent_class = self._find_parent_class(method_node, source, cfg)
            qualified = f"{parent_class}.{method_name}" if parent_class else method_name

            layer, etype = self._classify_method(
                method_node, source, language, cfg, file_layer,
                method_name, parent_class, class_map,
            )
            # FALLBACK: always emit
            if not layer:
                layer, etype = defaults[0], defaults[2]

            eid = self.emitter.emit_entity(
                layer=layer, entity_type=etype, repo=repo_id,
                qualifier=f"{rel_path}::{qualified}", name=qualified,
                file=rel_path, line=line, confidence=0.65 if layer != "shared" else 0.55,
                evidence_file=rel_path, evidence_method="ast",
                evidence_line_start=line,
                evidence_line_end=method_node.end_point[0] + 1,
                evidence_snippet=read_text(method_node, source)[:300],
                properties={"language": language, "parent_class": parent_class or "",
                             "ast_inferred_layer": layer},
            )
            entities += 1
            method_ids[qualified] = eid

            # Link method → parent class
            if parent_class and parent_class in class_map:
                _, _, cls_eid = class_map[parent_class]
                self.emitter.emit_relation(
                    source_id=cls_eid, target_id=eid,
                    relation_type="delegates_to", confidence=0.85,
                    evidence_file=rel_path, evidence_method="ast",
                    evidence_line_start=line,
                )
                relations += 1

        # ── If no classes or methods found, emit file as a module ────────
        if entities == 0 and content.strip():
            layer = file_layer or defaults[0]
            mtype = "module" if layer in ("ui", "shared") else "service"
            # For shared layer, must use valid types
            if layer == "shared":
                mtype = "module"
            elif layer == "api":
                mtype = "service"
            elif layer == "bff":
                mtype = "service"
            elif layer == "db":
                mtype = "function"

            fname = Path(rel_path).stem
            self.emitter.emit_entity(
                layer=layer, entity_type=mtype, repo=repo_id,
                qualifier=f"{rel_path}::{fname}", name=fname,
                file=rel_path, line=1, confidence=0.50,
                evidence_file=rel_path, evidence_method="ast",
                evidence_line_start=1,
                evidence_snippet=content[:200],
                properties={"language": language, "ast_inferred_layer": layer,
                             "file_level": True},
            )
            entities += 1

        # ── Call-graph edges ─────────────────────────────────────────────
        call_types = cfg.get("call_types", frozenset())
        method_type_set = cfg.get("method_types", frozenset())

        for method_node in method_nodes:
            name_node = method_node.child_by_field_name("name")
            if not name_node:
                for child in method_node.children:
                    if child.type == "identifier":
                        name_node = child
                        break
            if not name_node:
                continue
            method_name = read_text(name_node, source)
            parent_class = self._find_parent_class(method_node, source, cfg)
            qualified = f"{parent_class}.{method_name}" if parent_class else method_name
            src_eid = method_ids.get(qualified)
            if not src_eid:
                continue

            body = method_node.child_by_field_name("body")
            if not body:
                for child in method_node.children:
                    if child.type in cfg.get("block_types", frozenset()):
                        body = child
                        break
            if not body:
                continue

            seen_calls = set()
            self._walk_calls(
                body, source, language, cfg, call_types, method_type_set,
                src_eid, method_ids, class_map, rel_path, seen_calls,
            )
            relations += len(seen_calls)

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(
            file_path=rel_path, status=status,
            entities_emitted=entities, relations_emitted=relations,
        )

    # ── Layer inference ──────────────────────────────────────────────────

    def _infer_file_layer(self, tree, source, language, rel_path, cfg) -> str:
        rel_lower = rel_path.lower().replace("\\", "/")
        path_segments = rel_lower.split("/")

        # Path-based hints
        path_layer = ""
        if any(s in ("pages", "components", "hooks", "selectors", "ui", "frontend", "templates", "views") for s in path_segments):
            path_layer = "ui"
        elif any(s in ("routes", "middleware", "bff") for s in path_segments):
            path_layer = "bff"
        elif any(s in ("controller", "controllers", "service", "services",
                        "repository", "repositories", "api", "endpoints") for s in path_segments):
            path_layer = "api"
        elif any(s in ("functions", "schema", "schemas", "migrations", "sql",
                        "models", "db", "database", "queries", "dao") for s in path_segments):
            path_layer = "db"
        # File name hints for Python
        fname_lower = Path(rel_path).name.lower()
        if language == "python":
            if any(x in fname_lower for x in ("big_query", "bigquery", "bq_", "_bq.", "database", "db_", "_db.", "models", "repository", "dao")):
                path_layer = "db"
            elif any(x in fname_lower for x in ("app.", "routes.", "views.", "api.", "endpoint", "controller")):
                path_layer = "api"

        # Import-based hints
        import_layer_votes: dict[str, int] = {}
        import_nodes = find_all_imports(tree, language)
        for imp_node in import_nodes:
            imp_text = read_text(imp_node, source).lower()
            hints = {}
            if language in ("typescript", "javascript"):
                hints = _TS_IMPORT_LAYER_HINTS
            elif language == "python":
                hints = _PY_IMPORT_LAYER_HINTS
            for key, layer in hints.items():
                if key in imp_text:
                    import_layer_votes[layer] = import_layer_votes.get(layer, 0) + 1

        if import_layer_votes:
            return max(import_layer_votes, key=import_layer_votes.get)

        if language in ("sql",) or rel_path.endswith(".sql"):
            return "db"

        # Return path hint or empty — empty is fine, fallback handles it
        return path_layer

    def _classify_class(self, cls_node, source, language, cfg, file_layer, cls_name) -> tuple[str, str]:
        ann_types = cfg.get("annotation_types", frozenset())

        if language == "java":
            annotations = self._get_annotations(cls_node, source, ann_types)
            for ann in annotations:
                ann_bare = ann.lstrip("@").split("(")[0]
                if ann_bare in _JAVA_ANNOTATION_MAP:
                    return _JAVA_ANNOTATION_MAP[ann_bare]
            if cls_name.endswith("Controller") or cls_name.endswith("Resource"):
                return ("api", "controller")
            if cls_name.endswith("Service") or cls_name.endswith("ServiceImpl"):
                return ("api", "service")
            if cls_name.endswith("Repository"):
                return ("api", "repository")
            if cls_name.endswith("Dto") or cls_name.endswith("DTO"):
                return ("api", "dto")

        elif language in ("typescript", "javascript"):
            if file_layer == "ui":
                return ("ui", "component")
            if file_layer == "bff":
                return ("bff", "service")

        elif language == "python":
            decorators = self._get_annotations(cls_node, source, ann_types)
            for dec in decorators:
                dec_bare = dec.lstrip("@").split("(")[0]
                if dec_bare in _PY_DECORATOR_MAP:
                    return _PY_DECORATOR_MAP[dec_bare]

        # Use file_layer if known
        layer_type_map = {
            "api": ("api", "service"), "ui": ("ui", "component"),
            "bff": ("bff", "service"), "db": ("db", "function"),
        }
        if file_layer in layer_type_map:
            return layer_type_map[file_layer]

        # Return empty — caller will use shared fallback
        return ("", "")

    def _classify_method(self, method_node, source, language, cfg, file_layer,
                         method_name, parent_class, class_map) -> tuple[str, str]:
        ann_types = cfg.get("annotation_types", frozenset())

        if language == "java":
            annotations = self._get_annotations(method_node, source, ann_types)
            for ann in annotations:
                ann_bare = ann.lstrip("@").split("(")[0]
                if ann_bare in _JAVA_ANNOTATION_MAP:
                    return _JAVA_ANNOTATION_MAP[ann_bare]
            if parent_class and parent_class in class_map:
                cls_layer, cls_type, _ = class_map[parent_class]
                type_map = {"controller": "controller", "service": "service",
                            "repository": "repository", "entity": "service",
                            "config": "config"}
                return (cls_layer, type_map.get(cls_type, cls_type))

        elif language in ("typescript", "javascript"):
            method_text = read_text(method_node, source)[:500]
            if re.search(r'ctx\s*[:\.]|req\s*[:\.]|request\s*[:\.]', method_text):
                return ("bff", "controller")
            if method_name.startswith("use") and len(method_name) > 3 and method_name[3:4].isupper():
                return ("ui", "hook")
            if method_name[0:1].isupper() and re.search(r'return\s*\(?\s*<|jsx', method_text):
                return ("ui", "component")
            if file_layer == "ui":
                return ("ui", "module")
            if file_layer == "bff":
                return ("bff", "controller")

        elif language == "python":
            decorators = self._get_annotations(method_node, source, ann_types)
            for dec in decorators:
                dec_bare = dec.lstrip("@").split("(")[0]
                if dec_bare in _PY_DECORATOR_MAP:
                    return _PY_DECORATOR_MAP[dec_bare]

        # Inherit from parent class if classified
        if parent_class and parent_class in class_map:
            cls_layer, cls_type, _ = class_map[parent_class]
            if cls_layer == "shared":
                return ("shared", "function")
            return (cls_layer, cls_type)

        # Use file_layer
        layer_type_map = {
            "api": ("api", "service"), "ui": ("ui", "module"),
            "bff": ("bff", "controller"), "db": ("db", "function"),
        }
        if file_layer in layer_type_map:
            return layer_type_map[file_layer]

        # Return empty — caller will use shared fallback
        return ("", "")

    # ── Helpers ──────────────────────────────────────────────────────────

    def _get_annotations(self, node, source, ann_types) -> list[str]:
        annotations = []
        for child in node.children:
            if child.type in ann_types:
                annotations.append(read_text(child, source).strip())
            if child.type == "modifiers":
                for sub in child.children:
                    if sub.type in ann_types:
                        annotations.append(read_text(sub, source).strip())
        if node.parent:
            found = False
            for sib in reversed(list(node.parent.children)):
                if sib == node:
                    found = True
                    continue
                if found and sib.type in ann_types:
                    annotations.append(read_text(sib, source).strip())
                elif found and sib.is_named and sib.type not in ann_types:
                    break
        return annotations

    def _find_parent_class(self, method_node, source, cfg) -> Optional[str]:
        class_types = cfg.get("class_types", frozenset())
        cur = method_node.parent
        while cur:
            if cur.type in class_types:
                name_node = cur.child_by_field_name("name")
                if name_node:
                    return read_text(name_node, source)
            cur = cur.parent
        return None

    def _walk_calls(self, node, source, language, cfg, call_types, method_types,
                    src_eid, method_ids, class_map, rel_path, seen):
        if node.type in method_types:
            return
        if node.type in call_types:
            target_name = self._resolve_call(node, source, language)
            if target_name and target_name not in seen:
                tgt_eid = method_ids.get(target_name)
                if not tgt_eid:
                    for qn, eid in method_ids.items():
                        if qn.endswith(f".{target_name}"):
                            tgt_eid = eid
                            break
                if tgt_eid and tgt_eid != src_eid:
                    seen.add(target_name)
                    self.emitter.emit_relation(
                        source_id=src_eid, target_id=tgt_eid,
                        relation_type="calls", confidence=0.70,
                        evidence_file=rel_path, evidence_method="ast",
                        evidence_line_start=node.start_point[0] + 1,
                        evidence_snippet=read_text(node, source)[:200],
                    )
        for child in node.children:
            self._walk_calls(
                child, source, language, cfg, call_types, method_types,
                src_eid, method_ids, class_map, rel_path, seen,
            )

    def _resolve_call(self, call_node, source, language) -> Optional[str]:
        if language == "java":
            name_node = call_node.child_by_field_name("name")
            obj_node = call_node.child_by_field_name("object")
            if name_node:
                method = read_text(name_node, source)
                if obj_node:
                    obj = read_text(obj_node, source).split(".")[-1].split("(")[0]
                    return f"{obj}.{method}"
                return method
        elif language in ("typescript", "javascript"):
            func_node = call_node.child_by_field_name("function")
            if func_node:
                if func_node.type == "member_expression":
                    prop = func_node.child_by_field_name("property")
                    obj = func_node.child_by_field_name("object")
                    if prop:
                        method = read_text(prop, source)
                        if obj:
                            return f"{read_text(obj, source).split('.')[-1]}.{method}"
                        return method
                elif func_node.type == "identifier":
                    return read_text(func_node, source)
        elif language == "python":
            func_node = call_node.child_by_field_name("function")
            if func_node:
                if func_node.type == "attribute":
                    attr = func_node.child_by_field_name("attribute")
                    obj = func_node.child_by_field_name("object")
                    if attr:
                        method = read_text(attr, source)
                        if obj:
                            return f"{read_text(obj, source).split('.')[-1]}.{method}"
                        return method
                elif func_node.type == "identifier":
                    return read_text(func_node, source)
        return None
