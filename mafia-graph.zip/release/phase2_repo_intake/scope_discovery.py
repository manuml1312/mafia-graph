"""
MAFIA Scope Discovery
=====================
Top-level orchestrator: resolves source → discovers repos → detects workspaces → classifies stacks.
Produces DiscoveryResult with full Codebase/Repo/Workspace hierarchy.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from schemas.scope import Codebase, Repo, Workspace
from phase4_source_adapters import resolve_source
from phase4_workspace_detectors.runner import run_detectors
from phase2_repo_intake.stack_detector import detect_stack

_ROOT_MARKERS = {
    "package.json", "pom.xml", "build.gradle", "build.gradle.kts",
    "setup.py", "pyproject.toml", "go.mod", "Cargo.toml",
    "Gemfile", "composer.json", "mix.exs",
}

_SKIP = {".git", "node_modules", ".mafia", "__pycache__", ".venv", "venv"}


@dataclass
class DiscoveryResult:
    codebase: Codebase
    repos: list[Repo] = field(default_factory=list)
    workspaces: list[Workspace] = field(default_factory=list)


def _has_root_marker(path: Path) -> bool:
    return any((path / m).exists() for m in _ROOT_MARKERS)


def _has_git(path: Path) -> bool:
    return (path / ".git").exists()


def _discover_repos(codebase_root: Path) -> list[Path]:
    """Discover repo boundaries inside a codebase root (spec §6.3)."""
    # Rule 1: root itself is a repo
    if _has_git(codebase_root) or _has_root_marker(codebase_root):
        return [codebase_root]

    # Rule 2: one level deep
    children = [
        c for c in sorted(codebase_root.iterdir())
        if c.is_dir() and c.name not in _SKIP
    ]
    repos = [c for c in children if _has_git(c) or _has_root_marker(c)]
    if repos:
        return repos

    # Rule 3: two levels deep
    for child in children:
        try:
            grandchildren = [
                gc for gc in sorted(child.iterdir())
                if gc.is_dir() and gc.name not in _SKIP
            ]
        except PermissionError:
            continue
        repos.extend(gc for gc in grandchildren if _has_git(gc) or _has_root_marker(gc))
    if repos:
        return repos

    # Rule 4: fallback — treat root as single anonymous repo
    return [codebase_root]


def discover(source: str, *, name: Optional[str] = None,
             work_dir: Optional[Path] = None) -> DiscoveryResult:
    """Run full scope discovery on a source descriptor.

    Args:
        source: path, zip, tar, or git URL
        name: override codebase name (default: basename of resolved root)
        work_dir: working directory for adapters (default: .mafia)
    """
    if work_dir is None:
        work_dir = Path(".mafia")

    # Phase 1: resolve source
    codebase_root = resolve_source(source, work_dir)
    codebase_name = name or codebase_root.name

    codebase = Codebase(name=codebase_name, root=str(codebase_root))

    # Phase 2: discover repos
    repo_paths = _discover_repos(codebase_root)

    all_repos: list[Repo] = []
    all_workspaces: list[Workspace] = []

    for repo_path in repo_paths:
        repo_name = repo_path.name if repo_path != codebase_root else codebase_name
        repo = Repo(
            name=repo_name,
            root=str(repo_path),
            codebase=codebase_name,
        )
        all_repos.append(repo)

        # Detect workspaces
        systems, ws_specs = run_detectors(repo_path)

        if not ws_specs:
            # No monorepo — single workspace = repo
            stack = detect_stack(repo_path)
            ws = Workspace(
                name=repo_name,
                root=str(repo_path),
                repo=repo_name,
                codebase=codebase_name,
                classification=tuple(stack.classification),
                language_hint=stack.primary_language,
                framework_hint=stack.frameworks[0] if stack.frameworks else "",
            )
            all_workspaces.append(ws)
        else:
            for ws_spec in ws_specs:
                ws_root = repo_path / ws_spec.root
                stack = detect_stack(ws_root) if ws_root.exists() else None
                ws = Workspace(
                    name=ws_spec.name,
                    root=str(ws_root),
                    repo=repo_name,
                    codebase=codebase_name,
                    package_name=ws_spec.package_name,
                    classification=tuple(stack.classification) if stack else (),
                    language_hint=stack.primary_language if stack else "",
                    framework_hint=stack.frameworks[0] if stack and stack.frameworks else "",
                )
                all_workspaces.append(ws)

    return DiscoveryResult(
        codebase=codebase,
        repos=all_repos,
        workspaces=all_workspaces,
    )
