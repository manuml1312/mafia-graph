"""
MAFIA Phase 2 — Repo Source Adapters
======================================
Pluggable intake adapters for different source types.
Currently supports: local folder.
Designed for future plug-and-play: Git URL, archive (zip/tar), S3, etc.

Usage:
    adapter = get_adapter("local")
    repo_path = adapter.resolve("/path/to/repos")

    # Future:
    adapter = get_adapter("git")
    repo_path = adapter.resolve("https://github.com/org/repo.git", branch="main")
"""

import shutil
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional


class RepoSourceAdapter(ABC):
    """
    Abstract base for repo source adapters.
    Each adapter knows how to resolve a source reference into a local directory path.
    """

    name: str = "base"

    @abstractmethod
    def resolve(self, source: str, **kwargs) -> Path:
        """
        Resolve a source reference to a local directory path.
        For local: returns the path as-is.
        For git: clones to a temp dir and returns the path.
        For archive: extracts to a temp dir and returns the path.
        """
        ...

    @abstractmethod
    def supports(self, source: str) -> bool:
        """Return True if this adapter can handle the given source string."""
        ...

    def cleanup(self, path: Path):
        """Optional cleanup after processing (e.g. remove temp clone dirs)."""
        pass


# ── Local Folder Adapter (current implementation) ───────────────────────────

class LocalFolderAdapter(RepoSourceAdapter):
    """Resolves local filesystem paths. No-op adapter — path is already local."""

    name = "local"

    def resolve(self, source: str, **kwargs) -> Path:
        path = Path(source)
        if not path.exists():
            raise FileNotFoundError(f"Local path not found: {source}")
        return path

    def supports(self, source: str) -> bool:
        return Path(source).exists()


# ── Git URL Adapter (stub — ready for implementation) ────────────────────────

class GitRepoAdapter(RepoSourceAdapter):
    """
    Clones a Git repository to a local temp directory.
    NOT YET IMPLEMENTED — stub for future plug-and-play integration.

    Future implementation will:
      - Accept https:// or git:// URLs
      - Support branch/tag/commit selection
      - Clone to configurable workspace directory
      - Support shallow clone for performance
      - Cache cloned repos for incremental runs
    """

    name = "git"

    def resolve(self, source: str, **kwargs) -> Path:
        branch = kwargs.get("branch", "main")
        workspace = kwargs.get("workspace", Path.cwd() / ".mafia_workspace" / "git_clones")
        raise NotImplementedError(
            f"Git adapter not yet implemented. "
            f"To integrate: implement git clone of '{source}' (branch={branch}) "
            f"to workspace '{workspace}'. Use subprocess + git CLI or gitpython library."
        )

    def supports(self, source: str) -> bool:
        return source.startswith(("https://", "git://", "git@", "ssh://"))

    def cleanup(self, path: Path):
        if path.exists() and ".mafia_workspace" in str(path):
            shutil.rmtree(path, ignore_errors=True)


# ── Archive Adapter (stub — ready for implementation) ────────────────────────

class ArchiveAdapter(RepoSourceAdapter):
    """
    Extracts a zip/tar archive to a local temp directory.
    NOT YET IMPLEMENTED — stub for future plug-and-play integration.

    Future implementation will:
      - Accept .zip, .tar.gz, .tar.bz2 paths or URLs
      - Extract to configurable workspace directory
      - Handle nested archive structures
      - Support S3/HTTP URLs for remote archives
    """

    name = "archive"

    def resolve(self, source: str, **kwargs) -> Path:
        workspace = kwargs.get("workspace", Path.cwd() / ".mafia_workspace" / "archives")
        raise NotImplementedError(
            f"Archive adapter not yet implemented. "
            f"To integrate: extract '{source}' to workspace '{workspace}'. "
            f"Use zipfile/tarfile stdlib modules."
        )

    def supports(self, source: str) -> bool:
        return any(source.endswith(ext) for ext in ('.zip', '.tar.gz', '.tar.bz2', '.tgz'))

    def cleanup(self, path: Path):
        if path.exists() and ".mafia_workspace" in str(path):
            shutil.rmtree(path, ignore_errors=True)


# ── Adapter Registry ─────────────────────────────────────────────────────────

_ADAPTERS: list[RepoSourceAdapter] = [
    LocalFolderAdapter(),
    GitRepoAdapter(),
    ArchiveAdapter(),
]


def get_adapter(source: str) -> RepoSourceAdapter:
    """Auto-detect and return the appropriate adapter for a source string."""
    for adapter in _ADAPTERS:
        if adapter.supports(source):
            return adapter
    return LocalFolderAdapter()


def register_adapter(adapter: RepoSourceAdapter):
    """Register a custom adapter (e.g. S3, Azure DevOps, etc.)."""
    _ADAPTERS.insert(0, adapter)
