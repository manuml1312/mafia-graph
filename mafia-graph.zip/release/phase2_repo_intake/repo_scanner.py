"""
MAFIA Phase 2 — Repository Intake and Classification
=====================================================
Discovers repos on disk, detects tech stack, classifies layer type,
and produces repo_manifest.json.

Replaces the hardcoded BFF_REPOS / API_REPOS lists in the current system.

Usage:
    python -m phase2_repo_intake.repo_scanner --source-roots /path/to/marvel_repos /path/to/web_app
    python -m phase2_repo_intake.repo_scanner --source-roots c:/Users/MML/Downloads/d4u_marvel/marvel_repos c:/Users/MML/Downloads/d4u_marvel/test_flags/web_app_release
"""

import os
import re
import json
import argparse
import sys
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

# ── Constants ────────────────────────────────────────────────────────────────

SKIP_DIRS = {
    'node_modules', '.git', 'dist', 'build', 'out', 'target', '.idea',
    '.mvn', '.next', '.gradle', '__pycache__', '.venv', 'venv',
    '_scm_config', '_scm_container', '_scm_jenkins', 'wdyr',
    'test', 'tests', 'public',
}

# Extension groups for scan summary
EXTENSION_GROUPS = {
    'typescript': {'.ts', '.tsx'},
    'javascript': {'.js', '.jsx', '.mjs', '.cjs'},
    'java':       {'.java'},
    'python':     {'.py', '.ipynb'},
    'sql':        {'.sql'},
    'config':     {'.json', '.yaml', '.yml', '.xml', '.properties', '.toml', '.env'},
    'markup':     {'.html', '.css', '.scss', '.md', '.rst'},
}

ALL_SCANNABLE = set()
for exts in EXTENSION_GROUPS.values():
    ALL_SCANNABLE |= exts


# ── Stack Detection Signals ──────────────────────────────────────────────────

class StackSignal:
    """One piece of evidence for a tech stack or classification."""
    def __init__(self, stack: str, classification: str, confidence: float, reason: str, tier: str = "structure"):
        self.stack = stack
        self.classification = classification
        self.confidence = confidence
        self.reason = reason
        self.tier = tier


# ── Tier weights: how much to trust each signal source ───────────────────────
TIER_WEIGHTS = {
    "dependency": 1.0,    # package.json, pom.xml — most reliable
    "content":    0.70,   # content sampling — good but sampled
    "structure":  0.40,   # directory structure — suggestive only
    "folder":     0.30,   # folder name — weakest signal
}


def _detect_from_package_json(content: str) -> list[StackSignal]:
    """Detect stack from package.json dependencies."""
    signals = []
    try:
        pkg = json.loads(content)
    except Exception:
        return signals

    all_deps = {}
    for key in ('dependencies', 'devDependencies', 'peerDependencies'):
        all_deps.update(pkg.get(key, {}))

    dep_names = set(all_deps.keys())

    # React / Next.js → UI
    if 'react' in dep_names:
        signals.append(StackSignal('react', 'ui', 0.90, 'package.json has react dependency', tier='dependency'))
    if 'next' in dep_names:
        signals.append(StackSignal('next.js', 'ui', 0.95, 'package.json has next dependency', tier='dependency'))
    if 'recoil' in dep_names:
        signals.append(StackSignal('recoil', 'ui', 0.80, 'package.json has recoil dependency', tier='dependency'))
    if 'redux' in dep_names:
        signals.append(StackSignal('redux', 'ui', 0.80, 'package.json has redux dependency', tier='dependency'))

    # Koa / Express → BFF or API
    if 'koa' in dep_names:
        signals.append(StackSignal('koa', 'bff', 0.85, 'package.json has koa dependency', tier='dependency'))
    if 'express' in dep_names:
        signals.append(StackSignal('express', 'bff', 0.75, 'package.json has express dependency', tier='dependency'))

    # TypeScript
    if 'typescript' in dep_names:
        signals.append(StackSignal('typescript', '', 0.70, 'package.json has typescript', tier='dependency'))

    # Node
    if any(d.startswith('node') or d.startswith('@types/node') for d in dep_names):
        signals.append(StackSignal('node', '', 0.60, 'package.json has node types', tier='dependency'))

    return signals


def _detect_from_pom_xml(content: str) -> list[StackSignal]:
    """Detect stack from pom.xml."""
    signals = []

    if 'spring-boot' in content:
        signals.append(StackSignal('spring-boot', 'api', 0.90, 'pom.xml has spring-boot', tier='dependency'))
    if 'spring-boot-starter-web' in content:
        signals.append(StackSignal('spring-boot-web', 'api', 0.95, 'pom.xml has spring-boot-starter-web', tier='dependency'))
    if 'spring-data-jpa' in content or 'spring-boot-starter-data-jpa' in content:
        signals.append(StackSignal('jpa', 'api', 0.85, 'pom.xml has JPA dependency', tier='dependency'))
    if '<groupId>com.jnj' in content or '<groupId>com.janssen' in content:
        signals.append(StackSignal('java', '', 0.70, 'pom.xml is JnJ Java project', tier='dependency'))

    return signals


def _detect_from_build_gradle(content: str) -> list[StackSignal]:
    """Detect stack from build.gradle."""
    signals = []
    if 'spring-boot' in content:
        signals.append(StackSignal('spring-boot', 'api', 0.90, 'build.gradle has spring-boot', tier='dependency'))
    if 'org.springframework' in content:
        signals.append(StackSignal('spring', 'api', 0.85, 'build.gradle has spring', tier='dependency'))
    return signals


def _detect_from_requirements_txt(content: str) -> list[StackSignal]:
    """Detect stack from requirements.txt or setup.py."""
    signals = []
    lower = content.lower()
    if 'pyspark' in lower or 'databricks' in lower:
        signals.append(StackSignal('databricks', 'data', 0.90, 'requirements.txt has pyspark/databricks', tier='dependency'))
    if 'flask' in lower or 'fastapi' in lower or 'django' in lower:
        signals.append(StackSignal('python-web', 'api', 0.80, 'requirements.txt has web framework', tier='dependency'))
    return signals


# ── File Signature Detection (BOOSTER ONLY — low confidence) ─────────────────

def _detect_from_file_signatures(repo_path: Path, file_list: list[str]) -> list[StackSignal]:
    """
    Detect stack from file/directory structure.
    These are BOOSTERS, not primary classifiers. A project might use any naming
    convention — these just add a small nudge when patterns happen to match.
    Primary classification comes from dependency files and content sampling.
    """
    signals = []
    basenames = {os.path.basename(f) for f in file_list}
    rel_paths = {os.path.relpath(f, repo_path).replace('\\', '/') for f in file_list}

    # Language presence (stack detection only, not classification)
    ts_count = sum(1 for f in file_list if Path(f).suffix.lower() in ('.ts', '.tsx'))
    java_count = sum(1 for f in file_list if Path(f).suffix.lower() == '.java')
    py_count = sum(1 for f in file_list if Path(f).suffix.lower() in ('.py', '.ipynb'))
    sql_count = sum(1 for f in file_list if Path(f).suffix.lower() == '.sql')

    if ts_count > 0:
        signals.append(StackSignal('typescript', '', 0.30, f'{ts_count} .ts/.tsx files found'))
    if java_count > 0:
        signals.append(StackSignal('java', '', 0.30, f'{java_count} .java files found'))
    if py_count > 0:
        signals.append(StackSignal('python', '', 0.30, f'{py_count} .py/.ipynb files found'))

    # Directory structure boosters (low confidence)
    has_pages_dir = any('/pages/' in p or p.startswith('pages/') for p in rel_paths)
    has_components_dir = any('/components/' in p for p in rel_paths)
    has_routes_dir = any('/routes/' in p for p in rel_paths)
    has_controller_dir = any('/controller/' in p or '/controllers/' in p for p in rel_paths)
    has_service_dir = any('/service/' in p or '/services/' in p for p in rel_paths)
    has_repository_dir = any('/repository/' in p or '/repositories/' in p for p in rel_paths)
    has_model_dir = any('/model/' in p or '/models/' in p or '/entity/' in p for p in rel_paths)

    # Directory structure: Functions/ + Schema/ = database repo
    has_functions_dir = any('/Functions/' in p or '/functions/' in p for p in rel_paths)
    has_schema_dir = any('/Schema/' in p or '/schema/' in p or '/schemas/' in p for p in rel_paths)
    has_views_dir = any('/Views/' in p or '/views/' in p for p in rel_paths)
    has_migrations_dir = any('/migrations/' in p or '/migrate/' in p for p in rel_paths)

    if has_functions_dir and (has_schema_dir or has_views_dir):
        signals.append(StackSignal('functions+schema-dirs', 'db', 0.75,
                                   'Functions/ + Schema/ directories found — database repo'))
    elif has_functions_dir and sql_count > 10:
        signals.append(StackSignal('functions-dir+sql', 'db', 0.60,
                                   f'Functions/ directory with {sql_count} .sql files'))
    elif has_migrations_dir and sql_count > 5:
        signals.append(StackSignal('migrations+sql', 'db', 0.55,
                                   f'migrations/ directory with {sql_count} .sql files'))

    if has_pages_dir and has_components_dir:
        signals.append(StackSignal('pages+components', 'ui', 0.40,
                                   'pages/ + components/ directories found'))
    if has_routes_dir and has_controller_dir and ts_count > 0:
        signals.append(StackSignal('routes+controller-ts', 'bff', 0.40,
                                   'routes/ + controller/ dirs with TS files'))
    if has_controller_dir and has_service_dir and java_count > 0:
        signals.append(StackSignal('controller+service-java', 'api', 0.40,
                                   'controller/ + service/ dirs with Java files'))
    if has_repository_dir and has_model_dir:
        signals.append(StackSignal('repository+model', 'api', 0.35,
                                   'repository/ + model/ directories found'))

    # File type boosters (very low confidence)
    if sql_count > 0:
        signals.append(StackSignal('sql-files', 'db', 0.35,
                                   f'{sql_count} .sql files found'))
    # SQL-dominant repo: if >50% of scannable files are .sql, strong db signal
    total_scannable = len(file_list)
    if sql_count > 10 and total_scannable > 0 and sql_count / total_scannable > 0.50:
        signals.append(StackSignal('sql-dominant', 'db', 0.85,
                                   f'SQL-dominant repo: {sql_count}/{total_scannable} files are .sql'))
    elif sql_count > 20:
        signals.append(StackSignal('sql-heavy', 'db', 0.60,
                                   f'{sql_count} .sql files — likely a database repo'))
    if any(b.endswith('.ipynb') for b in basenames):
        signals.append(StackSignal('notebooks', 'data', 0.40,
                                   'Jupyter notebooks found'))

    # .env + pages = likely UI
    if any(b.startswith('.env') for b in basenames) and has_pages_dir:
        signals.append(StackSignal('env+pages', 'ui', 0.35,
                                   '.env files + pages/ directory'))

    return signals


# ── Content Sampling (for repos with no/weak dependency signals) ─────────────

CONTENT_SAMPLE_LIMIT = 15

def _detect_from_content_sampling(repo_path: Path, file_list: list[str]) -> list[StackSignal]:
    """
    When dependency files give no classification, sample actual source file
    contents to look for framework-specific patterns. Language-agnostic:
    looks for import/annotation/decorator patterns, not file names.
    """
    signals = []

    by_ext: dict[str, list[str]] = {}
    for f in file_list:
        ext = Path(f).suffix.lower()
        if ext in ('.ts', '.tsx', '.js', '.jsx', '.java', '.py', '.go', '.cs', '.rb', '.sql', '.html'):
            by_ext.setdefault(ext, []).append(f)

    sampled = []
    for ext, files in by_ext.items():
        prioritized = sorted(files, key=lambda f: (0 if '/src/' in f or '/app/' in f else 1, f))
        sampled.extend(prioritized[:max(2, CONTENT_SAMPLE_LIMIT // max(len(by_ext), 1))])
    sampled = sampled[:CONTENT_SAMPLE_LIMIT]

    ui_hits = bff_hits = api_hits = data_hits = db_hits = 0

    for fpath in sampled:
        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(8192)
        except Exception:
            continue

        ext = Path(fpath).suffix.lower()

        if ext in ('.ts', '.tsx', '.js', '.jsx'):
            if re.search(r'(?:import|require).*["\']react["\']', content):
                ui_hits += 1
            if re.search(r'(?:useState|useEffect|useContext|useReducer|useRef)\s*\(', content):
                ui_hits += 1
            if re.search(r'(?:router|app)\s*\.\s*(?:get|post|put|delete|patch|use)\s*\(', content):
                bff_hits += 1
            if re.search(r'(?:ctx|req|request)\s*\.\s*(?:body|params|query|headers)', content):
                bff_hits += 1
            if re.search(r'databricks|spark|pyspark', content, re.IGNORECASE):
                data_hits += 1

        elif ext == '.java':
            if re.search(r'@(?:RestController|Controller|RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping)', content):
                api_hits += 1
            if re.search(r'@(?:Service|Component|Repository|Entity|Table)', content):
                api_hits += 1
            if re.search(r'@Query\s*\(', content):
                db_hits += 1
            if re.search(r'extends\s+JpaRepository', content):
                api_hits += 1

        elif ext == '.py':
            if re.search(r'(?:from|import)\s+(?:pyspark|databricks|delta)', content):
                data_hits += 1
            if re.search(r'(?:from|import)\s+(?:flask|fastapi|django|starlette)', content):
                api_hits += 1
            if re.search(r'@(?:app|router)\s*\.\s*(?:get|post|put|delete|route)\s*\(', content):
                api_hits += 1
            if re.search(r'spark\s*\.\s*(?:read|sql|table|createDataFrame)', content):
                data_hits += 1
            if re.search(r'(?:from|import)\s+google\.cloud\.bigquery|BigQueryService|bq_client|_get_bq_service', content):
                db_hits += 1
            if re.search(r'client\.query\s*\(|insert_rows_json\s*\(|bq\.(?:get_all|insert|update|create)', content):
                db_hits += 1

        elif ext == '.html':
            # Jinja/Flask/Django templates — UI layer
            if re.search(r'\{%|\{\{|extends|block|include', content):
                ui_hits += 1
            if re.search(r'fetch\s*\(|axios\.|XMLHttpRequest|api/', content):
                ui_hits += 1  # template making API calls
            if re.search(r'CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION', content, re.IGNORECASE):
                db_hits += 2
            if re.search(r'CREATE\s+TABLE', content, re.IGNORECASE):
                db_hits += 1
            if re.search(r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:MATERIALIZED\s+)?VIEW', content, re.IGNORECASE):
                db_hits += 1

    total_sampled = len(sampled)
    if total_sampled == 0:
        return signals

    if ui_hits >= 2:
        conf = min(0.75, 0.40 + (ui_hits / total_sampled) * 0.35)
        signals.append(StackSignal('content-ui', 'ui', conf,
                                   f'Content sampling: {ui_hits} UI patterns in {total_sampled} files', tier='content'))
    if bff_hits >= 2:
        conf = min(0.75, 0.40 + (bff_hits / total_sampled) * 0.35)
        signals.append(StackSignal('content-bff', 'bff', conf,
                                   f'Content sampling: {bff_hits} BFF/server patterns in {total_sampled} files', tier='content'))
    if api_hits >= 2:
        conf = min(0.75, 0.40 + (api_hits / total_sampled) * 0.35)
        signals.append(StackSignal('content-api', 'api', conf,
                                   f'Content sampling: {api_hits} API patterns in {total_sampled} files', tier='content'))
    if data_hits >= 1:
        conf = min(0.75, 0.45 + (data_hits / total_sampled) * 0.30)
        signals.append(StackSignal('content-data', 'data', conf,
                                   f'Content sampling: {data_hits} data/Spark patterns in {total_sampled} files', tier='content'))
    if db_hits >= 1:
        conf = min(0.65, 0.35 + (db_hits / total_sampled) * 0.30)
        signals.append(StackSignal('content-db', 'db', conf,
                                   f'Content sampling: {db_hits} DB/query patterns in {total_sampled} files', tier='content'))

    return signals


# ── Folder Name Heuristic ────────────────────────────────────────────────────

def _detect_from_folder_name(folder_name: str) -> list[StackSignal]:
    """Low-confidence fallback: classify by folder name suffix."""
    signals = []
    lower = folder_name.lower()

    if lower.endswith('_bff') or '_bff-' in lower or '_bff_' in lower:
        signals.append(StackSignal('folder-name', 'bff', 0.60,
                                   f'Folder name contains _bff: {folder_name}', tier='folder'))
    if lower.endswith('_api') or '_api-' in lower or '_api_' in lower or 'api' == lower.split('_')[-1]:
        signals.append(StackSignal('folder-name', 'api', 0.60,
                                   f'Folder name contains _api: {folder_name}', tier='folder'))
    if 'web_app' in lower or 'webapp' in lower or 'frontend' in lower or 'ui' == lower:
        signals.append(StackSignal('folder-name', 'ui', 0.50,
                                   f'Folder name suggests UI: {folder_name}', tier='folder'))

    return signals


# ── Single Repo Scanner ──────────────────────────────────────────────────────

def scan_single_repo(repo_path: Path) -> dict:
    """Scan one repo directory. Returns a repo_manifest entry dict."""
    repo_id = repo_path.name
    all_files = []
    skipped_dirs_count = 0
    extension_counts = {}

    for root, dirs, filenames in os.walk(repo_path):
        orig_len = len(dirs)
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        skipped_dirs_count += (orig_len - len(dirs))

        for fname in filenames:
            fpath = os.path.join(root, fname)
            ext = Path(fname).suffix.lower()
            extension_counts[ext] = extension_counts.get(ext, 0) + 1
            all_files.append(fpath)

    scannable_files = [f for f in all_files if Path(f).suffix.lower() in ALL_SCANNABLE]

    # ── Collect signals (ordered: dependency > content > structure > name) ────
    signals: list[StackSignal] = []
    has_dependency_classification = False

    # Tier 1: Dependency file detection (HIGHEST priority, most reliable)
    for fpath in all_files:
        fname = os.path.basename(fpath)
        try:
            if fname == 'package.json' and os.path.getsize(fpath) < 500_000:
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                    dep_signals = _detect_from_package_json(f.read())
                    signals.extend(dep_signals)
                    if any(s.classification for s in dep_signals):
                        has_dependency_classification = True
            elif fname == 'pom.xml' and os.path.getsize(fpath) < 500_000:
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                    dep_signals = _detect_from_pom_xml(f.read())
                    signals.extend(dep_signals)
                    if any(s.classification for s in dep_signals):
                        has_dependency_classification = True
            elif fname in ('build.gradle', 'build.gradle.kts') and os.path.getsize(fpath) < 500_000:
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                    dep_signals = _detect_from_build_gradle(f.read())
                    signals.extend(dep_signals)
                    if any(s.classification for s in dep_signals):
                        has_dependency_classification = True
            elif fname in ('requirements.txt', 'setup.py', 'pyproject.toml') and os.path.getsize(fpath) < 200_000:
                with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                    dep_signals = _detect_from_requirements_txt(f.read())
                    signals.extend(dep_signals)
                    if any(s.classification for s in dep_signals):
                        has_dependency_classification = True
            elif fname == 'go.mod' and os.path.getsize(fpath) < 200_000:
                signals.append(StackSignal('go', 'api', 0.70, 'go.mod found', tier='dependency'))
                has_dependency_classification = True
            elif fname == 'Cargo.toml' and os.path.getsize(fpath) < 200_000:
                signals.append(StackSignal('rust', '', 0.50, 'Cargo.toml found', tier='dependency'))
            elif fname == 'Gemfile' and os.path.getsize(fpath) < 200_000:
                signals.append(StackSignal('ruby', '', 0.50, 'Gemfile found', tier='dependency'))
        except Exception:
            pass

    # Tier 2: Content sampling (when dependency files gave no classification)
    if not has_dependency_classification:
        signals.extend(_detect_from_content_sampling(repo_path, scannable_files))

    # Tier 3: File/directory structure boosters (always low confidence)
    signals.extend(_detect_from_file_signatures(repo_path, all_files))

    # Tier 4: Folder name heuristic (lowest priority fallback)
    signals.extend(_detect_from_folder_name(repo_id))

    # ── Aggregate classification ─────────────────────────────────────────────
    classification_scores: dict[str, float] = {}
    detected_stack = set()
    detection_reasons = []

    for sig in signals:
        if sig.stack:
            detected_stack.add(sig.stack)
        if sig.classification:
            weight = TIER_WEIGHTS.get(sig.tier, 0.40)
            weighted_conf = sig.confidence * weight
            current = classification_scores.get(sig.classification, 0.0)
            # Combine: 1 - (1-a)(1-b) — independent probability union on weighted values
            classification_scores[sig.classification] = 1.0 - (1.0 - current) * (1.0 - weighted_conf)
        detection_reasons.append(f"[{sig.tier}] {sig.reason}")

    # Pick classifications above threshold
    THRESHOLD = 0.40
    classifications = sorted(
        [(cls, score) for cls, score in classification_scores.items() if score >= THRESHOLD],
        key=lambda x: -x[1]
    )

    if not classifications:
        classifications = [('unknown', 0.0)]

    best_confidence = classifications[0][1] if classifications else 0.0

    # ── Detect sub-modules (monorepo support) ────────────────────────────────
    modules = []
    for child in sorted(repo_path.iterdir()):
        if child.is_dir() and child.name not in SKIP_DIRS:
            # Check if child looks like an independent module
            has_own_build = any(
                (child / f).exists()
                for f in ('package.json', 'pom.xml', 'build.gradle', 'setup.py', 'pyproject.toml')
            )
            if has_own_build:
                modules.append({
                    "module_id": f"{repo_id}/{child.name}",
                    "module_path": str(child),
                    "classification": [],  # filled by recursive scan if needed
                })

    return {
        "repo_id": repo_id,
        "repo_name": repo_id.replace('_', ' ').replace('-', ' ').title(),
        "root_path": str(repo_path),
        "classification": [c[0] for c in classifications],
        "classification_confidence": round(best_confidence, 3),
        "detected_stack": sorted(detected_stack),
        "detection_signals": detection_reasons,
        "modules": modules,
        "scan_summary": {
            "total_files": len(all_files),
            "scannable_files": len(scannable_files),
            "skipped_dirs": skipped_dirs_count,
            "file_extensions": dict(sorted(extension_counts.items(), key=lambda x: -x[1])),
        },
    }


# ── Multi-Root Discovery ─────────────────────────────────────────────────────

def discover_repos(source_roots: list[str]) -> list[Path]:
    """
    Given one or more root directories, discover all repo-like directories.
    A directory is a repo if it:
      - Contains source files directly, OR
      - Contains a build file (package.json, pom.xml, etc.), OR
      - Is a direct child of a source root (convention)
    """
    repos = []
    seen = set()

    for root_str in source_roots:
        root = Path(root_str)
        if not root.exists():
            print(f"[WARN] Source root not found: {root}")
            continue

        # Check if root itself is a repo (e.g. web_app_release/)
        build_files = {'package.json', 'pom.xml', 'build.gradle', 'setup.py', 'pyproject.toml'}
        root_has_build = any((root / bf).exists() for bf in build_files)

        if root_has_build:
            # Root itself is a repo
            if str(root) not in seen:
                repos.append(root)
                seen.add(str(root))
        else:
            # Root is a container — check if children look like real repos
            # (each child has its own build file) or if root is just a flat project
            children = [
                c for c in sorted(root.iterdir())
                if c.is_dir() and c.name not in SKIP_DIRS
            ]
            children_with_build = [
                c for c in children
                if any((c / bf).exists() for bf in build_files)
            ]

            if children_with_build:
                # True monorepo: each child is an independent repo
                for child in children_with_build:
                    if str(child) not in seen:
                        repos.append(child)
                        seen.add(str(child))
            elif children:
                # Children have no build files — root is a flat project
                # (e.g. codes_py/ containing static/ + templates/)
                if str(root) not in seen:
                    repos.append(root)
                    seen.add(str(root))
            else:
                # No subdirs — root itself is the repo
                if str(root) not in seen:
                    repos.append(root)
                    seen.add(str(root))

    return repos


# ── Main ─────────────────────────────────────────────────────────────────────

def build_manifest(source_roots: list[str], output_path: str, max_workers: int = 8) -> dict:
    """
    Discover repos, scan them in parallel, produce repo_manifest.json.
    Returns the manifest dict.
    """
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 2 — Repository Intake")
    print(f"{'='*60}")
    print(f"  Source roots: {source_roots}")

    # Discover
    repo_paths = discover_repos(source_roots)
    print(f"  Discovered {len(repo_paths)} repo(s)")

    if not repo_paths:
        print("  [ERROR] No repos found. Check source roots.")
        return {"generated_at": datetime.now(timezone.utc).isoformat(), "source_root": str(source_roots), "repos": []}

    # Scan in parallel
    print(f"  Scanning with {max_workers} workers...")
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        future_map = {pool.submit(scan_single_repo, rp): rp for rp in repo_paths}
        for future in as_completed(future_map):
            rp = future_map[future]
            try:
                result = future.result()
                results.append(result)
                cls = result['classification']
                conf = result['classification_confidence']
                stack = result['detected_stack'][:3]
                print(f"    [OK] {result['repo_id']:55s} -> {cls} ({conf:.2f}) [{', '.join(stack)}]")
            except Exception as e:
                print(f"    [FAIL] {rp.name}: {e}")
                results.append({
                    "repo_id": rp.name,
                    "repo_name": rp.name,
                    "root_path": str(rp),
                    "classification": ["unknown"],
                    "classification_confidence": 0.0,
                    "detected_stack": [],
                    "detection_signals": [f"Scan failed: {e}"],
                    "modules": [],
                    "scan_summary": {"total_files": 0, "scannable_files": 0, "skipped_dirs": 0, "file_extensions": {}},
                })

    # Sort by classification then name
    layer_order = {'ui': 0, 'bff': 1, 'api': 2, 'db': 3, 'data': 4, 'shared': 5, 'config': 6, 'unknown': 9}
    results.sort(key=lambda r: (layer_order.get(r['classification'][0], 9), r['repo_id']))

    manifest = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_roots": source_roots,
        "repos": results,
    }

    # Write
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with open(output, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    # Summary
    by_class = {}
    for r in results:
        for c in r['classification']:
            by_class[c] = by_class.get(c, 0) + 1

    total_files = sum(r['scan_summary']['total_files'] for r in results)
    total_scannable = sum(r['scan_summary']['scannable_files'] for r in results)

    print(f"\n{'='*60}")
    print(f"  Manifest saved -> {output}")
    print(f"  Repos: {len(results)}")
    print(f"  Files: {total_files} total, {total_scannable} scannable")
    print(f"  By classification: {by_class}")
    print(f"{'='*60}\n")

    return manifest


def main():
    parser = argparse.ArgumentParser(description='MAFIA Phase 2 — Repo Intake')
    parser.add_argument('--source-roots', nargs='+', required=True,
                        help='One or more root directories containing repos')
    parser.add_argument('--output', default=None,
                        help='Output path for repo_manifest.json')
    parser.add_argument('--workers', type=int, default=8,
                        help='Parallel scan workers (default: 8)')
    args = parser.parse_args()

    if args.output is None:
        # Default: write next to this script's parent
        script_dir = Path(__file__).resolve().parent.parent
        args.output = str(script_dir / 'output' / 'repo_manifest.json')

    build_manifest(args.source_roots, args.output, args.workers)


if __name__ == '__main__':
    main()
