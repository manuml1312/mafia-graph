"""
MAFIA Manifest Writer
=====================
Writes workspace_manifest.json (v2) and legacy repo_manifest.json from DiscoveryResult.
"""

import json
from pathlib import Path
from datetime import datetime, timezone

from phase2_repo_intake.scope_discovery import DiscoveryResult


def write_workspace_manifest(discovery: DiscoveryResult, output_dir: str) -> Path:
    """Write workspace_manifest.json and legacy repo_manifest.json."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    # Build workspace manifest
    repos_data = {}
    for repo in discovery.repos:
        repos_data[repo.name] = {
            "id": f"{discovery.codebase.name}/{repo.name}",
            "name": repo.name,
            "root": repo.root,
            "workspaces": [],
        }

    for ws in discovery.workspaces:
        repo_key = ws.repo
        if repo_key in repos_data:
            repos_data[repo_key]["workspaces"].append({
                "id": f"{discovery.codebase.name}/{ws.repo}/{ws.name}",
                "name": ws.name,
                "root": ws.root,
                "package_name": ws.package_name,
                "language_hint": ws.language_hint,
                "framework_hint": ws.framework_hint,
                "classification": list(ws.classification),
            })

    manifest = {
        "codebase": {
            "id": discovery.codebase.name,
            "root": discovery.codebase.root,
            "detected_at": datetime.now(timezone.utc).isoformat(),
        },
        "repos": list(repos_data.values()),
    }

    ws_path = out / "workspace_manifest.json"
    with open(ws_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    # Legacy repo_manifest.json (one entry per repo, first workspace classification)
    legacy_repos = []
    for repo in discovery.repos:
        repo_ws = [w for w in discovery.workspaces if w.repo == repo.name]
        classification = list(repo_ws[0].classification) if repo_ws else ["unknown"]
        legacy_repos.append({
            "repo_id": repo.name,
            "repo_name": repo.name,
            "root_path": repo.root,
            "classification": classification,
            "classification_confidence": 0.0,
            "detected_stack": [],
            "detection_signals": [],
            "modules": [],
            "scan_summary": {"total_files": 0, "scannable_files": 0,
                             "skipped_dirs": 0, "file_extensions": {}},
        })

    legacy = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_roots": [discovery.codebase.root],
        "repos": legacy_repos,
    }

    legacy_path = out / "repo_manifest.json"
    with open(legacy_path, "w", encoding="utf-8") as f:
        json.dump(legacy, f, indent=2, ensure_ascii=False)

    return ws_path
