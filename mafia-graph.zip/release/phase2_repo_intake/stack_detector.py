"""
MAFIA Stack Detector
====================
Detects tech stack and classification for a workspace root.
Split out from repo_scanner.py to run per-workspace instead of per-repo.
"""

from pathlib import Path
from dataclasses import dataclass, field

from phase2_repo_intake.repo_scanner import (
    _detect_from_package_json,
    _detect_from_pom_xml,
    _detect_from_build_gradle,
    _detect_from_requirements_txt,
    _detect_from_file_signatures,
    _detect_from_content_sampling,
    _detect_from_folder_name,
    StackSignal, TIER_WEIGHTS, ALL_SCANNABLE, SKIP_DIRS,
)
import os


@dataclass
class StackResult:
    classification: list[str] = field(default_factory=list)
    classification_confidence: float = 0.0
    detected_stack: list[str] = field(default_factory=list)
    primary_language: str = ""
    frameworks: list[str] = field(default_factory=list)
    signals: list[str] = field(default_factory=list)


def detect_stack(workspace_root: Path) -> StackResult:
    """Detect tech stack and classification for a workspace root directory."""
    all_files = []
    for root, dirs, filenames in os.walk(workspace_root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fname in filenames:
            all_files.append(os.path.join(root, fname))

    scannable_files = [f for f in all_files if Path(f).suffix.lower() in ALL_SCANNABLE]

    signals: list[StackSignal] = []
    has_dep_classification = False

    # Tier 1: dependency files
    for fpath in all_files:
        fname = os.path.basename(fpath)
        try:
            if fname == "package.json" and os.path.getsize(fpath) < 500_000:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    dep_sigs = _detect_from_package_json(f.read())
                    signals.extend(dep_sigs)
                    if any(s.classification for s in dep_sigs):
                        has_dep_classification = True
            elif fname == "pom.xml" and os.path.getsize(fpath) < 500_000:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    dep_sigs = _detect_from_pom_xml(f.read())
                    signals.extend(dep_sigs)
                    if any(s.classification for s in dep_sigs):
                        has_dep_classification = True
            elif fname in ("build.gradle", "build.gradle.kts") and os.path.getsize(fpath) < 500_000:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    dep_sigs = _detect_from_build_gradle(f.read())
                    signals.extend(dep_sigs)
                    if any(s.classification for s in dep_sigs):
                        has_dep_classification = True
            elif fname in ("requirements.txt", "setup.py", "pyproject.toml") and os.path.getsize(fpath) < 200_000:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    dep_sigs = _detect_from_requirements_txt(f.read())
                    signals.extend(dep_sigs)
                    if any(s.classification for s in dep_sigs):
                        has_dep_classification = True
        except Exception:
            pass

    # Tier 2: content sampling
    if not has_dep_classification:
        signals.extend(_detect_from_content_sampling(workspace_root, scannable_files))

    # Tier 3: structure
    signals.extend(_detect_from_file_signatures(workspace_root, all_files))

    # Tier 4: folder name
    signals.extend(_detect_from_folder_name(workspace_root.name))

    # Aggregate
    classification_scores: dict[str, float] = {}
    detected_stack = set()
    frameworks = set()

    for sig in signals:
        if sig.stack:
            detected_stack.add(sig.stack)
            if sig.tier == "dependency" and sig.classification:
                frameworks.add(sig.stack)
        if sig.classification:
            weight = TIER_WEIGHTS.get(sig.tier, 0.40)
            weighted_conf = sig.confidence * weight
            current = classification_scores.get(sig.classification, 0.0)
            classification_scores[sig.classification] = 1.0 - (1.0 - current) * (1.0 - weighted_conf)

    THRESHOLD = 0.40
    classifications = sorted(
        [(c, s) for c, s in classification_scores.items() if s >= THRESHOLD],
        key=lambda x: -x[1],
    )
    if not classifications:
        classifications = [("unknown", 0.0)]

    # Detect primary language
    lang_counts = {}
    for f in all_files:
        ext = Path(f).suffix.lower()
        if ext in (".ts", ".tsx"):
            lang_counts["typescript"] = lang_counts.get("typescript", 0) + 1
        elif ext in (".js", ".jsx"):
            lang_counts["javascript"] = lang_counts.get("javascript", 0) + 1
        elif ext == ".java":
            lang_counts["java"] = lang_counts.get("java", 0) + 1
        elif ext == ".py":
            lang_counts["python"] = lang_counts.get("python", 0) + 1
        elif ext == ".go":
            lang_counts["go"] = lang_counts.get("go", 0) + 1
        elif ext == ".rs":
            lang_counts["rust"] = lang_counts.get("rust", 0) + 1
        elif ext == ".cs":
            lang_counts["csharp"] = lang_counts.get("csharp", 0) + 1

    primary_lang = max(lang_counts, key=lang_counts.get) if lang_counts else ""

    return StackResult(
        classification=[c[0] for c in classifications],
        classification_confidence=round(classifications[0][1], 3),
        detected_stack=sorted(detected_stack),
        primary_language=primary_lang,
        frameworks=sorted(frameworks),
        signals=[f"[{s.tier}] {s.reason}" for s in signals],
    )
