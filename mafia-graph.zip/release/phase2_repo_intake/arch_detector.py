"""
MAFIA — Application Architecture Detector
==========================================
Runs BEFORE extraction. Scans source files to identify:

  1. UI layer type and how it calls backend
     - Jinja2/Django templates with fetch()/axios/url_for()
     - React/Next.js with fetch constants or hooks
     - Plain HTML with inline JS
     - Mobile/CLI (no UI layer)

  2. Backend framework and routing pattern
     - Flask: @app.route / @blueprint.route -> function name
     - FastAPI: @app.get/post -> function name
     - Django: urlpatterns -> view function
     - Express/Koa: router.get/post -> handler
     - Spring Boot: @GetMapping/@PostMapping -> method

  3. DB access pattern
     - BigQuery Python client: client.query() / insert_rows_json()
     - SQLAlchemy ORM: session.query() / db.session
     - Raw SQL: cursor.execute()
     - JPA/Hibernate: @Repository / JpaRepository
     - Mongoose/Prisma: model.find() / prisma.model
     - Databricks/PySpark: spark.sql() / df.write

  4. UI→Backend connection method
     - fetch('/api/path') -> match by http_path
     - axios.get('/api/path') -> match by http_path
     - url_for('function_name') -> match by function name
     - fetch constant: const URL = BASE + '/path' -> match by path_suffix
     - form action="/path" -> match by http_path

  5. Backend→DB connection method
     - Direct: route function calls db directly
     - Service layer: route -> service -> db
     - Repository pattern: route -> service -> repository -> db
     - Factory/getter: route -> get_db_service() -> db

Produces: arch_profile.json in output_dir
Used by: extractors, structural_relations, graph_builder, flow_intelligence
"""

import os
import re
import json
from pathlib import Path
from collections import defaultdict
from typing import Optional


# ── Pattern libraries ─────────────────────────────────────────────────────────

# UI framework detection
_UI_PATTERNS = {
    'jinja2':    [r'\{%\s*extends', r'\{%\s*block', r'\{%\s*include', r'url_for\s*\('],
    'django':    [r'\{%\s*url\s+', r'\{%\s*load\s+', r'{% csrf_token %}'],
    'react':     [r'import\s+React', r'useState\s*\(', r'useEffect\s*\(', r'JSX\.Element'],
    'nextjs':    [r'from\s+[\'"]next/', r'getServerSideProps', r'getStaticProps'],
    'vue':       [r'<template>', r'v-bind:', r'v-model=', r'@click='],
    'angular':   [r'@Component\s*\(', r'ngOnInit\s*\(', r'\[\(ngModel\)\]'],
    'vanilla_js': [r'document\.getElementById', r'document\.querySelector', r'addEventListener\s*\('],
}

# UI→Backend call patterns — each entry: (pattern, method, path_group, name_group)
_UI_CALL_PATTERNS = [
    # fetch('/api/path')
    (re.compile(r"""fetch\s*\(\s*['"`]([^'"`\s]+)['"`]"""), 'fetch_literal', 1, None),
    # fetch(CONSTANT) or fetch(url)
    (re.compile(r"""fetch\s*\(\s*(\w+)\s*[,)]"""), 'fetch_variable', None, 1),
    # axios.get/post/put/delete('/path')
    (re.compile(r"""axios\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*['"`]([^'"`\s]+)['"`]"""), 'axios_literal', 1, None),
    # url_for('function_name') — Jinja2/Flask
    (re.compile(r"""url_for\s*\(\s*['"]([^'"]+)['"]"""), 'url_for', None, 1),
    # $.ajax / $.get / $.post (jQuery)
    (re.compile(r"""\$\s*\.\s*(?:ajax|get|post)\s*\(\s*['"`]([^'"`\s]+)['"`]"""), 'jquery', 1, None),
    # XMLHttpRequest.open('GET', '/path')
    (re.compile(r"""\.open\s*\(\s*['"][A-Z]+['"]\s*,\s*['"`]([^'"`\s]+)['"`]"""), 'xhr', 1, None),
    # form action="/path"
    (re.compile(r"""<form[^>]+action\s*=\s*['"]([^'"]+)['"]"""), 'form_action', 1, None),
    # const URL = BASE_URL + '/path'  or  `${BASE}/path`
    (re.compile(r"""(?:const|let|var)\s+\w+\s*=\s*\w+\s*\+\s*['"`](/[^'"`\s]+)['"`]"""), 'fetch_constant', 1, None),
    (re.compile(r"""`\$\{\w+\}(/[^`\s]+)`"""), 'template_literal', 1, None),
]

# Backend framework routing patterns
_BACKEND_ROUTE_PATTERNS = {
    'flask': [
        re.compile(r"""@(?:app|bp|blueprint|api)\s*\.\s*route\s*\(\s*['"]([^'"]+)['"]"""),
        re.compile(r"""@(?:app|bp|blueprint|api)\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*['"]([^'"]+)['"]"""),
    ],
    'fastapi': [
        re.compile(r"""@(?:app|router)\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*['"]([^'"]+)['"]"""),
    ],
    'django': [
        re.compile(r"""path\s*\(\s*['"]([^'"]+)['"]\s*,\s*(\w+)"""),
        re.compile(r"""url\s*\(\s*r?['"]([^'"]+)['"]\s*,\s*(\w+)"""),
    ],
    'express': [
        re.compile(r"""(?:app|router)\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]"""),
    ],
    'koa': [
        re.compile(r"""router\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]"""),
    ],
    'spring': [
        re.compile(r"""@(?:Get|Post|Put|Delete|Patch|Request)Mapping\s*\(\s*(?:value\s*=\s*)?['"]([^'"]+)['"]"""),
    ],
}

# DB access patterns
_DB_PATTERNS = {
    'bigquery':    [r'bigquery\.Client', r'client\.query\s*\(', r'insert_rows_json\s*\(', r'BigQueryService'],
    'sqlalchemy':  [r'db\.session', r'session\.query\s*\(', r'Base\.metadata', r'Column\s*\('],
    'raw_sql':     [r'cursor\.execute\s*\(', r'connection\.execute\s*\(', r'psycopg2', r'pymysql'],
    'jpa':         [r'@Repository', r'JpaRepository', r'@Query\s*\(', r'EntityManager'],
    'mongoose':    [r'mongoose\.model', r'\.find\s*\(', r'\.findOne\s*\(', r'\.save\s*\('],
    'prisma':      [r'prisma\.\w+\.find', r'prisma\.\w+\.create', r'PrismaClient'],
    'pyspark':     [r'spark\.sql\s*\(', r'\.write\.', r'SparkSession', r'DataFrame'],
    'redis':       [r'redis\.Redis', r'r\.get\s*\(', r'r\.set\s*\('],
    'mongodb':     [r'MongoClient', r'\.find\s*\(', r'\.insert_one\s*\('],
    'firestore':   [r'firestore\.Client', r'\.collection\s*\(', r'\.document\s*\('],
}

# Backend→DB connection depth patterns
_DB_DEPTH_PATTERNS = {
    'direct':      [r'def\s+\w+.*:\s*\n.*(?:query|execute|insert|select)', r'@app\.route.*\n.*db\.'],
    'service':     [r'class\s+\w+Service', r'def\s+\w+_service\s*\(', r'service\s*=\s*\w+Service'],
    'repository':  [r'class\s+\w+Repository', r'Repository\s*\(', r'extends\s+JpaRepository'],
    'factory':     [r'def\s+_get_\w+\s*\(', r'def\s+get_\w+_client\s*\(', r'\w+Factory\s*\('],
}

SKIP_DIRS = {'node_modules', '.git', '__pycache__', '.venv', 'venv', 'dist',
             'build', 'out', 'target', '.next', '.gradle', '.idea'}


def detect_architecture(source_roots: list, output_dir: str) -> dict:
    """
    Scan all source files and produce an architecture profile.
    This runs BEFORE any extraction and guides all downstream phases.
    """
    print(f"\n{'='*60}")
    print(f"  MAFIA — Architecture Detection")
    print(f"{'='*60}")

    profile = {
        'source_roots': source_roots,
        'repos': [],
        'global': {
            'ui_frameworks': [],
            'backend_frameworks': [],
            'db_patterns': [],
            'ui_to_backend_methods': [],
            'backend_to_db_depth': [],
            'flow_patterns': [],
        },
        'extraction_hints': {},
    }

    for root in source_roots:
        root_path = Path(root)
        if not root_path.exists():
            continue
        repo_profile = _detect_repo(root_path)
        profile['repos'].append(repo_profile)
        print(f"\n  Repo: {root_path.name}")
        print(f"    UI frameworks:      {repo_profile['ui_frameworks']}")
        print(f"    Backend frameworks: {repo_profile['backend_frameworks']}")
        print(f"    DB patterns:        {repo_profile['db_patterns']}")
        print(f"    UI->Backend methods: {repo_profile['ui_to_backend_methods']}")
        print(f"    Backend->DB depth:   {repo_profile['backend_to_db_depth']}")
        print(f"    Route->function map: {len(repo_profile['route_to_function'])} routes")
        print(f"    UI calls found:     {len(repo_profile['ui_calls'])} calls")

    # Aggregate global profile
    for repo in profile['repos']:
        for k in ('ui_frameworks', 'backend_frameworks', 'db_patterns',
                  'ui_to_backend_methods', 'backend_to_db_depth'):
            for v in repo.get(k, []):
                if v not in profile['global'][k]:
                    profile['global'][k].append(v)

    # Derive flow patterns
    profile['global']['flow_patterns'] = _derive_flow_patterns(profile)

    # Produce extraction hints
    profile['extraction_hints'] = _build_extraction_hints(profile)

    print(f"\n  Flow patterns detected: {profile['global']['flow_patterns']}")
    print(f"  Extraction hints:")
    for k, v in profile['extraction_hints'].items():
        print(f"    {k}: {v}")
    print(f"{'='*60}\n")

    # Write profile
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / 'arch_profile.json', 'w', encoding='utf-8') as f:
        json.dump(profile, f, indent=2, ensure_ascii=False)

    return profile


def _detect_repo(root_path: Path) -> dict:
    """Scan one repo directory and build its architecture profile."""
    repo = {
        'root': str(root_path),
        'name': root_path.name,
        'ui_frameworks': [],
        'backend_frameworks': [],
        'db_patterns': [],
        'ui_to_backend_methods': [],
        'backend_to_db_depth': [],
        'route_to_function': {},   # http_path -> {function_name, file, line, method}
        'ui_calls': [],            # {type, path_or_name, file, line}
        'db_access_sites': [],     # {pattern, file, line}
        'service_classes': [],     # class names that are service/repository layers
        'file_roles': {},          # file -> detected role (ui/api/db/service/etc)
    }

    # Score accumulators
    ui_scores = defaultdict(int)
    be_scores = defaultdict(int)
    db_scores = defaultdict(int)
    depth_scores = defaultdict(int)
    ui_method_scores = defaultdict(int)

    for fpath in _walk_files(root_path):
        rel = os.path.relpath(fpath, root_path).replace('\\', '/')
        ext = Path(fpath).suffix.lower()

        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(65536)  # 64KB per file
        except Exception:
            continue

        if not content.strip():
            continue

        # ── UI framework detection ────────────────────────────────────────
        if ext in ('.html', '.jinja', '.jinja2', '.j2', '.htm'):
            for fw, patterns in _UI_PATTERNS.items():
                for pat in patterns:
                    if re.search(pat, content, re.IGNORECASE):
                        ui_scores[fw] += 2
                        break

        if ext in ('.js', '.jsx', '.ts', '.tsx'):
            for fw in ('react', 'nextjs', 'vue', 'angular', 'vanilla_js'):
                for pat in _UI_PATTERNS[fw]:
                    if re.search(pat, content):
                        ui_scores[fw] += 1

        # ── UI→Backend call detection ─────────────────────────────────────
        if ext in ('.html', '.js', '.jsx', '.ts', '.tsx', '.jinja', '.jinja2'):
            for pattern, method, path_grp, name_grp in _UI_CALL_PATTERNS:
                for m in pattern.finditer(content):
                    line = content[:m.start()].count('\n') + 1
                    path = m.group(path_grp) if path_grp else None
                    name = m.group(name_grp) if name_grp else None
                    # Skip infra paths
                    if path and any(path.startswith(p) for p in
                                    ('/static', '/favicon', '/health', '/ping', '/_')):
                        continue
                    repo['ui_calls'].append({
                        'type': method, 'path': path, 'name': name,
                        'file': rel, 'line': line,
                    })
                    ui_method_scores[method] += 1

        # ── Backend framework + route detection ───────────────────────────
        if ext in ('.py', '.js', '.ts', '.java', '.kt', '.go', '.rb', '.cs'):
            for fw, patterns in _BACKEND_ROUTE_PATTERNS.items():
                for pat in patterns:
                    for m in pat.finditer(content):
                        be_scores[fw] += 1
                        http_path = m.group(1)
                        # Try to find the function name after the decorator
                        after = content[m.end():m.end() + 300]
                        fn_match = re.search(
                            r'(?:def|function|async\s+function|func)\s+(\w+)\s*\(',
                            after
                        )
                        fn_name = fn_match.group(1) if fn_match else None
                        line = content[:m.start()].count('\n') + 1
                        if http_path and fn_name:
                            repo['route_to_function'][http_path] = {
                                'function': fn_name,
                                'file': rel,
                                'line': line,
                                'framework': fw,
                            }

        # ── DB pattern detection ──────────────────────────────────────────
        for db_type, patterns in _DB_PATTERNS.items():
            for pat in patterns:
                if re.search(pat, content):
                    db_scores[db_type] += 1
                    line_matches = [(content[:m.start()].count('\n') + 1)
                                    for m in re.finditer(pat, content)]
                    for line in line_matches[:3]:
                        repo['db_access_sites'].append({
                            'db_type': db_type, 'file': rel, 'line': line,
                        })
                    break

        # ── Backend→DB depth detection ────────────────────────────────────
        for depth, patterns in _DB_DEPTH_PATTERNS.items():
            for pat in patterns:
                if re.search(pat, content, re.MULTILINE):
                    depth_scores[depth] += 1

        # ── Service/Repository class detection ────────────────────────────
        for m in re.finditer(
            r'class\s+(\w+(?:Service|Repository|Manager|DAO|Store|Client))\s*[:(]',
            content
        ):
            cls_name = m.group(1)
            if cls_name not in repo['service_classes']:
                repo['service_classes'].append(cls_name)

        # ── File role assignment ──────────────────────────────────────────
        role = _infer_file_role(rel, content, ext)
        if role:
            repo['file_roles'][rel] = role

    # Consolidate scores into ranked lists
    repo['ui_frameworks'] = _top_keys(ui_scores, min_score=1)
    repo['backend_frameworks'] = _top_keys(be_scores, min_score=1)
    repo['db_patterns'] = _top_keys(db_scores, min_score=1)
    repo['backend_to_db_depth'] = _top_keys(depth_scores, min_score=1)

    # UI→Backend methods
    for method, score in sorted(ui_method_scores.items(), key=lambda x: -x[1]):
        if score > 0:
            repo['ui_to_backend_methods'].append(method)

    return repo


def _infer_file_role(rel_path: str, content: str, ext: str) -> Optional[str]:
    """Infer the architectural role of a file."""
    rel_lower = rel_path.lower()
    parts = rel_lower.replace('\\', '/').split('/')

    # Path-based
    if any(p in parts for p in ('templates', 'views', 'pages', 'components')):
        return 'ui'
    if any(p in parts for p in ('static', 'assets', 'public')):
        return 'static'
    if any(p in parts for p in ('migrations', 'schema', 'sql')):
        return 'db_schema'

    # Content-based
    if ext == '.html':
        return 'ui_template'
    if ext in ('.js', '.jsx', '.ts', '.tsx'):
        if re.search(r'useState|useEffect|React|render\s*\(', content):
            return 'ui_component'
        if re.search(r'router\.|app\.get|app\.post', content):
            return 'api_routes'
    if ext == '.py':
        if re.search(r'@app\.route|@blueprint\.route|@router\.(get|post)', content):
            return 'api_routes'
        if re.search(r'BigQueryService|bigquery\.Client|db\.session', content):
            return 'db_access'
        if re.search(r'class\s+\w+Service\s*[:(]', content):
            return 'service_layer'
    if ext == '.java':
        if re.search(r'@RestController|@Controller', content):
            return 'api_controller'
        if re.search(r'@Repository|JpaRepository', content):
            return 'db_repository'
        if re.search(r'@Service', content):
            return 'service_layer'
    return None


def _derive_flow_patterns(profile: dict) -> list:
    """
    Based on detected frameworks and methods, derive the actual
    UI→Backend→DB flow patterns present in this application.
    """
    patterns = []
    g = profile['global']

    ui_fws = g['ui_frameworks']
    be_fws = g['backend_frameworks']
    db_pats = g['db_patterns']
    ui_methods = g['ui_to_backend_methods']
    depths = g['backend_to_db_depth']

    # Determine UI→Backend connection type
    if 'url_for' in ui_methods:
        patterns.append('UI_JINJA2_URL_FOR -> FLASK_ROUTE')
    if 'fetch_literal' in ui_methods or 'fetch_variable' in ui_methods:
        patterns.append('UI_FETCH_HTTP_PATH -> BACKEND_ROUTE_BY_PATH')
    if 'axios_literal' in ui_methods:
        patterns.append('UI_AXIOS_HTTP_PATH -> BACKEND_ROUTE_BY_PATH')
    if 'fetch_constant' in ui_methods or 'template_literal' in ui_methods:
        patterns.append('UI_FETCH_CONSTANT -> BACKEND_ROUTE_BY_PATH_SUFFIX')
    if 'form_action' in ui_methods:
        patterns.append('UI_FORM_ACTION -> BACKEND_ROUTE_BY_PATH')

    # Determine Backend→DB connection type
    if 'factory' in depths:
        patterns.append('BACKEND_ROUTE -> FACTORY_GETTER -> DB_CLIENT')
    if 'service' in depths:
        patterns.append('BACKEND_ROUTE -> SERVICE_CLASS -> DB')
    if 'repository' in depths:
        patterns.append('BACKEND_ROUTE -> SERVICE -> REPOSITORY -> DB')
    if 'direct' in depths:
        patterns.append('BACKEND_ROUTE -> DB_DIRECT')

    # DB type
    for db in db_pats:
        patterns.append(f'DB_TYPE:{db.upper()}')

    return patterns


def _build_extraction_hints(profile: dict) -> dict:
    """
    Produce concrete hints for extractors and structural_relations
    based on the detected architecture.
    """
    hints = {}
    g = profile['global']
    ui_methods = g['ui_to_backend_methods']
    be_fws = g['backend_frameworks']
    db_pats = g['db_patterns']
    depths = g['backend_to_db_depth']

    # How to match UI calls to backend routes
    match_strategies = []
    if 'url_for' in ui_methods:
        match_strategies.append('function_name')   # url_for('fn_name') -> match by fn name
    if any(m in ui_methods for m in ('fetch_literal', 'axios_literal', 'form_action')):
        match_strategies.append('http_path')       # fetch('/api/x') -> match by path
    if any(m in ui_methods for m in ('fetch_constant', 'template_literal')):
        match_strategies.append('path_suffix')     # const URL = BASE + '/x' -> match suffix
    if any(m in ui_methods for m in ('fetch_variable',)):
        match_strategies.append('variable_resolve') # fetch(VAR) -> resolve VAR to path
    hints['ui_to_backend_match_strategies'] = match_strategies or ['http_path', 'function_name']

    # Backend route extraction method
    if 'flask' in be_fws:
        hints['backend_route_extractor'] = 'flask_decorator'
        hints['route_id_format'] = 'function_name'  # Flask uses function names in url_for
    elif 'fastapi' in be_fws:
        hints['backend_route_extractor'] = 'fastapi_decorator'
        hints['route_id_format'] = 'function_name'
    elif 'django' in be_fws:
        hints['backend_route_extractor'] = 'django_urlpatterns'
        hints['route_id_format'] = 'view_name'
    elif 'express' in be_fws or 'koa' in be_fws:
        hints['backend_route_extractor'] = 'js_router'
        hints['route_id_format'] = 'http_path'
    elif 'spring' in be_fws:
        hints['backend_route_extractor'] = 'spring_mapping'
        hints['route_id_format'] = 'http_path'
    else:
        hints['backend_route_extractor'] = 'generic'
        hints['route_id_format'] = 'http_path'

    # DB extraction method
    hints['db_extractors_needed'] = db_pats or ['generic']

    # Cross-layer stitching strategy
    stitch_strategies = []
    if 'factory' in depths:
        stitch_strategies.append('bridge_factory')
    if 'service' in depths or 'repository' in depths:
        stitch_strategies.append('class_import')
    if 'direct' in depths:
        stitch_strategies.append('direct_call')
    hints['cross_layer_stitch_strategies'] = stitch_strategies or ['bridge_factory', 'class_import']

    # Build route→function map from all repos
    route_map = {}
    for repo in profile['repos']:
        for path, info in repo.get('route_to_function', {}).items():
            route_map[path] = info
    hints['route_to_function_map'] = route_map

    # Build UI call inventory
    ui_call_paths = set()
    ui_call_names = set()
    for repo in profile['repos']:
        for call in repo.get('ui_calls', []):
            if call.get('path'):
                ui_call_paths.add(call['path'])
            if call.get('name'):
                ui_call_names.add(call['name'])
    hints['ui_http_paths'] = sorted(ui_call_paths)
    hints['ui_url_for_names'] = sorted(ui_call_names)

    return hints


def _walk_files(root: Path):
    """Walk directory yielding file paths, skipping noise dirs."""
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fname in files:
            ext = Path(fname).suffix.lower()
            if ext in ('.py', '.js', '.jsx', '.ts', '.tsx', '.html', '.jinja',
                       '.jinja2', '.j2', '.java', '.kt', '.go', '.rb', '.cs',
                       '.php', '.vue', '.svelte', '.erb', '.haml'):
                yield os.path.join(dirpath, fname)


def _top_keys(scores: dict, min_score: int = 1) -> list:
    """Return keys sorted by score descending, filtered by min_score."""
    return [k for k, v in sorted(scores.items(), key=lambda x: -x[1]) if v >= min_score]


def load_arch_profile(output_dir: str) -> dict:
    """Load existing arch_profile.json if available."""
    path = Path(output_dir) / 'arch_profile.json'
    if path.exists():
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {}
