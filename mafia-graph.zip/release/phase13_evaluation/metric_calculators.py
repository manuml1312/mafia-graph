"""
MAFIA Phase 13 — Metric Calculators
======================================
Computes precision, recall, and F1 of current extraction against gold datasets.
Also computes extraction drift metrics between the current run and baseline.

Metrics produced:
  - Entity precision/recall/F1 (overall + per-layer + per-type)
  - Relation precision/recall/F1
  - Flow recall (what % of gold flows are still found)
  - Drift: new entities, lost entities, confidence shifts

Output:
  output/benchmark/evaluation_report.json

Usage:
    python -m phase13_evaluation.metric_calculators
"""

import json
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def evaluate(output_dir: str) -> dict:
    """Compare current artifacts against gold benchmark datasets."""
    output = Path(output_dir)
    bench_dir = output / "benchmark"

    if not (bench_dir / "gold_entities.jsonl").exists():
        print("[WARN] No gold datasets found. Run gold_dataset_builder first.")
        return {"status": "no_gold_data"}

    # ── Load gold + current ──────────────────────────────────────────────────
    gold_entities = {e["id"]: e for e in _load_jsonl(bench_dir / "gold_entities.jsonl")}
    gold_relations = {_rel_key(r): r for r in _load_jsonl(bench_dir / "gold_relations.jsonl")}
    gold_flows_data = _load_json(bench_dir / "gold_flows.json")
    gold_flow_ids = {f.get("flow_id", f.get("entry", "")) for f in gold_flows_data.get("flows", [])}

    curr_entities = {e["id"]: e for e in _load_jsonl(output / "entities.jsonl")}
    curr_relations = {_rel_key(r): r for r in _load_jsonl(output / "relations.jsonl")}
    curr_flows_data = _load_json(output / "e2e_flows.json")
    curr_flow_ids = set()
    for catalog in curr_flows_data.get("catalogs", {}).values():
        flows_list = catalog if isinstance(catalog, list) else catalog.get("flows", [])
        for f in flows_list:
            curr_flow_ids.add(f.get("flow_id", f.get("entry", "")))

    # ── Entity metrics ───────────────────────────────────────────────────────
    entity_overall = _prf(gold_entities.keys(), curr_entities.keys())

    entity_by_layer = {}
    for layer in _unique_vals(gold_entities.values(), "layer"):
        gold_layer = {eid for eid, e in gold_entities.items() if e.get("layer") == layer}
        curr_layer = {eid for eid, e in curr_entities.items() if e.get("layer") == layer}
        entity_by_layer[layer] = _prf(gold_layer, curr_layer)

    entity_by_type = {}
    for etype in _unique_vals(gold_entities.values(), "type"):
        gold_type = {eid for eid, e in gold_entities.items() if e.get("type") == etype}
        curr_type = {eid for eid, e in curr_entities.items() if e.get("type") == etype}
        entity_by_type[etype] = _prf(gold_type, curr_type)

    # ── Relation metrics ─────────────────────────────────────────────────────
    relation_overall = _prf(gold_relations.keys(), curr_relations.keys())

    # ── Flow recall ──────────────────────────────────────────────────────────
    flow_recall = len(gold_flow_ids & curr_flow_ids) / max(len(gold_flow_ids), 1)

    # ── Drift analysis ───────────────────────────────────────────────────────
    new_entities = list(curr_entities.keys() - gold_entities.keys())
    lost_entities = list(gold_entities.keys() - curr_entities.keys())

    conf_shifts = []
    for eid in gold_entities.keys() & curr_entities.keys():
        gold_conf = gold_entities[eid].get("confidence", 0)
        curr_conf = curr_entities[eid].get("confidence", 0)
        delta = curr_conf - gold_conf
        if abs(delta) > 0.05:
            conf_shifts.append({"id": eid, "gold": gold_conf, "current": curr_conf, "delta": round(delta, 3)})

    # ── Build report ─────────────────────────────────────────────────────────
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "gold_counts": {
            "entities": len(gold_entities),
            "relations": len(gold_relations),
            "flows": len(gold_flow_ids),
        },
        "current_counts": {
            "entities": len(curr_entities),
            "relations": len(curr_relations),
            "flows": len(curr_flow_ids),
        },
        "entity_metrics": {
            "overall": entity_overall,
            "by_layer": entity_by_layer,
            "by_type": entity_by_type,
        },
        "relation_metrics": {"overall": relation_overall},
        "flow_metrics": {"recall": round(flow_recall, 4)},
        "drift": {
            "new_entities": len(new_entities),
            "lost_entities": len(lost_entities),
            "lost_entity_ids": lost_entities[:20],
            "confidence_shifts": len(conf_shifts),
            "confidence_shift_samples": conf_shifts[:20],
        },
        "passed": entity_overall["recall"] >= 0.95 and relation_overall["recall"] >= 0.90,
    }

    report_path = bench_dir / "evaluation_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # ── Print ────────────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 13 — Evaluation Report")
    print(f"{'='*60}")
    print(f"  Entity  P={entity_overall['precision']:.3f}  R={entity_overall['recall']:.3f}  F1={entity_overall['f1']:.3f}")
    print(f"  Relation P={relation_overall['precision']:.3f}  R={relation_overall['recall']:.3f}  F1={relation_overall['f1']:.3f}")
    print(f"  Flow recall: {flow_recall:.3f}")
    print(f"  Drift: +{len(new_entities)} new, -{len(lost_entities)} lost, {len(conf_shifts)} conf shifts")
    print(f"  Gate: {'PASSED' if report['passed'] else 'FAILED'}")
    print(f"  Report: {report_path}")
    print(f"{'='*60}\n")

    return report


# ── Helpers ──────────────────────────────────────────────────────────────────

def _prf(gold_set, current_set):
    """Precision, recall, F1 between two ID sets."""
    gold_set = set(gold_set)
    current_set = set(current_set)
    tp = len(gold_set & current_set)
    precision = tp / max(len(current_set), 1)
    recall = tp / max(len(gold_set), 1)
    f1 = 2 * precision * recall / max(precision + recall, 1e-9)
    return {"precision": round(precision, 4), "recall": round(recall, 4), "f1": round(f1, 4),
            "tp": tp, "fp": len(current_set - gold_set), "fn": len(gold_set - current_set)}


def _rel_key(r):
    return f"{r.get('source', '')}--{r.get('type', '')}-->{r.get('target', '')}"


def _unique_vals(items, key):
    return sorted({item.get(key, "unknown") for item in items})


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    evaluate(str(base / "output"))
