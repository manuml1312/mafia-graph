"""
MAFIA Phase 13 — Gold Dataset Builder
========================================
Samples high-confidence entities, relations, and flows from current artifacts
to create benchmark gold datasets for precision/recall evaluation.

Strategies:
  - Entities:  all entities with confidence >= 0.90 and evidence_method in (regex, ast)
  - Relations: all relations whose source AND target are gold entities
  - Flows:     all complete flows where every hop is a gold entity

Output:
  output/benchmark/gold_entities.jsonl
  output/benchmark/gold_relations.jsonl
  output/benchmark/gold_flows.json
  output/benchmark/gold_manifest.json   (metadata: counts, date, sampling criteria)

Usage:
    python -m phase13_evaluation.gold_dataset_builder
    python -m phase13_evaluation.gold_dataset_builder --min-confidence 0.85
"""

import json
import argparse
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ── Defaults ─────────────────────────────────────────────────────────────────
GOLD_CONFIDENCE = 0.90
GOLD_METHODS = {"regex", "ast"}


def build_gold_dataset(output_dir: str, min_confidence: float = GOLD_CONFIDENCE,
                       methods: set = None) -> dict:
    """Build gold benchmark datasets from current high-confidence artifacts."""
    methods = methods or GOLD_METHODS
    output = Path(output_dir)
    bench_dir = output / "benchmark"
    bench_dir.mkdir(parents=True, exist_ok=True)

    # ── Load source artifacts ────────────────────────────────────────────────
    entities = _load_jsonl(output / "entities.jsonl")
    relations = _load_jsonl(output / "relations.jsonl")
    flows_data = _load_json(output / "e2e_flows.json")

    # ── Gold entities: high confidence + deterministic method ────────────────
    gold_entities = []
    gold_ids = set()
    for e in entities:
        conf = e.get("confidence", 0)
        method = e.get("evidence", {}).get("method", e.get("evidence_method", ""))
        if conf >= min_confidence and method in methods:
            gold_entities.append(e)
            gold_ids.add(e.get("id", ""))

    # ── Gold relations: both endpoints are gold entities ─────────────────────
    gold_relations = []
    for r in relations:
        src = r.get("source", "")
        tgt = r.get("target", "")
        if src in gold_ids and tgt in gold_ids:
            gold_relations.append(r)

    # ── Gold flows: every hop is a gold entity ───────────────────────────────
    gold_flows = []
    all_catalogs = flows_data.get("catalogs", {})
    for catalog_name, catalog in all_catalogs.items():
        flows_list = catalog if isinstance(catalog, list) else catalog.get("flows", [])
        for flow in flows_list:
            hops = flow.get("standard", flow.get("hops", []))
            hop_ids = [h.get("id", "") for h in hops]
            if hop_ids and all(hid in gold_ids for hid in hop_ids):
                gold_flows.append(flow)

    # ── Write gold datasets ──────────────────────────────────────────────────
    _write_jsonl(bench_dir / "gold_entities.jsonl", gold_entities)
    _write_jsonl(bench_dir / "gold_relations.jsonl", gold_relations)
    with open(bench_dir / "gold_flows.json", 'w', encoding='utf-8') as f:
        json.dump({"flows": gold_flows}, f, indent=2, ensure_ascii=False)

    # ── Gold manifest ────────────────────────────────────────────────────────
    manifest = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sampling_criteria": {
            "min_confidence": min_confidence,
            "allowed_methods": sorted(methods),
        },
        "source_totals": {
            "entities": len(entities),
            "relations": len(relations),
        },
        "gold_totals": {
            "entities": len(gold_entities),
            "relations": len(gold_relations),
            "flows": len(gold_flows),
        },
        "gold_entity_layers": _count_by(gold_entities, "layer"),
        "gold_entity_types": _count_by(gold_entities, "type"),
        "gold_rate": {
            "entities": len(gold_entities) / max(len(entities), 1),
            "relations": len(gold_relations) / max(len(relations), 1),
        },
    }
    with open(bench_dir / "gold_manifest.json", 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    # ── Print summary ────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 13 — Gold Dataset Builder")
    print(f"{'='*60}")
    print(f"  Criteria: confidence >= {min_confidence}, methods = {sorted(methods)}")
    print(f"  Gold entities:  {len(gold_entities):>6} / {len(entities)} ({len(gold_entities)/max(len(entities),1):.1%})")
    print(f"  Gold relations: {len(gold_relations):>6} / {len(relations)} ({len(gold_relations)/max(len(relations),1):.1%})")
    print(f"  Gold flows:     {len(gold_flows):>6}")
    print(f"  Output: {bench_dir}")
    print(f"{'='*60}\n")

    return manifest


# ── Helpers ──────────────────────────────────────────────────────────────────

def _count_by(items, key):
    counts = {}
    for item in items:
        val = item.get(key, "unknown")
        counts[val] = counts.get(val, 0) + 1
    return counts


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


def _write_jsonl(path, items):
    with open(path, 'w', encoding='utf-8') as f:
        for item in items:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='MAFIA Gold Dataset Builder')
    parser.add_argument('--min-confidence', type=float, default=GOLD_CONFIDENCE,
                        help=f'Minimum confidence for gold entities (default: {GOLD_CONFIDENCE})')
    parser.add_argument('--output-dir', default=None)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    output_dir = args.output_dir or str(base / "output")
    build_gold_dataset(output_dir, min_confidence=args.min_confidence)
