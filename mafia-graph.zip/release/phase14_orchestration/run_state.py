"""
MAFIA Phase 14 — Run State Persistence
=========================================
Tracks per-repo extraction fingerprints (file count + total size + mtime max)
so incremental mode can skip repos whose source files haven't changed.

Stores:
  output/run_state.json — last successful run state per repo

Usage:
    from phase14_orchestration.run_state import RunState
    rs = RunState(output_dir)
    if rs.repo_changed(repo_id, repo_path):
        # run extraction
        rs.mark_done(repo_id, repo_path)
    rs.save()
"""

import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


STATE_FILE = "run_state.json"

# ── Skip dirs (same as extractors) ───────────────────────────────────────────
SKIP_DIRS = {"node_modules", ".git", "__pycache__", "dist", "build", ".next",
             "target", ".gradle", ".idea", ".vscode", "venv", ".env"}


class RunState:
    """Persistent run state for incremental extraction."""

    def __init__(self, output_dir: str):
        self._path = Path(output_dir) / STATE_FILE
        self._state = self._load()

    def _load(self) -> dict:
        if self._path.exists():
            try:
                with open(self._path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {"version": 1, "repos": {}, "last_full_run": None}

    def save(self):
        """Persist current state to disk."""
        with open(self._path, 'w', encoding='utf-8') as f:
            json.dump(self._state, f, indent=2, ensure_ascii=False)

    def repo_changed(self, repo_id: str, repo_path: str) -> bool:
        """Check if a repo's source files have changed since last run."""
        current_fp = _fingerprint(repo_path)
        prev = self._state["repos"].get(repo_id, {})
        prev_fp = prev.get("fingerprint", "")
        return current_fp != prev_fp

    def mark_done(self, repo_id: str, repo_path: str, extractor_names: list = None):
        """Record that a repo was successfully extracted."""
        self._state["repos"][repo_id] = {
            "fingerprint": _fingerprint(repo_path),
            "extracted_at": datetime.now(timezone.utc).isoformat(),
            "extractors": extractor_names or [],
        }

    def mark_full_run(self):
        """Record that a full pipeline run completed."""
        self._state["last_full_run"] = datetime.now(timezone.utc).isoformat()

    def get_last_run(self, repo_id: str) -> dict:
        return self._state["repos"].get(repo_id, {})

    def get_all_repos(self) -> dict:
        return dict(self._state["repos"])

    def clear(self):
        self._state = {"version": 1, "repos": {}, "last_full_run": None}


def _fingerprint(repo_path: str) -> str:
    """Fast fingerprint: hash of (file_count, total_size, max_mtime)."""
    root = Path(repo_path)
    if not root.exists():
        return ""
    file_count = 0
    total_size = 0
    max_mtime = 0.0
    for p in root.rglob("*"):
        if p.is_file() and not any(skip in p.parts for skip in SKIP_DIRS):
            file_count += 1
            try:
                st = p.stat()
                total_size += st.st_size
                max_mtime = max(max_mtime, st.st_mtime)
            except OSError:
                pass
    raw = f"{file_count}:{total_size}:{max_mtime:.6f}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]
