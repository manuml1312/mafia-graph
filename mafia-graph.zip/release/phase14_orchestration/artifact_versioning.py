"""
MAFIA Phase 14 — Artifact Versioning
=======================================
Stamps every pipeline run with a monotonic version number.
Maintains a version log so artifacts can be compared or rolled back.

Stores:
  output/artifact_versions.json — version history with per-run stats

Usage:
    from phase14_orchestration.artifact_versioning import ArtifactVersioner
    av = ArtifactVersioner(output_dir)
    version = av.next_version()
    # ... run pipeline ...
    av.record(version, stats_dict)
"""

import json
import shutil
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


VERSION_FILE = "artifact_versions.json"

# ── Artifacts to snapshot ────────────────────────────────────────────────────
VERSIONED_ARTIFACTS = [
    "entities.jsonl", "relations.jsonl", "repo_manifest.json",
    "coverage_report.json", "mapping_confidence_report.json",
    "quality_gate_report.json", "system_graph.json", "e2e_flows.json",
]


class ArtifactVersioner:
    """Manages artifact version history and optional snapshots."""

    def __init__(self, output_dir: str):
        self._output = Path(output_dir)
        self._path = self._output / VERSION_FILE
        self._history = self._load()

    def _load(self) -> dict:
        if self._path.exists():
            try:
                with open(self._path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                pass
        return {"versions": []}

    def _save(self):
        with open(self._path, 'w', encoding='utf-8') as f:
            json.dump(self._history, f, indent=2, ensure_ascii=False)

    def next_version(self) -> int:
        """Return the next version number."""
        versions = self._history.get("versions", [])
        if not versions:
            return 1
        return max(v.get("version", 0) for v in versions) + 1

    def current_version(self) -> int:
        versions = self._history.get("versions", [])
        if not versions:
            return 0
        return max(v.get("version", 0) for v in versions)

    def record(self, version: int, stats: dict = None, snapshot: bool = False):
        """Record a completed pipeline run as a version entry."""
        entry = {
            "version": version,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "artifacts": {},
            "stats": stats or {},
        }

        for artifact in VERSIONED_ARTIFACTS:
            p = self._output / artifact
            if p.exists():
                st = p.stat()
                entry["artifacts"][artifact] = {
                    "size": st.st_size,
                    "mtime": datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
                }

        if snapshot:
            self._snapshot(version)
            entry["snapshot"] = True

        self._history["versions"].append(entry)
        self._save()

        print(f"  [VERSION] v{version} recorded — {len(entry['artifacts'])} artifacts tracked")
        return entry

    def _snapshot(self, version: int):
        """Copy current artifacts to a versioned snapshot directory."""
        snap_dir = self._output / "snapshots" / f"v{version}"
        snap_dir.mkdir(parents=True, exist_ok=True)
        for artifact in VERSIONED_ARTIFACTS:
            src = self._output / artifact
            if src.exists():
                shutil.copy2(src, snap_dir / artifact)

    def diff(self, v1: int = None, v2: int = None) -> dict:
        """Compare stats between two versions. Defaults to last two."""
        versions = self._history.get("versions", [])
        if len(versions) < 2:
            return {"error": "Need at least 2 versions to diff"}

        by_ver = {v["version"]: v for v in versions}
        if v1 is None:
            v1 = versions[-2]["version"]
        if v2 is None:
            v2 = versions[-1]["version"]

        e1 = by_ver.get(v1, {}).get("stats", {})
        e2 = by_ver.get(v2, {}).get("stats", {})

        changes = {}
        all_keys = set(e1.keys()) | set(e2.keys())
        for k in sorted(all_keys):
            old = e1.get(k)
            new = e2.get(k)
            if old != new and isinstance(old, (int, float)) and isinstance(new, (int, float)):
                changes[k] = {"old": old, "new": new, "delta": new - old}

        return {"v1": v1, "v2": v2, "changes": changes}

    def get_history(self) -> list:
        return list(self._history.get("versions", []))
