"""
MAFIA Phase 14 — Pipeline Orchestrator (redirect)
====================================================
This module redirects to the unified pipeline runner at:
    phase3_extraction_framework.run_extraction

All flags are supported:
    python -m phase14_orchestration.orchestrator                     # incremental (default)
    python -m phase14_orchestration.orchestrator --full              # full re-extract
    python -m phase14_orchestration.orchestrator --from-phase 9      # rebuild graph onward
    python -m phase14_orchestration.orchestrator --snapshot --evaluate
"""

from phase3_extraction_framework.run_extraction import main

if __name__ == "__main__":
    main()
