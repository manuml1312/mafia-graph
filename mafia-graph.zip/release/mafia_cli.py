"""
MAFIA CLI — Agent-Friendly Codebase Intelligence Tool
=======================================================
Lightweight CLI that AI agents (Amazon Q, Claude, etc.) can invoke
to initialize MAFIA on any project and query the graph.

No Flask server needed. Reads artifacts directly from .mafia/ in the
target project root.

Usage (from any project directory):
    python -m MAFIA_Phase1_Execution.mafia_cli init [--source-roots .]
    python -m MAFIA_Phase1_Execution.mafia_cli search "getFlagTypes"
    python -m MAFIA_Phase1_Execution.mafia_cli trace "api:endpoint:flags_api:GET:/flagTypes"
    python -m MAFIA_Phase1_Execution.mafia_cli blast "api:service:flags_api:FlagServiceImpl"
    python -m MAFIA_Phase1_Execution.mafia_cli flows --node "bff:endpoint:flags_bff:/flagTypes"
    python -m MAFIA_Phase1_Execution.mafia_cli neighbors "api:controller:flags_api:FlagController"
    python -m MAFIA_Phase1_Execution.mafia_cli status
    python -m MAFIA_Phase1_Execution.mafia_cli update
"""

import argparse
import json
import os
import sys
import shutil
from pathlib import Path
from datetime import datetime, timezone

_MAFIA_ROOT = Path(__file__).resolve().parent
if str(_MAFIA_ROOT) not in sys.path:
    sys.path.insert(0, str(_MAFIA_ROOT))

MAFIA_DIR = ".mafia"
CONFIG_FILE = "mafia.json"


# ── Helpers ──────────────────────────────────────────────────────────────────

def _find_mafia_dir(start: Path = None) -> Path:
    """Walk up from start to find .mafia/ directory."""
    cur = start or Path.cwd()
    for _ in range(10):
        candidate = cur / MAFIA_DIR
        if candidate.is_dir() and (candidate / CONFIG_FILE).exists():
            return candidate
        if cur.parent == cur:
            break
        cur = cur.parent
    return None


def _load_config(mafia_dir: Path) -> dict:
    cfg_path = mafia_dir / CONFIG_FILE
    if cfg_path.exists():
        return json.loads(cfg_path.read_text(encoding="utf-8"))
    return {}


def _save_config(mafia_dir: Path, config: dict):
    with open(mafia_dir / CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def _output_dir(mafia_dir: Path) -> str:
    return str(mafia_dir / "output")


def _load_graph_query(mafia_dir: Path):
    """Load GraphQuery from .mafia/output/ artifacts."""
    from phase9_graph.graph_query import GraphQuery
    out = _output_dir(mafia_dir)
    graph_path = os.path.join(out, "system_graph.json")
    flows_path = os.path.join(out, "e2e_flows.json")
    if not os.path.exists(graph_path):
        print(f"ERROR: No graph found at {graph_path}. Run 'mafia init' first.")
        sys.exit(1)
    gq = GraphQuery(graph_path, flows_path if os.path.exists(flows_path) else None)
    return gq


def _print_json(data):
    print(json.dumps(data, indent=2, ensure_ascii=False))


# ── Commands ─────────────────────────────────────────────────────────────────

def cmd_init(args):
    """Initialize MAFIA on the target project."""
    project_root = Path(args.project_path).resolve()
    if not project_root.is_dir():
        print(f"ERROR: {project_root} is not a directory.")
        sys.exit(1)

    mafia_dir = project_root / MAFIA_DIR
    mafia_dir.mkdir(parents=True, exist_ok=True)
    out_dir = mafia_dir / "output"
    out_dir.mkdir(exist_ok=True)

    source_roots = args.source_roots or [str(project_root)]
    source_roots = [str(Path(s).resolve()) for s in source_roots]

    print(f"\n  MAFIA init: {project_root}")
    print(f"  Source roots: {source_roots}")
    print(f"  Output: {out_dir}\n")

    # Phase 2: Scan repos
    from phase2_repo_intake.repo_scanner import build_manifest
    manifest_path = str(out_dir / "repo_manifest.json")
    build_manifest(source_roots, manifest_path, max_workers=args.workers)

    # Phase 2b: Architecture detection
    from phase2_repo_intake.arch_detector import detect_architecture
    detect_architecture(source_roots, str(out_dir))

    # Phase 2c: Symbol index
    from phase3_extraction_framework.symbol_resolver import build_symbol_index
    build_symbol_index(source_roots, str(out_dir))

    # Phase 3+: Full extraction pipeline (via subprocess to avoid argparse conflicts)
    import subprocess
    cmd = [
        sys.executable, "-m", "phase3_extraction_framework.run_extraction",
        "--manifest", manifest_path,
        "--output-dir", str(out_dir),
        "--repo-workers", str(args.workers),
    ]
    if args.full:
        cmd.append("--full")
    print(f"\n  Running extraction pipeline...")
    result = subprocess.run(cmd, cwd=str(_MAFIA_ROOT))
    if result.returncode != 0:
        print(f"  [WARN] Pipeline exited with code {result.returncode}")

    # Save config
    config = {
        "version": 1,
        "project_root": str(project_root),
        "source_roots": source_roots,
        "mafia_root": str(_MAFIA_ROOT),
        "initialized_at": datetime.now(timezone.utc).isoformat(),
        "output_dir": str(out_dir),
    }
    _save_config(mafia_dir, config)

    # Install agent rules
    _install_agent_rules(project_root, mafia_dir)

    # Register in central project registry
    _register_project(str(project_root), name=project_root.name)

    print(f"\n  [OK] MAFIA initialized at {mafia_dir}")
    print(f"  [OK] Agent rules installed")
    print(f"  Run 'mafia status' to check, 'mafia update' after code changes.\n")


def cmd_update(args):
    """Incremental update — re-scan changed repos, rebuild graph."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found. Run 'mafia init' first.")
        sys.exit(1)

    config = _load_config(mafia_dir)
    out_dir = _output_dir(mafia_dir)
    manifest_path = os.path.join(out_dir, "repo_manifest.json")

    if not os.path.exists(manifest_path):
        print("ERROR: No manifest found. Run 'mafia init' first.")
        sys.exit(1)

    print(f"\n  MAFIA update (incremental): {config.get('project_root', '?')}\n")

    # Re-scan repos
    source_roots = config.get("source_roots", [])
    from phase2_repo_intake.repo_scanner import build_manifest
    build_manifest(source_roots, manifest_path, max_workers=4)

    # Symbol index refresh
    from phase3_extraction_framework.symbol_resolver import build_symbol_index
    build_symbol_index(source_roots, out_dir)

    # Incremental extraction (via subprocess)
    import subprocess
    cmd = [
        sys.executable, "-m", "phase3_extraction_framework.run_extraction",
        "--manifest", manifest_path,
        "--output-dir", out_dir,
    ]
    print(f"\n  Running incremental extraction pipeline...")
    result = subprocess.run(cmd, cwd=str(_MAFIA_ROOT))
    if result.returncode != 0:
        print(f"  [WARN] Pipeline exited with code {result.returncode}")

    # Update timestamp
    config["last_updated"] = datetime.now(timezone.utc).isoformat()
    _save_config(mafia_dir, config)
    print(f"\n  [OK] Update complete.\n")


def cmd_status(args):
    """Show MAFIA status for the current project."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print(json.dumps({"initialized": False, "error": "No .mafia/ found. Run 'mafia init'."}))
        return

    config = _load_config(mafia_dir)
    out = _output_dir(mafia_dir)

    # Ensure this project is in the central registry
    project_root = config.get("project_root", str(mafia_dir.parent))
    _register_project(project_root)

    # Count artifacts
    entities = relations = flows = nodes = 0
    ent_path = os.path.join(out, "entities.jsonl")
    rel_path = os.path.join(out, "relations.jsonl")
    graph_path = os.path.join(out, "system_graph.json")
    flows_path = os.path.join(out, "e2e_flows.json")

    if os.path.exists(ent_path):
        with open(ent_path, "r", encoding="utf-8") as f:
            entities = sum(1 for _ in f)
    if os.path.exists(rel_path):
        with open(rel_path, "r", encoding="utf-8") as f:
            relations = sum(1 for _ in f)
    if os.path.exists(graph_path):
        g = json.loads(Path(graph_path).read_text(encoding="utf-8"))
        nodes = g.get("meta", {}).get("node_count", 0)
    if os.path.exists(flows_path):
        fl = json.loads(Path(flows_path).read_text(encoding="utf-8"))
        for cat_flows in fl.get("catalogs", {}).values():
            flows += len(cat_flows) if isinstance(cat_flows, list) else 0

    _print_json({
        "initialized": True,
        "project_root": config.get("project_root", ""),
        "source_roots": config.get("source_roots", []),
        "initialized_at": config.get("initialized_at", ""),
        "last_updated": config.get("last_updated", ""),
        "entities": entities,
        "relations": relations,
        "graph_nodes": nodes,
        "flows": flows,
        "output_dir": out,
    })


def cmd_search(args):
    """Search entities by name/keyword."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found. Run 'mafia init' first.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    results = gq.find_by_name(
        args.query,
        layer=args.layer,
        node_type=args.type,
        min_confidence=args.min_confidence,
        limit=args.limit,
    )
    _print_json({"query": args.query, "count": len(results), "results": results})


def cmd_trace(args):
    """Trace the full call chain from an entity downstream."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    result = gq.trace_flow(args.entity_id, max_depth=args.depth)
    _print_json(result)


def cmd_blast(args):
    """Compute blast radius for an entity."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    nb = gq.neighborhood(args.entity_id, direction=args.direction, depth=args.depth,
                         node_budget=args.budget)
    # Enrich with layer counts
    by_layer = {}
    for n in nb.get("nodes", []):
        l = n.get("layer", "unknown")
        by_layer[l] = by_layer.get(l, 0) + 1
    nb["by_layer"] = by_layer
    _print_json(nb)


def cmd_flows(args):
    """List flows, optionally filtered by node."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    if args.node:
        results = gq.flows_for_node(args.node, limit=args.limit)
        _print_json({"node": args.node, "count": len(results), "flows": results})
    else:
        summary = gq.flow_summary()
        _print_json(summary)


def cmd_neighbors(args):
    """Get immediate neighbors of an entity."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    nb = gq.neighborhood(args.entity_id, direction=args.direction, depth=1,
                         node_budget=args.limit)
    _print_json(nb)


def cmd_path(args):
    """Find shortest path between two entities."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    result = gq.find_path(args.source, args.target, max_depth=args.depth)
    if result:
        _print_json(result)
    else:
        _print_json({"error": "No path found", "source": args.source, "target": args.target})


def cmd_orphans(args):
    """List orphan entities (dead code candidates)."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    gq = _load_graph_query(mafia_dir)
    _print_json({
        "bff_no_ui_caller": gq.orphan_bff_no_ui()[:args.limit],
        "api_no_bff_caller": gq.orphan_api_no_bff()[:args.limit],
        "db_no_api_caller": gq.orphan_db_no_api()[:args.limit],
        "ui_no_bff_target": gq.orphan_ui_no_bff()[:args.limit],
    })


def cmd_workspaces(args):
    """List workspaces in the project."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    m = _open_mafia(mafia_dir)
    _print_json({"workspaces": m.workspaces})


def cmd_repos(args):
    """List repos in the project."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    m = _open_mafia(mafia_dir)
    _print_json({"repos": m.repos})


def cmd_tree(args):
    """Show entity tree grouped by layer."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    out = _output_dir(mafia_dir)
    views_path = os.path.join(out, "graph_views.json")
    if not os.path.exists(views_path):
        print("ERROR: No graph_views.json. Run pipeline first.")
        sys.exit(1)
    views = json.loads(Path(views_path).read_text(encoding="utf-8"))
    layer_view = views.get("layer_view", {}).get("layers", {})
    tree = {layer: data.get("node_count", 0) for layer, data in layer_view.items()}
    _print_json({"tree": tree})


def cmd_workspace_deps(args):
    """Show workspace dependency edges."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    out = _output_dir(mafia_dir)
    ws_graph_path = os.path.join(out, "workspace_graph.json")
    if os.path.exists(ws_graph_path):
        _print_json(json.loads(Path(ws_graph_path).read_text(encoding="utf-8")))
    else:
        _print_json({"error": "No workspace_graph.json. Run pipeline first."})


def cmd_shared(args):
    """Show shared resources (libs, tables, envs)."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    m = _open_mafia(mafia_dir)
    _print_json({
        "shared_libs": m.shared_libs(),
        "shared_tables": m.shared_tables(),
        "shared_envs": m.shared_envs(),
    })


def cmd_cross_edges(args):
    """Show cross-repo or cross-workspace edges."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    m = _open_mafia(mafia_dir)
    if args.boundary == "repo":
        edges = m.cross_repo_edges()
    else:
        edges = m.cross_workspace_edges()
    _print_json({"boundary": args.boundary, "count": len(edges), "edges": edges[:args.limit]})


def cmd_skill(args):
    """Skill adapter commands: spec or serve."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found.")
        sys.exit(1)
    m = _open_mafia(mafia_dir)
    skill = m.as_skill()
    if args.skill_action == "spec":
        _print_json(skill.describe(format=args.format))
    elif args.skill_action == "serve":
        if args.transport == "http":
            print(f"Starting skill HTTP server on {args.host}:{args.port}")
            skill.serve_http(host=args.host, port=args.port)
        elif args.transport == "mcp":
            skill.serve_mcp(transport="stdio")


def cmd_index(args):
    """Build or update the vector search index."""
    mafia_dir = _find_mafia_dir()
    if not mafia_dir:
        print("ERROR: No .mafia/ found. Run 'mafia init' first.")
        sys.exit(1)
    out_dir = _output_dir(mafia_dir)
    import subprocess
    cmd = [
        sys.executable, "-m", "phase11_search.vector_index",
        "--output-dir", out_dir,
    ]
    if args.incremental:
        cmd.append("--incremental")
    print(f"\n  Building {'incremental ' if args.incremental else ''}vector index...\n")
    subprocess.run(cmd, cwd=str(_MAFIA_ROOT))


def cmd_serve(args):
    """Start the MAFIA API server and UI."""
    mafia_dir = _find_mafia_dir()
    out_dir = _output_dir(mafia_dir) if mafia_dir else str(_MAFIA_ROOT / "output")
    import subprocess
    cmd = [
        sys.executable, "-m", "phase11_search.search_api1",
        "--output-dir", out_dir,
        "--port", str(args.port),
        "--host", args.host,
    ]
    print(f"\n  Starting MAFIA server at http://{args.host}:{args.port}\n")
    subprocess.run(cmd, cwd=str(_MAFIA_ROOT))


def cmd_purge(args):
    """Completely remove MAFIA from the system: all projects, registry, and pip package."""
    reg = _load_registry()
    projects = reg.get("projects", [])

    print("\n  MAFIA System Purge")
    print(f"  This will remove MAFIA from {len(projects)} project(s) and uninstall the package.\n")

    if not args.yes and not args.dry_run:
        confirm = input("  Type YES to confirm full purge: ").strip()
        if confirm != "YES":
            print("  Aborted.")
            return

    # 1. Uninstall from every registered project
    for p in projects:
        project_root = Path(p["path"])
        print(f"  Cleaning {project_root.name} ({project_root})...")

        mafia_dir = project_root / MAFIA_DIR
        if mafia_dir.exists():
            if not args.dry_run:
                shutil.rmtree(mafia_dir)
            print(f"    {'[dry-run] ' if args.dry_run else ''}Removed {mafia_dir}")

        for rule_path in [
            project_root / ".amazonq" / "rules" / "mafia-agent.md",
            project_root / ".kiro" / "rules" / "mafia-agent.md",
        ]:
            if rule_path.exists():
                if not args.dry_run:
                    rule_path.unlink()
                print(f"    {'[dry-run] ' if args.dry_run else ''}Removed {rule_path}")

        claude_md = project_root / "CLAUDE.md"
        if claude_md.exists():
            content = claude_md.read_text(encoding="utf-8")
            header = "# MAFIA Codebase Intelligence"
            if header in content:
                if not args.dry_run:
                    idx = content.index(header)
                    claude_md.write_text(content[:idx].rstrip() + "\n", encoding="utf-8")
                print(f"    {'[dry-run] ' if args.dry_run else ''}Removed MAFIA section from {claude_md.name}")

    # 2. Remove ~/.mafia/ (central registry + any global state)
    home_mafia = Path.home() / ".mafia"
    if home_mafia.exists():
        if not args.dry_run:
            shutil.rmtree(home_mafia)
        print(f"\n  {'[dry-run] ' if args.dry_run else ''}Removed {home_mafia}")

    # 3. Pip uninstall
    import subprocess
    result = subprocess.run(
        [sys.executable, "-m", "pip", "show", "mafia-intel"],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        if args.dry_run:
            print("  [dry-run] Would run: pip uninstall mafia-intel -y")
        else:
            subprocess.run([sys.executable, "-m", "pip", "uninstall", "mafia-intel", "-y"])
            print("  [OK] pip uninstall mafia-intel")
    else:
        print("  [skip] mafia-intel not installed as pip package (running from source)")

    print()
    if args.dry_run:
        print("  Dry run complete. Nothing was changed. Remove --dry-run to apply.")
    else:
        print("  MAFIA has been fully removed from your system.")
        print("  The source folder itself was not deleted — remove it manually if needed.")


def cmd_uninstall(args):
    """Remove MAFIA from a project: delete .mafia/, agent rules, and registry entry."""
    project_root = Path(args.project_path).resolve()
    if not project_root.is_dir():
        print(f"ERROR: {project_root} is not a directory.")
        sys.exit(1)

    removed = []
    skipped = []

    # 1. Remove .mafia/ directory
    mafia_dir = project_root / MAFIA_DIR
    if mafia_dir.exists():
        if args.dry_run:
            print(f"  [dry-run] Would remove: {mafia_dir}")
        else:
            shutil.rmtree(mafia_dir)
            removed.append(str(mafia_dir))
            print(f"  [OK] Removed {mafia_dir}")
    else:
        skipped.append(str(mafia_dir) + " (not found)")

    # 2. Remove .amazonq/rules/mafia-agent.md
    amazonq_rule = project_root / ".amazonq" / "rules" / "mafia-agent.md"
    if amazonq_rule.exists():
        if args.dry_run:
            print(f"  [dry-run] Would remove: {amazonq_rule}")
        else:
            amazonq_rule.unlink()
            removed.append(str(amazonq_rule))
            print(f"  [OK] Removed {amazonq_rule}")
    else:
        skipped.append(str(amazonq_rule) + " (not found)")

    # 3. Remove MAFIA section from CLAUDE.md
    claude_md = project_root / "CLAUDE.md"
    if claude_md.exists():
        content = claude_md.read_text(encoding="utf-8")
        header = "# MAFIA Codebase Intelligence"
        if header in content:
            if args.dry_run:
                print(f"  [dry-run] Would remove MAFIA section from {claude_md}")
            else:
                idx = content.index(header)
                content = content[:idx].rstrip() + "\n"
                claude_md.write_text(content, encoding="utf-8")
                removed.append(str(claude_md) + " (MAFIA section)")
                print(f"  [OK] Removed MAFIA section from {claude_md}")
        else:
            skipped.append(str(claude_md) + " (no MAFIA section)")

    # 4. Remove .kiro/rules/mafia-agent.md
    kiro_rule = project_root / ".kiro" / "rules" / "mafia-agent.md"
    if kiro_rule.exists():
        if args.dry_run:
            print(f"  [dry-run] Would remove: {kiro_rule}")
        else:
            kiro_rule.unlink()
            removed.append(str(kiro_rule))
            print(f"  [OK] Removed {kiro_rule}")

    # 5. Remove from central registry
    project_root_str = str(project_root)
    reg = _load_registry()
    before = len(reg["projects"])
    reg["projects"] = [p for p in reg["projects"] if p.get("path") != project_root_str]
    if len(reg["projects"]) < before:
        if args.dry_run:
            print(f"  [dry-run] Would remove {project_root_str} from registry")
        else:
            _save_registry(reg)
            removed.append("registry entry")
            print(f"  [OK] Removed from central registry")
    else:
        skipped.append("registry entry (not found)")

    print()
    if args.dry_run:
        print("  Dry run complete. Nothing was changed. Remove --dry-run to apply.")
    else:
        print(f"  Uninstall complete. Removed {len(removed)} item(s).")
        if skipped:
            print(f"  Skipped: {', '.join(skipped)}")


def cmd_migrate(args):
    """Migrate entity IDs from v1 to v2 format."""
    from mafia.compat import migrate_id
    result = migrate_id(args.entity_id)
    _print_json({"input": args.entity_id, "output": result})


def _open_mafia(mafia_dir: Path):
    """Open a MAFIA instance from .mafia/ dir."""
    from mafia import MAFIA
    return MAFIA.open(str(mafia_dir))


# ── Central Project Registry ─────────────────────────────────────────────────

def _registry_path() -> Path:
    """Central registry lives in ~/.mafia/projects.json"""
    return Path.home() / ".mafia" / "projects.json"


def _load_registry() -> dict:
    p = _registry_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"projects": []}


def _save_registry(reg: dict):
    p = _registry_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(reg, f, indent=2, ensure_ascii=False)


def _register_project(project_root: str, name: str = ""):
    """Add or update a project in the central registry."""
    from datetime import datetime, timezone
    reg = _load_registry()
    project_root = str(Path(project_root).resolve())
    now = datetime.now(timezone.utc).isoformat()
    existing = next((p for p in reg["projects"] if p["path"] == project_root), None)
    if existing:
        existing["last_updated"] = now
        if name:
            existing["name"] = name
    else:
        reg["projects"].append({
            "name": name or Path(project_root).name,
            "path": project_root,
            "mafia_dir": str(Path(project_root) / MAFIA_DIR),
            "output_dir": str(Path(project_root) / MAFIA_DIR / "output"),
            "created_at": now,
            "last_updated": now,
        })
    _save_registry(reg)


def cmd_hub(args):
    """Start MAFIA Hub -- multi-project dashboard."""
    reg = _load_registry()
    projects = reg.get("projects", [])

    # Register all known projects as sessions in the server's registry
    server_registry_path = _MAFIA_ROOT / "output" / ".sessions.json"
    server_registry_path.parent.mkdir(parents=True, exist_ok=True)
    sessions = []
    active = None
    for p in projects:
        out = p.get("output_dir", "")
        if out and Path(out).exists():
            sessions.append({
                "name": p.get("name", Path(p["path"]).name),
                "path": out,
                "created_at": p.get("created_at", ""),
                "last_used": p.get("last_updated", ""),
            })
            if active is None:
                active = out
    server_reg = {"active": active, "sessions": sessions}
    with open(server_registry_path, "w", encoding="utf-8") as f:
        json.dump(server_reg, f, indent=2)

    print(f"\n  MAFIA Hub")
    print(f"  {len(projects)} project(s) registered:")
    for p in projects:
        has_data = (Path(p["output_dir"]) / "system_graph.json").exists() if p.get("output_dir") else False
        status = "[OK]" if has_data else "[--]"
        print(f"    {status} {p['name']:30s} {p['path']}")
    print(f"\n  Starting server on http://localhost:{args.port}")
    print(f"  Switch between projects in the UI session dropdown.\n")

    # Start the server
    import subprocess
    cmd = [
        sys.executable, "-m", "phase11_search.search_api1",
        "--port", str(args.port),
    ]
    subprocess.run(cmd, cwd=str(_MAFIA_ROOT))


def cmd_projects(args):
    """List all initialized MAFIA projects."""
    reg = _load_registry()
    projects = reg.get("projects", [])
    if not projects:
        print(json.dumps({"projects": [], "message": "No projects initialized. Run 'mafia init /path/to/project'."}))
        return
    result = []
    for p in projects:
        out = p.get("output_dir", "")
        has_graph = (Path(out) / "system_graph.json").exists() if out else False
        entities = 0
        ent_path = os.path.join(out, "entities.jsonl") if out else ""
        if ent_path and os.path.exists(ent_path):
            with open(ent_path, "r", encoding="utf-8") as f:
                entities = sum(1 for _ in f)
        result.append({
            "name": p.get("name", ""),
            "path": p.get("path", ""),
            "output_dir": out,
            "has_graph": has_graph,
            "entities": entities,
            "last_updated": p.get("last_updated", ""),
        })
    _print_json({"projects": result})


# ── Agent Rules Installer ────────────────────────────────────────────────────

def cmd_configure_ai(args):
    """Configure AI credentials for Gemini features."""
    from utils.ai_config import AIConfig

    if args.show:
        cfg = AIConfig()
        _print_json(cfg.to_dict())
        if not cfg.ai_available:
            print(f"\n  [WARN] AI unavailable: {cfg.reason_unavailable}")
        return

    cfg = AIConfig()
    if args.sa_key:
        cfg.sa_key_path = str(Path(args.sa_key).resolve())
    if args.cert_file:
        cfg.cert_file = str(Path(args.cert_file).resolve())
    if args.project:
        cfg.gcp_project = args.project
    if args.location:
        cfg.gcp_location = args.location
    if args.model:
        cfg.gemini_model = args.model

    if not cfg.sa_key_path:
        print("ERROR: --sa-key is required. Provide path to Google service account JSON key.")
        sys.exit(1)

    cfg.save()
    _print_json(cfg.to_dict())
    if cfg.ai_available:
        print("\n  [OK] AI configured and ready.")
    else:
        print(f"\n  [WARN] AI config saved but: {cfg.reason_unavailable}")


def _sample_entities(mafia_dir: Path, count: int = 3) -> list[dict]:
    """Pick a few real entities from the graph to use as examples in rules."""
    ent_path = mafia_dir / "output" / "entities.jsonl"
    if not ent_path.exists():
        return []
    samples = []
    seen_layers = set()
    with open(ent_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
                layer = e.get("layer", "")
                if layer not in seen_layers and e.get("id"):
                    samples.append(e)
                    seen_layers.add(layer)
                if len(samples) >= count:
                    break
            except Exception:
                continue
    return samples


def _build_rule_content(mafia_dir: Path, project_root: Path) -> str:
    """Build the agent rule content with real examples from this project's graph."""
    samples = _sample_entities(mafia_dir)

    # Count entities/relations for the header
    entities = relations = 0
    ent_path = mafia_dir / "output" / "entities.jsonl"
    rel_path = mafia_dir / "output" / "relations.jsonl"
    if ent_path.exists():
        with open(ent_path, "r", encoding="utf-8") as f:
            entities = sum(1 for _ in f)
    if rel_path.exists():
        with open(rel_path, "r", encoding="utf-8") as f:
            relations = sum(1 for _ in f)

    # Build example commands from real entities
    if samples:
        s0 = samples[0]
        qual = s0.get("qualifier", s0.get("id", "main"))
        # Extract a clean search-friendly name from the qualifier
        # e.g. "mafia_cli.py::_find_mafia_dir" -> "_find_mafia_dir"
        # e.g. "FlagController.getFlagTypes" -> "getFlagTypes"
        for sep in ["::", "."]:
            if sep in qual:
                qual = qual.rsplit(sep, 1)[-1]
        search_term = qual
        example_id = s0.get("id", "layer:type:repo:qualifier")
        example_lines = f"""```bash
# Search for any entity (function, class, table, endpoint)
mafia search "{search_term}" --limit 10

# Who calls this (upstream neighbors)
mafia neighbors "{example_id}" --direction upstream

# What this calls (downstream neighbors)
mafia neighbors "{example_id}" --direction downstream

# Full blast radius — what breaks if this changes
mafia blast "{example_id}" --direction downstream

# Trace the downstream call chain
mafia trace "{example_id}" --depth 10

# End-to-end flows through a node
mafia flows --node "{example_id}"
"""
        if len(samples) >= 2:
            s1 = samples[1]
            example_lines += f"""
# Shortest path between two entities
mafia path "{example_id}" "{s1.get('id', 'layer:type:repo:other')}"
"""
        example_lines += """\n# Dead code candidates
mafia orphans

# Project graph stats
mafia status

# Refresh graph after code changes
mafia update
```"""
    else:
        search_term = "main"
        example_id = "layer:type:repo:qualifier"
        example_lines = """```bash
mafia search "<name>" --limit 10
mafia neighbors "<entity_id>" --direction upstream
mafia neighbors "<entity_id>" --direction downstream
mafia blast "<entity_id>" --direction downstream
mafia trace "<entity_id>" --depth 10
mafia flows --node "<entity_id>"
mafia path "<source_id>" "<target_id>"
mafia orphans
mafia status
mafia update
```"""

    return f"""---
description: MANDATORY - Use mafia CLI for ALL code questions before any other tool
globs: "**/*"
---

# CRITICAL RULE: Use `mafia` CLI FIRST for ALL code questions

This project has a live dependency graph with {entities} entities and {relations} relations.
The `mafia` CLI is installed and initialized. You MUST use it.

## MANDATORY BEHAVIOR

**BEFORE using fileSearch, grep, find, or reading source files to answer ANY question
about code structure, functions, classes, dependencies, imports, usage, or behavior —
you MUST first run the appropriate `mafia` command via executeBash.**

This applies to ALL of these question patterns (not just exact matches):

| User asks about... | Run this FIRST |
|---|---|
| Any function, class, method, table, endpoint by name | `mafia search "<name>" --limit 10` |
| "where is X used" / "who uses X" / "who calls X" | `mafia search "<X>"` then `mafia neighbors "<id>" --direction upstream` |
| "what does X call" / "what does X depend on" | `mafia neighbors "<id>" --direction downstream` |
| "what breaks if I change X" / "impact of changing X" | `mafia blast "<id>" --direction downstream` |
| "how does X connect to Y" / "relationship between X and Y" | `mafia path "<X_id>" "<Y_id>"` |
| "trace the flow" / "end to end" / "full chain" | `mafia trace "<id>" --depth 10` or `mafia flows --node "<id>"` |
| "show me the flow for X" / "what flows involve X" | `mafia flows --node "<id>"` |
| "unused code" / "dead code" / "orphans" | `mafia orphans` |
| "how is the project structured" / "overview" | `mafia status` |
| "find X" / "locate X" / "where is X defined" | `mafia search "<X>" --limit 10` |
| "explain how X works" / "what does X do" | `mafia search "<X>"` → get ID → `mafia neighbors "<id>" --direction both` → THEN read source |
| "list all endpoints" / "list all tables" | `mafia search "endpoint" --limit 50` or search by type |
| "what changed" / "refresh" | `mafia update` |

## WORKFLOW

1. **Always start with `mafia search`** to find the entity ID
2. **Use the entity ID** in follow-up commands (neighbors, blast, trace, flows, path)
3. **Only THEN read source files** if the user needs to see actual code

## DO NOT

- Do NOT use fileSearch/grep to find function definitions when mafia search can find them
- Do NOT manually read import statements to trace dependencies when mafia neighbors exists
- Do NOT guess at call chains when mafia trace gives the real graph
- Do NOT scan files to find usages when mafia neighbors --direction upstream gives them

## Commands (real examples from this project)

{example_lines}

All commands run from: `{project_root}`

## Entity ID format

`{{layer}}:{{type}}:{{repo}}:{{qualifier}}` — e.g. `{example_id}`

Layers: ui, bff, api, db, config, shared
"""


def _install_agent_rules(project_root: Path, mafia_dir: Path):
    """Install agent rules into .amazonq/rules/, CLAUDE.md, and .kiro/rules/."""
    rule_content = _build_rule_content(mafia_dir, project_root)

    # Install to .amazonq/rules/
    amazonq_rules = project_root / ".amazonq" / "rules"
    amazonq_rules.mkdir(parents=True, exist_ok=True)
    (amazonq_rules / "mafia-agent.md").write_text(rule_content, encoding="utf-8")

    # Install to CLAUDE.md (replace section if exists, append if not, create if missing)
    claude_md = project_root / "CLAUDE.md"
    claude_section_header = "# MAFIA Codebase Intelligence"
    # Strip frontmatter for CLAUDE.md (it doesn't use ---/globs)
    body = rule_content.split("---", 2)[-1].strip() if rule_content.startswith("---") else rule_content
    claude_block = f"\n\n{claude_section_header}\n\n{body}\n"
    if claude_md.exists():
        existing = claude_md.read_text(encoding="utf-8")
        if claude_section_header in existing:
            # Replace existing MAFIA section
            import re
            # Find the section start and replace everything after it
            idx = existing.index(claude_section_header)
            existing = existing[:idx].rstrip() + claude_block
            claude_md.write_text(existing, encoding="utf-8")
        else:
            with open(claude_md, "a", encoding="utf-8") as f:
                f.write(claude_block)
    else:
        claude_md.write_text(claude_block, encoding="utf-8")

    # Install to .kiro/rules/ if .kiro exists
    kiro_rules = project_root / ".kiro" / "rules"
    if (project_root / ".kiro").exists():
        kiro_rules.mkdir(parents=True, exist_ok=True)
        (kiro_rules / "mafia-agent.md").write_text(rule_content, encoding="utf-8")


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="mafia",
        description="MAFIA CLI — Agent-friendly codebase intelligence",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # init
    p = sub.add_parser("init", help="Initialize MAFIA on a project")
    p.add_argument("project_path", nargs="?", default=".", help="Project root directory (default: current dir)")
    p.add_argument("--source-roots", nargs="+", default=None, help="Source directories to scan")
    p.add_argument("--full", action="store_true", help="Force full extraction")
    p.add_argument("--workers", type=int, default=4, help="Parallel workers")

    # update
    p = sub.add_parser("update", help="Incremental update after code changes")

    # status
    p = sub.add_parser("status", help="Show MAFIA status")

    # search
    p = sub.add_parser("search", help="Search entities")
    p.add_argument("query", help="Search query")
    p.add_argument("--layer", default=None)
    p.add_argument("--type", default=None)
    p.add_argument("--min-confidence", type=float, default=0.0)
    p.add_argument("--limit", type=int, default=20)

    # trace
    p = sub.add_parser("trace", help="Trace call chain from entity")
    p.add_argument("entity_id", help="Entity ID or search term")
    p.add_argument("--depth", type=int, default=12)

    # blast
    p = sub.add_parser("blast", help="Compute blast radius")
    p.add_argument("entity_id", help="Entity ID or search term")
    p.add_argument("--direction", default="downstream", choices=["upstream", "downstream", "both"])
    p.add_argument("--depth", type=int, default=4)
    p.add_argument("--budget", type=int, default=50)

    # flows
    p = sub.add_parser("flows", help="List flows")
    p.add_argument("--node", default=None, help="Filter by node ID")
    p.add_argument("--limit", type=int, default=20)

    # neighbors
    p = sub.add_parser("neighbors", help="Get neighbors of entity")
    p.add_argument("entity_id", help="Entity ID or search term")
    p.add_argument("--direction", default="both", choices=["upstream", "downstream", "both"])
    p.add_argument("--limit", type=int, default=30)

    # path
    p = sub.add_parser("path", help="Find path between two entities")
    p.add_argument("source", help="Source entity ID")
    p.add_argument("target", help="Target entity ID")
    p.add_argument("--depth", type=int, default=15)

    # orphans
    p = sub.add_parser("orphans", help="List orphan entities")
    p.add_argument("--limit", type=int, default=20)

    # workspaces
    p = sub.add_parser("workspaces", help="List workspaces")

    # repos
    p = sub.add_parser("repos", help="List repos")

    # tree
    p = sub.add_parser("tree", help="Entity tree by layer")

    # workspace-deps
    p = sub.add_parser("workspace-deps", help="Workspace dependency graph")

    # shared
    p = sub.add_parser("shared", help="Shared resources (libs, tables, envs)")

    # cross-edges
    p = sub.add_parser("cross-edges", help="Cross-scope edges")
    p.add_argument("--boundary", default="repo", choices=["repo", "workspace"])
    p.add_argument("--limit", type=int, default=50)

    # skill
    p = sub.add_parser("skill", help="Skill adapter (spec/serve)")
    p.add_argument("skill_action", choices=["spec", "serve"])
    p.add_argument("--format", default="anthropic", choices=["anthropic", "openai", "mcp", "langchain"])
    p.add_argument("--transport", default="http", choices=["http", "mcp"])
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=5050)

    # index
    p = sub.add_parser("index", help="Build or update the vector search index")
    p.add_argument("--incremental", action="store_true", help="Only embed new documents (faster)")

    # serve
    p = sub.add_parser("serve", help="Start the MAFIA API server and UI")
    p.add_argument("--port", type=int, default=5001, help="Port (default: 5001)")
    p.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")

    # purge
    p = sub.add_parser("purge", help="Completely remove MAFIA from the system")
    p.add_argument("--yes", action="store_true", help="Skip confirmation prompt")
    p.add_argument("--dry-run", action="store_true", help="Show what would be removed without deleting")

    # uninstall
    p = sub.add_parser("uninstall", help="Remove MAFIA from a project")
    p.add_argument("project_path", nargs="?", default=".", help="Project root directory (default: current dir)")
    p.add_argument("--dry-run", action="store_true", help="Show what would be removed without deleting anything")

    # migrate
    p = sub.add_parser("migrate", help="Migrate entity ID v1 to v2")
    p.add_argument("entity_id", help="Entity ID to migrate")

    # configure-ai
    p = sub.add_parser("configure-ai", help="Configure AI credentials (Gemini)")
    p.add_argument("--sa-key", default=None, help="Path to Google service account JSON key")
    p.add_argument("--cert-file", default=None, help="Path to CA cert bundle (ZScaler bypass)")
    p.add_argument("--project", default=None, help="GCP project ID")
    p.add_argument("--location", default=None, help="GCP location (default: us-central1)")
    p.add_argument("--model", default=None, help="Gemini model (default: gemini-2.5-flash)")
    p.add_argument("--show", action="store_true", help="Show current AI config")

    # hub
    p = sub.add_parser("hub", help="Start MAFIA Hub — multi-project dashboard")
    p.add_argument("--port", type=int, default=5001, help="Server port (default: 5001)")
    p.add_argument("--host", default="127.0.0.1", help="Server host (default: 127.0.0.1)")

    # projects
    p = sub.add_parser("projects", help="List all initialized MAFIA projects")

    args = parser.parse_args()

    cmd_map = {
        "init": cmd_init, "update": cmd_update, "status": cmd_status,
        "search": cmd_search, "trace": cmd_trace, "blast": cmd_blast,
        "flows": cmd_flows, "neighbors": cmd_neighbors, "path": cmd_path,
        "orphans": cmd_orphans, "configure-ai": cmd_configure_ai,
        "hub": cmd_hub, "projects": cmd_projects,
        "workspaces": cmd_workspaces, "repos": cmd_repos, "tree": cmd_tree,
        "workspace-deps": cmd_workspace_deps, "shared": cmd_shared,
        "cross-edges": cmd_cross_edges, "skill": cmd_skill, "migrate": cmd_migrate,
        "uninstall": cmd_uninstall, "purge": cmd_purge,
        "index": cmd_index, "serve": cmd_serve,
    }
    cmd_map[args.command](args)


if __name__ == "__main__":
    main()
