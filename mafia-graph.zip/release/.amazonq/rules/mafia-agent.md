---
description: MANDATORY - Use mafia CLI for ALL code questions before any other tool
globs: "**/*"
---

# CRITICAL RULE: Use `mafia` CLI FIRST for ALL code questions

This project has a live dependency graph with 343 entities and 1433 relations.
The `mafia` CLI is installed and initialized. You MUST use it.

## MANDATORY BEHAVIOR

**BEFORE using fileSearch, grep, find, or reading source files to answer ANY question
about code structure, functions, classes, dependencies, imports, usage, or behavior —
you MUST first run the appropriate `mafia` command via executeBash.**

This applies to ALL of these question patterns (not just exact matches):

| User asks about... | Run this FIRST |
|---|---|
| Any function, class, method, table, endpoint by name | `mafia search "<name>" --limit 10` |
| "where is X used" / "who uses X" / "who calls X" | `mafia search "<X>"` then `mafia neighbors "<id>" --direction upstream` |
| "what does X call" / "what does X depend on" | `mafia neighbors "<id>" --direction downstream` |
| "what breaks if I change X" / "impact of changing X" | `mafia blast "<id>" --direction downstream` |
| "how does X connect to Y" / "relationship between X and Y" | `mafia path "<X_id>" "<Y_id>"` |
| "trace the flow" / "end to end" / "full chain" | `mafia trace "<id>" --depth 10` or `mafia flows --node "<id>"` |
| "show me the flow for X" / "what flows involve X" | `mafia flows --node "<id>"` |
| "unused code" / "dead code" / "orphans" | `mafia orphans` |
| "how is the project structured" / "overview" | `mafia status` |
| "find X" / "locate X" / "where is X defined" | `mafia search "<X>" --limit 10` |
| "explain how X works" / "what does X do" | `mafia search "<X>"` → get ID → `mafia neighbors "<id>" --direction both` → THEN read source |
| "list all endpoints" / "list all tables" | `mafia search "endpoint" --limit 50` or search by type |
| "what changed" / "refresh" | `mafia update` |

## WORKFLOW

1. **Always start with `mafia search`** to find the entity ID
2. **Use the entity ID** in follow-up commands (neighbors, blast, trace, flows, path)
3. **Only THEN read source files** if the user needs to see actual code

## DO NOT

- Do NOT use fileSearch/grep to find function definitions when mafia search can find them
- Do NOT manually read import statements to trace dependencies when mafia neighbors exists
- Do NOT guess at call chains when mafia trace gives the real graph
- Do NOT scan files to find usages when mafia neighbors --direction upstream gives them

## Commands (real examples from this project)

```bash
# Search for any entity (function, class, table, endpoint)
mafia search "py" --limit 10

# Who calls this (upstream neighbors)
mafia neighbors "code:module:MAFIA_Phase1_Execution:install.py" --direction upstream

# What this calls (downstream neighbors)
mafia neighbors "code:module:MAFIA_Phase1_Execution:install.py" --direction downstream

# Full blast radius — what breaks if this changes
mafia blast "code:module:MAFIA_Phase1_Execution:install.py" --direction downstream

# Trace the downstream call chain
mafia trace "code:module:MAFIA_Phase1_Execution:install.py" --depth 10

# End-to-end flows through a node
mafia flows --node "code:module:MAFIA_Phase1_Execution:install.py"

# Shortest path between two entities
mafia path "code:module:MAFIA_Phase1_Execution:install.py" "api:service:MAFIA_Phase1_Execution:mafia/api.py::MAFIA"

# Dead code candidates
mafia orphans

# Project graph stats
mafia status

# Refresh graph after code changes
mafia update
```

All commands run from: `C:\Users\MML\Downloads\Graphify-MAFIA\MAFIA_Phase1_Execution`

## Entity ID format

`{layer}:{type}:{repo}:{qualifier}` — e.g. `code:module:MAFIA_Phase1_Execution:install.py`

Layers: ui, bff, api, db, config, shared
