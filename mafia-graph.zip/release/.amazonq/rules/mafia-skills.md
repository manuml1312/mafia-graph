---
description: MAFIA codebase analysis system — skills and capabilities reference
globs: "**/*"
---

# MAFIA System Context

This workspace is the MAFIA (Multi-Artifact Flow Intelligence Architecture) codebase analysis pipeline. When working in this project, you have access to these capabilities:

## Quick Reference

- **Scan repos:** `python -m phase2_repo_intake.repo_scanner --source-roots /path`
- **Run pipeline:** `python -m phase3_extraction_framework.run_extraction` (incremental) or `--full`
- **Rebuild graph only:** `python -m phase3_extraction_framework.run_extraction --from-phase 9`
- **AST summaries:** `python -m phase10_ast.run_ast_summaries --discover`
- **Build search index:** `python -m phase11_search.vector_index --incremental`
- **Start server:** `python -m phase11_search.search_api1` → http://localhost:5001

## Key Artifacts (all in output/)

- `repo_manifest.json` — discovered repos with classification
- `entities.jsonl` — all extracted entities (ID format: `layer:type:repo:qualifier`)
- `relations.jsonl` — all edges between entities
- `system_graph.json` — full graph (nodes + edges)
- `e2e_flows.json` — end-to-end flows across catalogs
- `ast_summaries.jsonl` — method-level structural summaries
- `coverage_report.json`, `quality_gate_report.json` — health metrics

## Architecture Layers

UI (React) → BFF (Koa/Express) → API (Spring Boot) → DB (Postgres/Databricks)

## When reading/modifying extractors

- All extractors subclass `BaseExtractor` in `phase3_extraction_framework/base_extractor.py`
- Extractors live in `phase4_extractors/` organized by layer
- Entity IDs use canonical format: `{layer}:{type}:{repo}:{qualifier}`
- Relations use: `{source_id}--{type}-->{target_id}`
- Valid layers/types/relations defined in `schemas/id_format.py`
- Emission goes through `schemas/emitter.py` (thread-safe, deduplicating)

## When working on the UI

- UI files in `phase12_ui/` — served by Flask at localhost:5001
- API endpoints defined in `phase11_search/search_api1.py`
- Key API routes: /search, /node/{id}, /flows, /flow/{id}, /blast_radius, /chat, /coverage

## Agent CLI (for any project)

MAFIA can be initialized on any project to give the agent codebase intelligence:

```bash
# Initialize on a project (scans, extracts, builds graph)
python mafia_cli.py init --project-root /path/to/project

# Query from the agent (no server needed)
python mafia_cli.py search "getUserProfile" --limit 10
python mafia_cli.py trace "api:endpoint:user_api:GET:/users"
python mafia_cli.py blast "api:service:user_api:UserService" --direction downstream
python mafia_cli.py flows --node "bff:endpoint:user_bff:/users"
python mafia_cli.py neighbors "api:controller:user_api:UserController" --direction both
python mafia_cli.py path "ui:fetch_def:web:getUsers" "db:table:pg:users"
python mafia_cli.py orphans
python mafia_cli.py update  # incremental after code changes
```

Init creates `.mafia/` in the target project with artifacts + installs agent rules into `.amazonq/rules/mafia-agent.md` and `CLAUDE.md` automatically.

## For full skills reference, see skills.md in the project root.
