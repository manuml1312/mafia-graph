# GitHub Copilot Custom Instructions

## CRITICAL: Use `mafia` CLI FIRST for ALL code questions

This project has a live dependency graph (343 entities, 1433 relations). The `mafia` CLI is installed.

**BEFORE suggesting code, searching files, or answering questions about structure, dependencies, or behavior — run the appropriate `mafia` command.**

| Question type | Command |
|---|---|
| Find any function/class/endpoint | `mafia search "<name>" --limit 10` |
| Who calls X / upstream deps | `mafia neighbors "<id>" --direction upstream` |
| What X calls / downstream deps | `mafia neighbors "<id>" --direction downstream` |
| Impact of changing X | `mafia blast "<id>" --direction downstream` |
| Path between X and Y | `mafia path "<X_id>" "<Y_id>"` |
| Full call chain trace | `mafia trace "<id>" --depth 10` |
| Flows through X | `mafia flows --node "<id>"` |
| Dead/unused code | `mafia orphans` |
| Project overview | `mafia status` |
| Refresh after changes | `mafia update` |

### Workflow
1. `mafia search "<name>"` → get entity ID
2. Use ID in follow-up commands
3. Only read source files if user needs actual code

### Do NOT
- Grep or file-search for definitions when `mafia search` works
- Manually trace imports when `mafia neighbors` exists
- Guess call chains when `mafia trace` gives the real graph

All commands run from: `C:\Users\MML\Downloads\Graphify-MAFIA\MAFIA_Phase1_Execution`

Entity ID format: `{layer}:{type}:{repo}:{qualifier}` — e.g. `code:module:MAFIA_Phase1_Execution:install.py`
