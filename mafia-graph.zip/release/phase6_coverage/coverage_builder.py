"""
MAFIA Phase 6 — Coverage Analysis and coverage_report.json
============================================================
Reads extraction outputs and produces coverage_report.json (artifact 4 of 5).
Measures:
  - File-level: scanned / parsed / failed / zero-extraction
  - Entity-level: counts by layer/type, low-confidence, missing evidence
  - Relation-level: unresolved targets, dangling refs, low-confidence
  - Gaps: ranked by severity (critical / warning / info)

Usage:
    python -m phase6_coverage.coverage_builder
"""

import json
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def build_coverage_report(output_dir: str) -> dict:
    output = Path(output_dir)

    # Load inputs
    extraction_report = _load_json(output / "extraction_report.json")
    entities = _load_jsonl(output / "entities.jsonl")
    relations = _load_jsonl(output / "relations.jsonl")
    manifest = _load_json(output / "repo_manifest.json")

    # ── File coverage (from extraction_report) ───────────────────────────────
    repo_file_coverage = []
    total_scanned = total_parsed = total_failed = total_unsupported = total_zero = 0

    for repo_summary in extraction_report.get("repo_summaries", []):
        repo_id = repo_summary["repo_id"]
        files_ok = files_failed = files_skipped = files_no_entities = files_ineligible = 0
        files_eligible = files_eligible_with_entities = 0

        for ext_summary in repo_summary.get("extractors_run", []):
            files_ok += ext_summary.get("files_ok", 0)
            files_failed += ext_summary.get("files_failed", 0)
            files_skipped += ext_summary.get("files_skipped", 0)
            files_no_entities += ext_summary.get("files_no_entities", 0)
            files_ineligible += ext_summary.get("files_ineligible", 0)
            files_eligible += ext_summary.get("files_eligible", 0)
            files_eligible_with_entities += ext_summary.get("files_eligible_with_entities", 0)

        files_scanned = files_ok + files_failed + files_skipped + files_no_entities + files_ineligible
        parse_errors = []
        for ext_summary in repo_summary.get("extractors_run", []):
            for f in ext_summary.get("failures", []):
                parse_errors.append(f"{f['file']}: {f.get('error', 'unknown')}")

        repo_file_coverage.append({
            "repo_id": repo_id,
            "files_scanned": files_scanned,
            "files_parsed": files_ok + files_no_entities,
            "files_failed": files_failed,
            "files_unsupported": files_skipped,
            "files_zero_entities": files_no_entities,
            "files_ineligible": files_ineligible,
            "files_eligible": files_eligible,
            "files_eligible_with_entities": files_eligible_with_entities,
            "parse_errors": parse_errors[:10],
        })
        total_scanned += files_scanned
        total_parsed += files_ok + files_no_entities
        total_failed += files_failed
        total_unsupported += files_skipped
        total_zero += files_no_entities

    # Eligible totals for dual metrics
    total_eligible = sum(r["files_eligible"] for r in repo_file_coverage)
    total_eligible_with_entities = sum(r["files_eligible_with_entities"] for r in repo_file_coverage)

    parse_rate = total_parsed / max(total_scanned, 1)
    extraction_rate = (total_parsed - total_zero) / max(total_scanned, 1)
    eligible_yield = total_eligible_with_entities / max(total_eligible, 1) if total_eligible > 0 else extraction_rate

    # ── Entity coverage ──────────────────────────────────────────────────────
    by_layer = defaultdict(int)
    by_type = defaultdict(int)
    low_conf_entities = 0
    no_evidence_entities = 0

    for e in entities:
        by_layer[e.get("layer", "unknown")] += 1
        by_type[f"{e.get('layer', '?')}:{e.get('type', '?')}"] += 1
        if e.get("confidence", 1.0) < 0.50:
            low_conf_entities += 1
        ev = e.get("evidence", {})
        if not ev or not ev.get("file"):
            no_evidence_entities += 1

    # ── Relation coverage ────────────────────────────────────────────────────
    entity_ids = {e["id"] for e in entities}
    rel_by_type = defaultdict(int)
    unresolved_targets = 0
    dangling_refs = 0
    low_conf_relations = 0

    for r in relations:
        rel_by_type[r.get("type", "unknown")] += 1
        if r.get("confidence", 1.0) < 0.50:
            low_conf_relations += 1
        if r.get("source", "") not in entity_ids:
            dangling_refs += 1
        if r.get("target", "") not in entity_ids:
            if r.get("unresolved_target"):
                unresolved_targets += 1
            else:
                dangling_refs += 1

    # ── Per-repo entity/relation counts (for per-repo coverage view) ────────
    entities_by_repo = defaultdict(int)
    relations_by_repo = defaultdict(int)
    for e in entities:
        entities_by_repo[e.get("repo", "unknown")] += 1
    for r in relations:
        src_repo = r.get("source", "").split(":")[2] if len(r.get("source", "").split(":")) > 2 else "unknown"
        relations_by_repo[src_repo] += 1

    for rfc in repo_file_coverage:
        rfc["entity_count"] = entities_by_repo.get(rfc["repo_id"], 0)
        rfc["relation_count"] = relations_by_repo.get(rfc["repo_id"], 0)

    # ── Cross-layer link coverage ────────────────────────────────────────────
    cross_layer_types = {
        "fetches", "calls_api", "calls_function", "entity_maps_to",
        "reads_from", "writes_to", "routes_to", "delegates_to",
        "uses_repo", "uses_table", "validates_with", "invokes_http",
    }
    cross_layer_count = sum(1 for r in relations if r.get("type") in cross_layer_types)
    # Estimate: ~1 cross-layer relation per 5 BFF+API entities (conservative)
    expected_cross = (by_layer.get("bff", 0) + by_layer.get("api", 0)) // 5
    missing_cross_layer = max(0, expected_cross - cross_layer_count)

    # ── Gap detection ────────────────────────────────────────────────────────
    gaps = []

    # Critical: repos with 0 entities but many scannable files
    for repo_meta in manifest.get("repos", []):
        repo_id = repo_meta["repo_id"]
        repo_ent_count = entities_by_repo.get(repo_id, 0)
        scannable = repo_meta.get("scan_summary", {}).get("scannable_files", 0)
        if repo_ent_count == 0 and scannable > 3:
            gaps.append({
                "severity": "critical",
                "category": "zero_extraction_repo",
                "description": f"Repo '{repo_id}' has {scannable} scannable files but 0 entities extracted",
                "affected": [repo_id],
            })

    # Critical: high failure rate
    if total_scanned > 0 and total_failed / total_scanned > 0.10:
        gaps.append({
            "severity": "critical",
            "category": "high_failure_rate",
            "description": f"Parse failure rate is {total_failed/total_scanned:.1%} ({total_failed}/{total_scanned})",
            "affected": [r["repo_id"] for r in repo_file_coverage if r["files_failed"] > 0],
        })

    # Critical: extraction rate below 50%
    if extraction_rate < 0.50:
        gaps.append({
            "severity": "critical",
            "category": "low_extraction_rate",
            "description": f"Extraction rate is {extraction_rate:.1%} (below 50% threshold)",
            "affected": [],
        })

    # Warning: layers with 0 entities
    expected_layers = {"ui", "bff", "api", "db"}
    for layer in expected_layers:
        if by_layer.get(layer, 0) == 0:
            gaps.append({
                "severity": "warning",
                "category": "missing_layer",
                "description": f"No entities extracted for layer '{layer}'",
                "affected": [layer],
            })

    # Warning: no relations at all
    if len(relations) == 0 and len(entities) > 10:
        gaps.append({
            "severity": "warning",
            "category": "no_relations",
            "description": f"{len(entities)} entities but 0 relations -- cross-layer mapping will fail",
            "affected": [],
        })

    # Warning: high unresolved target rate
    if len(relations) > 0 and unresolved_targets / max(len(relations), 1) > 0.20:
        gaps.append({
            "severity": "warning",
            "category": "high_unresolved_rate",
            "description": f"{unresolved_targets}/{len(relations)} relations have unresolved targets",
            "affected": [],
        })

    # Warning: missing cross-layer links
    if missing_cross_layer > 20:
        gaps.append({
            "severity": "warning",
            "category": "missing_cross_layer_links",
            "description": f"Only {cross_layer_count} cross-layer relations found (expected ~{expected_cross // 3}+)",
            "affected": [],
        })

    # Warning: repos with entities but 0 relations
    for rfc in repo_file_coverage:
        if rfc["entity_count"] > 10 and rfc["relation_count"] == 0:
            cls = next((r.get("classification", []) for r in manifest.get("repos", []) if r["repo_id"] == rfc["repo_id"]), [])
            if any(c in ("bff", "api") for c in cls):
                gaps.append({
                    "severity": "warning",
                    "category": "entities_without_relations",
                    "description": f"Repo '{rfc['repo_id']}' has {rfc['entity_count']} entities but 0 relations",
                    "affected": [rfc["repo_id"]],
                })

    # Info: many low-confidence entities
    if low_conf_entities > 10:
        gaps.append({
            "severity": "info",
            "category": "low_confidence_entities",
            "description": f"{low_conf_entities} entities have confidence < 0.50",
            "affected": [],
        })

    # Info: zero-extraction files
    if total_zero > total_scanned * 0.30:
        gaps.append({
            "severity": "info",
            "category": "many_zero_extraction_files",
            "description": f"{total_zero}/{total_scanned} files yielded 0 entities",
            "affected": [],
        })

    # Info: entities without evidence detail
    if no_evidence_entities > 0:
        gaps.append({
            "severity": "info",
            "category": "missing_evidence_detail",
            "description": f"{no_evidence_entities} entities have no evidence file",
            "affected": [],
        })

    gaps.sort(key=lambda g: {"critical": 0, "warning": 1, "info": 2}[g["severity"]])

    # ── Build unresolved_artifacts.json ───────────────────────────────────────
    unresolved = []

    # Entities in repos with 0 extraction
    for repo_meta in manifest.get("repos", []):
        repo_id = repo_meta["repo_id"]
        if entities_by_repo.get(repo_id, 0) == 0 and repo_meta.get("scan_summary", {}).get("scannable_files", 0) > 3:
            unresolved.append({
                "type": "zero_extraction_repo",
                "repo": repo_id,
                "scannable_files": repo_meta.get("scan_summary", {}).get("scannable_files", 0),
                "classification": repo_meta.get("classification", []),
                "severity": "critical",
                "reason": "Repo has scannable files but no entities were extracted",
            })

    # Relations with unresolved targets
    for r in relations:
        if r.get("unresolved_target"):
            unresolved.append({
                "type": "unresolved_relation_target",
                "relation_id": r["id"],
                "source": r.get("source", ""),
                "unresolved_target": r["unresolved_target"],
                "relation_type": r.get("type", ""),
                "severity": "warning",
                "reason": "Relation target could not be resolved to a known entity",
            })

    # Files with zero extraction in repos that otherwise have entities
    for rfc in repo_file_coverage:
        if rfc["entity_count"] > 0 and rfc["files_zero_entities"] > rfc["files_scanned"] * 0.5:
            unresolved.append({
                "type": "high_zero_extraction_files",
                "repo": rfc["repo_id"],
                "zero_files": rfc["files_zero_entities"],
                "total_files": rfc["files_scanned"],
                "severity": "info",
                "reason": f"{rfc['files_zero_entities']}/{rfc['files_scanned']} files yielded 0 entities",
            })

    # Entities with warnings (dead code candidates, ambiguous resolution, etc.)
    for e in entities:
        warnings = e.get("warnings", [])
        if warnings:
            unresolved.append({
                "type": "entity_with_warnings",
                "entity_id": e["id"],
                "entity_name": e.get("name", ""),
                "repo": e.get("repo", ""),
                "file": e.get("file", ""),
                "warnings": warnings,
                "severity": "info",
                "reason": "; ".join(warnings),
            })

    unresolved.sort(key=lambda u: {"critical": 0, "warning": 1, "info": 2}.get(u.get("severity", "info"), 2))

    unresolved_path = output / "unresolved_artifacts.json"
    with open(unresolved_path, 'w', encoding='utf-8') as f:
        json.dump({
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_unresolved": len(unresolved),
            "by_severity": {
                "critical": sum(1 for u in unresolved if u["severity"] == "critical"),
                "warning": sum(1 for u in unresolved if u["severity"] == "warning"),
                "info": sum(1 for u in unresolved if u["severity"] == "info"),
            },
            "artifacts": unresolved,
        }, f, indent=2, ensure_ascii=False)

    # ── Build low_confidence_zones.json ───────────────────────────────────────
    low_conf_zones = []

    # Low-confidence entities grouped by repo+file
    lc_by_file = defaultdict(list)
    for e in entities:
        if e.get("confidence", 1.0) < 0.70:
            key = (e.get("repo", ""), e.get("file", ""))
            lc_by_file[key].append({
                "entity_id": e["id"],
                "name": e.get("name", ""),
                "type": f"{e.get('layer', '?')}:{e.get('type', '?')}",
                "confidence": e.get("confidence", 0),
                "line": e.get("line"),
            })

    for (repo, file_path), ents in sorted(lc_by_file.items(), key=lambda x: -len(x[1])):
        low_conf_zones.append({
            "repo": repo,
            "file": file_path,
            "low_confidence_count": len(ents),
            "avg_confidence": round(sum(e["confidence"] for e in ents) / len(ents), 3),
            "entities": ents[:20],
        })

    # Low-confidence relations grouped by type
    lc_rel_by_type = defaultdict(list)
    for r in relations:
        if r.get("confidence", 1.0) < 0.70:
            lc_rel_by_type[r.get("type", "unknown")].append({
                "relation_id": r["id"],
                "confidence": r.get("confidence", 0),
                "source": r.get("source", ""),
                "target": r.get("target", ""),
            })

    lc_zones_path = output / "low_confidence_zones.json"
    with open(lc_zones_path, 'w', encoding='utf-8') as f:
        json.dump({
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "total_low_confidence_entities": sum(len(v) for v in lc_by_file.values()),
            "total_low_confidence_relations": sum(len(v) for v in lc_rel_by_type.values()),
            "file_zones": low_conf_zones[:50],
            "relation_zones": {
                rtype: {"count": len(rels), "samples": rels[:10]}
                for rtype, rels in sorted(lc_rel_by_type.items(), key=lambda x: -len(x[1]))
            },
        }, f, indent=2, ensure_ascii=False)

    # ── Language distribution (from ALL scanned files in source repos) ────────
    ext_lines = defaultdict(int)
    _SKIP_DIRS = {'node_modules', '.git', '__pycache__', '.venv', 'venv', 'dist',
                  'build', 'out', 'target', '.next', '.gradle', '.idea',
                  '.schema_cache', '.sheet_cache', '.amazonq', '.vscode'}
    _SKIP_EXTS = {'lock', 'png', 'jpg', 'jpeg', 'gif', 'svg', 'ico', 'woff',
                  'woff2', 'ttf', 'eot', 'map', 'gz', 'zip', 'jar', 'class',
                  'pyc', 'DS_Store', 'gitignore', 'gitkeep', 'log', 'bin',
                  'exe', 'dll', 'so', 'dylib', 'cache', 'tmp', 'pdf', 'docx',
                  'xlsx', 'pptx', 'mp3', 'mp4', 'wav', 'ogg', 'webp', 'bmp'}

    for repo_meta in manifest.get('repos', []):
        # Use root_path (the correct field name in repo_manifest.json)
        repo_root = repo_meta.get('root_path') or repo_meta.get('source_root', '')
        if not repo_root:
            continue
        repo_path = Path(repo_root)
        if not repo_path.exists():
            continue
        try:
            for fp in repo_path.rglob('*'):
                if not fp.is_file():
                    continue
                # Skip noise directories anywhere in the path
                if any(part in _SKIP_DIRS for part in fp.parts):
                    continue
                ext = fp.suffix.lstrip('.').lower()
                if not ext or ext in _SKIP_EXTS:
                    continue
                try:
                    line_count = fp.read_text(encoding='utf-8', errors='ignore').count('\n') + 1
                    ext_lines[ext] += line_count
                except Exception:
                    pass
        except Exception:
            pass

    # Fallback: if source scan yielded nothing, count entity file extensions
    if not ext_lines:
        for e in entities:
            fpath = e.get('file', '')
            if fpath and '.' in fpath:
                ext_lines[fpath.rsplit('.', 1)[-1].lower()] += 1

    total_lines = sum(ext_lines.values()) or 1
    languages = [
        {'ext': ext, 'lines': count, 'pct': round(count / total_lines * 100, 1)}
        for ext, count in sorted(ext_lines.items(), key=lambda x: -x[1])
        if count > 0
    ]

    # ── Build report ─────────────────────────────────────────────────────────
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "repos": repo_file_coverage,
        "file_coverage": {
            "total_scanned": total_scanned,
            "total_parsed": total_parsed,
            "total_failed": total_failed,
            "total_unsupported": total_unsupported,
            "total_zero_entities": total_zero,
            "total_eligible": total_eligible,
            "total_eligible_with_entities": total_eligible_with_entities,
            "parse_rate": round(parse_rate, 4),
            "extraction_rate": round(extraction_rate, 4),
            "eligible_yield": round(eligible_yield, 4),
            "languages": languages,
        },
        "entity_coverage": {
            "total_entities": len(entities),
            "by_layer": dict(by_layer),
            "by_type": dict(sorted(by_type.items(), key=lambda x: -x[1])),
            "low_confidence_count": low_conf_entities,
            "no_evidence_count": no_evidence_entities,
        },
        "relation_coverage": {
            "total_relations": len(relations),
            "by_type": dict(sorted(rel_by_type.items(), key=lambda x: -x[1])),
            "unresolved_targets": unresolved_targets,
            "low_confidence_count": low_conf_relations,
            "dangling_references": dangling_refs,
        },
        "gaps": gaps,
    }

    # Write
    report_path = output / "coverage_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # Print summary
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 6 -- Coverage Report")
    print(f"{'='*60}")
    print(f"  Files: {total_scanned} scanned, {total_parsed} parsed, {total_failed} failed")
    print(f"  Eligible: {total_eligible} files, {total_eligible_with_entities} with entities")
    print(f"  Parse rate: {parse_rate:.1%}  |  Overall yield: {extraction_rate:.1%}  |  Eligible yield: {eligible_yield:.1%}")
    print(f"  Entities: {len(entities)} ({dict(by_layer)})")
    print(f"  Relations: {len(relations)} ({dict(rel_by_type)})")
    print(f"  Low-confidence: {low_conf_entities}E / {low_conf_relations}R")
    print(f"  Unresolved targets: {unresolved_targets}  |  Dangling refs: {dangling_refs}")
    print(f"  Gaps: {sum(1 for g in gaps if g['severity']=='critical')} critical, "
          f"{sum(1 for g in gaps if g['severity']=='warning')} warning, "
          f"{sum(1 for g in gaps if g['severity']=='info')} info")
    print(f"  Unresolved artifacts: {len(unresolved)}")
    print(f"  Low-confidence zones: {len(low_conf_zones)} files, "
          f"{sum(len(v) for v in lc_rel_by_type.values())} relations")
    print(f"  Report: {report_path}")
    print(f"{'='*60}\n")

    return report


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    build_coverage_report(str(base / "output"))
