"""Gradle multi-project detector — settings.gradle[.kts] with include directives."""

import re
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class GradleDetector(WorkspaceDetector):
    name = "gradle"
    priority = 8

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        for name in ("settings.gradle", "settings.gradle.kts"):
            settings = repo_root / name
            if settings.exists():
                return self._parse(repo_root, settings)
        return None

    def _parse(self, repo_root: Path, settings: Path) -> Optional[MonorepoSpec]:
        try:
            content = settings.read_text(encoding="utf-8")
        except Exception:
            return None
        # Match include ':module-a', ':module-b' or include(":module-a")
        includes = re.findall(r"""include\s*\(?['"]:([^'"]+)['"]""", content)
        if not includes:
            return None
        workspaces = []
        for mod in includes:
            # Gradle uses ':' as path separator
            rel = mod.replace(":", "/")
            workspaces.append(WorkspaceSpec(name=mod, root=rel))
        return MonorepoSpec(system="gradle", workspaces=workspaces)
