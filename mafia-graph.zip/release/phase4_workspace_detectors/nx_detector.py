"""Nx detector — nx.json + apps/libs or project.json files."""

import json
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class NxDetector(WorkspaceDetector):
    name = "nx"
    priority = 4

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        if not (repo_root / "nx.json").exists():
            return None
        workspaces = []
        # Scan apps/ and libs/ for project.json
        for folder in ("apps", "libs"):
            base = repo_root / folder
            if not base.is_dir():
                continue
            for child in sorted(base.iterdir()):
                if child.is_dir() and (child / "project.json").exists():
                    rel = str(child.relative_to(repo_root)).replace("\\", "/")
                    workspaces.append(WorkspaceSpec(name=child.name, root=rel))
        # Also check workspace.json
        ws_json = repo_root / "workspace.json"
        if ws_json.exists():
            try:
                data = json.loads(ws_json.read_text(encoding="utf-8"))
                for name, proj in data.get("projects", {}).items():
                    root = proj if isinstance(proj, str) else proj.get("root", name)
                    if not any(w.name == name for w in workspaces):
                        workspaces.append(WorkspaceSpec(name=name, root=root))
            except Exception:
                pass
        if not workspaces:
            return None
        return MonorepoSpec(system="nx", workspaces=workspaces)
