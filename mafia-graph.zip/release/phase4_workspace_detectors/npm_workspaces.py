"""npm workspaces detector — package.json with 'workspaces' field."""

import json
import glob
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class NpmWorkspacesDetector(WorkspaceDetector):
    name = "npm_workspaces"
    priority = 1

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        pkg_json = repo_root / "package.json"
        if not pkg_json.exists():
            return None
        try:
            pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
        except Exception:
            return None

        ws_field = pkg.get("workspaces")
        if ws_field is None:
            return None

        # workspaces can be a list or {"packages": [...]}
        patterns = ws_field if isinstance(ws_field, list) else ws_field.get("packages", [])
        if not patterns:
            return None

        workspaces = []
        for pattern in patterns:
            for match in sorted(glob.glob(str(repo_root / pattern))):
                ws_path = Path(match)
                if not ws_path.is_dir():
                    continue
                ws_pkg = ws_path / "package.json"
                pkg_name = ""
                deps = []
                if ws_pkg.exists():
                    try:
                        ws_data = json.loads(ws_pkg.read_text(encoding="utf-8"))
                        pkg_name = ws_data.get("name", "")
                        for dep_key in ("dependencies", "devDependencies"):
                            deps.extend(ws_data.get(dep_key, {}).keys())
                    except Exception:
                        pass
                rel = str(ws_path.relative_to(repo_root)).replace("\\", "/")
                workspaces.append(WorkspaceSpec(
                    name=ws_path.name, root=rel,
                    package_name=pkg_name, declared_deps=deps,
                ))

        if not workspaces:
            return None
        return MonorepoSpec(system="npm_workspaces", workspaces=workspaces)
