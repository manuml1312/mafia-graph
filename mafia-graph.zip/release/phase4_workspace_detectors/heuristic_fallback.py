"""Heuristic fallback detector — sibling subfolders with root project markers."""

from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec

_ROOT_MARKERS = {
    "package.json", "pom.xml", "build.gradle", "build.gradle.kts",
    "setup.py", "pyproject.toml", "go.mod", "Cargo.toml",
    "Gemfile", "composer.json", "mix.exs",
}


class HeuristicFallbackDetector(WorkspaceDetector):
    name = "heuristic_fallback"
    priority = 100  # runs last

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        workspaces = []
        try:
            children = sorted(repo_root.iterdir())
        except PermissionError:
            return None
        for child in children:
            if not child.is_dir() or child.name.startswith("."):
                continue
            has_marker = any((child / m).exists() for m in _ROOT_MARKERS)
            if has_marker:
                rel = str(child.relative_to(repo_root)).replace("\\", "/")
                workspaces.append(WorkspaceSpec(name=child.name, root=rel))
        if len(workspaces) < 2:
            return None  # need at least 2 to call it a multi-workspace
        return MonorepoSpec(system="heuristic_fallback", workspaces=workspaces)
