"""
Workspace Detector Runner
==========================
Runs all registered detectors against a repo root, merges results,
deduplicates by workspace root path.
"""

from pathlib import Path
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec
from phase4_workspace_detectors.npm_workspaces import NpmWorkspacesDetector
from phase4_workspace_detectors.pnpm import PnpmDetector
from phase4_workspace_detectors.lerna import LernaDetector
from phase4_workspace_detectors.nx_detector import NxDetector
from phase4_workspace_detectors.turborepo import TurborepoDetector
from phase4_workspace_detectors.rush import RushDetector
from phase4_workspace_detectors.maven import MavenDetector
from phase4_workspace_detectors.gradle import GradleDetector
from phase4_workspace_detectors.bazel import BazelDetector
from phase4_workspace_detectors.cargo import CargoDetector
from phase4_workspace_detectors.go_workspaces import GoWorkspacesDetector
from phase4_workspace_detectors.dotnet import DotnetDetector
from phase4_workspace_detectors.python_workspaces import PythonWorkspacesDetector
from phase4_workspace_detectors.heuristic_fallback import HeuristicFallbackDetector


_BUILTIN_DETECTORS: list[WorkspaceDetector] = sorted([
    NpmWorkspacesDetector(),
    PnpmDetector(),
    LernaDetector(),
    NxDetector(),
    TurborepoDetector(),
    RushDetector(),
    MavenDetector(),
    GradleDetector(),
    BazelDetector(),
    CargoDetector(),
    GoWorkspacesDetector(),
    DotnetDetector(),
    PythonWorkspacesDetector(),
    HeuristicFallbackDetector(),
], key=lambda d: d.priority)

_extra_detectors: list[WorkspaceDetector] = []


def _load_plugin_detectors() -> list[WorkspaceDetector]:
    """Discover plugin workspace detectors via entry points."""
    try:
        from mafia.plugins import load_plugins
        plugins = load_plugins("mafia.workspace_detectors")
        return [cls() for cls in plugins.values()]
    except Exception:
        return []


def register_detector(detector: WorkspaceDetector):
    _extra_detectors.append(detector)


def run_detectors(repo_root: Path) -> tuple[list[str], list[WorkspaceSpec]]:
    """Run all detectors. Returns (systems_detected, merged_workspaces)."""
    all_detectors = sorted(
        _load_plugin_detectors() + _extra_detectors + _BUILTIN_DETECTORS,
        key=lambda d: d.priority,
    )
    systems: list[str] = []
    seen_roots: dict[str, WorkspaceSpec] = {}

    for detector in all_detectors:
        # Heuristic fallback only runs if no other detector matched
        if detector.name == "heuristic_fallback" and systems:
            continue
        try:
            result = detector.detect(repo_root)
        except Exception:
            continue
        if result is None:
            continue
        systems.append(result.system)
        for ws in result.workspaces:
            if ws.root not in seen_roots:
                seen_roots[ws.root] = ws

    return systems, list(seen_roots.values())
