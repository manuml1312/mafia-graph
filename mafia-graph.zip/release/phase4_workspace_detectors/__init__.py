"""MAFIA Workspace Detectors — auto-detect monorepo systems."""

from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec
from phase4_workspace_detectors.runner import run_detectors, register_detector
