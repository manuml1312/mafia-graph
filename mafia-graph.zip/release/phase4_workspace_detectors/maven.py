"""Maven multi-module detector — parent pom.xml with <modules>."""

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class MavenDetector(WorkspaceDetector):
    name = "maven"
    priority = 7

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        pom = repo_root / "pom.xml"
        if not pom.exists():
            return None
        try:
            tree = ET.parse(pom)
            root = tree.getroot()
        except Exception:
            return None

        ns = ""
        m = re.match(r"\{(.+?)\}", root.tag)
        if m:
            ns = m.group(1)
        prefix = f"{{{ns}}}" if ns else ""

        modules_el = root.find(f"{prefix}modules")
        if modules_el is None:
            return None
        module_names = [m.text.strip() for m in modules_el.findall(f"{prefix}module") if m.text]
        if not module_names:
            return None

        workspaces = []
        for mod_name in module_names:
            mod_dir = repo_root / mod_name
            artifact_id = mod_name
            deps = []
            mod_pom = mod_dir / "pom.xml"
            if mod_pom.exists():
                try:
                    mtree = ET.parse(mod_pom)
                    mroot = mtree.getroot()
                    aid = mroot.find(f"{prefix}artifactId")
                    if aid is not None and aid.text:
                        artifact_id = aid.text.strip()
                    deps_el = mroot.find(f"{prefix}dependencies")
                    if deps_el is not None:
                        for dep in deps_el.findall(f"{prefix}dependency"):
                            gid = dep.find(f"{prefix}groupId")
                            did = dep.find(f"{prefix}artifactId")
                            if gid is not None and did is not None and gid.text and did.text:
                                deps.append(f"{gid.text.strip()}:{did.text.strip()}")
                except Exception:
                    pass
            workspaces.append(WorkspaceSpec(
                name=mod_name, root=mod_name,
                package_name=artifact_id, declared_deps=deps,
            ))
        if not workspaces:
            return None
        return MonorepoSpec(system="maven", workspaces=workspaces)
