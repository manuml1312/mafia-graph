"""pnpm workspace detector — pnpm-workspace.yaml."""

import glob
import json
from pathlib import Path
from typing import Optional

import yaml

from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class PnpmDetector(WorkspaceDetector):
    name = "pnpm"
    priority = 2

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        ws_yaml = repo_root / "pnpm-workspace.yaml"
        if not ws_yaml.exists():
            return None
        try:
            data = yaml.safe_load(ws_yaml.read_text(encoding="utf-8"))
        except Exception:
            return None
        patterns = data.get("packages", []) if isinstance(data, dict) else []
        if not patterns:
            return None

        workspaces = []
        for pattern in patterns:
            for match in sorted(glob.glob(str(repo_root / pattern))):
                ws_path = Path(match)
                if not ws_path.is_dir():
                    continue
                pkg_name = ""
                deps = []
                ws_pkg = ws_path / "package.json"
                if ws_pkg.exists():
                    try:
                        ws_data = json.loads(ws_pkg.read_text(encoding="utf-8"))
                        pkg_name = ws_data.get("name", "")
                        for dk in ("dependencies", "devDependencies"):
                            deps.extend(ws_data.get(dk, {}).keys())
                    except Exception:
                        pass
                rel = str(ws_path.relative_to(repo_root)).replace("\\", "/")
                workspaces.append(WorkspaceSpec(
                    name=ws_path.name, root=rel,
                    package_name=pkg_name, declared_deps=deps,
                ))
        if not workspaces:
            return None
        return MonorepoSpec(system="pnpm", workspaces=workspaces)
