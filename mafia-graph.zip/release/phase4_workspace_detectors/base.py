"""
MAFIA Workspace Detector Base
==============================
ABC for workspace detectors + shared dataclasses.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class WorkspaceSpec:
    name: str
    root: str  # relative to repo root
    package_name: str = ""
    declared_deps: list[str] = field(default_factory=list)


@dataclass
class MonorepoSpec:
    system: str
    workspaces: list[WorkspaceSpec] = field(default_factory=list)


class WorkspaceDetector(ABC):
    name: str = "base"
    priority: int = 10  # lower = runs first

    @abstractmethod
    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        """Return MonorepoSpec if this repo is a monorepo of this type, else None."""
        ...
