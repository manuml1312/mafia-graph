"""Rush detector — rush.json projects array."""

import json
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class RushDetector(WorkspaceDetector):
    name = "rush"
    priority = 6

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        rush_json = repo_root / "rush.json"
        if not rush_json.exists():
            return None
        try:
            data = json.loads(rush_json.read_text(encoding="utf-8"))
        except Exception:
            return None
        projects = data.get("projects", [])
        if not projects:
            return None
        workspaces = []
        for proj in projects:
            name = proj.get("packageName", proj.get("projectFolder", ""))
            root = proj.get("projectFolder", "")
            workspaces.append(WorkspaceSpec(name=name, root=root))
        return MonorepoSpec(system="rush", workspaces=workspaces)
