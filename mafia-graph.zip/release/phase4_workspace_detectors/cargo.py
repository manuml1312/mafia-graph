"""Cargo workspace detector — Cargo.toml with [workspace] members."""

import tomllib
import glob
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class CargoDetector(WorkspaceDetector):
    name = "cargo"
    priority = 10

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        cargo_toml = repo_root / "Cargo.toml"
        if not cargo_toml.exists():
            return None
        try:
            data = tomllib.loads(cargo_toml.read_text(encoding="utf-8"))
        except Exception:
            return None
        ws = data.get("workspace", {})
        members = ws.get("members", [])
        if not members:
            return None
        workspaces = []
        for pattern in members:
            for match in sorted(glob.glob(str(repo_root / pattern))):
                ws_path = Path(match)
                if ws_path.is_dir():
                    rel = str(ws_path.relative_to(repo_root)).replace("\\", "/")
                    workspaces.append(WorkspaceSpec(name=ws_path.name, root=rel))
        if not workspaces:
            return None
        return MonorepoSpec(system="cargo", workspaces=workspaces)
