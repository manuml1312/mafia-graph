"""Python workspace detector — pyproject.toml with uv workspace or poetry path deps."""

import tomllib
import glob
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class PythonWorkspacesDetector(WorkspaceDetector):
    name = "python_workspaces"
    priority = 13

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        pyproject = repo_root / "pyproject.toml"
        if not pyproject.exists():
            return None
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except Exception:
            return None

        workspaces = []

        # uv workspace: [tool.uv.workspace] members = [...]
        uv_ws = data.get("tool", {}).get("uv", {}).get("workspace", {})
        members = uv_ws.get("members", [])
        for pattern in members:
            for match in sorted(glob.glob(str(repo_root / pattern))):
                ws_path = Path(match)
                if ws_path.is_dir():
                    rel = str(ws_path.relative_to(repo_root)).replace("\\", "/")
                    workspaces.append(WorkspaceSpec(name=ws_path.name, root=rel))

        # Poetry path deps: [tool.poetry.dependencies] foo = {path = "libs/foo"}
        poetry_deps = data.get("tool", {}).get("poetry", {}).get("dependencies", {})
        for dep_name, dep_val in poetry_deps.items():
            if isinstance(dep_val, dict) and "path" in dep_val:
                path_val = dep_val["path"]
                ws_path = repo_root / path_val
                if ws_path.is_dir():
                    rel = str(ws_path.relative_to(repo_root)).replace("\\", "/")
                    if not any(w.root == rel for w in workspaces):
                        workspaces.append(WorkspaceSpec(name=dep_name, root=rel))

        if not workspaces:
            return None
        return MonorepoSpec(system="python_workspaces", workspaces=workspaces)
