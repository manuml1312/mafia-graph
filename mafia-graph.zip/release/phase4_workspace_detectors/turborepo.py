"""Turborepo detector — turbo.json present, reuses npm workspaces resolution."""

from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec
from phase4_workspace_detectors.npm_workspaces import NpmWorkspacesDetector


class TurborepoDetector(WorkspaceDetector):
    name = "turborepo"
    priority = 5

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        if not (repo_root / "turbo.json").exists():
            return None
        # Turborepo uses npm/pnpm/yarn workspaces under the hood
        npm_result = NpmWorkspacesDetector().detect(repo_root)
        if npm_result:
            return MonorepoSpec(system="turborepo", workspaces=npm_result.workspaces)
        return None
