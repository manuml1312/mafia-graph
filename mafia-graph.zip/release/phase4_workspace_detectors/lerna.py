"""lerna detector — lerna.json packages field."""

import json
import glob
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class LernaDetector(WorkspaceDetector):
    name = "lerna"
    priority = 3

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        lerna_json = repo_root / "lerna.json"
        if not lerna_json.exists():
            return None
        try:
            data = json.loads(lerna_json.read_text(encoding="utf-8"))
        except Exception:
            return None
        patterns = data.get("packages", ["packages/*"])
        workspaces = []
        for pattern in patterns:
            for match in sorted(glob.glob(str(repo_root / pattern))):
                ws_path = Path(match)
                if not ws_path.is_dir():
                    continue
                rel = str(ws_path.relative_to(repo_root)).replace("\\", "/")
                workspaces.append(WorkspaceSpec(name=ws_path.name, root=rel))
        if not workspaces:
            return None
        return MonorepoSpec(system="lerna", workspaces=workspaces)
