"""Dotnet solution detector — *.sln with Project(...) entries."""

import re
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class DotnetDetector(WorkspaceDetector):
    name = "dotnet"
    priority = 12

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        sln_files = list(repo_root.glob("*.sln"))
        if not sln_files:
            return None
        workspaces = []
        for sln in sln_files:
            try:
                content = sln.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                continue
            # Project("{...}") = "Name", "path\to\proj.csproj", "{...}"
            for m in re.finditer(r'Project\("[^"]*"\)\s*=\s*"([^"]+)",\s*"([^"]+)"', content):
                name, proj_path = m.group(1), m.group(2)
                proj_path = proj_path.replace("\\", "/")
                # Get directory of the .csproj
                proj_dir = str(Path(proj_path).parent)
                if proj_dir and proj_dir != ".":
                    if not any(w.root == proj_dir for w in workspaces):
                        workspaces.append(WorkspaceSpec(name=name, root=proj_dir))
        if not workspaces:
            return None
        return MonorepoSpec(system="dotnet", workspaces=workspaces)
