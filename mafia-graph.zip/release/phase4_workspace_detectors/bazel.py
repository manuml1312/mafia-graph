"""Bazel detector — WORKSPACE or MODULE.bazel + BUILD files."""

from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class BazelDetector(WorkspaceDetector):
    name = "bazel"
    priority = 9

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        has_ws = (repo_root / "WORKSPACE").exists() or (repo_root / "MODULE.bazel").exists()
        if not has_ws:
            return None
        workspaces = []
        for build_file in sorted(repo_root.rglob("BUILD")) + sorted(repo_root.rglob("BUILD.bazel")):
            pkg_dir = build_file.parent
            if pkg_dir == repo_root:
                continue
            rel = str(pkg_dir.relative_to(repo_root)).replace("\\", "/")
            # Avoid deep nesting — only top-level packages
            if rel.count("/") <= 1:
                if not any(w.root == rel for w in workspaces):
                    workspaces.append(WorkspaceSpec(name=pkg_dir.name, root=rel))
        if not workspaces:
            return None
        return MonorepoSpec(system="bazel", workspaces=workspaces)
