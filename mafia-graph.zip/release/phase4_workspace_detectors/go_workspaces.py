"""Go workspaces detector — go.work with use directives."""

import re
from pathlib import Path
from typing import Optional
from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec, WorkspaceSpec


class GoWorkspacesDetector(WorkspaceDetector):
    name = "go_workspaces"
    priority = 11

    def detect(self, repo_root: Path) -> Optional[MonorepoSpec]:
        go_work = repo_root / "go.work"
        if not go_work.exists():
            return None
        try:
            content = go_work.read_text(encoding="utf-8")
        except Exception:
            return None
        # Match use ( ./mod-a ./mod-b ) or use ./mod-a
        uses = re.findall(r'(?:use\s*\(\s*(.*?)\s*\)|use\s+(\S+))', content, re.DOTALL)
        dirs = []
        for block, single in uses:
            if block:
                dirs.extend(block.split())
            if single:
                dirs.append(single)
        dirs = [d.strip().strip("./") for d in dirs if d.strip()]
        if not dirs:
            return None
        workspaces = [WorkspaceSpec(name=Path(d).name, root=d) for d in dirs]
        return MonorepoSpec(system="go_workspaces", workspaces=workspaces)
