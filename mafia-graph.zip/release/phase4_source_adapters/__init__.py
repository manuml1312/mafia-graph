"""
MAFIA Source Adapters
=====================
Registry of source adapters. resolve_source picks the first matching adapter.
"""

from pathlib import Path
from phase4_source_adapters.base import SourceAdapter
from phase4_source_adapters.folder_adapter import FolderAdapter
from phase4_source_adapters.zip_adapter import ZipAdapter
from phase4_source_adapters.tar_adapter import TarAdapter
from phase4_source_adapters.git_adapter import GitAdapter

_BUILTIN_ADAPTERS: list[SourceAdapter] = [
    ZipAdapter(),
    TarAdapter(),
    GitAdapter(),
    FolderAdapter(),  # last — accepts any existing directory
]

_extra_adapters: list[SourceAdapter] = []


def _load_plugin_adapters() -> list[SourceAdapter]:
    """Discover plugin source adapters via entry points."""
    try:
        from mafia.plugins import load_plugins
        plugins = load_plugins("mafia.source_adapters")
        return [cls() for cls in plugins.values()]
    except Exception:
        return []


def register_adapter(adapter: SourceAdapter):
    """Register a plugin adapter (checked before built-ins)."""
    _extra_adapters.insert(0, adapter)


def resolve_source(descriptor: str, work_dir: Path | None = None) -> Path:
    """Resolve an input descriptor to a filesystem root using the first matching adapter."""
    if work_dir is None:
        work_dir = Path(".mafia")
    for adapter in _load_plugin_adapters() + _extra_adapters + _BUILTIN_ADAPTERS:
        if adapter.accepts(descriptor):
            return adapter.resolve(descriptor, work_dir)
    raise ValueError(f"No source adapter accepts: {descriptor}")
