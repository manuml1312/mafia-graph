"""TarAdapter — extracts tar archives to a cached work directory."""

import hashlib
import tarfile
from pathlib import Path
from phase4_source_adapters.base import SourceAdapter

_TAR_EXTENSIONS = (".tar", ".tar.gz", ".tgz", ".tar.bz2")


class TarAdapter(SourceAdapter):
    name = "tar"

    def accepts(self, descriptor: str) -> bool:
        low = descriptor.lower()
        return any(low.endswith(ext) for ext in _TAR_EXTENSIONS) and Path(descriptor).is_file()

    def resolve(self, descriptor: str, work_dir: Path) -> Path:
        src = Path(descriptor)
        if not src.is_file():
            raise FileNotFoundError(f"Tar file not found: {descriptor}")
        file_hash = hashlib.sha256(src.read_bytes()).hexdigest()[:16]
        dest = work_dir / "extracted" / file_hash
        sentinel = dest / ".mafia_extracted"
        if sentinel.exists():
            return dest
        dest.mkdir(parents=True, exist_ok=True)
        with tarfile.open(src, "r:*") as tf:
            tf.extractall(dest)
        sentinel.touch()
        return dest
