"""
MAFIA Source Adapter Base
=========================
ABC for source adapters that resolve input descriptors to filesystem roots.
"""

from abc import ABC, abstractmethod
from pathlib import Path


class SourceAdapter(ABC):
    """Resolves an input descriptor to a normalized filesystem root."""

    name: str = "base"

    @abstractmethod
    def accepts(self, descriptor: str) -> bool:
        """Return True if this adapter can handle the descriptor."""
        ...

    @abstractmethod
    def resolve(self, descriptor: str, work_dir: Path) -> Path:
        """Resolve descriptor to a local filesystem root."""
        ...
