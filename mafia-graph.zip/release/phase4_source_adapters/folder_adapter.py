"""FolderAdapter — returns the path unchanged if it's a directory."""

from pathlib import Path
from phase4_source_adapters.base import SourceAdapter


class FolderAdapter(SourceAdapter):
    name = "folder"

    def accepts(self, descriptor: str) -> bool:
        return Path(descriptor).is_dir()

    def resolve(self, descriptor: str, work_dir: Path) -> Path:
        p = Path(descriptor)
        if not p.is_dir():
            raise FileNotFoundError(f"Not a directory: {descriptor}")
        return p.resolve()
