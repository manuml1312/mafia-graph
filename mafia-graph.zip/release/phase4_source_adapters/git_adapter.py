"""GitAdapter — shallow-clones a git URL to a cached work directory."""

import hashlib
import subprocess
from pathlib import Path
from phase4_source_adapters.base import SourceAdapter


class GitAdapter(SourceAdapter):
    name = "git"

    def accepts(self, descriptor: str) -> bool:
        return descriptor.startswith(("https://", "git://", "git@", "ssh://"))

    def resolve(self, descriptor: str, work_dir: Path, ref: str = "HEAD") -> Path:
        url_hash = hashlib.sha256(f"{descriptor}:{ref}".encode()).hexdigest()[:16]
        dest = work_dir / "cloned" / url_hash
        sentinel = dest / ".mafia_cloned"
        if sentinel.exists():
            return dest
        dest.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["git", "clone", "--depth", "1", descriptor, str(dest)],
            check=True, capture_output=True,
        )
        sentinel.touch()
        return dest
