"""ZipAdapter — extracts .zip archives to a cached work directory."""

import hashlib
import zipfile
from pathlib import Path
from phase4_source_adapters.base import SourceAdapter


class ZipAdapter(SourceAdapter):
    name = "zip"

    def accepts(self, descriptor: str) -> bool:
        return descriptor.lower().endswith(".zip") and Path(descriptor).is_file()

    def resolve(self, descriptor: str, work_dir: Path) -> Path:
        src = Path(descriptor)
        if not src.is_file():
            raise FileNotFoundError(f"Zip file not found: {descriptor}")
        file_hash = hashlib.sha256(src.read_bytes()).hexdigest()[:16]
        dest = work_dir / "extracted" / file_hash
        sentinel = dest / ".mafia_extracted"
        if sentinel.exists():
            return dest
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(src, "r") as zf:
            zf.extractall(dest)
        sentinel.touch()
        return dest
