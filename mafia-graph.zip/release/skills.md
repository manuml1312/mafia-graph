# MAFIA Skills — What This System Can Do

> This file is context for AI agents. Read it to understand what capabilities are available and how to use them.

## First-Time Setup

```bash
cd MAFIA_Phase1_Execution
setup.bat              # creates venv, installs deps, validates imports
setup.bat --extras     # also installs 9 extra language grammars
```

After setup, activate the venv (`.venv/Scripts/activate` on Windows, `source .venv/bin/activate` on Mac/Linux) before running any commands.

## System Overview

MAFIA is a codebase analysis pipeline that extracts entities (endpoints, controllers, services, tables, functions, components) from a multi-layer microservice architecture (UI → BFF → API → DB), builds a system graph, assembles end-to-end flows, and serves an interactive explorer.

All artifacts live in `output/`. All commands run from `MAFIA_Phase1_Execution/`.

---

## Skill 1: Scan & Discover Repositories

**When to use:** User has source code directories and wants to analyze them.

```bash
python -m phase2_repo_intake.repo_scanner --source-roots /path/to/repos
```

**What it produces:** `output/repo_manifest.json` — every repo with its classification (ui/bff/api/db/data/config), detected tech stack, and root path.

**In Python:**
```python
from phase2_repo_intake.repo_scanner import scan_roots
manifest = scan_roots(["/path/to/repos"])
# manifest["repos"] → list of {repo_id, classification, detected_stack, root_path}
```

---

## Skill 2: Extract Entities & Relations

**When to use:** User wants to extract all code entities and their relationships.

```bash
# Incremental (default — skips unchanged repos)
python -m phase3_extraction_framework.run_extraction

# Full re-extraction
python -m phase3_extraction_framework.run_extraction --full

# Only rebuild graph from existing entities
python -m phase3_extraction_framework.run_extraction --from-phase 9
```

**What it produces:**
- `output/entities.jsonl` — every entity with ID, layer, type, confidence, evidence
- `output/relations.jsonl` — every edge between entities
- `output/extraction_report.json` — per-repo extraction stats

**Entity ID format:** `{layer}:{type}:{repo}:{qualifier}`
- Example: `api:endpoint:marvel_flags_api:GET:/flagTypes`
- Example: `db:table:pg:dre.flag_type`
- Example: `ui:component:web_app:src/pages/FlagPage.tsx::FlagTable`

**In Python:**
```python
import json
entities = [json.loads(line) for line in open("output/entities.jsonl")]
relations = [json.loads(line) for line in open("output/relations.jsonl")]

# Filter by layer
api_endpoints = [e for e in entities if e["layer"] == "api" and e["type"] == "endpoint"]

# Filter by confidence
high_conf = [e for e in entities if e["confidence"] >= 0.85]
```

---

## Skill 3: Query the System Graph

**When to use:** User asks about what connects to what, dependencies, or architecture.

**The graph is in** `output/system_graph.json` with `nodes` and `edges` arrays.

**In Python:**
```python
from phase9_graph.graph_query import GraphQuery
gq = GraphQuery("output")

# Get a node and all its connections
profile = gq.get_node("api:endpoint:marvel_flags_api:GET:/flagTypes")

# Get neighbors
neighbors = gq.get_neighbors("api:controller:marvel_flags_api:FlagController.java::getFlagTypes", depth=2)

# Find all nodes of a type
all_services = gq.query(layer="api", type="service")

# Find cross-layer connections
cross = gq.cross_layer_edges(source_layer="bff", target_layer="api")
```

**Via HTTP (if server is running on localhost:5001):**
```
GET /node/api:endpoint:marvel_flags_api:GET:/flagTypes
GET /node/api:endpoint:marvel_flags_api:GET:/flagTypes/neighbors?depth=2&direction=both
GET /inventory
GET /graph/full?layer=api&limit=200
```

---

## Skill 4: Trace End-to-End Flows

**When to use:** User asks "what happens when a user clicks X" or "trace the flow from UI to database."

**Flows are in** `output/e2e_flows.json` organized by catalog:
- `full_chains` — all flows from entry to deepest reachable node
- `complete_flows` — flows that reach the DB layer
- `partial_flows` — flows that break before reaching DB
- `ui_to_db`, `bff_to_api`, `api_to_db` — layer-specific catalogs

**In Python:**
```python
import json
flows = json.load(open("output/e2e_flows.json"))

# Get all complete flows
complete = flows["catalogs"]["complete_flows"]

# Each flow has:
# - flow_id, entry, terminal, hop_count, completeness
# - confidence_range: {min, max, avg}
# - standard: [{id, name, layer, type, repo, confidence, next_relation}, ...]
# - breakpoint (for partial flows): {reason_code, message, layer, node_id}

# Find flows involving a specific entity
flag_flows = [f for f in flows["catalogs"]["full_chains"]
              if any("flag" in h.get("name","").lower() for h in f["standard"])]
```

**Via HTTP:**
```
GET /flows?start_node=api:endpoint:marvel_flags_api:GET:/flagTypes
GET /flow/full::ui:fetch_def:web_app:src/api/flagApi.ts::getFlagTypes?depth=deep
```

---

## Skill 5: Blast Radius / Impact Analysis

**When to use:** User asks "what breaks if X changes" or "what's the impact of modifying this service."

**In Python:**
```python
from phase9_graph.blast_radius_engine import BlastRadiusEngine
engine = BlastRadiusEngine("output/system_graph.json")

result = engine.compute(
    "api:service:marvel_flags_api:FlagServiceImpl.java::getFlagTypes",
    direction="both",      # downstream, upstream, or both
    change_type="failure", # failure, contract_change, removal
    max_depth=6,
)
# result has: impacted_nodes (with severity), by_layer, severity_counts, paths
```

**Via HTTP:**
```
POST /blast_radius
{"component_id": "api:service:...", "direction": "both", "max_depth": 6}
```

---

## Skill 6: Read Source Code

**When to use:** User asks to see the actual code for an entity.

**Via HTTP:**
```
GET /code/api:controller:marvel_flags_api:FlagController.java::getFlagTypes?context_lines=30
GET /codefile?id=api:controller:marvel_flags_api:FlagController.java::getFlagTypes
```

**In Python:**
```python
from phase11_search.code_reader import CodeReader
reader = CodeReader("output")

# Focused view (just the method + context)
code = reader.read_entity_code("api:controller:...", context_lines=30)

# Full file with highlight
full = reader.read_full_file("api:controller:...")
```

---

## Skill 7: Search (Vector + Graph)

**When to use:** User searches by natural language or keyword.

**Via HTTP:**
```
GET /search?q=flag+types&layer=api&top_k=20
GET /search?q=user+authentication&confidence_bucket=high
```

**In Python:**
```python
from phase11_search.graph_retriever import GraphRetriever
from phase11_search.vector_index import VectorIndex

vi = VectorIndex.load("output/search_index")
retriever = GraphRetriever(vi, "output/system_graph.json")

results = retriever.retrieve("flag types", top_k=20, filters={"layer": "api"})
# results: {results: [{id, name, layer, type, score, ...}], total, ...}
```

---

## Skill 8: AST Structural Summaries

**When to use:** User asks about method signatures, call chains, complexity, or code structure.

```bash
# Summarize methods matching existing entities
python -m phase10_ast.run_ast_summaries

# Discover ALL methods in the codebase
python -m phase10_ast.run_ast_summaries --discover
```

**What it produces:** `output/ast_summaries.jsonl` — per-method structural summaries with:
- `signature`, `return_type`, `parameters`
- `calls_made` (what this method calls)
- `exceptions_thrown`, `config_refs`
- `cyclomatic_complexity`, `line_count`

**Via HTTP:**
```
GET /ast_summary/api:controller:marvel_flags_api:FlagController.java::getFlagTypes
GET /ast_file/api:controller:marvel_flags_api:FlagController.java::getFlagTypes
```

---

## Skill 9: Coverage & Quality Analysis

**When to use:** User asks about extraction quality, gaps, or health.

**Files:**
- `output/coverage_report.json` — parse rates, extraction rates, gaps
- `output/mapping_confidence_report.json` — cross-layer mapping quality
- `output/quality_gate_report.json` — 18-check pass/fail gate
- `output/topology_report.json` — communities, god nodes, bridges

**Via HTTP:**
```
GET /coverage
GET /weak-points
```

**In Python:**
```python
import json
gate = json.load(open("output/quality_gate_report.json"))
print(f"Gate: {'PASSED' if gate['gate_passed'] else 'FAILED'}")
for check in gate["checks"]:
    print(f"  {'✓' if check['passed'] else '✗'} {check['name']}: {check['value']}")
```

---

## Skill 10: AI Chat (RAG-Grounded)

**When to use:** User asks a complex question about the codebase that needs reasoning.

**Via HTTP:**
```
POST /chat
{"message": "What happens when a user updates a flag?", "code_mode": true}
```

**In Python:**
```python
from phase11_search.chat_engine import ChatEngine
engine = ChatEngine("output")
conv_id = engine.create_conversation()
result = engine.chat(conv_id, "What connects to the flags database?", code_mode=True)
# result: {response, sources, warnings, stats}
```

---

## Skill 11: Change Simulation

**When to use:** User asks "what if we remove this service" or "what's the risk of changing this API."

**Via HTTP:**
```
POST /simulate
{"type": "removal", "node_id": "api:service:..."}
{"type": "contract_change", "node_id": "api:endpoint:...", "changes": ["path", "response_schema"]}
{"type": "failure", "node_id": "api:service:...", "duration": "permanent"}
```

---

## Skill 12: Document Ingestion

**When to use:** User wants to add supplementary docs (PDFs, DOCX, XLSX, Markdown) to the knowledge base.

**Via HTTP:**
```
POST /docs/upload  (multipart/form-data with 'file' field)
POST /docs/ingest-dir  {"path": "/path/to/docs", "tags": ["architecture"]}
GET /docs
```

---

## Entity Types Reference

| Layer | Types |
|-------|-------|
| ui | component, hook, selector, fetch_def, route, env_var, module |
| bff | endpoint, controller, middleware, service, constant |
| api | endpoint, controller, service, repository, entity, dto, util, config |
| db | function, table, view, schema |
| config | env, toggle, property, secret |
| shared | library, module, class, function |

## Relation Types Reference

| Category | Types |
|----------|-------|
| Call chain | calls, invokes_http, routes_to, delegates_to, uses_repo |
| Data | reads_from, writes_to, calls_function, uses_table, entity_maps_to |
| Structural | defined_in, belongs_to_repo, imports, exports |
| Config | depends_on_config, validates_with |
| Cross-layer | fetches (UI→BFF), calls_api (BFF→API) |

## Confidence Levels

| Score | Label | Meaning |
|-------|-------|---------|
| 0.95 | Exact | AST or deterministic regex match |
| 0.85 | Strong | High-confidence heuristic |
| 0.70 | Inferred | Cross-file resolution |
| 0.50 | Weak | Partial evidence |
| 0.30 | Guess | Very low evidence |
