"""
MAFIA Canonical ID Format
=========================
Every entity in the system gets a deterministic, globally unique ID.
Format: {layer}:{type}:{repo}:{qualifier}

Examples:
    ui:component:web_app_release:src/pages/FlagPage.tsx::FlagTable
    ui:hook:web_app_release:src/hooks/useFlags.ts::useFlags
    ui:route:web_app_release:/flags
    ui:fetch_def:web_app_release:src/api/flagApi.ts::getFlagTypes
    bff:endpoint:marvel_flags_bff:/flagTypes
    bff:controller:marvel_flags_bff:src/app/controller/controller.ts::getFlagTypesAndCustomFlagLables
    bff:middleware:marvel_flags_bff:src/app/middleware/validateHeader.ts::validateBaseHeader
    api:endpoint:marvel_flags_(develop)_api:GET:/flagTypes
    api:controller:marvel_flags_(develop)_api:FlagController.java::getFlagTypes
    api:service:marvel_flags_(develop)_api:FlagServiceImpl.java::getFlagTypes
    api:repository:marvel_flags_(develop)_api:FlagRepository.java::findFlagTypes
    db:function:pg:dre.get_flag_types
    db:table:pg:dre.flag_type
    db:table:databricks:catalog.schema.table_name
    config:env:web_app_release:NEXT_PUBLIC_FLAGS_BFF_URL
    config:toggle:web_app_release:ENABLE_FLAG_EDITING

Layer values:  ui | bff | api | db | config | shared
Type values:   per-layer (see ENTITY_TYPES below)
Repo:          repo folder name or logical name
Qualifier:     file_path::symbol_name or path or schema.name
"""


# ── Valid layers ─────────────────────────────────────────────────────────────

LAYERS = {
    # Specialized (existing)
    "ui", "bff", "api", "db", "data", "config", "shared",
    # Generic (new in v2)
    "code", "lib", "infra", "test", "doc",
}

# ── Valid entity types per layer ─────────────────────────────────────────────

ENTITY_TYPES = {
    "ui": {
        "component",    # React component / page
        "hook",         # custom hook
        "selector",     # Recoil selector / Redux selector
        "route",        # page route
        "fetch_def",    # API call definition (fetch wrapper)
        "env_var",      # process.env usage
        "module",       # file-level module
    },
    "bff": {
        "endpoint",     # registered route
        "controller",   # controller method
        "middleware",    # validation / auth middleware
        "service",      # if BFF has service layer
        "constant",     # Constant.xxx_bff / Constant.xxx_API
    },
    "api": {
        "endpoint",     # @GetMapping etc
        "controller",   # controller method
        "service",      # service method
        "repository",   # repository method
        "entity",       # JPA @Entity class
        "dto",          # request/response model
        "util",         # utility class
        "config",       # @Configuration class
    },
    "db": {
        "function",     # pg stored function
        "table",        # schema.table
        "view",         # schema.view
        "schema",       # schema itself
    },
    "config": {
        "env",          # environment variable
        "toggle",       # feature toggle
        "property",     # application.properties / yml key
        "secret",       # secret manager reference
    },
    "shared": {
        "library",      # shared npm/maven package
        "module",       # shared module / file-level code
        "class",        # class with no recognized layer
        "function",     # function/method with no recognized layer
    },
    "data": {
        "table",        # data platform table
        "function",     # data transform function
        "pipeline",     # data pipeline
        "notebook",     # notebook
    },
    # ── Generic layers (v2) ──────────────────────────────────────────────
    "code": {
        "module",       # file-level module
        "function",     # function / method
        "class",        # class / struct
        "interface",    # interface / protocol
        "trait",        # trait (Rust, Scala)
    },
    "lib": {
        "package",      # npm/maven/pip package
        "library",      # shared library
        "binding",      # language binding
    },
    "infra": {
        "dockerfile",   # Dockerfile
        "ci_pipeline",  # CI/CD pipeline
        "deployment",   # deployment config
        "iac_resource", # IaC resource (Terraform, CloudFormation)
    },
    "test": {
        "test_module",  # test file
        "test_case",    # individual test
    },
    "doc": {
        "document",     # documentation file
        "section",      # document section
    },
}

# ── Valid relation types ─────────────────────────────────────────────────────

RELATION_TYPES = {
    # Structural
    "defined_in",           # entity → file/module
    "belongs_to_repo",      # entity → repo
    "belongs_to_layer",     # entity → layer
    "imports",              # file imports symbol
    "exports",              # file exports symbol

    # Behavioral — call chain
    "calls",                # generic function call
    "invokes_http",         # HTTP call (UI→BFF, BFF→API)
    "routes_to",            # route registration → handler
    "delegates_to",         # controller → service
    "uses_repo",            # service → repository

    # Data
    "reads_from",           # reads table/view
    "writes_to",            # writes table
    "calls_function",       # repo method → pg function
    "uses_table",           # pg function → table
    "entity_maps_to",       # JPA entity → table

    # Config
    "depends_on_config",    # code depends on env/toggle
    "validates_with",       # middleware validates request

    # Cross-layer HTTP
    "fetches",              # UI fetch_def → BFF endpoint
    "calls_api",            # BFF controller → API endpoint

    # Cross-DB tentative
    "potential_shared_table",  # cross-db-engine table name match (unverified)

    # ── Cross-scope (v2) ─────────────────────────────────────────────────
    "workspace_depends_on",       # workspace → workspace declared dep
    "cross_workspace_import",     # import crossing workspace boundary
    "cross_repo_import",          # import crossing repo boundary
    "shared_lib_used_by",         # shared lib → consumer workspace
    "shares_table_with",          # table shared across workspaces
    "shares_env_with",            # env var shared across workspaces
    "consumes_artifact",          # workspace consumes another's build artifact
}

# ── Confidence levels ────────────────────────────────────────────────────────

CONFIDENCE = {
    "exact":    0.95,   # deterministic match: AST, regex on known pattern
    "strong":   0.85,   # high-confidence heuristic: naming convention + context
    "inferred": 0.70,   # cross-file resolution, last-segment URL match
    "weak":     0.50,   # partial evidence, ambiguous
    "guess":    0.30,   # very low evidence, flagged for review
}

# ── ID format version ────────────────────────────────────────────────────────

ID_FORMAT_VERSION = 2


from dataclasses import dataclass


@dataclass(frozen=True)
class ParsedEntityId:
    layer: str
    entity_type: str
    scope_path: str
    qualifier: str


def parse_entity_id(eid: str) -> ParsedEntityId:
    """Parse 'layer:type:scope_path:qualifier' into components.
    scope_path may contain '/' for multi-level scopes."""
    parts = eid.split(":", 3)
    if len(parts) < 4:
        raise ValueError(f"Malformed entity ID (need 4+ colon-separated parts): {eid}")
    return ParsedEntityId(layer=parts[0], entity_type=parts[1],
                          scope_path=parts[2], qualifier=parts[3])


def make_entity_id(layer: str, entity_type: str, repo: str = "",
                   qualifier: str = "", *, scope_path: str | None = None) -> str:
    """Build canonical entity ID.

    Accepts either legacy positional (layer, type, repo, qualifier)
    or keyword scope_path= for v2 scope paths.
    """
    effective_scope = scope_path if scope_path is not None else repo
    assert layer in LAYERS, f"Invalid layer: {layer}"
    assert entity_type in ENTITY_TYPES.get(layer, set()), \
        f"Invalid type '{entity_type}' for layer '{layer}'"
    return f"{layer}:{entity_type}:{effective_scope}:{qualifier}"


def migrate_entity_id_v1_to_v2(eid: str) -> str:
    """Migrate a v1 entity ID to v2 format.
    Currently identity — v1 IDs are valid v2 IDs (repo becomes scope_path)."""
    parse_entity_id(eid)  # validate structure
    return eid


def make_relation_id(source_id: str, relation_type: str, target_id: str) -> str:
    """Build canonical relation ID (deterministic, dedup-safe)."""
    assert relation_type in RELATION_TYPES, f"Invalid relation: {relation_type}"
    return f"{source_id}--{relation_type}-->{target_id}"
