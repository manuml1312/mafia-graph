"""
MAFIA Canonical Emitter
=======================
Single interface for all extractors to emit entities and relations.
Enforces schema, attaches evidence, validates IDs, deduplicates.

Usage:
    emitter = CanonicalEmitter("my_extractor")
    emitter.emit_entity(
        layer="api", entity_type="controller", repo="marvel_flags_api",
        qualifier="FlagController.java::getFlagTypes",
        name="getFlagTypes",
        file="src/main/.../FlagController.java", line=42,
        confidence=0.95,
        evidence_file="src/main/.../FlagController.java",
        evidence_line_start=42, evidence_line_end=55,
        evidence_snippet="@GetMapping(...)",
        evidence_method="regex",
        properties={"http_method": "GET", "endpoint_path": "/flagTypes"},
    )
    emitter.emit_relation(
        source_id="api:controller:...", target_id="api:service:...",
        relation_type="delegates_to",
        confidence=0.95,
        evidence_file="...", evidence_line_start=45,
        evidence_method="regex",
    )
    emitter.flush("output/entities.jsonl", "output/relations.jsonl")
"""

import json
import threading
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from schemas.scope import Scope

from schemas.id_format import (
    LAYERS, ENTITY_TYPES, RELATION_TYPES, CONFIDENCE,
    ID_FORMAT_VERSION,
    make_entity_id, make_relation_id, parse_entity_id,
)


class EmitterError(Exception):
    pass


class CanonicalEmitter:
    """Thread-safe emitter for entities and relations."""

    def __init__(self, extractor_name: str):
        self.extractor_name = extractor_name
        self._entities: dict[str, dict] = {}   # id -> entity
        self._relations: dict[str, dict] = {}  # id -> relation
        self._warnings: list[dict] = []
        self._lock = threading.Lock()
        self._counters = {"entities": 0, "relations": 0, "warnings": 0, "duplicates": 0}
        self._emit_counts: dict[str, int] = {}  # id -> times emitted (for Bayesian boost)

    # ── Entity emission ──────────────────────────────────────────────────────

    def emit_entity(
        self,
        layer: str,
        entity_type: str,
        repo: str = "",
        qualifier: str = "",
        name: str = "",
        confidence: float = 0.95,
        evidence_file: str = "",
        evidence_method: str = "",
        file: Optional[str] = None,
        line: Optional[int] = None,
        evidence_line_start: Optional[int] = None,
        evidence_line_end: Optional[int] = None,
        evidence_snippet: Optional[str] = None,
        properties: Optional[dict] = None,
        warnings: Optional[list[str]] = None,
        scope: Optional["Scope"] = None,
    ) -> str:
        """Emit one entity. Returns the canonical ID.

        Accepts either legacy `repo` positional or `scope` keyword.
        When scope is given, scope_path/codebase/repo/workspace are derived from it.
        """
        # Resolve scope
        if scope is not None:
            effective_scope = scope.path
            codebase_val = scope.codebase
            repo_val = scope.repo
            workspace_val = scope.workspace
        else:
            effective_scope = repo
            codebase_val = repo
            repo_val = repo
            workspace_val = repo

        # Validate
        if layer not in LAYERS:
            raise EmitterError(f"Invalid layer '{layer}'. Valid: {LAYERS}")
        valid_types = ENTITY_TYPES.get(layer, set())
        if entity_type not in valid_types:
            raise EmitterError(f"Invalid type '{entity_type}' for layer '{layer}'. Valid: {valid_types}")
        if not (0.0 <= confidence <= 1.0):
            raise EmitterError(f"Confidence must be 0.0-1.0, got {confidence}")

        entity_id = make_entity_id(layer, entity_type, qualifier=qualifier,
                                   scope_path=effective_scope)

        entity = {
            "id": entity_id,
            "layer": layer,
            "type": entity_type,
            "repo": effective_scope,
            "codebase": codebase_val,
            "workspace": workspace_val,
            "scope_path": effective_scope,
            "name": name,
            "file": file,
            "line": line,
            "confidence": confidence,
            "evidence": {
                "repo": effective_scope,
                "file": evidence_file,
                "line_start": evidence_line_start,
                "line_end": evidence_line_end,
                "snippet": (evidence_snippet[:500] if evidence_snippet else None),
                "extractor": self.extractor_name,
                "method": evidence_method,
            },
            "properties": properties or {},
            "warnings": warnings or [],
        }

        with self._lock:
            if entity_id in self._entities:
                self._counters["duplicates"] += 1
                self._emit_counts[entity_id] = self._emit_counts.get(entity_id, 1) + 1
                # Merge: keep higher confidence, merge warnings
                existing = self._entities[entity_id]
                if confidence > existing["confidence"]:
                    entity["warnings"] = list(set(existing.get("warnings", []) + (warnings or [])))
                    self._entities[entity_id] = entity
                return entity_id
            self._entities[entity_id] = entity
            self._emit_counts[entity_id] = 1
            self._counters["entities"] += 1

        return entity_id

    # ── Relation emission ────────────────────────────────────────────────────

    def emit_relation(
        self,
        source_id: str,
        target_id: str,
        relation_type: str,
        confidence: float,
        evidence_file: str,
        evidence_method: str,
        evidence_line_start: Optional[int] = None,
        evidence_line_end: Optional[int] = None,
        evidence_snippet: Optional[str] = None,
        properties: Optional[dict] = None,
        unresolved_target: Optional[str] = None,
        candidates: Optional[list[dict]] = None,
    ) -> str:
        """Emit one relation. Returns the canonical relation ID."""
        if relation_type not in RELATION_TYPES:
            raise EmitterError(f"Invalid relation type '{relation_type}'. Valid: {RELATION_TYPES}")
        if not (0.0 <= confidence <= 1.0):
            raise EmitterError(f"Confidence must be 0.0-1.0, got {confidence}")

        rel_id = make_relation_id(source_id, relation_type, target_id)

        # Cross-scope tagging
        cross_scope = False
        boundary = None
        try:
            src_parsed = parse_entity_id(source_id)
            tgt_parsed = parse_entity_id(target_id)
            src_parts = src_parsed.scope_path.split("/")
            tgt_parts = tgt_parsed.scope_path.split("/")
            if src_parsed.scope_path != tgt_parsed.scope_path:
                cross_scope = True
                # Pad to 3 levels for comparison
                while len(src_parts) < 3:
                    src_parts.append(src_parts[-1])
                while len(tgt_parts) < 3:
                    tgt_parts.append(tgt_parts[-1])
                if src_parts[0] != tgt_parts[0]:
                    boundary = "codebase"
                elif src_parts[1] != tgt_parts[1]:
                    boundary = "repo"
                else:
                    boundary = "workspace"
        except (ValueError, IndexError):
            pass

        relation = {
            "id": rel_id,
            "source": source_id,
            "target": target_id,
            "type": relation_type,
            "confidence": confidence,
            "cross_scope": cross_scope,
            "boundary": boundary,
            "evidence": {
                "repo": source_id.split(":")[2] if len(source_id.split(":")) > 2 else "",
                "file": evidence_file,
                "line_start": evidence_line_start,
                "line_end": evidence_line_end,
                "snippet": (evidence_snippet[:500] if evidence_snippet else None),
                "extractor": self.extractor_name,
                "method": evidence_method,
            },
            "properties": properties or {},
            "unresolved_target": unresolved_target,
            "candidates": candidates,
        }

        with self._lock:
            if rel_id in self._relations:
                self._counters["duplicates"] += 1
                existing = self._relations[rel_id]
                if confidence > existing["confidence"]:
                    self._relations[rel_id] = relation
                return rel_id
            self._relations[rel_id] = relation
            self._counters["relations"] += 1

        return rel_id

    # ── Warning emission ─────────────────────────────────────────────────────

    def emit_warning(self, category: str, message: str, file: Optional[str] = None, line: Optional[int] = None):
        with self._lock:
            self._warnings.append({
                "extractor": self.extractor_name,
                "category": category,
                "message": message,
                "file": file,
                "line": line,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            })
            self._counters["warnings"] += 1

    # ── Flush to disk ────────────────────────────────────────────────────────

    def flush(self, entities_path: str, relations_path: str, warnings_path: Optional[str] = None):
        """Write all accumulated entities and relations to JSONL files (append mode)."""
        entities_path = Path(entities_path)
        relations_path = Path(relations_path)

        entities_path.parent.mkdir(parents=True, exist_ok=True)
        relations_path.parent.mkdir(parents=True, exist_ok=True)

        with self._lock:
            with open(entities_path, "a", encoding="utf-8") as f:
                for entity in self._entities.values():
                    f.write(json.dumps(entity, ensure_ascii=False) + "\n")

            with open(relations_path, "a", encoding="utf-8") as f:
                for relation in self._relations.values():
                    f.write(json.dumps(relation, ensure_ascii=False) + "\n")

            if warnings_path and self._warnings:
                warnings_path = Path(warnings_path)
                warnings_path.parent.mkdir(parents=True, exist_ok=True)
                with open(warnings_path, "a", encoding="utf-8") as f:
                    for warning in self._warnings:
                        f.write(json.dumps(warning, ensure_ascii=False) + "\n")

        # Write id_format version sidecar
        sidecar = entities_path.parent / "id_format.json"
        with open(sidecar, "w", encoding="utf-8") as f:
            json.dump({"id_format_version": ID_FORMAT_VERSION}, f)

        print(f"[{self.extractor_name}] Flushed: "
              f"{self._counters['entities']} entities, "
              f"{self._counters['relations']} relations, "
              f"{self._counters['warnings']} warnings, "
              f"{self._counters['duplicates']} duplicates merged")

    # ── Stats ────────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        with self._lock:
            return {
                **self._counters,
                "entity_ids": len(self._entities),
                "relation_ids": len(self._relations),
            }

    # ── Bayesian confidence adjustment ───────────────────────────────────────

    def adjust_confidence(self):
        """
        Post-processing Bayesian adjustment on all entities.
        Called after all extractors have merged, before flush.

        Adjustments:
          1. Multi-extractor confirmation: +0.05 per additional emitter (capped +0.10)
          2. Relation-backed boost: +0.03 if entity has both upstream and downstream
          3. Isolation penalty: -0.05 if zero relations (except config layer)
          4. Test-file penalty: -0.10 if file path contains /test/ or /mock/

        All values clamped to [0.0, 1.0].
        """
        rel_index = {}
        for rel in self._relations.values():
            src, tgt = rel.get("source", ""), rel.get("target", "")
            if src:
                rel_index.setdefault(src, {"as_source": 0, "as_target": 0})["as_source"] += 1
            if tgt:
                rel_index.setdefault(tgt, {"as_source": 0, "as_target": 0})["as_target"] += 1

        adjusted = 0
        with self._lock:
            for eid, entity in self._entities.items():
                original = entity["confidence"]
                delta = 0.0

                emit_count = self._emit_counts.get(eid, 1)
                if emit_count > 1:
                    delta += min(0.10, (emit_count - 1) * 0.05)

                ri = rel_index.get(eid, {"as_source": 0, "as_target": 0})
                if ri["as_source"] > 0 and ri["as_target"] > 0:
                    delta += 0.03

                if ri["as_source"] == 0 and ri["as_target"] == 0 and entity.get("layer") != "config":
                    delta -= 0.05

                fpath = (entity.get("file") or "").lower()
                if '/test/' in fpath or '/mock/' in fpath or '/example/' in fpath or '/__test' in fpath:
                    delta -= 0.10

                if delta != 0.0:
                    entity["confidence"] = round(max(0.0, min(1.0, original + delta)), 3)
                    adjusted += 1

        if adjusted:
            print(f"[{self.extractor_name}] Bayesian adjustment: {adjusted} entities adjusted")

    # ── File-level cache support ───────────────────────────────────────────

    def get_file_emissions(self, file_path: str) -> dict:
        """Return entities and relations emitted for a specific evidence file.
        Used by file cache to capture what a single file produced."""
        with self._lock:
            entities = [e for e in self._entities.values()
                        if e.get("evidence", {}).get("file") == file_path]
            relations = [r for r in self._relations.values()
                         if r.get("evidence", {}).get("file") == file_path]
        return {"entities": entities, "relations": relations}

    def replay_cached(self, cached: dict) -> tuple[int, int]:
        """Replay cached entities/relations into this emitter.
        Preserves dedup/merge logic. Returns (entity_count, relation_count)."""
        e_count = r_count = 0
        for entity in cached.get("entities", []):
            eid = entity.get("id", "")
            parts = eid.split(":", 3)
            if len(parts) < 4:
                continue
            self.emit_entity(
                layer=entity["layer"], entity_type=entity["type"],
                repo=entity["repo"], qualifier=parts[3],
                name=entity["name"], confidence=entity["confidence"],
                evidence_file=entity["evidence"]["file"],
                evidence_method=entity["evidence"]["method"],
                file=entity.get("file"), line=entity.get("line"),
                evidence_line_start=entity["evidence"].get("line_start"),
                evidence_line_end=entity["evidence"].get("line_end"),
                evidence_snippet=entity["evidence"].get("snippet"),
                properties=entity.get("properties"),
                warnings=entity.get("warnings"),
            )
            e_count += 1
        for rel in cached.get("relations", []):
            self.emit_relation(
                source_id=rel["source"], target_id=rel["target"],
                relation_type=rel["type"], confidence=rel["confidence"],
                evidence_file=rel["evidence"]["file"],
                evidence_method=rel["evidence"]["method"],
                evidence_line_start=rel["evidence"].get("line_start"),
                evidence_line_end=rel["evidence"].get("line_end"),
                evidence_snippet=rel["evidence"].get("snippet"),
                properties=rel.get("properties"),
                unresolved_target=rel.get("unresolved_target"),
            )
            r_count += 1
        return e_count, r_count

    # ── Merge another emitter into this one ──────────────────────────────────

    def merge(self, other: "CanonicalEmitter"):
        """Merge another emitter's data into this one (for combining extractors)."""
        with self._lock:
            for eid, entity in other._entities.items():
                if eid not in self._entities:
                    self._entities[eid] = entity
                    self._counters["entities"] += 1
                elif entity["confidence"] > self._entities[eid]["confidence"]:
                    self._entities[eid] = entity
                    self._counters["duplicates"] += 1
                else:
                    self._counters["duplicates"] += 1
                # Carry over emit counts
                self._emit_counts[eid] = self._emit_counts.get(eid, 0) + other._emit_counts.get(eid, 1)
            for rid, relation in other._relations.items():
                if rid not in self._relations:
                    self._relations[rid] = relation
                    self._counters["relations"] += 1
                elif relation["confidence"] > self._relations[rid]["confidence"]:
                    self._relations[rid] = relation
                    self._counters["duplicates"] += 1
                else:
                    self._counters["duplicates"] += 1
            self._warnings.extend(other._warnings)
            self._counters["warnings"] += len(other._warnings)
