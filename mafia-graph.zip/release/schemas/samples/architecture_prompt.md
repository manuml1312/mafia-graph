# Generate Architecture Diagram

Create an `architecture.md` file for this project using the MAFIA architecture format.

## Format

```markdown
# Architecture — {Project Name}

## {Zone Name}

### {Component Name}
- type: {frontend|gateway|service|database|queue|external|agent|storage|config}
- description: {one-line description}

## Connections

{Source} -> {Target} : {label}
```

## Rules

1. Each `##` section is a **zone** (swimlane) — group related components together
2. Each `###` is a **component** (box) — a logical unit like a service, database, UI app
3. The last `## Connections` section lists all edges as `Source -> Target : label`
4. Component names in connections must EXACTLY match the `###` headings
5. Keep it high-level — 8-20 components is ideal, not every class/function
6. Use descriptive connection labels: "HTTP/REST", "Query", "Publish Event", "Read/Write", etc.

## Valid component types

| Type | Use for | Default color |
|------|---------|---------------|
| frontend | Web apps, mobile apps, CLI tools | Blue |
| gateway | API gateways, load balancers, BFF | Amber |
| service | Backend services, workers, processors | Green |
| database | SQL/NoSQL databases, data warehouses | Purple |
| queue | Message queues, event buses | Rose |
| external | Third-party APIs, SaaS services | Slate |
| agent | AI agents, LLMs, ML models | Emerald |
| storage | File storage, blob storage, CDN | Cyan |
| config | Config servers, feature flags, secrets | Gray |

## System Context

Here is what MAFIA extracted from the codebase:

### Repositories
{repos}

### Entity Summary by Layer
{entity_summary}

### Key Components (high-confidence entities)
{key_components}

### Cross-Layer Connections
{connections}

### End-to-End Flows
{flows}

## Instructions

Using the system context above, create an `architecture.md` that:
1. Groups the system into 3-6 logical zones
2. Identifies the major components (services, databases, UIs, external deps)
3. Maps the connections between them with meaningful labels
4. Captures the real architecture — don't invent components that aren't in the data
5. Save the file as `architecture.md` in the project root or in the `.mafia/` directory
