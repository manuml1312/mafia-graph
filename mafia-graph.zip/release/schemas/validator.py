"""
MAFIA Artifact Validator
========================
Validates all 5 artifacts for:
  - Schema correctness (required fields, types)
  - Referential integrity (entity IDs in relations must exist)
  - Duplicate detection
  - Confidence range validity
  - Evidence completeness
  - Semantic checks (no orphan entities, no dangling relations)

Usage:
    validator = ArtifactValidator()
    validator.load_entities("output/entities.jsonl")
    validator.load_relations("output/relations.jsonl")
    report = validator.validate()
    validator.print_report(report)
"""

import json
from pathlib import Path
from datetime import datetime, timezone

from schemas.id_format import LAYERS, ENTITY_TYPES, RELATION_TYPES, parse_entity_id


class ArtifactValidator:

    def __init__(self):
        self.entities: dict[str, dict] = {}
        self.relations: dict[str, dict] = {}
        self.errors: list[dict] = []
        self.warnings: list[dict] = []

    # ── Loading ──────────────────────────────────────────────────────────────

    def load_entities(self, path: str):
        for line_num, line in enumerate(_read_jsonl(path), 1):
            try:
                entity = json.loads(line)
                eid = entity.get("id", f"MISSING_ID_line_{line_num}")
                if eid in self.entities:
                    self.warnings.append({"type": "duplicate_entity", "id": eid, "line": line_num})
                self.entities[eid] = entity
            except json.JSONDecodeError as e:
                self.errors.append({"type": "json_parse_error", "file": path, "line": line_num, "error": str(e)})

    def load_relations(self, path: str):
        for line_num, line in enumerate(_read_jsonl(path), 1):
            try:
                relation = json.loads(line)
                rid = relation.get("id", f"MISSING_ID_line_{line_num}")
                if rid in self.relations:
                    self.warnings.append({"type": "duplicate_relation", "id": rid, "line": line_num})
                self.relations[rid] = relation
            except json.JSONDecodeError as e:
                self.errors.append({"type": "json_parse_error", "file": path, "line": line_num, "error": str(e)})

    # ── Validation ───────────────────────────────────────────────────────────

    def validate(self) -> dict:
        self.errors = []
        self.warnings = []

        self._validate_entities()
        self._validate_relations()
        self._validate_referential_integrity()
        self._validate_semantic()

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "entity_count": len(self.entities),
            "relation_count": len(self.relations),
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "errors": self.errors,
            "warnings": self.warnings,
            "valid": len(self.errors) == 0,
        }

    def _validate_entities(self):
        required = {"id", "layer", "type", "repo", "name", "confidence", "evidence"}
        evidence_required = {"repo", "file", "extractor"}

        for eid, entity in self.entities.items():
            # Required fields
            missing = required - set(entity.keys())
            if missing:
                self.errors.append({"type": "missing_entity_fields", "id": eid, "missing": list(missing)})
                continue

            # Layer validity
            if entity["layer"] not in LAYERS:
                self.errors.append({"type": "invalid_layer", "id": eid, "layer": entity["layer"]})

            # Type validity
            valid_types = ENTITY_TYPES.get(entity["layer"], set())
            if entity["type"] not in valid_types:
                self.errors.append({"type": "invalid_entity_type", "id": eid,
                                    "entity_type": entity["type"], "layer": entity["layer"]})

            # Confidence range
            conf = entity.get("confidence", -1)
            if not (0.0 <= conf <= 1.0):
                self.errors.append({"type": "invalid_confidence", "id": eid, "confidence": conf})

            # Evidence completeness
            evidence = entity.get("evidence", {})
            if not isinstance(evidence, dict):
                self.errors.append({"type": "invalid_evidence", "id": eid})
            else:
                ev_missing = evidence_required - set(evidence.keys())
                if ev_missing:
                    self.errors.append({"type": "missing_evidence_fields", "id": eid, "missing": list(ev_missing)})

            # ID format check — use parse_entity_id (supports v2 slash-scopes)
            try:
                parsed = parse_entity_id(eid)
                if parsed.layer not in LAYERS:
                    self.errors.append({"type": "invalid_layer", "id": eid, "layer": parsed.layer})
            except ValueError:
                self.errors.append({"type": "malformed_id", "id": eid})

    def _validate_relations(self):
        required = {"id", "source", "target", "type", "confidence", "evidence"}
        evidence_required = {"file", "extractor"}

        for rid, relation in self.relations.items():
            missing = required - set(relation.keys())
            if missing:
                self.errors.append({"type": "missing_relation_fields", "id": rid, "missing": list(missing)})
                continue

            if relation["type"] not in RELATION_TYPES:
                self.errors.append({"type": "invalid_relation_type", "id": rid, "relation_type": relation["type"]})

            conf = relation.get("confidence", -1)
            if not (0.0 <= conf <= 1.0):
                self.errors.append({"type": "invalid_confidence", "id": rid, "confidence": conf})

            evidence = relation.get("evidence", {})
            if isinstance(evidence, dict):
                ev_missing = evidence_required - set(evidence.keys())
                if ev_missing:
                    self.errors.append({"type": "missing_evidence_fields", "id": rid, "missing": list(ev_missing)})

    def _validate_referential_integrity(self):
        entity_ids = set(self.entities.keys())

        for rid, relation in self.relations.items():
            source = relation.get("source", "")
            target = relation.get("target", "")

            if source not in entity_ids:
                # Only error if there's no unresolved_target marker
                self.errors.append({"type": "dangling_source", "relation_id": rid, "source": source})

            if target not in entity_ids:
                if not relation.get("unresolved_target"):
                    self.warnings.append({"type": "dangling_target", "relation_id": rid, "target": target})

    def _validate_semantic(self):
        # Entities with no relations (orphans)
        entity_ids = set(self.entities.keys())
        referenced = set()
        for relation in self.relations.values():
            referenced.add(relation.get("source", ""))
            referenced.add(relation.get("target", ""))

        orphans = entity_ids - referenced
        # Only warn for non-config entities (configs may legitimately be standalone)
        for eid in orphans:
            entity = self.entities[eid]
            if entity.get("layer") not in ("config",):
                self.warnings.append({"type": "orphan_entity", "id": eid, "layer": entity.get("layer")})

    # ── Reporting ────────────────────────────────────────────────────────────

    def print_report(self, report: dict):
        print(f"\n{'='*60}")
        print(f"  MAFIA Artifact Validation Report")
        print(f"{'='*60}")
        print(f"  Entities:  {report['entity_count']}")
        print(f"  Relations: {report['relation_count']}")
        print(f"  Errors:    {report['error_count']}")
        print(f"  Warnings:  {report['warning_count']}")
        print(f"  Valid:     {'YES' if report['valid'] else 'NO'}")
        print(f"{'='*60}")

        if report["errors"]:
            print(f"\n  ERRORS ({len(report['errors'])}):")
            for err in report["errors"][:20]:
                print(f"    [{err['type']}] {err.get('id', '')} — {err}")
            if len(report["errors"]) > 20:
                print(f"    ... and {len(report['errors']) - 20} more")

        if report["warnings"]:
            print(f"\n  WARNINGS ({len(report['warnings'])}):")
            for warn in report["warnings"][:10]:
                print(f"    [{warn['type']}] {warn.get('id', '')}")
            if len(report["warnings"]) > 10:
                print(f"    ... and {len(report['warnings']) - 10} more")

    def save_report(self, report: dict, path: str):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)


def _read_jsonl(path: str):
    """Yield non-empty lines from a JSONL file."""
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield line


def validate_entity_id(eid: str) -> bool:
    """Validate an entity ID string (v1 or v2 format). Returns True if valid."""
    try:
        parsed = parse_entity_id(eid)
    except ValueError:
        return False
    if parsed.layer not in LAYERS:
        return False
    valid_types = ENTITY_TYPES.get(parsed.layer, set())
    if parsed.entity_type not in valid_types:
        return False
    return True
