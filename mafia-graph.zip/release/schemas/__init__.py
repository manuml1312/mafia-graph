# MAFIA Phase 1 — Schema and Contract Definitions
