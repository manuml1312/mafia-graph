"""
MAFIA Scope Hierarchy
=====================
Frozen dataclasses representing the codebase → repo → workspace hierarchy.

The scope_path is the compound location string used as the entity-ID scope segment.
Collapse rule (spec §7.2): adjacent identical levels are deduplicated.

Examples:
    Single repo, no monorepo:  build_scope_path("X", "X", "X") → "X"
    Multi-repo, no monorepo:   build_scope_path("acme", "orders", "orders") → "acme/orders"
    Monorepo (repo=codebase):  build_scope_path("web", "web", "admin") → "web/admin"
    Full hierarchy:            build_scope_path("acme", "web", "admin") → "acme/web/admin"
"""

from dataclasses import dataclass


def build_scope_path(codebase: str, repo: str, workspace: str) -> str:
    """Build collapsed scope path from hierarchy levels.

    Adjacent identical levels are deduplicated:
      (X, X, X) → "X"
      (A, B, B) → "A/B"
      (A, A, B) → "A/B"
      (A, B, C) → "A/B/C"
    """
    parts = [codebase]
    if repo != codebase:
        parts.append(repo)
    if workspace != repo:
        parts.append(workspace)
    return "/".join(parts)


@dataclass(frozen=True)
class Codebase:
    name: str
    root: str = ""


@dataclass(frozen=True)
class Repo:
    name: str
    root: str = ""
    codebase: str = ""


@dataclass(frozen=True)
class Workspace:
    name: str
    root: str = ""
    repo: str = ""
    codebase: str = ""
    package_name: str = ""
    language_hint: str = ""
    framework_hint: str = ""
    classification: tuple[str, ...] = ()


@dataclass(frozen=True)
class Scope:
    """Active scope during extraction. Passed to extractors and emitter."""
    codebase: str
    repo: str
    workspace: str

    @property
    def path(self) -> str:
        return build_scope_path(self.codebase, self.repo, self.workspace)

    @property
    def repo_id(self) -> str:
        """Backward compat: extractors that read scope.repo_id get the scope path."""
        return self.path
