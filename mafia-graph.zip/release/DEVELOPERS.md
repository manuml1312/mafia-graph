# MAFIA — Multi-Artifact Flow Intelligence Architecture

**Give your AI coding assistant a map of your entire codebase.**

MAFIA scans your repositories, extracts every endpoint, controller, service, function, and table, traces how they connect across files and repos, and builds a dependency graph your AI agent can query in real time.

```
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│    UI    │────▶│   BFF    │────▶│   API    │────▶│    DB    │
│ React    │     │ Koa      │     │ Spring   │     │ Postgres │
│ Next.js  │     │ Express  │     │ Flask    │     │ PySpark  │
│ Vue      │     │ FastAPI  │     │ Django   │     │ BigQuery │
└──────────┘     └──────────┘     └──────────┘     └──────────┘
```

**Before MAFIA:** Your AI assistant sees one file at a time. It guesses at cross-file dependencies.

**After MAFIA:** Your AI assistant knows the full call chain from UI button click to database query. It can trace flows, compute blast radius, and find dead code — instantly.

---

## Table of Contents

- [Install](#install)
- [Quick Start — Agent Mode](#quick-start--agent-mode)
- [Quick Start — Full Application](#quick-start--full-application)
- [What MAFIA Extracts](#what-mafia-extracts)
- [CLI Reference](#cli-reference)
- [How It Works](#how-it-works)
- [Supported Languages & Frameworks](#supported-languages--frameworks)
- [Configuration](#configuration)
- [Pipeline Reference](#pipeline-reference)
- [Project Structure](#project-structure)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

---

## Install

### Option A: pip install (recommended)

```bash
pip install mafia-intel            # core (graph, extraction, CLI)
pip install mafia-intel[full]      # + search index, AI chat, doc ingestion
pip install mafia-intel[all]       # + all 19 AST language grammars
```

### Option B: Clone + install

```bash
git clone https://github.com/your-org/mafia-intel.git
cd mafia-intel

# Isolated venv install
python install.py                  # creates .venv, installs deps
python install.py --full           # + optional deps

# Or global editable install
pip install -e ".[all]"
```

### Option C: Windows quick setup

```bash
cd MAFIA_Phase1_Execution
setup.bat                          # creates venv, installs deps, validates
setup.bat --extras                 # + extra AST grammars
```

### Verify

```bash
mafia --help
```

---

## Quick Start — Agent Mode

This is the primary use case: give your AI coding assistant (Amazon Q, Claude, Cursor, etc.) deep codebase understanding.

### Step 1: Initialize on your project

```bash
cd /path/to/your-project
mafia init
```

This takes 30 seconds to a few minutes depending on codebase size. It:
- Scans all source files, detects tech stacks
- Extracts entities (endpoints, controllers, services, functions, tables)
- Traces cross-file and cross-repo relationships
- Builds a dependency graph and assembles end-to-end flows
- Writes everything to `.mafia/` in your project root
- **Auto-installs agent rules** into `.amazonq/rules/` and `CLAUDE.md`

### Step 2: There is no step 2

Your AI agent now automatically uses MAFIA. When you ask:

> "What calls getUserProfile?"

The agent runs `mafia neighbors "getUserProfile" --direction upstream` and gives you the full caller chain with confidence scores.

> "If I change the users table schema, what breaks?"

The agent runs `mafia blast "db:table:pg:users" --direction upstream --depth 4` and lists every service, controller, and UI component affected.

> "Show me the full flow from the login button to the database"

The agent runs `mafia trace "ui:component:web:LoginButton"` and walks the entire UI → BFF → API → DB chain.

### Step 3: Keep it updated

After code changes:
```bash
mafia update
```

Incremental — only re-scans changed files, takes seconds.

---

## Quick Start — Full Application

MAFIA also has a full web UI with interactive graph visualization, AI chat, and document ingestion.

```bash
cd MAFIA_Phase1_Execution

# Scan + extract + start server
python -m MAFIA_Phase1_Execution --source-roots /path/to/your/repos

# → Open http://localhost:5001
```

The UI provides:
- **Search** — semantic + graph-expanded search across all entities
- **Explorer** — interactive D3 code tree, force-directed graph, AST structure viewer
- **Flows** — end-to-end flow chains with hop-by-hop evidence
- **Blast Radius** — visual impact analysis with severity scoring
- **AI Chat** — RAG-grounded conversation with provenance labels
- **Coverage** — extraction health metrics, quality gate, orphan detection
- **Documents** — upload PDFs, DOCX, XLSX as supplementary context

---

## What MAFIA Extracts

### Entities (what it finds)

| Layer | Entity Types |
|-------|-------------|
| UI | component, hook, selector, fetch_def, route, env_var, module |
| BFF | endpoint, constant, controller, middleware, service |
| API | endpoint, controller, service, repository, entity, dto, util, config |
| DB | function, table, view, schema |
| Config | env, toggle, property, secret |

### Relations (how they connect)

| Relation | Meaning |
|----------|---------|
| fetches | UI calls BFF/API endpoint |
| calls_api | BFF calls API endpoint |
| routes_to | Route registration → handler |
| delegates_to | Controller → service |
| uses_repo | Service → repository |
| calls_function | Repository → DB function |
| reads_from / writes_to | DB function → table |
| depends_on_config | Code references config variable |
| imports / exports | File-level module dependencies |

### Confidence Scores

Every entity and relation has a confidence score (0–100%):

| Score | Meaning |
|-------|---------|
| ≥90% | Exact match — AST parse or deterministic regex |
| ≥80% | Strong heuristic — naming convention + context |
| ≥60% | Inferred — cross-file resolution, URL segment match |
| ≥40% | Weak — partial evidence, some ambiguity |
| <40% | Guess — flagged for human review |

---

## CLI Reference

All commands work from any directory inside an initialized project.

### Core Commands

```bash
# Initialize MAFIA on a project
mafia init --project-root /path/to/project

# Incremental update after code changes
mafia update

# Check status
mafia status
```

### Query Commands

```bash
# Search entities by name
mafia search "getUserProfile" --limit 10 --layer api

# Trace full call chain downstream
mafia trace "api:endpoint:user_api:GET:/users" --depth 10

# Compute blast radius
mafia blast "api:service:user_api:UserService" --direction downstream --depth 4

# List flows through a node
mafia flows --node "bff:endpoint:user_bff:/users"

# Get neighbors (callers / targets)
mafia neighbors "api:controller:user_api:UserController" --direction both

# Find shortest path between two entities
mafia path "ui:fetch_def:web:getUsers" "db:table:pg:users"

# Find dead code candidates
mafia orphans
```

### Entity ID Format

```
{layer}:{type}:{repo}:{qualifier}

Examples:
  api:endpoint:marvel_flags_api:GET:/flagTypes
  bff:controller:marvel_flags_bff:FlagController.getFlagTypes
  db:function:pg:dre.get_flag_types
  ui:component:web_app:src/pages/FlagPage.tsx::FlagTable
```

---

## How It Works

```
Your Code                    MAFIA                         Your AI Agent
─────────                    ─────                         ─────────────
                    ┌─────────────────────┐
  repos on disk ──▶ │  Phase 2: Scan      │
                    │  Detect tech stack   │
                    │  Classify layers     │
                    ├─────────────────────┤
                    │  Phase 3: Extract    │
                    │  Entities + relations│
                    │  Cross-file stitching│
                    ├─────────────────────┤
                    │  Phase 9: Graph      │
                    │  Build dep graph     │
                    │  Assemble flows      │
                    ├─────────────────────┤
                    │  .mafia/output/      │──▶  mafia search "X"
                    │  entities.jsonl      │──▶  mafia trace "X"
                    │  relations.jsonl     │──▶  mafia blast "X"
                    │  system_graph.json   │──▶  mafia flows --node "X"
                    │  e2e_flows.json      │──▶  mafia neighbors "X"
                    └─────────────────────┘
```

### Incremental Mode

MAFIA fingerprints every repo using `SHA256(file_count:total_size:max_mtime)`. On `mafia update`, only changed repos are re-extracted. Unchanged entities are preserved and merged. All downstream phases (graph, flows, coverage) run on the complete merged dataset.

### Cross-Repo Stitching

The pipeline traces connections across repo boundaries:

- **UI → BFF**: fetch path matching (exact, normalized, last-segment)
- **BFF → API**: constant endpoint path matching with HTTP method disambiguation
- **API → DB**: Spring Boot call chain (controller → service → repository → DB function)
- **Config**: environment variable references across all repos
- **Imports**: cross-file symbol resolution via pre-built symbol index
- **Tables**: same-engine table name matching across repos

---

## Supported Languages & Frameworks

| Layer | Frameworks | Extraction Depth |
|-------|-----------|-----------------|
| UI | React, Next.js, Vue (partial), Jinja2, vanilla JS | Components, hooks, fetch definitions, routes |
| BFF | Koa, Express | Endpoints, controllers, API constants, middleware |
| API | Spring Boot, Flask, FastAPI, Django | Full call chain: endpoint → controller → service → repo → DB |
| DB | PostgreSQL, Databricks/PySpark, BigQuery | Functions, tables, views, inline SQL |
| Config | .env, .properties, .yml, .yaml | Environment variables, toggles, secrets |
| AST | Java, TypeScript, JavaScript, Python + 15 more via tree-sitter | Method signatures, call targets, complexity |

---

## Configuration

### AI Features (Optional)

MAFIA works fully without AI. The extraction pipeline, graph, flows, blast radius, and CLI are all deterministic — zero AI dependency.

Three features use Google Gemini and require credentials:

| Feature | What it does | Without credentials |
|---------|-------------|--------------------|
| AI Chat | Conversational Q&A grounded in graph context | Chat panel disabled |
| Vector Search | Semantic search via Gemini embeddings | Falls back to keyword search |
| GenAI Gap Analysis | AI suggests missing entities | Skipped (use `--enable-genai` to opt in) |

To enable AI features, configure your Google Cloud credentials:

```bash
# Option A: CLI command (saves to .mafia/ai_config.json)
mafia configure-ai \
    --sa-key /path/to/service-account-key.json \
    --project my-gcp-project

# Option B: Environment variables
export MAFIA_SA_KEY_PATH=/path/to/service-account-key.json
export MAFIA_GCP_PROJECT=my-gcp-project

# Optional: corporate proxy CA cert
export MAFIA_CERT_FILE=/path/to/ca-bundle.pem

# Optional: model overrides
export MAFIA_GEMINI_MODEL=gemini-2.5-flash
export MAFIA_GCP_LOCATION=us-central1
```

Check current AI config:
```bash
mafia configure-ai --show
```

Credential resolution order: environment variables > `.mafia/ai_config.json` > `~/.mafia/ai_config.json` > disabled.

### Project-Level: `.mafia/mafia.json`

Created by `mafia init`. Contains source roots, timestamps, MAFIA installation path.

### Agent Rules: `.amazonq/rules/mafia-agent.md`

Auto-installed by `mafia init`. Teaches Amazon Q when and how to use MAFIA commands. Edit this file to customize agent behavior.

### Claude Rules: `CLAUDE.md`

Auto-appended by `mafia init`. Teaches Claude the same commands.

### Ignore Patterns: `.mafiaignore`

Place in any repo root. Same syntax as `.gitignore`. Files matching these patterns are skipped during extraction.

```
# .mafiaignore example
*.generated.ts
**/vendor/**
**/migrations/**
```

---

## Pipeline Reference

For the full 14-phase pipeline documentation, phase control flags, output artifact reference, and advanced usage, see [PIPELINE.md](README.md) (the original detailed reference).

### Key Commands (Full Pipeline)

```bash
# Scan repos
python -m phase2_repo_intake.repo_scanner --source-roots /path/to/repos

# Run extraction (incremental)
python -m phase3_extraction_framework.run_extraction

# Force full re-extraction
python -m phase3_extraction_framework.run_extraction --full

# Rebuild graph only (after manual edits)
python -m phase3_extraction_framework.run_extraction --from-phase 9

# AST structural summaries for all methods
python -m phase10_ast.run_ast_summaries --discover

# Build search index
python -m phase11_search.vector_index --incremental

# Start UI server
python -m phase11_search.search_api1
# → http://localhost:5001
```

---

## Project Structure

```
MAFIA_Phase1_Execution/
├── mafia_cli.py                        # ★ Agent CLI — init, search, trace, blast
├── install.py                          # Cross-platform installer
├── pyproject.toml                      # Python packaging (pip install)
├── __main__.py                         # Full application entry point
│
├── phase2_repo_intake/                 # Repo discovery + classification
├── phase3_extraction_framework/        # Extraction engine + pipeline runner
├── phase4_extractors/                  # Deterministic extractors (UI/BFF/API/DB/Config)
├── phase5_compatibility/               # Legacy artifact generators
├── phase6_coverage/                    # Coverage analysis
├── phase7_mapping/                     # Cross-layer mapping evaluation
├── phase7_genai/                       # GenAI gap analysis (optional)
├── phase8_hardening/                   # Quality gates + regression
├── phase9_graph/                       # Graph construction + query + blast radius
├── phase10_intelligence/               # AI enrichment (summaries, narratives)
├── phase10_ast/                        # AST structural summaries (19 languages)
├── phase11_search/                     # Search index + Flask API server
├── phase12_ui/                         # Web UI (SPA)
├── phase13_evaluation/                 # Gold datasets + P/R/F1 evaluation
├── phase14_orchestration/              # Incremental state + versioning
├── schemas/                            # Entity/relation schemas + emitter
└── utils/                              # Shared utilities (fuzzy match, AST, cache)
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `mafia: command not found` | Activate venv (`.venv/Scripts/activate`) or run `pip install -e .` |
| `No .mafia/ found` | Run `mafia init` in your project root |
| `No graph found` | Run `mafia init` — extraction may have failed, check terminal output |
| SSL errors (corporate proxy) | `export REQUESTS_CA_BUNDLE=/path/to/ca-bundle.pem` |
| FAISS numpy conflict | `pip install "numpy<2"` |
| Empty search results | Run `mafia update` to re-index |
| `mafia update` says "no repos changed" | Expected if no files changed. Use `mafia init --full` to force |
| Slow on large codebase | Use `--workers 8` on init. Subsequent updates are incremental. |
| Agent not using MAFIA | Check `.amazonq/rules/mafia-agent.md` exists. Re-run `mafia init`. |

---

## Contributing

### Adding a new extractor

1. Create `phase4_extractors/your_layer/your_extractor.py`
2. Subclass `BaseExtractor` from `phase3_extraction_framework/base_extractor.py`
3. Implement `extract_file()` — emit entities and relations via `self.emitter`
4. Register in `phase3_extraction_framework/run_extraction.py`
5. Add valid entity types to `schemas/id_format.py`

### Adding a new relation type

1. Add to `RELATION_TYPES` in `schemas/id_format.py`
2. If it should participate in flow assembly, add to `FLOW_ALLOWLIST` in `phase9_graph/graph_builder.py`
3. If it's structural (not a call chain), add to `STRUCTURAL` set instead

### Running tests

```bash
pip install -e ".[dev]"
pytest
```

---

## License

MIT
