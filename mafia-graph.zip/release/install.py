#!/usr/bin/env python3
"""
MAFIA Installer — Cross-platform setup script.

Usage:
    python install.py                  # Standard install (venv + core deps)
    python install.py --full           # Full install (all optional deps)
    python install.py --global         # Install globally (pip install -e .)
    python install.py --check          # Just validate the installation
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
MIN_PYTHON = (3, 10)


def _print(icon, msg):
    print(f"  [{icon}] {msg}")


def _run(cmd, **kwargs):
    return subprocess.run(cmd, capture_output=True, text=True, **kwargs)


def check_python():
    v = sys.version_info
    if v < MIN_PYTHON:
        _print("XX", f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ required. You have {v.major}.{v.minor}.{v.micro}")
        sys.exit(1)
    _print("OK", f"Python {v.major}.{v.minor}.{v.micro}")


def create_venv():
    if VENV.exists() and (VENV / ("Scripts" if os.name == "nt" else "bin") / "python").exists():
        _print("OK", "Virtual environment exists")
        return
    _print("..", "Creating virtual environment...")
    r = _run([sys.executable, "-m", "venv", str(VENV)])
    if r.returncode != 0:
        _print("XX", f"Failed to create venv: {r.stderr}")
        sys.exit(1)
    _print("OK", "Virtual environment created")


def get_pip():
    if os.name == "nt":
        return str(VENV / "Scripts" / "pip.exe")
    return str(VENV / "bin" / "pip")


def get_python():
    if os.name == "nt":
        return str(VENV / "Scripts" / "python.exe")
    return str(VENV / "bin" / "python")


def install_deps(full=False):
    pip = get_pip()
    _print("..", "Upgrading pip...")
    _run([pip, "install", "--upgrade", "pip", "-q"])

    _print("..", "Installing core dependencies...")
    r = _run([pip, "install", "-r", str(ROOT / "requirements.txt"), "-q"])
    if r.returncode != 0:
        _print("XX", f"Core deps failed: {r.stderr[:200]}")
        sys.exit(1)
    _print("OK", "Core dependencies installed")

    if full:
        _print("..", "Installing optional dependencies (AST, document ingestion)...")
        extras = [
            "tree-sitter-go", "tree-sitter-rust", "tree-sitter-c-sharp",
            "tree-sitter-kotlin", "tree-sitter-scala", "tree-sitter-ruby",
            "tree-sitter-c", "tree-sitter-cpp", "tree-sitter-php",
            "graspologic",
        ]
        _run([pip, "install"] + extras + ["-q"])
        _print("OK", "Optional dependencies installed")


def create_dirs():
    for d in ["output", "workspace"]:
        (ROOT / d).mkdir(exist_ok=True)
    _print("OK", "Directories ready")


def fix_init_files():
    count = 0
    for d in ROOT.iterdir():
        if d.is_dir() and (d.name.startswith("phase") or d.name in ("schemas", "utils")):
            init = d / "__init__.py"
            if not init.exists():
                init.touch()
                count += 1
    if count:
        _print("OK", f"Created {count} missing __init__.py files")


def create_launcher():
    """Create a 'mafia' launcher script in the venv bin/Scripts."""
    if os.name == "nt":
        launcher = VENV / "Scripts" / "mafia.cmd"
        py = str(VENV / "Scripts" / "python.exe")
        launcher.write_text(
            f'@echo off\n"{py}" "{ROOT / "mafia_cli.py"}" %*\n',
            encoding="utf-8",
        )
    else:
        launcher = VENV / "bin" / "mafia"
        py = str(VENV / "bin" / "python")
        launcher.write_text(
            f'#!/bin/sh\nexec "{py}" "{ROOT / "mafia_cli.py"}" "$@"\n',
            encoding="utf-8",
        )
        launcher.chmod(0o755)
    _print("OK", f"Launcher created: {launcher}")


def validate():
    py = get_python()
    _print("..", "Validating imports...")
    r = _run([py, "-c", (
        "import flask, numpy, requests, networkx; "
        "import sys; sys.path.insert(0, '.'); "
        "from schemas.id_format import LAYERS; "
        "from schemas.emitter import CanonicalEmitter; "
        "from phase9_graph.graph_query import GraphQuery; "
        "print('All core imports OK')"
    )], cwd=str(ROOT))
    if r.returncode == 0:
        _print("OK", r.stdout.strip())
    else:
        _print("!!", f"Some imports failed: {r.stderr[:200]}")

    # Check tree-sitter
    r2 = _run([py, "-c", "import tree_sitter; print('tree-sitter OK')"])
    if r2.returncode == 0:
        _print("OK", "tree-sitter available (AST features enabled)")
    else:
        _print("!!", "tree-sitter not available (AST features disabled, install with --full)")


def install_global():
    """pip install -e . for global 'mafia' command."""
    _print("..", "Installing MAFIA globally (editable)...")
    r = _run([sys.executable, "-m", "pip", "install", "-e", str(ROOT)])
    if r.returncode == 0:
        _print("OK", "Installed globally. Run 'mafia --help' from anywhere.")
    else:
        _print("XX", f"Global install failed: {r.stderr[:200]}")


def main():
    full = "--full" in sys.argv
    global_install = "--global" in sys.argv
    check_only = "--check" in sys.argv

    print()
    print("  ══════════════════════════════════════════════")
    print("   MAFIA Installer")
    print("  ══════════════════════════════════════════════")
    print()

    check_python()

    if check_only:
        if VENV.exists():
            validate()
        else:
            _print("!!", "No venv found. Run without --check to install.")
        return

    if global_install:
        install_global()
        return

    create_venv()
    install_deps(full=full)
    create_dirs()
    fix_init_files()
    create_launcher()
    validate()

    activate = ".venv\\Scripts\\activate" if os.name == "nt" else "source .venv/bin/activate"

    print()
    print("  ══════════════════════════════════════════════")
    print("   Setup Complete")
    print("  ══════════════════════════════════════════════")
    print()
    print(f"  Activate the environment:")
    print(f"    {activate}")
    print()
    print(f"  Then use MAFIA on any project:")
    print(f"    mafia init --project-root /path/to/project")
    print(f"    mafia search \"getUserProfile\"")
    print(f"    mafia trace \"api:endpoint:user_api:GET:/users\"")
    print(f"    mafia blast \"api:service:user_api:UserService\"")
    print()
    print(f"  Or start the full UI server:")
    print(f"    python -m MAFIA_Phase1_Execution")
    print(f"    # -> http://localhost:5001")
    print()


if __name__ == "__main__":
    main()
