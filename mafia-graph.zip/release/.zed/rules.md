# MAFIA Project — Zed AI Rules

## CRITICAL: Use `mafia` CLI FIRST for ALL code questions

This project has a live dependency graph (343 entities, 1433 relations). The `mafia` CLI is installed.

**BEFORE reading source files or answering questions about structure, dependencies, or behavior —
run the appropriate `mafia` command in the terminal.**

| Question | Command |
|---|---|
| Find function/class/endpoint | `mafia search "<name>" --limit 10` |
| Who calls X | `mafia neighbors "<id>" --direction upstream` |
| What X calls | `mafia neighbors "<id>" --direction downstream` |
| Impact of changing X | `mafia blast "<id>" --direction downstream` |
| Path from X to Y | `mafia path "<X_id>" "<Y_id>"` |
| Full call chain | `mafia trace "<id>" --depth 10` |
| Flows through X | `mafia flows --node "<id>"` |
| Dead code | `mafia orphans` |
| Project overview | `mafia status` |
| Refresh after changes | `mafia update` |

Workflow: search → get ID → neighbors/blast/trace → read source only if needed.

All commands run from: `C:\Users\MML\Downloads\Graphify-MAFIA\MAFIA_Phase1_Execution`

Entity ID: `{layer}:{type}:{repo}:{qualifier}` — e.g. `code:module:MAFIA_Phase1_Execution:install.py`
