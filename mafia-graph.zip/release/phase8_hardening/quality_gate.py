"""
MAFIA Phase 8 — Hardening, Validation, and Quality Gates
==========================================================
Validates all 5 artifacts for schema correctness, referential integrity,
semantic consistency, and quality thresholds. Produces a pass/fail gate
decision that blocks downstream stages (graph, RAG, AI) if artifacts
are not stable enough.

Usage:
    python -m phase8_hardening.quality_gate
"""

import json
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from schemas.validator import ArtifactValidator


# ── Quality thresholds ───────────────────────────────────────────────────────

THRESHOLDS = {
    "min_parse_rate": 0.90,
    "min_extraction_rate": 0.50,
    "max_validation_errors": 0,
    "max_dangling_refs": 0,
    "min_entity_count": 100,
    "min_relation_count": 10,
    "min_overall_mapping_confidence": 0.50,
    "max_critical_gaps": 0,
}


def run_quality_gate(output_dir: str) -> dict:
    output = Path(output_dir)
    checks = []
    all_pass = True

    # ── 1. Artifact existence ────────────────────────────────────────────────
    required_files = [
        "repo_manifest.json",
        "entities.jsonl",
        "relations.jsonl",
        "extraction_report.json",
        "coverage_report.json",
        "mapping_confidence_report.json",
        "validation_report.json",
    ]
    for fname in required_files:
        exists = (output / fname).exists()
        checks.append({
            "check": f"artifact_exists:{fname}",
            "passed": exists,
            "detail": f"{'Found' if exists else 'MISSING'}: {fname}",
        })
        if not exists:
            all_pass = False

    # ── 2. Schema validation (entities + relations) ──────────────────────────
    validator = ArtifactValidator()
    entities_path = output / "entities.jsonl"
    relations_path = output / "relations.jsonl"

    if entities_path.exists():
        validator.load_entities(str(entities_path))
    if relations_path.exists():
        validator.load_relations(str(relations_path))

    validation = validator.validate()

    err_count = validation["error_count"]
    passed = err_count <= THRESHOLDS["max_validation_errors"]
    checks.append({
        "check": "schema_validation_errors",
        "passed": passed,
        "detail": f"{err_count} errors (threshold: <={THRESHOLDS['max_validation_errors']})",
    })
    if not passed:
        all_pass = False

    # Duplicate detection
    dup_warnings = [w for w in validation.get("warnings", []) if "duplicate" in w.get("type", "")]
    checks.append({
        "check": "duplicate_ids",
        "passed": len(dup_warnings) == 0,
        "detail": f"{len(dup_warnings)} duplicate IDs found",
    })

    # Dangling references
    dangling = [e for e in validation.get("errors", []) if "dangling" in e.get("type", "")]
    passed = len(dangling) <= THRESHOLDS["max_dangling_refs"]
    checks.append({
        "check": "dangling_references",
        "passed": passed,
        "detail": f"{len(dangling)} dangling refs (threshold: <={THRESHOLDS['max_dangling_refs']})",
    })
    if not passed:
        all_pass = False

    # ── 3. Coverage report checks ────────────────────────────────────────────
    coverage = _load_json(output / "coverage_report.json")
    fc = coverage.get("file_coverage", {})

    parse_rate = fc.get("parse_rate", 0)
    passed = parse_rate >= THRESHOLDS["min_parse_rate"]
    checks.append({
        "check": "parse_rate",
        "passed": passed,
        "detail": f"{parse_rate:.1%} (threshold: >={THRESHOLDS['min_parse_rate']:.0%})",
    })
    if not passed:
        all_pass = False

    extraction_rate = fc.get("extraction_rate", 0)
    eligible_yield = fc.get("eligible_yield", extraction_rate)
    passed = eligible_yield >= THRESHOLDS["min_extraction_rate"]
    checks.append({
        "check": "eligible_yield",
        "passed": passed,
        "detail": f"{eligible_yield:.1%} eligible yield (threshold: >={THRESHOLDS['min_extraction_rate']:.0%})",
    })
    if not passed:
        all_pass = False

    entity_count = coverage.get("entity_coverage", {}).get("total_entities", 0)
    passed = entity_count >= THRESHOLDS["min_entity_count"]
    checks.append({
        "check": "min_entity_count",
        "passed": passed,
        "detail": f"{entity_count} entities (threshold: >={THRESHOLDS['min_entity_count']})",
    })
    if not passed:
        all_pass = False

    relation_count = coverage.get("relation_coverage", {}).get("total_relations", 0)
    passed = relation_count >= THRESHOLDS["min_relation_count"]
    checks.append({
        "check": "min_relation_count",
        "passed": passed,
        "detail": f"{relation_count} relations (threshold: >={THRESHOLDS['min_relation_count']})",
    })
    if not passed:
        all_pass = False

    critical_gaps = sum(1 for g in coverage.get("gaps", []) if g.get("severity") == "critical")
    passed = critical_gaps <= THRESHOLDS["max_critical_gaps"]
    checks.append({
        "check": "critical_gaps",
        "passed": passed,
        "detail": f"{critical_gaps} critical gaps (threshold: <={THRESHOLDS['max_critical_gaps']})",
    })
    if not passed:
        all_pass = False

    # ── 4. Mapping confidence checks ─────────────────────────────────────────
    mapping = _load_json(output / "mapping_confidence_report.json")
    summary = mapping.get("summary", {})

    overall_conf = summary.get("overall_confidence", 0)
    passed = overall_conf >= THRESHOLDS["min_overall_mapping_confidence"]
    checks.append({
        "check": "mapping_confidence",
        "passed": passed,
        "detail": f"{overall_conf:.2f} (threshold: >={THRESHOLDS['min_overall_mapping_confidence']})",
    })
    if not passed:
        all_pass = False

    ready = summary.get("ready_for_flow_gen", False)
    checks.append({
        "check": "ready_for_flow_gen",
        "passed": ready,
        "detail": f"{'YES' if ready else 'NO'} (from mapping confidence report)",
    })
    if not ready:
        all_pass = False

    # ── 5. Cross-artifact consistency ────────────────────────────────────────
    manifest = _load_json(output / "repo_manifest.json")
    manifest_repos = {r["repo_id"] for r in manifest.get("repos", [])}
    entity_repos = {e.get("repo", "") for e in validator.entities.values()}
    orphan_repos = entity_repos - manifest_repos - {""}
    checks.append({
        "check": "entity_repos_in_manifest",
        "passed": len(orphan_repos) == 0,
        "detail": f"{len(orphan_repos)} entity repos not in manifest: {list(orphan_repos)[:5]}",
    })

    # ── Build gate report ────────────────────────────────────────────────────
    gate_report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "gate_passed": all_pass,
        "checks_total": len(checks),
        "checks_passed": sum(1 for c in checks if c["passed"]),
        "checks_failed": sum(1 for c in checks if not c["passed"]),
        "thresholds": THRESHOLDS,
        "checks": checks,
    }

    gate_path = output / "quality_gate_report.json"
    with open(gate_path, 'w', encoding='utf-8') as f:
        json.dump(gate_report, f, indent=2, ensure_ascii=False)

    # Print
    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 8 -- Quality Gate")
    print(f"{'='*60}")
    for c in checks:
        status = "[PASS]" if c["passed"] else "[FAIL]"
        print(f"  {status} {c['check']:40s} {c['detail']}")
    print(f"{'='*60}")
    print(f"  GATE: {'PASSED' if all_pass else 'FAILED'}  ({gate_report['checks_passed']}/{gate_report['checks_total']} checks passed)")
    print(f"  Report: {gate_path}")
    print(f"{'='*60}\n")

    return gate_report


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


if __name__ == "__main__":
    base = Path(__file__).resolve().parent.parent
    run_quality_gate(str(base / "output"))
