"""
MAFIA Phase 8 — Structural Graph Diff
=========================================
Compares current entities.jsonl + relations.jsonl against the previous run's
snapshot. Produces a diff showing exactly which entities/relations were
added, removed, or had confidence changes.

Complements the existing regression_runner.py metric-count checks with
structural detail: instead of "entity count dropped by 5" you get
"these 5 specific entities disappeared."

Usage:
    from phase8_hardening.graph_diff import compute_diff, snapshot_current
    snapshot_current("output")          # call before extraction overwrites
    diff = compute_diff("output")       # call after extraction completes
"""

import json
import shutil
from pathlib import Path
from datetime import datetime, timezone


PREV_DIR = "_prev"


def _load_jsonl(path) -> list[dict]:
    items = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


# ── Snapshot ─────────────────────────────────────────────────────────────────

def snapshot_current(output_dir: str) -> None:
    """Copy current entities.jsonl and relations.jsonl to _prev/ for later diff."""
    output = Path(output_dir)
    prev = output / PREV_DIR
    prev.mkdir(parents=True, exist_ok=True)

    for fname in ("entities.jsonl", "relations.jsonl"):
        src = output / fname
        if src.exists():
            shutil.copy2(src, prev / fname)


# ── Diff ─────────────────────────────────────────────────────────────────────

def compute_diff(output_dir: str) -> dict:
    """Compare current artifacts against _prev/ snapshot. Returns structured diff."""
    output = Path(output_dir)
    prev = output / PREV_DIR

    current_entities = {e["id"]: e for e in _load_jsonl(output / "entities.jsonl") if "id" in e}
    current_relations = {r["id"]: r for r in _load_jsonl(output / "relations.jsonl") if "id" in r}
    prev_entities = {e["id"]: e for e in _load_jsonl(prev / "entities.jsonl") if "id" in e}
    prev_relations = {r["id"]: r for r in _load_jsonl(prev / "relations.jsonl") if "id" in r}

    # Entities
    added_eids = set(current_entities) - set(prev_entities)
    removed_eids = set(prev_entities) - set(current_entities)
    common_eids = set(current_entities) & set(prev_entities)

    entities_added = [
        {"id": eid, "layer": current_entities[eid].get("layer", ""),
         "type": current_entities[eid].get("type", ""),
         "name": current_entities[eid].get("name", ""),
         "repo": current_entities[eid].get("repo", "")}
        for eid in sorted(added_eids)
    ]
    entities_removed = [
        {"id": eid, "layer": prev_entities[eid].get("layer", ""),
         "type": prev_entities[eid].get("type", ""),
         "name": prev_entities[eid].get("name", ""),
         "repo": prev_entities[eid].get("repo", "")}
        for eid in sorted(removed_eids)
    ]
    confidence_changed = []
    for eid in common_eids:
        old_conf = prev_entities[eid].get("confidence", 0)
        new_conf = current_entities[eid].get("confidence", 0)
        if abs(old_conf - new_conf) >= 0.01:
            confidence_changed.append({
                "id": eid,
                "name": current_entities[eid].get("name", ""),
                "old_confidence": old_conf,
                "new_confidence": new_conf,
                "delta": round(new_conf - old_conf, 3),
            })
    confidence_changed.sort(key=lambda x: -abs(x["delta"]))

    # Relations
    added_rids = set(current_relations) - set(prev_relations)
    removed_rids = set(prev_relations) - set(current_relations)

    relations_added = [
        {"id": rid, "type": current_relations[rid].get("type", ""),
         "source": current_relations[rid].get("source", ""),
         "target": current_relations[rid].get("target", "")}
        for rid in sorted(added_rids)
    ]
    relations_removed = [
        {"id": rid, "type": prev_relations[rid].get("type", ""),
         "source": prev_relations[rid].get("source", ""),
         "target": prev_relations[rid].get("target", "")}
        for rid in sorted(removed_rids)
    ]

    summary = {
        "entities_added": len(entities_added),
        "entities_removed": len(entities_removed),
        "confidence_upgrades": sum(1 for c in confidence_changed if c["delta"] > 0),
        "confidence_downgrades": sum(1 for c in confidence_changed if c["delta"] < 0),
        "relations_added": len(relations_added),
        "relations_removed": len(relations_removed),
        "has_prev": bool(prev_entities or prev_relations),
    }

    # Build human-readable summary line
    parts = []
    if entities_added:
        parts.append(f"{len(entities_added)} entities added")
    if entities_removed:
        parts.append(f"{len(entities_removed)} entities removed")
    if relations_added:
        parts.append(f"{len(relations_added)} relations added")
    if relations_removed:
        parts.append(f"{len(relations_removed)} relations removed")
    summary["text"] = ", ".join(parts) if parts else "no structural changes"

    diff = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "entities": {
            "added": entities_added,
            "removed": entities_removed,
            "confidence_changed": confidence_changed[:50],
        },
        "relations": {
            "added": relations_added,
            "removed": relations_removed,
        },
        "summary": summary,
    }

    diff_path = Path(output_dir) / "graph_diff.json"
    with open(diff_path, "w", encoding="utf-8") as f:
        json.dump(diff, f, indent=2, ensure_ascii=False)

    return diff
