"""
MAFIA Phase 8 — Regression Runner
===================================
Compares current artifact stats against a saved baseline.
Flags any degradation in entity count, relation count, parse rate,
mapping confidence, or validation errors.

Usage:
    python -m phase8_hardening.regression_runner --save-baseline   # save current as baseline
    python -m phase8_hardening.regression_runner                   # compare against baseline
"""

import json
import argparse
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


BASELINE_FILE = "regression_baseline.json"


def save_baseline(output_dir: str):
    """Save current artifact stats as the regression baseline.
    Also snapshots JSONL files for structural graph diff."""
    output = Path(output_dir)
    baseline = _collect_stats(output)
    baseline_path = output / BASELINE_FILE
    with open(baseline_path, 'w', encoding='utf-8') as f:
        json.dump(baseline, f, indent=2, ensure_ascii=False)

    # Snapshot for graph diff (Change 6)
    from phase8_hardening.graph_diff import snapshot_current
    snapshot_current(output_dir)

    print(f"[OK] Baseline saved: {baseline_path}")
    print(f"  Entities: {baseline['entity_count']}")
    print(f"  Relations: {baseline['relation_count']}")
    print(f"  Parse rate: {baseline['parse_rate']}")
    print(f"  Mapping confidence: {baseline['mapping_confidence']}")
    return baseline


def run_regression(output_dir: str) -> dict:
    """Compare current stats against baseline. Returns regression report."""
    output = Path(output_dir)
    baseline_path = output / BASELINE_FILE

    if not baseline_path.exists():
        print("[WARN] No baseline found. Run with --save-baseline first.")
        return {"status": "no_baseline"}

    baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
    current = _collect_stats(output)

    checks = []

    # Entity count should not drop more than 5%
    _check_no_drop(checks, "entity_count", baseline, current, tolerance=0.05)
    _check_no_drop(checks, "relation_count", baseline, current, tolerance=0.05)
    _check_no_drop(checks, "parse_rate", baseline, current, tolerance=0.02)
    _check_no_drop(checks, "extraction_rate", baseline, current, tolerance=0.05)
    _check_no_drop(checks, "mapping_confidence", baseline, current, tolerance=0.05)

    # Validation errors should not increase
    _check_no_increase(checks, "validation_errors", baseline, current)
    _check_no_increase(checks, "dangling_refs", baseline, current)
    _check_no_increase(checks, "critical_gaps", baseline, current)

    # Per-layer entity counts should not drop
    for layer in ("ui", "bff", "api", "db", "config"):
        bkey = f"entities_{layer}"
        if bkey in baseline and bkey in current:
            _check_no_drop(checks, bkey, baseline, current, tolerance=0.10)

    all_pass = all(c["passed"] for c in checks)

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "baseline_date": baseline.get("generated_at", "unknown"),
        "regression_passed": all_pass,
        "checks": checks,
        "baseline": baseline,
        "current": current,
    }

    # Include structural diff if available
    from phase8_hardening.graph_diff import compute_diff
    diff = compute_diff(output_dir)
    if diff.get("summary", {}).get("has_prev"):
        report["structural_diff"] = diff["summary"]

    report_path = output / "regression_report.json"
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print(f"\n{'='*60}")
    print(f"  MAFIA Phase 8 -- Regression Check")
    print(f"{'='*60}")
    for c in checks:
        status = "[PASS]" if c["passed"] else "[FAIL]"
        print(f"  {status} {c['metric']:30s} baseline={c['baseline']}, current={c['current']} {c.get('detail', '')}")
    print(f"{'='*60}")
    print(f"  REGRESSION: {'PASSED' if all_pass else 'FAILED'}")
    print(f"{'='*60}\n")

    return report


def _collect_stats(output: Path) -> dict:
    """Collect key metrics from all artifacts."""
    stats = {"generated_at": datetime.now(timezone.utc).isoformat()}

    # Entities
    entities = _load_jsonl(output / "entities.jsonl")
    stats["entity_count"] = len(entities)
    by_layer = {}
    for e in entities:
        layer = e.get("layer", "unknown")
        by_layer[layer] = by_layer.get(layer, 0) + 1
    for layer, count in by_layer.items():
        stats[f"entities_{layer}"] = count

    # Relations
    relations = _load_jsonl(output / "relations.jsonl")
    stats["relation_count"] = len(relations)

    # Coverage
    coverage = _load_json(output / "coverage_report.json")
    fc = coverage.get("file_coverage", {})
    stats["parse_rate"] = fc.get("parse_rate", 0)
    stats["extraction_rate"] = fc.get("extraction_rate", 0)
    stats["critical_gaps"] = sum(1 for g in coverage.get("gaps", []) if g.get("severity") == "critical")

    # Validation
    validation = _load_json(output / "validation_report.json")
    stats["validation_errors"] = validation.get("error_count", 0)
    stats["dangling_refs"] = sum(1 for e in validation.get("errors", []) if "dangling" in e.get("type", ""))

    # Mapping
    mapping = _load_json(output / "mapping_confidence_report.json")
    stats["mapping_confidence"] = mapping.get("summary", {}).get("overall_confidence", 0)

    return stats


def _check_no_drop(checks, metric, baseline, current, tolerance=0.05):
    b = baseline.get(metric, 0)
    c = current.get(metric, 0)
    if b == 0:
        passed = True
        detail = "(baseline was 0)"
    else:
        drop = (b - c) / b
        passed = drop <= tolerance
        detail = f"({drop:+.1%} change)" if not passed else ""
    checks.append({"metric": metric, "baseline": b, "current": c, "passed": passed, "detail": detail})


def _check_no_increase(checks, metric, baseline, current):
    b = baseline.get(metric, 0)
    c = current.get(metric, 0)
    passed = c <= b
    detail = f"(+{c - b})" if not passed else ""
    checks.append({"metric": metric, "baseline": b, "current": c, "passed": passed, "detail": detail})


def _load_json(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}

def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='MAFIA Regression Runner')
    parser.add_argument('--save-baseline', action='store_true', help='Save current stats as baseline')
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    output_dir = str(base / "output")

    if args.save_baseline:
        save_baseline(output_dir)
    else:
        run_regression(output_dir)
