"""
MAFIA Migrate
==============
Rewrites v1 artifacts to v2 format in place. Backs up originals.
"""

import json
import shutil
from pathlib import Path

from schemas.id_format import migrate_entity_id_v1_to_v2, ID_FORMAT_VERSION


def migrate(output_dir: str) -> dict:
    """Migrate v1 artifacts to v2 in place. Returns migration stats."""
    out = Path(output_dir)
    backup = out / "backup-v1"

    stats = {"entities_migrated": 0, "relations_migrated": 0, "already_v2": False}

    # Check if already v2
    sidecar = out / "id_format.json"
    if sidecar.exists():
        data = json.loads(sidecar.read_text(encoding="utf-8"))
        if data.get("id_format_version", 1) >= 2:
            stats["already_v2"] = True
            return stats

    # Backup
    backup.mkdir(parents=True, exist_ok=True)
    for fname in ("entities.jsonl", "relations.jsonl", "system_graph.json", "e2e_flows.json"):
        src = out / fname
        if src.exists():
            shutil.copy2(src, backup / fname)

    # Migrate entities.jsonl
    ent_path = out / "entities.jsonl"
    if ent_path.exists():
        lines = ent_path.read_text(encoding="utf-8").splitlines()
        migrated = []
        for line in lines:
            if not line.strip():
                continue
            e = json.loads(line)
            eid = e.get("id", "")
            try:
                e["id"] = migrate_entity_id_v1_to_v2(eid)
            except Exception:
                pass
            # Add v2 fields if missing
            if "scope_path" not in e:
                e["scope_path"] = e.get("repo", "")
            if "codebase" not in e:
                e["codebase"] = e.get("repo", "")
            if "workspace" not in e:
                e["workspace"] = e.get("repo", "")
            migrated.append(json.dumps(e, ensure_ascii=False))
            stats["entities_migrated"] += 1
        ent_path.write_text("\n".join(migrated) + "\n", encoding="utf-8")

    # Migrate relations.jsonl
    rel_path = out / "relations.jsonl"
    if rel_path.exists():
        lines = rel_path.read_text(encoding="utf-8").splitlines()
        migrated = []
        for line in lines:
            if not line.strip():
                continue
            r = json.loads(line)
            if "cross_scope" not in r:
                r["cross_scope"] = False
            if "boundary" not in r:
                r["boundary"] = None
            migrated.append(json.dumps(r, ensure_ascii=False))
            stats["relations_migrated"] += 1
        rel_path.write_text("\n".join(migrated) + "\n", encoding="utf-8")

    # Migrate system_graph.json
    sg_path = out / "system_graph.json"
    if sg_path.exists():
        sg = json.loads(sg_path.read_text(encoding="utf-8"))
        if "id_format_version" not in sg:
            sg["id_format_version"] = ID_FORMAT_VERSION
            for node in sg.get("nodes", []):
                if "scope_path" not in node:
                    node["scope_path"] = node.get("repo", "")
            sg_path.write_text(json.dumps(sg, indent=2, ensure_ascii=False), encoding="utf-8")

    # Write sidecar
    sidecar.write_text(json.dumps({"id_format_version": ID_FORMAT_VERSION}), encoding="utf-8")

    return stats
