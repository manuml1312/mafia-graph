"""
MAFIA Public API — Façade
==========================
Single entry point for all MAFIA operations.
"""

import json
from pathlib import Path
from typing import Optional

from mafia.ids import EntityID
from mafia.graph import Graph


class MAFIA:
    """Main façade for MAFIA codebase intelligence."""

    def __init__(self, codebase_root: Path, mafia_dir: Path):
        self._root = codebase_root
        self._mafia_dir = mafia_dir
        self._output_dir = mafia_dir / "output"
        self._graph: Optional[Graph] = None
        self._config: dict = {}

    # ── Constructors ─────────────────────────────────────────────────────────

    @classmethod
    def from_path(cls, path: str | Path, *, name: str | None = None) -> "MAFIA":
        from phase4_source_adapters import resolve_source
        root = resolve_source(str(path), Path(".mafia"))
        mafia_dir = root / ".mafia"
        mafia_dir.mkdir(parents=True, exist_ok=True)
        (mafia_dir / "output").mkdir(parents=True, exist_ok=True)
        inst = cls(root, mafia_dir)
        # Apply mafia.json overrides if present
        from mafia.config import load_config
        inst._config = load_config(str(mafia_dir))
        return inst

    @classmethod
    def from_archive(cls, archive: str | Path, *, name: str | None = None) -> "MAFIA":
        from phase4_source_adapters import resolve_source
        work_dir = Path(".mafia")
        root = resolve_source(str(archive), work_dir)
        mafia_dir = root / ".mafia"
        mafia_dir.mkdir(parents=True, exist_ok=True)
        (mafia_dir / "output").mkdir(parents=True, exist_ok=True)
        return cls(root, mafia_dir)

    @classmethod
    def from_git(cls, url: str, *, ref: str = "HEAD", name: str | None = None) -> "MAFIA":
        from phase4_source_adapters.git_adapter import GitAdapter
        root = GitAdapter().resolve(url, Path(".mafia"), ref=ref)
        mafia_dir = root / ".mafia"
        mafia_dir.mkdir(parents=True, exist_ok=True)
        (mafia_dir / "output").mkdir(parents=True, exist_ok=True)
        return cls(root, mafia_dir)

    @classmethod
    def open(cls, mafia_dir: str | Path) -> "MAFIA":
        """Open an already-initialized .mafia/ directory."""
        md = Path(mafia_dir)
        if not md.exists():
            raise FileNotFoundError(f".mafia directory not found: {md}")
        root = md.parent
        return cls(root, md)

    # ── Pipeline methods ─────────────────────────────────────────────────────

    def scan(self) -> "MAFIA":
        from phase2_repo_intake.scope_discovery import discover
        from phase2_repo_intake.manifest_writer import write_workspace_manifest
        result = discover(str(self._root))
        write_workspace_manifest(result, str(self._output_dir))
        return self

    def extract(self, *, full: bool = False, workers: int = 8) -> "MAFIA":
        # Build a minimal manifest for the dispatcher
        manifest_path = self._output_dir / "repo_manifest.json"
        if not manifest_path.exists():
            self.scan()
        from phase3_extraction_framework.dispatcher import ExtractionDispatcher
        from phase4_extractors.generic.ast_extractor import GenericAstExtractor
        dispatcher = ExtractionDispatcher(str(manifest_path), str(self._output_dir))
        dispatcher.register("*", GenericAstExtractor)
        # Try to register framework extractors if available
        try:
            from phase4_extractors.ui.ui_extractor import UiExtractor
            dispatcher.register("ui", UiExtractor)
        except Exception:
            pass
        try:
            from phase4_extractors.bff.bff_extractor import BffExtractor
            dispatcher.register("bff", BffExtractor)
        except Exception:
            pass
        try:
            from phase4_extractors.api.api_extractor import ApiExtractor
            dispatcher.register("api", ApiExtractor)
        except Exception:
            pass
        dispatcher.run(repo_workers=1, file_workers=workers)
        return self

    def stitch(self) -> "MAFIA":
        from phase3_extraction_framework.cross_scope import run_all_stitchers
        run_all_stitchers(str(self._output_dir))
        return self

    def build_graph(self) -> "MAFIA":
        from phase9_graph.graph_builder import build_graph
        build_graph(str(self._output_dir))
        self._graph = None  # reset lazy cache
        return self

    def run_all(self, *, full: bool = False) -> "MAFIA":
        return self.scan().extract(full=full).stitch().build_graph()

    def update(self) -> "MAFIA":
        return self.scan().extract().stitch().build_graph()

    # ── Scope inspection ─────────────────────────────────────────────────────

    @property
    def codebase(self):
        manifest = self._load_workspace_manifest()
        if manifest:
            return manifest.get("codebase", {})
        return {"id": self._root.name, "root": str(self._root)}

    @property
    def repos(self) -> list:
        manifest = self._load_workspace_manifest()
        return manifest.get("repos", []) if manifest else []

    @property
    def workspaces(self) -> list:
        manifest = self._load_workspace_manifest()
        if not manifest:
            return []
        result = []
        for repo in manifest.get("repos", []):
            result.extend(repo.get("workspaces", []))
        return result

    # ── Graph queries ────────────────────────────────────────────────────────

    def _get_graph(self) -> Graph:
        if self._graph is None:
            self._graph = Graph(str(self._output_dir))
        return self._graph

    def search(self, query: str, *, layer: str | None = None, limit: int = 10) -> list:
        return self._get_graph().search(query, layer=layer, limit=limit)

    def neighbors(self, eid: str | EntityID, *, direction: str = "both", depth: int = 1) -> dict:
        return self._get_graph().neighbors(str(eid), direction=direction, depth=depth)

    def trace(self, eid: str | EntityID, *, depth: int = 10) -> dict:
        return self._get_graph().trace(str(eid), depth=depth)

    def blast(self, eid: str | EntityID, *, direction: str = "downstream", depth: int = 4) -> dict:
        return self._get_graph().neighbors(str(eid), direction=direction, depth=depth)

    def flows(self, *, node: str | EntityID | None = None) -> list:
        return self._get_graph().flows(node=str(node) if node else None)

    def path(self, src: str | EntityID, dst: str | EntityID) -> Optional[dict]:
        return self._get_graph().path(str(src), str(dst))

    def orphans(self) -> list:
        return self._get_graph().orphans()

    # ── Cross-scope queries ──────────────────────────────────────────────────

    def shared_libs(self) -> list:
        return self._load_shared_resources().get("shared_libs", [])

    def shared_tables(self) -> list:
        return self._load_shared_resources().get("shared_tables", [])

    def shared_envs(self) -> list:
        return self._load_shared_resources().get("shared_envs", [])

    def cross_repo_edges(self) -> list:
        return self._load_cross_edges("repo")

    def cross_workspace_edges(self) -> list:
        return self._load_cross_edges("workspace")

    # ── Export ────────────────────────────────────────────────────────────────

    def export_graph(self, path: str | Path) -> None:
        import shutil
        sg = self._output_dir / "system_graph.json"
        if sg.exists():
            shutil.copy2(sg, path)

    def networkx_graph(self):
        import networkx as nx
        g = self._get_graph()
        G = nx.DiGraph()
        for nid, node in g.nodes().items():
            G.add_node(nid, **node)
        for (s, t), edge in g.edges().items():
            G.add_edge(s, t, **edge)
        return G

    # ── Skill adapter ────────────────────────────────────────────────────────

    def as_skill(self) -> "Skill":
        from mafia.skill import Skill
        return Skill(self)

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _load_workspace_manifest(self) -> Optional[dict]:
        p = self._output_dir / "workspace_manifest.json"
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        return None

    def _load_shared_resources(self) -> dict:
        p = self._output_dir / "shared_resources.json"
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        return {}

    def _load_cross_edges(self, boundary: str) -> list:
        p = self._output_dir / "relations.jsonl"
        if not p.exists():
            return []
        edges = []
        for line in p.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            r = json.loads(line)
            if r.get("cross_scope") and r.get("boundary") == boundary:
                edges.append(r)
        return edges
