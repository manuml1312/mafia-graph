"""MAFIA public API — Graph wrapper."""

from pathlib import Path
from typing import Optional


class Graph:
    """Lazy-loading wrapper around system_graph.json + e2e_flows.json."""

    def __init__(self, output_dir: str):
        self._output_dir = Path(output_dir)
        self._gq = None

    def _ensure_loaded(self):
        if self._gq is not None:
            return
        from phase9_graph.graph_query import GraphQuery
        sg = self._output_dir / "system_graph.json"
        fl = self._output_dir / "e2e_flows.json"
        self._gq = GraphQuery(
            str(sg) if sg.exists() else None,
            str(fl) if fl.exists() else None,
        )

    def nodes(self) -> dict:
        self._ensure_loaded()
        return dict(self._gq.nodes)

    def edges(self) -> dict:
        self._ensure_loaded()
        return dict(self._gq._edges)

    def node(self, eid: str) -> Optional[dict]:
        self._ensure_loaded()
        return self._gq.nodes.get(eid)

    def neighbors(self, eid: str, direction: str = "both", depth: int = 2) -> dict:
        self._ensure_loaded()
        return self._gq.neighborhood(eid, direction=direction, depth=depth)

    def search(self, query: str, layer: str = None, limit: int = 10) -> list:
        self._ensure_loaded()
        return self._gq.find_by_name(query, layer=layer, limit=limit)

    def trace(self, eid: str, depth: int = 10) -> dict:
        self._ensure_loaded()
        return self._gq.trace_flow(eid, max_depth=depth)

    def flows(self, node: str = None, limit: int = 10) -> list:
        self._ensure_loaded()
        if node:
            return self._gq.flows_for_node(node, limit=limit)
        return self._gq.complete_flows(limit=limit)

    def path(self, src: str, dst: str) -> Optional[dict]:
        self._ensure_loaded()
        return self._gq.find_path(src, dst)

    def orphans(self) -> list:
        self._ensure_loaded()
        return self._gq.orphan_nodes()

    @property
    def query(self):
        """Access the underlying GraphQuery for advanced operations."""
        self._ensure_loaded()
        return self._gq
