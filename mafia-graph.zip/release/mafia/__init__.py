"""
MAFIA — Multi-Artifact Flow Intelligence Architecture
======================================================
Public Python API. This is the only stable surface.

Usage:
    from mafia import MAFIA
    m = MAFIA.from_path("/path/to/project").run_all()
    results = m.search("getUserProfile")
    skill = m.as_skill()
"""

from mafia.api import MAFIA
from mafia.ids import EntityID
from mafia.graph import Graph
from mafia.skill import Skill
from schemas.scope import Scope

__all__ = ["MAFIA", "EntityID", "Graph", "Skill", "Scope"]
