"""MAFIA public API — backward compatibility helpers."""

from schemas.id_format import migrate_entity_id_v1_to_v2


def migrate_id(old_id: str) -> str:
    """Migrate a v1 entity ID to v2 format (currently identity)."""
    return migrate_entity_id_v1_to_v2(old_id)
