"""MAFIA public API — EntityID type."""

from schemas.id_format import parse_entity_id, ParsedEntityId


class EntityID:
    """Thin wrapper around a parsed entity ID string."""

    def __init__(self, eid: str):
        self._raw = eid
        self._parsed = parse_entity_id(eid)

    @classmethod
    def from_string(cls, s: str) -> "EntityID":
        return cls(s)

    @property
    def layer(self) -> str:
        return self._parsed.layer

    @property
    def entity_type(self) -> str:
        return self._parsed.entity_type

    @property
    def scope_path(self) -> str:
        return self._parsed.scope_path

    @property
    def qualifier(self) -> str:
        return self._parsed.qualifier

    @property
    def codebase(self) -> str:
        parts = self._parsed.scope_path.split("/")
        return parts[0]

    @property
    def repo(self) -> str:
        parts = self._parsed.scope_path.split("/")
        return parts[1] if len(parts) > 1 else parts[0]

    @property
    def workspace(self) -> str:
        parts = self._parsed.scope_path.split("/")
        return parts[-1]

    def __str__(self) -> str:
        return self._raw

    def __repr__(self) -> str:
        return f"EntityID({self._raw!r})"

    def __eq__(self, other) -> bool:
        if isinstance(other, EntityID):
            return self._raw == other._raw
        return self._raw == str(other)

    def __hash__(self) -> int:
        return hash(self._raw)
