"""
MAFIA Skill Adapter
====================
Exposes MAFIA queries as tool specs for AI agents.
"""

from dataclasses import asdict
from typing import Any


_TOOLS = [
    {"name": "mafia_search", "description": "Search entities by name",
     "params": {"query": "str", "layer": "str|null", "limit": "int"}},
    {"name": "mafia_neighbors", "description": "Get neighbors of an entity",
     "params": {"entity_id": "str", "direction": "str", "depth": "int"}},
    {"name": "mafia_trace", "description": "Trace downstream call chain",
     "params": {"entity_id": "str", "depth": "int"}},
    {"name": "mafia_blast", "description": "Blast radius analysis",
     "params": {"entity_id": "str", "direction": "str", "depth": "int"}},
    {"name": "mafia_flows", "description": "Get end-to-end flows",
     "params": {"node": "str|null"}},
    {"name": "mafia_path", "description": "Find shortest path between two entities",
     "params": {"source": "str", "target": "str"}},
    {"name": "mafia_orphans", "description": "Find orphan nodes with no connections",
     "params": {}},
    {"name": "mafia_shared_libs", "description": "List shared libraries across workspaces",
     "params": {}},
    {"name": "mafia_shared_tables", "description": "List shared database tables",
     "params": {}},
    {"name": "mafia_cross_repo_edges", "description": "List cross-repo edges",
     "params": {}},
    {"name": "mafia_status", "description": "Get codebase status and stats",
     "params": {}},
    {"name": "mafia_workspace_deps", "description": "Get workspace dependencies",
     "params": {"workspace": "str"}},
]


def _param_schema(params: dict) -> dict:
    """Convert simple param spec to JSON Schema properties."""
    properties = {}
    required = []
    for name, ptype in params.items():
        if ptype == "str":
            properties[name] = {"type": "string"}
            required.append(name)
        elif ptype == "str|null":
            properties[name] = {"type": ["string", "null"]}
        elif ptype == "int":
            properties[name] = {"type": "integer"}
        else:
            properties[name] = {"type": "string"}
    return {"type": "object", "properties": properties, "required": required}


class Skill:
    """Adapter that exposes MAFIA as AI agent tools."""

    def __init__(self, mafia_instance):
        self._mafia = mafia_instance

    def describe(self, *, format: str = "anthropic") -> list[dict]:
        """Return tool specs in the requested format."""
        if format == "anthropic":
            return [
                {"name": t["name"], "description": t["description"],
                 "input_schema": _param_schema(t["params"])}
                for t in _TOOLS
            ]
        elif format == "openai":
            return [
                {"type": "function", "function": {
                    "name": t["name"], "description": t["description"],
                    "parameters": _param_schema(t["params"]),
                }}
                for t in _TOOLS
            ]
        elif format == "mcp":
            return [
                {"name": t["name"], "description": t["description"],
                 "inputSchema": _param_schema(t["params"])}
                for t in _TOOLS
            ]
        elif format == "langchain":
            return [
                {"name": t["name"], "description": t["description"],
                 "args_schema": _param_schema(t["params"])}
                for t in _TOOLS
            ]
        else:
            raise ValueError(f"Unknown format: {format}. Use anthropic|openai|mcp|langchain")

    def handle_call(self, name: str, arguments: dict) -> dict:
        """Dispatch a tool call by name. Returns JSON-serializable result."""
        m = self._mafia
        try:
            if name == "mafia_search":
                return {"results": m.search(arguments["query"],
                                            layer=arguments.get("layer"),
                                            limit=arguments.get("limit", 10))}
            elif name == "mafia_neighbors":
                return m.neighbors(arguments["entity_id"],
                                   direction=arguments.get("direction", "both"),
                                   depth=arguments.get("depth", 1))
            elif name == "mafia_trace":
                return m.trace(arguments["entity_id"],
                               depth=arguments.get("depth", 10))
            elif name == "mafia_blast":
                return m.blast(arguments["entity_id"],
                               direction=arguments.get("direction", "downstream"),
                               depth=arguments.get("depth", 4))
            elif name == "mafia_flows":
                return {"flows": m.flows(node=arguments.get("node"))}
            elif name == "mafia_path":
                result = m.path(arguments["source"], arguments["target"])
                return result or {"error": "No path found"}
            elif name == "mafia_orphans":
                return {"orphans": m.orphans()}
            elif name == "mafia_shared_libs":
                return {"shared_libs": m.shared_libs()}
            elif name == "mafia_shared_tables":
                return {"shared_tables": m.shared_tables()}
            elif name == "mafia_cross_repo_edges":
                return {"edges": m.cross_repo_edges()}
            elif name == "mafia_status":
                return {
                    "codebase": m.codebase,
                    "repo_count": len(m.repos),
                    "workspace_count": len(m.workspaces),
                }
            elif name == "mafia_workspace_deps":
                return {"workspaces": m.workspaces}
            else:
                return {"error": f"Unknown tool: {name}"}
        except Exception as e:
            return {"error": str(e)}

    def serve_http(self, host: str = "127.0.0.1", port: int = 5050):
        """Start a small Flask server exposing tools via HTTP."""
        from flask import Flask, request, jsonify
        app = Flask("mafia-skill")

        @app.route("/tools", methods=["GET"])
        def list_tools():
            return jsonify(self.describe(format="anthropic"))

        @app.route("/tools/<name>", methods=["POST"])
        def call_tool(name):
            args = request.get_json(force=True, silent=True) or {}
            return jsonify(self.handle_call(name, args))

        app.run(host=host, port=port)

    def serve_mcp(self, transport: str = "stdio"):
        """Serve tools via MCP (Model Context Protocol) over stdio."""
        import sys as _sys
        tools = self.describe(format="mcp")
        # Thin JSON-RPC stdio loop
        for line in _sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                import json as _json
                req = _json.loads(line)
                method = req.get("method", "")
                rid = req.get("id")
                if method == "tools/list":
                    resp = {"jsonrpc": "2.0", "id": rid, "result": {"tools": tools}}
                elif method == "tools/call":
                    params = req.get("params", {})
                    name = params.get("name", "")
                    args = params.get("arguments", {})
                    result = self.handle_call(name, args)
                    resp = {"jsonrpc": "2.0", "id": rid,
                            "result": {"content": [{"type": "text", "text": _json.dumps(result)}]}}
                else:
                    resp = {"jsonrpc": "2.0", "id": rid,
                            "error": {"code": -32601, "message": f"Unknown method: {method}"}}
                _sys.stdout.write(_json.dumps(resp) + "\n")
                _sys.stdout.flush()
            except Exception as e:
                pass
