"""
MAFIA Plugin Loader
====================
Discovers plugins via importlib.metadata entry points.
Groups: mafia.extractors, mafia.workspace_detectors, mafia.source_adapters
"""

from typing import Optional


def load_plugins(group: str, config: Optional[dict] = None) -> dict[str, type]:
    """Load plugins from entry points for the given group.

    Args:
        group: entry point group name (e.g. 'mafia.extractors')
        config: optional plugins config from mafia.json with enable/disable/order

    Returns:
        dict of name → class, filtered and ordered per config.
    """
    try:
        from importlib.metadata import entry_points
        eps = entry_points(group=group)
    except Exception:
        return {}

    plugins = {}
    for ep in eps:
        try:
            plugins[ep.name] = ep.load()
        except Exception:
            continue

    if not config:
        return plugins

    # Apply enable/disable/order from config
    enable = config.get("enable")
    disable = set(config.get("disable", []))
    order = config.get("order", [])

    if enable is not None:
        enable_set = set(enable)
        plugins = {k: v for k, v in plugins.items() if k in enable_set}

    plugins = {k: v for k, v in plugins.items() if k not in disable}

    if order:
        ordered = {}
        for name in order:
            if name == "..." :
                # "..." means "all remaining in original order"
                for k, v in plugins.items():
                    if k not in ordered:
                        ordered[k] = v
            elif name in plugins:
                ordered[name] = plugins[name]
        # Add any remaining not in order list
        for k, v in plugins.items():
            if k not in ordered:
                ordered[k] = v
        plugins = ordered

    return plugins
