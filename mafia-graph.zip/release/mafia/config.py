"""MAFIA config loader — reads .mafia/mafia.json."""

import json
from pathlib import Path
from typing import Optional


def load_config(mafia_dir: str | Path) -> dict:
    """Load .mafia/mafia.json if present, else return empty dict."""
    p = Path(mafia_dir) / "mafia.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}
