"""
MAFIA Phase 5 — Structural and Cross-Layer Relation Emitter
=============================================================
Post-processing pass that reads entities.jsonl and source files to emit:
  - belongs_to_repo (every entity -> its repo)
  - belongs_to_layer (every entity -> its layer)
  - defined_in (every entity with a file -> that file)
  - imports (JS/TS import statements)
  - exports (JS/TS export statements)
  - fetches (UI fetch_def -> BFF endpoint by path matching)

Runs AFTER all extractors have flushed entities.jsonl.
"""

import json
import os
import re
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from schemas.emitter import CanonicalEmitter
from phase2_repo_intake.arch_detector import load_arch_profile
from phase3_extraction_framework.symbol_resolver import load_symbol_index


def emit_structural_relations(output_dir: str, manifest_path: str, max_workers: int = 8):
    """Post-process entities.jsonl to emit structural + cross-layer relations."""
    output = Path(output_dir)
    emitter = CanonicalEmitter("structural_emitter")

    entities = _load_jsonl(output / "entities.jsonl")
    manifest = json.loads(Path(manifest_path).read_text(encoding='utf-8'))
    repo_map = {r["repo_id"]: r for r in manifest.get("repos", [])}

    # ── Pass 0: Endpoint normalizer — ensure every api:endpoint has http_path ─
    # Re-reads source files for any endpoint missing http_path in properties.
    # This makes Method 1 (exact http_path match) work universally.
    _normalize_endpoint_paths(entities, manifest, output)

    # ── Pass 0b: Entity dedup + merge — collapse same file+line duplicates ────
    # TreeSitter and regex extractors both emit entities for the same function.
    # Keep highest-confidence version, remap all relations to surviving ID.
    entities = _dedup_entities(entities, output)

    # ── Pass 0c: API endpoint variant dedup — merge ClassName.method with /path ──
    entities = _dedup_api_endpoint_variants(entities, output)

    # Load symbol index for cross-file call resolution
    symbol_index = load_symbol_index(output_dir)

    entity_map = {e["id"]: e for e in entities}
    entities_by_repo = defaultdict(list)
    for e in entities:
        entities_by_repo[e.get("repo", "")].append(e)

    # ── belongs_to_repo + belongs_to_layer + defined_in ──────────────────────
    for e in entities:
        eid = e["id"]
        repo = e.get("repo", "")
        layer = e.get("layer", "")
        file_path = e.get("file")

        if repo:
            emitter.emit_relation(
                source_id=eid, target_id=f"repo:{repo}",
                relation_type="belongs_to_repo", confidence=0.95,
                evidence_file=file_path or "", evidence_method="heuristic",
                properties={"repo_id": repo},
            )

        if layer:
            emitter.emit_relation(
                source_id=eid, target_id=f"layer:{layer}",
                relation_type="belongs_to_layer", confidence=0.95,
                evidence_file=file_path or "", evidence_method="heuristic",
                properties={"layer": layer},
            )

        if file_path:
            emitter.emit_relation(
                source_id=eid, target_id=f"file:{repo}:{file_path}",
                relation_type="defined_in", confidence=0.95,
                evidence_file=file_path, evidence_method="heuristic",
                evidence_line_start=e.get("line"),
            )

    # ── imports / exports (JS/TS files) ──────────────────────────────────────
    re_import = re.compile(r'import\s*\{([^}]+)\}\s*from\s*[\'"]([^\'"]+)[\'"]')
    re_export = re.compile(r'export\s+(?:default\s+)?(?:const|let|var|function|class)\s+(\w+)')
    # Python imports
    re_py_import = re.compile(r'^(?:from\s+(\S+)\s+import\s+(.+)|import\s+(.+))$', re.MULTILINE)
    re_py_from_import = re.compile(r'^from\s+(\S+)\s+import\s+(.+)$', re.MULTILINE)

    # Build entity lookup: (repo, symbol_name) -> entity_id
    symbol_to_entity = {}
    for e in entities:
        name = e.get("name", "")
        repo = e.get("repo", "")
        if name and repo:
            symbol_to_entity[(repo, name)] = e["id"]

    def _process_imports_exports(repo_id, repo_path):
        count = 0
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in {'node_modules', '.git', 'dist', 'build', 'out', 'target', '.next', '__pycache__', '.venv', 'venv'}]
            for fname in filenames:
                ext = Path(fname).suffix.lower()
                if ext not in ('.ts', '.tsx', '.js', '.jsx', '.py'):
                    continue
                fpath = os.path.join(root, fname)
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read(16384)
                except Exception:
                    continue

                if ext == '.py':
                    # Python: from module import Name1, Name2
                    for m in re_py_from_import.finditer(content):
                        names_str = m.group(2)
                        names = [n.strip().split(' as ')[0].strip() for n in names_str.split(',')]
                        line = content[:m.start()].count('\n') + 1
                        for name in names:
                            if not name or name == '*':
                                continue
                            tgt_id = symbol_to_entity.get((repo_id, name))
                            if tgt_id:
                                file_ents = [e for e in entities_by_repo.get(repo_id, []) if e.get('file') == rel]
                                for fe in file_ents[:1]:
                                    emitter.emit_relation(
                                        source_id=fe['id'], target_id=tgt_id,
                                        relation_type='imports', confidence=0.85,
                                        evidence_file=rel, evidence_method='regex',
                                        evidence_line_start=line,
                                        evidence_snippet=m.group(0)[:200],
                                    )
                                    count += 1
                    continue

                # JS/TS exports
                for m in re_export.finditer(content):
                    sym = m.group(1)
                    src_id = symbol_to_entity.get((repo_id, sym))
                    if src_id:
                        emitter.emit_relation(
                            source_id=src_id, target_id=f'file:{repo_id}:{rel}',
                            relation_type='exports', confidence=0.90,
                            evidence_file=rel, evidence_method='regex',
                            evidence_line_start=content[:m.start()].count('\n') + 1,
                            evidence_snippet=m.group(0)[:200],
                        )
                        count += 1

                # JS/TS imports
                for m in re_import.finditer(content):
                    names = [n.strip().split(' as ')[0].strip() for n in m.group(1).split(',')]
                    line = content[:m.start()].count('\n') + 1
                    for name in names:
                        if not name:
                            continue
                        tgt_id = symbol_to_entity.get((repo_id, name))
                        if tgt_id:
                            file_entities = [e for e in entities_by_repo.get(repo_id, []) if e.get('file') == rel]
                            for fe in file_entities[:1]:
                                emitter.emit_relation(
                                    source_id=fe['id'], target_id=tgt_id,
                                    relation_type='imports', confidence=0.85,
                                    evidence_file=rel, evidence_method='regex',
                                    evidence_line_start=line,
                                    evidence_snippet=m.group(0)[:200],
                                )
                                count += 1
        return count

    # Run imports/exports in parallel per repo — all repos, not just ui/bff
    all_repos_for_imports = manifest.get('repos', [])
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_process_imports_exports, r['repo_id'], r['root_path']): r['repo_id'] for r in all_repos_for_imports if r.get('root_path')}
        for future in as_completed(futures):
            try:
                future.result()
            except Exception:
                pass

    # ── Helper: last-segment matching (mirrors bff_api_mapping/endpoint_mapper.py) ─
    def _get_last_segment(path):
        """Extract last meaningful URL segment, lowercased."""
        path = path.strip().split("?")[0].rstrip("/")
        if "/" in path:
            seg = path.split("/")[-1]
        else:
            seg = path
        # Skip path parameters like {protocolNo}
        if seg.startswith("{") or not seg:
            parts = path.split("/")
            for p in reversed(parts):
                if p and not p.startswith("{"):
                    return p.lower()
            return seg.lower()
        return seg.lower()

    def _normalize_api_path(path: str) -> str:
        """Normalize an API path for comparison: strip method prefix, version prefix, lowercase."""
        path = path.strip().lower()
        # Strip HTTP method prefix (e.g. "GET /flag/..." -> "/flag/...")
        if ' ' in path:
            path = path.split(' ', 1)[1]
        path = path.strip().rstrip('/')
        # Strip common API version prefixes
        for prefix in ('/api/v1', '/api/v2', '/api/v3', '/api', '/v1', '/v2'):
            if path.startswith(prefix):
                path = path[len(prefix):]
                break
        return path.lstrip('/')

    # ── fetches: UI fetch_def -> BFF or API endpoint ────────────────────────
    # Method 0: arch_profile route_to_function_map (highest confidence)
    # Method 1: exact http_path match
    # Method 2: path-to-name conversion (/api/approved-dtas -> api_approved_dtas)
    # Method 3: last-segment match (unique only)
    # Method 4: url_for name match
    arch_profile = load_arch_profile(output_dir)
    route_to_fn_map = arch_profile.get('extraction_hints', {}).get('route_to_function_map', {})

    ui_fetch_defs = [e for e in entities if e.get("layer") == "ui" and e.get("type") == "fetch_def"]
    bff_endpoints = [e for e in entities if e.get("layer") == "bff" and e.get("type") == "endpoint"]
    api_endpoints_all = [e for e in entities if e.get("layer") == "api" and e.get("type") == "endpoint"]
    # All backend endpoints to match against (BFF first, then API)
    all_backend_endpoints = bff_endpoints + api_endpoints_all

    def _path_to_name_variants(http_path: str) -> list:
        """Convert an HTTP path to likely function name variants.
        /api/approved-dtas -> ['api_approved_dtas', 'approved_dtas', 'approved-dtas',
                               'get_approved_dtas', 'list_approved_dtas']
        Works for Flask, FastAPI, Django, Express, Spring Boot."""
        path = http_path.strip().split('?')[0].rstrip('/')
        # Remove common prefixes
        for prefix in ('/api/v1/', '/api/v2/', '/api/v3/', '/api/', '/v1/', '/v2/', '/'):
            if path.startswith(prefix):
                path = path[len(prefix):]
                break
        # Replace path separators and hyphens with underscores
        base = re.sub(r'[/\-]', '_', path).strip('_').lower()
        # Remove path parameters like {id} or :id
        base = re.sub(r'[{:][^}_]+[}]?', '', base).strip('_')
        variants = [base]
        if base:
            variants += [
                f'api_{base}', f'get_{base}', f'list_{base}',
                f'post_{base}', f'create_{base}', f'update_{base}',
                f'delete_{base}', f'{base}_view', f'{base}_handler',
            ]
        return [v for v in variants if v]

    # Build backend endpoint lookup indexes
    be_by_http_path = {}       # exact http_path -> endpoint
    be_by_name = {}            # exact name -> endpoint
    be_by_segment = defaultdict(list)  # last segment -> [endpoint]

    for ep in all_backend_endpoints:
        # Index by stored http_path property
        http_path = ep.get('properties', {}).get('http_path', '') or \
                    ep.get('properties', {}).get('endpoint_path', '')
        if http_path:
            be_by_http_path[http_path.lower()] = ep
            be_by_http_path[http_path.lower().lstrip('/')] = ep
        # Index by name
        name = ep.get('name', '')
        if name:
            be_by_name[name.lower()] = ep
        # Index by last URL segment
        seg = _get_last_segment(http_path or name or '')
        if seg:
            be_by_segment[seg].append(ep)

    for fd in ui_fetch_defs:
        props = fd.get('properties', {})
        # Get the HTTP path from various property names
        http_path = (props.get('http_path') or props.get('path_suffix') or
                     props.get('endpoint_path') or fd.get('name', ''))
        if not http_path:
            continue
        http_path_clean = http_path.strip()

        target_ep = None
        conf = 0.85
        match_method = 'none'

        # Method 0: arch_profile route_to_function_map (path -> function name -> entity)
        route_info = route_to_fn_map.get(http_path_clean) or route_to_fn_map.get(http_path_clean.rstrip('/'))
        if route_info:
            fn_name = route_info.get('function', '')
            if fn_name:
                target_ep = be_by_name.get(fn_name.lower())
                if target_ep:
                    conf, match_method = 0.95, f'arch_profile_route_map:{fn_name}'

        # Method 1: exact http_path match
        if not target_ep:
            target_ep = be_by_http_path.get(http_path_clean.lower()) or \
                        be_by_http_path.get(http_path_clean.lower().lstrip('/'))
        if target_ep and match_method == 'none':
            conf, match_method = 0.90, 'exact_http_path'

        # Method 2: path-to-name conversion
        if not target_ep:
            for variant in _path_to_name_variants(http_path_clean):
                target_ep = be_by_name.get(variant)
                if target_ep:
                    conf, match_method = 0.82, f'path_to_name:{variant}'
                    break

        # Method 3: last-segment match (unique only)
        if not target_ep:
            seg = _get_last_segment(http_path_clean)
            candidates = be_by_segment.get(seg, [])
            if len(candidates) == 1:
                target_ep = candidates[0]
                conf, match_method = 0.70, 'last_segment_unique'
            elif len(candidates) > 1:
                api_cands = [c for c in candidates if c.get('layer') == 'api']
                if len(api_cands) == 1:
                    target_ep = api_cands[0]
                    conf, match_method = 0.65, 'last_segment_api_only'

        if target_ep:
            emitter.emit_relation(
                source_id=fd['id'], target_id=target_ep['id'],
                relation_type='fetches', confidence=conf,
                evidence_file=fd.get('file', ''), evidence_method='heuristic',
                evidence_line_start=fd.get('line'),
                properties={
                    'http_path': http_path_clean,
                    'matched_endpoint': target_ep.get('name', ''),
                    'match_method': match_method,
                    'target_layer': target_ep.get('layer', ''),
                },
            )

    # ── calls_api: BFF constant -> API endpoint (last-segment matching) ──────
    # This is the critical cross-layer hop that the old endpoint_mapper.py handles.
    # BFF constants with _API suffix have an endpoint_path property.
    # API endpoints have an endpoint_path property.
    # Match by last URL segment (lowercased), same as the proven old approach.
    # Include bff:service entities with endpoint_path - these are Constant class
    # members extracted by TreeSitter before the BFF extractor ran.
    bff_constants = [
        e for e in entities
        if e.get("layer") == "bff"
        and (
            e.get("type") == "constant"
            or (e.get("type") == "service"
                and e.get("properties", {}).get("endpoint_path"))
        )
    ]
    api_endpoints = [e for e in entities if e.get("layer") == "api" and e.get("type") == "endpoint"]

    # Build API endpoint lookup by last segment
    api_by_segment = defaultdict(list)
    api_by_path = {}
    api_by_norm_path = {}  # normalized path -> endpoint
    api_by_method_path = {}  # "METHOD:/path" -> endpoint (for HTTP-method-aware matching)
    for ep in api_endpoints:
        path = ep.get("properties", {}).get("endpoint_path", "") or ep.get("name", "")
        if path:
            api_by_path[path] = ep
            norm = _normalize_api_path(path)
            if norm:
                api_by_norm_path[norm] = ep
            seg = _get_last_segment(path)
            if seg:
                api_by_segment[seg].append(ep)
            # Index by METHOD:path for method-aware matching
            ep_method = (ep.get('properties', {}).get('http_method', '') or '').upper()
            if ep_method:
                api_by_method_path[f'{ep_method}:{norm}'] = ep

    # Build BFF controller HTTP method lookup: constant_var_name -> http_method
    # Used to disambiguate when multiple API endpoints match the same path.
    _bff_const_to_method = {}  # constant_var_name -> HTTP method from controller
    for ctrl in [e for e in entities if e.get('layer') == 'bff' and e.get('type') == 'controller']:
        ctrl_method = (ctrl.get('properties', {}).get('http_method', '') or '').upper()
        if not ctrl_method:
            continue
        for api_var in ctrl.get('properties', {}).get('api_constants', []):
            _bff_const_to_method[api_var] = ctrl_method
        const_ref = ctrl.get('properties', {}).get('constant_ref', '')
        if const_ref:
            _bff_const_to_method[const_ref] = ctrl_method

    def _pick_by_http_method(candidates: list, bff_method: str) -> tuple:
        """From a list of API endpoint candidates, prefer the one whose
        HTTP method matches the BFF controller's method.
        Returns (endpoint, confidence_delta, match_note)."""
        if not bff_method or len(candidates) < 2:
            return None, 0.0, ''
        method_matches = [
            c for c in candidates
            if (c.get('properties', {}).get('http_method', '') or '').upper() == bff_method
        ]
        if len(method_matches) == 1:
            return method_matches[0], 0.05, f'+method_match:{bff_method}'
        return None, 0.0, ''

    bff_api_matched = 0
    for const in bff_constants:
        const_path = const.get("properties", {}).get("endpoint_path", "")
        if not const_path:
            continue

        # Resolve HTTP method from the BFF controller that references this constant
        const_var = const.get('properties', {}).get('variable_name') or const.get('name', '')
        bff_http_method = _bff_const_to_method.get(const_var, '')

        # Try exact path match first
        api_ep = api_by_path.get(const_path)
        conf = 0.90
        match_method = "exact_path"

        # Try method+path exact match (higher confidence)
        if not api_ep and bff_http_method:
            norm = _normalize_api_path(const_path)
            if norm:
                api_ep = api_by_method_path.get(f'{bff_http_method}:{norm}')
                if api_ep:
                    conf = 0.92
                    match_method = f"exact_method_path:{bff_http_method}"

        # Fallback 1: normalized suffix match — strip leading /api/v1 etc. and compare
        if not api_ep:
            norm = _normalize_api_path(const_path)
            if norm:
                api_ep = api_by_norm_path.get(norm)
                if api_ep:
                    conf = 0.85
                    match_method = "normalized_path"

        # Fallback 2: suffix match — const_path is a suffix of api path or vice versa
        if not api_ep:
            cp_stripped = const_path.rstrip('/').lower()
            for ap, ep in api_by_path.items():
                ap_stripped = ap.rstrip('/').lower()
                # Strip HTTP method prefix from api path (e.g. "GET /flag/..." -> "/flag/...")
                if ' ' in ap_stripped:
                    ap_stripped = ap_stripped.split(' ', 1)[1]
                if ap_stripped.endswith(cp_stripped) or cp_stripped.endswith(ap_stripped):
                    api_ep = ep
                    conf = 0.78
                    match_method = "suffix_match"
                    break

        # Fallback 3: last-segment match — now with HTTP method disambiguation
        if not api_ep:
            seg = _get_last_segment(const_path)
            candidates = api_by_segment.get(seg, [])
            if len(candidates) == 1:
                api_ep = candidates[0]
                conf = 0.70
                match_method = "last_segment_unique"
            elif len(candidates) > 1:
                # Try HTTP method disambiguation first
                method_ep, method_delta, method_note = _pick_by_http_method(
                    candidates, bff_http_method)
                if method_ep:
                    api_ep = method_ep
                    conf = 0.72
                    match_method = f"last_segment_method_disambig{method_note}"
                else:
                    # Fall back to path overlap scoring
                    best_ep, best_overlap = None, 0
                    cp_parts = const_path.lower().strip('/').split('/')
                    for c in candidates:
                        c_path = (c.get('properties', {}).get('endpoint_path', '') or c.get('name', '')).lower().strip('/')
                        if ' ' in c_path:
                            c_path = c_path.split(' ', 1)[1].strip('/')
                        c_parts = c_path.split('/')
                        overlap = sum(1 for a, b in zip(reversed(cp_parts), reversed(c_parts)) if a == b)
                        if overlap > best_overlap:
                            best_overlap, best_ep = overlap, c
                    if best_ep and best_overlap >= 2:
                        api_ep = best_ep
                        conf = 0.65
                        match_method = "last_segment_best_overlap"
                    elif best_ep:
                        api_ep = best_ep
                        conf = 0.50
                        match_method = "last_segment_ambiguous"

        if api_ep:
            emitter.emit_relation(
                source_id=const["id"], target_id=api_ep["id"],
                relation_type="calls_api", confidence=conf,
                evidence_file=const.get("file", ""), evidence_method="heuristic",
                evidence_line_start=const.get("line"),
                properties={
                    "bff_constant": const.get("name", ""),
                    "bff_path": const_path,
                    "api_path": api_ep.get("properties", {}).get("endpoint_path", ""),
                    "api_repo": api_ep.get("repo", ""),
                    "match_method": match_method,
                },
            )
            bff_api_matched += 1

    # ── BFF controller → BFF constant bridging (completes the BFF→API chain) ───
    # The BFF extractor emits calls_api for controllers that directly reference
    # Constant.xxx_API. But many controllers call API through helper methods.
    # This step re-reads BFF controller files and traces ALL Constant.xxx_API
    # references reachable from each controller, then links them.
    # Mirrors bff_endpoint_extractor.py's downstream_api_constants tracing.
    bff_controllers = [e for e in entities if e.get("layer") == "bff" and e.get("type") == "controller"]
    bff_const_by_repo = defaultdict(dict)  # repo -> {var_name -> entity_id}
    for _bc in bff_constants:
        # Use variable_name property if present (BFF extractor stores it there)
        _key = _bc.get("properties", {}).get("variable_name") or _bc.get("name", "")
        bff_const_by_repo[_bc.get("repo", "")][_key] = _bc["id"]

    # For each BFF repo, read all TS files and build: method_name -> [Constant.xxx_API refs]
    def _trace_bff_controller_apis(repo_id, repo_path):
        count = 0
        const_lookup = bff_const_by_repo.get(repo_id, {})
        if not const_lookup:
            return 0

        # Build method -> api_constants map from controller files
        method_api_map = {}  # method_name -> [constant_var_names]
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in {'node_modules', '.git', 'dist', 'build', 'out', 'target', '.next'}]
            for fname in filenames:
                if not fname.endswith(('.ts', '.js')):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except Exception:
                    continue

                # Find async method(ctx: Context) bodies and their Constant.xxx_API refs
                for m in re.finditer(r'async\s+(\w+)\s*\(\s*ctx\s*:\s*Context', content):
                    method_name = m.group(1)
                    brace_start = content.find('{', m.end())
                    if brace_start == -1:
                        continue
                    depth, i = 1, brace_start + 1
                    while i < len(content) and depth > 0:
                        if content[i] == '{': depth += 1
                        elif content[i] == '}': depth -= 1
                        i += 1
                    body = content[brace_start:i]
                    api_refs = re.findall(r'Constant\.(\w+_API)\b', body)
                    # Also find this.xxx() calls and trace their bodies
                    internal_calls = re.findall(r'this\.(\w+)\s*\(', body)
                    if api_refs or internal_calls:
                        method_api_map[method_name] = list(dict.fromkeys(api_refs))

                # Also trace helper methods that internal calls reference
                for m in re.finditer(r'(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?::\s*\w+)?\s*\{', content):
                    helper_name = m.group(1)
                    if helper_name in method_api_map:
                        continue  # already traced as controller
                    brace_start = content.find('{', m.end() - 1)
                    if brace_start == -1:
                        continue
                    depth, i = 1, brace_start + 1
                    while i < len(content) and depth > 0:
                        if content[i] == '{': depth += 1
                        elif content[i] == '}': depth -= 1
                        i += 1
                    body = content[brace_start:i]
                    api_refs = re.findall(r'Constant\.(\w+_API)\b', body)
                    if api_refs:
                        method_api_map.setdefault(helper_name, []).extend(api_refs)

        # Now link controllers to their API constants
        repo_controllers = [e for e in bff_controllers if e.get("repo") == repo_id]
        for ctrl in repo_controllers:
            ctrl_name = ctrl.get("name", "")
            api_refs = method_api_map.get(ctrl_name, [])
            if not api_refs:
                # Try matching by properties
                ctrl_props = ctrl.get("properties", {})
                for prop_key in ("api_constants", "internal_calls"):
                    for ref in ctrl_props.get(prop_key, []):
                        if ref in method_api_map:
                            api_refs.extend(method_api_map[ref])

            for api_var in api_refs:
                const_id = const_lookup.get(api_var)
                if const_id:
                    emitter.emit_relation(
                        source_id=ctrl["id"], target_id=const_id,
                        relation_type="calls_api", confidence=0.85,
                        evidence_file=ctrl.get("file", ""), evidence_method="heuristic",
                        evidence_line_start=ctrl.get("line"),
                        properties={"constant": api_var, "match_method": "controller_body_trace"},
                    )
                    count += 1
        return count

    bff_repos = [r for r in manifest.get("repos", []) if "bff" in r.get("classification", [])]
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_trace_bff_controller_apis, r["repo_id"], r["root_path"]): r["repo_id"] for r in bff_repos if r.get("root_path")}
        for future in as_completed(futures):
            try:
                future.result()
            except Exception:
                pass

    # ── DB function description reconciliation ──────────────────────────────
    # Enrich db.function entities with descriptions from functions_documentation_full.json
    # if available. This is a reconciliation step, not a dependency — the file is optional.
    func_doc = {}
    for candidate in [
        Path(output_dir).parent / "bff_api_mapping" / "functions_documentation_full.json",
        Path(output_dir).parent.parent / "bff_api_mapping" / "functions_documentation_full.json",
    ]:
        if candidate.exists():
            try:
                with open(candidate, 'r', encoding='utf-8') as f:
                    doc_data = json.load(f)
                for fn in doc_data.get("functions", []):
                    name = fn.get("name", "").lower()
                    func_doc[name] = fn
            except Exception:
                pass
            break

    if func_doc:
        db_functions = [e for e in entities if e.get("layer") == "db" and e.get("type") == "function"]
        enriched = 0
        for fn_ent in db_functions:
            fn_name = fn_ent.get("name", "").lower()
            # Try bare name and schema.name
            doc = func_doc.get(fn_name) or func_doc.get(fn_name.split(".")[-1])
            if doc:
                # Update the entity in-place in the JSONL (we can't modify emitted entities,
                # but we can emit enrichment as properties on a re-emitted entity)
                # Instead, store enrichment data for the graph builder to use
                fn_ent.setdefault("properties", {})["description"] = str(doc.get("description", ""))[:500]
                fn_ent["properties"]["function_dependencies"] = doc.get("function_dependency", [])
                fn_ent["properties"]["table_dependencies"] = doc.get("schema_table_dependency", [])
                fn_ent["properties"]["output"] = doc.get("output", [])[:5]
                fn_ent["properties"]["has_documentation"] = True
                enriched += 1

        # Rewrite entities.jsonl with enriched data
        if enriched > 0:
            entities_path = output / "entities.jsonl"
            with open(entities_path, 'w', encoding='utf-8') as f:
                for e in entities:
                    f.write(json.dumps(e, ensure_ascii=False) + "\n")

    # ── Cross-repo config usage tracing ───────────────────────────────────────
    # Build config entity index: config_name -> entity_id
    config_entities = {}
    for e in entities:
        if e.get("layer") == "config":
            config_entities[e.get("name", "")] = e["id"]

    re_env_ref_ts = re.compile(r'process\.env\.([A-Z_][A-Z0-9_]*)')
    re_env_ref_java = re.compile(r'@Value\s*\(\s*["\']\$\{([\w.]+)\}["\']\s*\)')
    re_prop_ref_java = re.compile(r'environment\.getProperty\s*\(\s*["\']([\w.]+)["\']')
    re_env_ref_py = re.compile(r'os\.(?:environ(?:\.get)?|getenv)\s*\(["\']([A-Z_][A-Z0-9_]*)["\']')

    def _trace_config_usage(repo_id, repo_path, classification):
        count = 0
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in {'node_modules', '.git', 'dist', 'build', 'out', 'target', '.next', '__pycache__', '.venv', 'venv'}]
            for fname in filenames:
                ext = Path(fname).suffix.lower()
                if ext not in ('.ts', '.tsx', '.js', '.jsx', '.java', '.py'):
                    continue
                fpath = os.path.join(root, fname)
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read(32768)
                except Exception:
                    continue

                file_ents = [e for e in entities_by_repo.get(repo_id, []) if e.get('file') == rel]
                if not file_ents:
                    continue
                src_id = file_ents[0]['id']

                if ext in ('.ts', '.tsx', '.js', '.jsx'):
                    for m in re_env_ref_ts.finditer(content):
                        env_name = m.group(1)
                        cfg_id = config_entities.get(env_name)
                        if cfg_id:
                            emitter.emit_relation(
                                source_id=src_id, target_id=cfg_id,
                                relation_type='depends_on_config', confidence=0.85,
                                evidence_file=rel, evidence_method='regex',
                                evidence_line_start=content[:m.start()].count('\n') + 1,
                                evidence_snippet=m.group(0)[:200],
                                properties={'config_name': env_name},
                            )
                            count += 1

                elif ext == '.java':
                    for m in re_env_ref_java.finditer(content):
                        prop_name = m.group(1)
                        cfg_id = config_entities.get(prop_name)
                        if cfg_id:
                            emitter.emit_relation(
                                source_id=src_id, target_id=cfg_id,
                                relation_type='depends_on_config', confidence=0.85,
                                evidence_file=rel, evidence_method='regex',
                                evidence_line_start=content[:m.start()].count('\n') + 1,
                                evidence_snippet=m.group(0)[:200],
                                properties={'config_name': prop_name},
                            )
                            count += 1
                    for m in re_prop_ref_java.finditer(content):
                        prop_name = m.group(1)
                        cfg_id = config_entities.get(prop_name)
                        if cfg_id:
                            emitter.emit_relation(
                                source_id=src_id, target_id=cfg_id,
                                relation_type='depends_on_config', confidence=0.80,
                                evidence_file=rel, evidence_method='regex',
                                evidence_line_start=content[:m.start()].count('\n') + 1,
                                evidence_snippet=m.group(0)[:200],
                                properties={'config_name': prop_name},
                            )
                            count += 1

                elif ext == '.py':
                    for m in re_env_ref_py.finditer(content):
                        env_name = m.group(1)
                        cfg_id = config_entities.get(env_name)
                        if cfg_id:
                            emitter.emit_relation(
                                source_id=src_id, target_id=cfg_id,
                                relation_type='depends_on_config', confidence=0.85,
                                evidence_file=rel, evidence_method='regex',
                                evidence_line_start=content[:m.start()].count('\n') + 1,
                                evidence_snippet=m.group(0)[:200],
                                properties={'config_name': env_name},
                            )
                            count += 1
        return count

    # Run config tracing across all repos
    all_repos = manifest.get("repos", [])
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_trace_config_usage, r["repo_id"], r["root_path"], r.get("classification", [])): r["repo_id"]
            for r in all_repos if r.get("root_path")
        }
        for future in as_completed(futures):
            try:
                future.result()
            except Exception:
                pass

    # ── Cross-repo DB table name matching ──────────────────────────────────────
    # When the same table name appears in multiple repos, surface the potential
    # connection. Confidence depends on whether the db_type matches:
    #   same db_type + same schema.table  → 0.80 (likely the same physical table)
    #   same db_type + bare name only     → 0.65 (probable, schema may differ)
    #   different db_type (e.g. pg vs dbr) → uses potential_shared_table relation
    #     at 0.30 confidence, excluded from flow assembly, written to dedicated artifact
    db_tables_by_name = defaultdict(list)
    for e in entities:
        if e.get("layer") != "db" or e.get("type") not in ("table", "view"):
            continue
        name = e.get("name", "").lower()
        parts = name.split(".")
        db_tables_by_name[parts[-1]].append(e)
        if len(parts) >= 2:
            db_tables_by_name[".".join(parts[-2:])].append(e)

    cross_db_candidates = []  # collected for dedicated artifact

    for name, table_ents in db_tables_by_name.items():
        if len(table_ents) < 2:
            continue
        # Only match across different repos (same-repo duplicates handled by dedup)
        seen_pairs = set()
        for i, a in enumerate(table_ents):
            for b in table_ents[i + 1:]:
                if a["id"] == b["id"] or a.get("repo") == b.get("repo"):
                    continue
                pair_key = tuple(sorted([a["id"], b["id"]]))
                if pair_key in seen_pairs:
                    continue
                seen_pairs.add(pair_key)

                a_db = a.get("properties", {}).get("db_type", "unknown")
                b_db = b.get("properties", {}).get("db_type", "unknown")
                same_db_type = a_db == b_db
                full_name_match = "." in name  # schema.table vs bare name

                if same_db_type and full_name_match:
                    conf = 0.80
                    warnings = []
                elif same_db_type:
                    conf = 0.65
                    warnings = ["Matched on bare table name only — schema may differ"]
                else:
                    # Cross-engine: use dedicated relation type, collect for artifact
                    conf = 0.30
                    warnings = [
                        f"Cross-database-engine name match ({a_db} vs {b_db}) — "
                        f"likely different physical tables, requires verification"
                    ]
                    cross_db_candidates.append({
                        "matched_name": name,
                        "source": {"id": a["id"], "name": a.get("name", ""),
                                   "repo": a.get("repo", ""), "db_type": a_db,
                                   "file": a.get("file", "")},
                        "target": {"id": b["id"], "name": b.get("name", ""),
                                   "repo": b.get("repo", ""), "db_type": b_db,
                                   "file": b.get("file", "")},
                        "confidence": conf,
                        "warnings": warnings,
                    })

                rel_type = "uses_table" if same_db_type else "potential_shared_table"

                emitter.emit_relation(
                    source_id=a["id"], target_id=b["id"],
                    relation_type=rel_type, confidence=conf,
                    evidence_file=a.get("file", ""), evidence_method="inferred",
                    evidence_line_start=a.get("line"),
                    properties={
                        "match_type": "cross_repo_table_name",
                        "source_db_type": a_db,
                        "target_db_type": b_db,
                        "same_db_engine": same_db_type,
                        "source_repo": a.get("repo", ""),
                        "target_repo": b.get("repo", ""),
                        "matched_name": name,
                        "warnings": warnings,
                    },
                )

    # Write dedicated cross-db artifact for review
    if cross_db_candidates:
        cross_db_path = output / "cross_db_table_candidates.json"
        with open(cross_db_path, 'w', encoding='utf-8') as f:
            json.dump({
                "description": "Cross-database-engine table name matches. "
                               "These are unverified — same name across different "
                               "DB engines (e.g. Postgres vs Databricks). "
                               "Review and confirm or dismiss.",
                "total": len(cross_db_candidates),
                "candidates": cross_db_candidates,
            }, f, indent=2, ensure_ascii=False)
        print(f'[StructuralRelations] Cross-DB candidates: {len(cross_db_candidates)} '
              f'written to cross_db_table_candidates.json')

    # ── Flush (append to existing relations.jsonl) ───────────────────────────
    relations_path = str(output / "relations.jsonl")

    # ── Cross-file method call stitching ─────────────────────────────────────
    # Stitches cross-file hops TreeSitter misses due to no type inference.
    # Strategy 1 (bridge): factory/getter fn returns ClassX → link callers to ClassX.method()
    # Strategy 2 (import): file imports ClassX → link instance.method() calls to ClassX.method

    re_inst_call    = re.compile(r'\b(\w+)\s*\.\s*(\w+)\s*\(', re.MULTILINE)
    re_py_imp_cls   = re.compile(r'^from\s+\S+\s+import\s+(.+)$', re.MULTILINE)

    meth_ents   = {}                  # "ClassName.method" -> entity
    meth_bare   = defaultdict(list)   # "method"           -> [entity]
    cls_ent_map = {}                  # "ClassName"        -> entity

    for _e in entities:
        _n, _t = _e.get('name', ''), _e.get('type', '')
        if _t in ('class', 'service') and _n and _n[0].isupper():
            cls_ent_map[_n] = _e
        if _t in ('function', 'service', 'repository', 'controller', 'endpoint'):
            meth_ents[_n] = _e
            meth_bare[_n.split('.')[-1]].append(_e)

    def _res_meth(cls_name, meth_name):
        t = meth_ents.get(f'{cls_name}.{meth_name}')
        if t:
            return t
        ce = cls_ent_map.get(cls_name)
        cf = ce.get('file', '') if ce else ''
        for _e in meth_bare.get(meth_name, []):
            if cls_name in _e.get('name', '') or (cf and _e.get('file', '') == cf):
                return _e
        return None

    def _fn_body(src, fn_name):
        p = src.find(f'def {fn_name}(')
        if p < 0:
            return ''
        c = src.find(':', p)
        return src[c:c + 3000] if c >= 0 else ''

    _existing_rels = _load_jsonl(output / 'relations.jsonl')
    _callers_of    = defaultdict(list)
    for _r in _existing_rels:
        if _r.get('type') == 'calls':
            _callers_of[_r.get('target', '')].append(_r.get('source', ''))
    _ent_by_id = {_e['id']: _e for _e in entities}
    _sc = 0

    for _rm in manifest.get('repos', []):
        _rid, _rp = _rm['repo_id'], _rm.get('root_path') or ''
        if not _rp:
            continue
        _rents = [_e for _e in entities if _e.get('repo') == _rid]

        # Strategy 1: bridge stitching
        for _be in _rents:
            if _be.get('type') not in ('function', 'service'):
                continue
            _bn = _be.get('name', '')
            if not any(p in _bn.lower() for p in ('_get_', 'get_', 'factory', '_service', '_client', '_create')):
                continue
            _bf = os.path.join(_rp, _be.get('file') or '')
            try:
                _bc = open(_bf, encoding='utf-8', errors='ignore').read()
            except Exception:
                continue
            _body = _fn_body(_bc, _bn.split('.')[-1])
            _rc = None
            for _cn in cls_ent_map:
                if _cn + '(' in _body or f'return {_cn}' in _body:
                    _rc = _cn
                    break
            if not _rc:
                continue
            for _cid in _callers_of.get(_be['id'], []):
                _ce = _ent_by_id.get(_cid)
                if not _ce or _ce.get('repo') != _rid:
                    continue
                _cf = os.path.join(_rp, _ce.get('file') or '')
                try:
                    _cc = open(_cf, encoding='utf-8', errors='ignore').read()
                except Exception:
                    continue
                _cb = _fn_body(_cc, _ce.get('name', '').split('.')[-1]) or _cc
                _seen = set()
                for _m in re_inst_call.finditer(_cb):
                    _mn = _m.group(2)
                    if _mn in _seen or _mn.startswith('_'):
                        continue
                    _tgt = _res_meth(_rc, _mn)
                    if _tgt and _tgt['id'] != _cid:
                        _seen.add(_mn)
                        emitter.emit_relation(
                            source_id=_cid, target_id=_tgt['id'],
                            relation_type='calls_function', confidence=0.82,
                            evidence_file=_ce.get('file', ''),
                            evidence_method='cross_file_stitch',
                            evidence_line_start=_ce.get('line'),
                            evidence_snippet=_m.group(0)[:100],
                            properties={'class': _rc, 'method': _mn, 'stitch': 'bridge'},
                        )
                        _sc += 1

        # Strategy 2: import stitching
        for _root, _dirs, _fnames in os.walk(_rp):
            _dirs[:] = [d for d in _dirs if d not in
                        {'node_modules', '.git', '__pycache__', '.venv', 'venv', 'dist', 'build'}]
            for _fn in _fnames:
                if not _fn.endswith('.py'):
                    continue
                _fp = os.path.join(_root, _fn)
                _rel = os.path.relpath(_fp, _rp).replace('\\', '/')
                try:
                    _src = open(_fp, encoding='utf-8', errors='ignore').read(32768)
                except Exception:
                    continue
                _imp = set()
                for _m in re_py_imp_cls.finditer(_src):
                    for _part in _m.group(1).split(','):
                        _pn = _part.strip().split(' as ')[0].strip()
                        if _pn and _pn[0].isupper() and _pn in cls_ent_map:
                            _imp.add(_pn)
                if not _imp:
                    continue
                _fents = sorted([_e for _e in _rents if _e.get('file') == _rel],
                                key=lambda x: x.get('line') or 0)
                if not _fents:
                    continue
                for _cn in _imp:
                    for _m in re_inst_call.finditer(_src):
                        _mn = _m.group(2)
                        if _mn.startswith('_'):
                            continue
                        _tgt = _res_meth(_cn, _mn)
                        if not _tgt:
                            continue
                        _cl = _src[:_m.start()].count('\n') + 1
                        _enc = None
                        for _fe in reversed(_fents):
                            if ((_fe.get('line') or 0) <= _cl and
                                    _fe.get('type') in ('function', 'service', 'endpoint', 'controller')):
                                _enc = _fe
                                break
                        _sid = _enc['id'] if _enc else _fents[0]['id']
                        if _sid != _tgt['id']:
                            emitter.emit_relation(
                                source_id=_sid, target_id=_tgt['id'],
                                relation_type='calls_function', confidence=0.80,
                                evidence_file=_rel,
                                evidence_method='cross_file_stitch',
                                evidence_line_start=_cl,
                                evidence_snippet=_m.group(0)[:100],
                                properties={'class': _cn, 'method': _mn, 'stitch': 'import'},
                            )
                            _sc += 1

    print(f'[StructuralRelations] Cross-file stitching: {_sc} new relations')

    # ── SQL string extraction — inline SQL in Python/JS/TS files ──────────────
    # Extracts table names from SELECT/INSERT/UPDATE/DELETE strings in any file.
    _sql_count = _extract_sql_strings(manifest, entities, entities_by_repo, emitter)
    print(f'[StructuralRelations] SQL string extraction: {_sql_count} new relations')

    # ── Extended config pattern tracing ─────────────────────────────────────────────
    # Covers Flask app.config['KEY'], Django settings.KEY, configparser patterns.
    _cfg_count = _trace_extended_config(manifest, entities, entities_by_repo, config_entities, emitter)
    print(f'[StructuralRelations] Extended config tracing: {_cfg_count} new relations')

    # ── Symbol-index enhanced cross-file stitching ───────────────────────────
    # Uses symbol_index to resolve obj.method() -> ClassName.method() with
    # higher confidence than the bridge/import strategies above.
    _sym_count = _stitch_via_symbol_index(
        manifest, entities, entities_by_repo, symbol_index, emitter
    )
    print(f'[StructuralRelations] Symbol-index stitching: {_sym_count} new relations')

    emitter.flush(
        str(output / "entities.jsonl"),  # won't add entities (emitter has none)
        relations_path,
    )

    return emitter.stats()


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


# ── Pass 0: Endpoint path normalizer ─────────────────────────────────────────

_RE_FLASK_ROUTE_DEC = re.compile(
    r'@(?:app|bp|blueprint|api)\s*\.\s*(?:route|get|post|put|delete|patch)\s*\(\s*[\'"]([^\'"]+)[\'"]',
)
_RE_FASTAPI_ROUTE_DEC = re.compile(
    r'@(?:app|router)\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*[\'"]([^\'"]+)[\'"]',
)
_RE_DJANGO_PATH = re.compile(
    r'path\s*\(\s*[\'"]([^\'"]+)[\'"]\s*,\s*(\w+)',
)
_RE_EXPRESS_ROUTE = re.compile(
    r'(?:app|router)\s*\.\s*(?:get|post|put|delete|patch)\s*\(\s*[\'"`]([^\'"`]+)[\'"`]',
)
_RE_SPRING_MAPPING = re.compile(
    r'@(?:Get|Post|Put|Delete|Patch|Request)Mapping\s*\(\s*(?:value\s*=\s*)?[\'"]([^\'"]+)[\'"]',
)


def _normalize_endpoint_paths(entities: list, manifest: dict, output):
    """
    For every api:endpoint entity missing http_path in properties,
    re-read its source file and extract the path from the decorator/annotation.
    Mutates entities in-place and rewrites entities.jsonl.
    """
    # Build repo_id -> root_path map
    repo_roots = {r['repo_id']: r.get('root_path', '') for r in manifest.get('repos', [])}

    changed = 0
    for e in entities:
        if e.get('layer') != 'api' or e.get('type') != 'endpoint':
            continue
        props = e.get('properties', {})
        if props.get('http_path') or props.get('endpoint_path'):
            continue  # already has path

        file_rel = e.get('file', '')
        repo_id = e.get('repo', '')
        repo_root = repo_roots.get(repo_id, '')
        if not file_rel or not repo_root:
            continue

        fpath = os.path.join(repo_root, file_rel)
        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception:
            continue

        entity_line = e.get('line', 0) or 0
        # Search near the entity's line (±10 lines)
        lines = content.splitlines()
        search_start = max(0, entity_line - 10)
        search_end = min(len(lines), entity_line + 5)
        snippet = '\n'.join(lines[search_start:search_end])

        path_found = None
        for pat in (_RE_FLASK_ROUTE_DEC, _RE_FASTAPI_ROUTE_DEC,
                    _RE_EXPRESS_ROUTE, _RE_SPRING_MAPPING):
            m = pat.search(snippet)
            if m:
                path_found = m.group(1)
                break
        if not path_found:
            # Django: path('route', view) — match by function name
            fn_name = e.get('name', '')
            for m in _RE_DJANGO_PATH.finditer(content):
                if m.group(2) == fn_name:
                    path_found = '/' + m.group(1).lstrip('/')
                    break

        if path_found:
            e.setdefault('properties', {})['http_path'] = path_found
            changed += 1

    if changed:
        entities_path = output / 'entities.jsonl'
        with open(entities_path, 'w', encoding='utf-8') as f:
            for e in entities:
                f.write(json.dumps(e, ensure_ascii=False) + '\n')
        print(f'[StructuralRelations] Endpoint normalizer: {changed} endpoints enriched with http_path')


# ── Pass 0b: Entity dedup + merge ─────────────────────────────────────────────

def _dedup_entities(entities: list, output) -> list:
    """
    Collapse entities that share the same (file, line, name) — these are
    duplicate emissions from TreeSitter + regex extractors for the same symbol.
    Keep highest-confidence version. Remap all relation source/target IDs.
    Rewrites entities.jsonl and relations.jsonl.
    """
    # Group by (file, line, name_lower)
    from collections import defaultdict
    groups = defaultdict(list)
    for e in entities:
        key = (e.get('file', ''), e.get('line') or 0, e.get('name', '').lower())
        if key[0] and key[2]:  # only group if file+name are present
            groups[key].append(e)

    id_remap = {}  # old_id -> surviving_id
    survivors = {}  # id -> entity

    for key, group in groups.items():
        if len(group) == 1:
            survivors[group[0]['id']] = group[0]
            continue
        # Pick highest confidence; prefer regex/ast over heuristic
        def _score(e):
            method_bonus = {'regex': 0.05, 'ast': 0.04, 'heuristic': 0.0}.get(
                e.get('evidence', {}).get('method', ''), 0.0)
            return e.get('confidence', 0) + method_bonus
        group.sort(key=_score, reverse=True)
        winner = group[0]
        # Never collapse entities with different types - a bff:constant and a
        # bff:service can share the same file but are distinct semantic entities.
        types_in_group = {e.get('type', '') for e in group}
        if len(types_in_group) > 1:
            for e in group:
                survivors[e['id']] = e
            continue
        # Merge properties from all duplicates into winner
        for dup in group[1:]:
            for k, v in dup.get('properties', {}).items():
                if k not in winner.get('properties', {}):
                    winner.setdefault('properties', {})[k] = v
            id_remap[dup['id']] = winner['id']
        survivors[winner['id']] = winner

    # Add entities that weren't in any group (no file or no name)
    for e in entities:
        if e['id'] not in survivors and e['id'] not in id_remap:
            survivors[e['id']] = e

    if not id_remap:
        return entities  # nothing to do

    # Rewrite entities.jsonl
    clean_entities = list(survivors.values())
    entities_path = output / 'entities.jsonl'
    with open(entities_path, 'w', encoding='utf-8') as f:
        for e in clean_entities:
            f.write(json.dumps(e, ensure_ascii=False) + '\n')

    # Rewrite relations.jsonl — remap source/target IDs
    relations_path = output / 'relations.jsonl'
    relations = _load_jsonl(relations_path)
    remapped = 0
    for r in relations:
        if r.get('source') in id_remap:
            r['source'] = id_remap[r['source']]
            remapped += 1
        if r.get('target') in id_remap:
            r['target'] = id_remap[r['target']]
            remapped += 1
    if remapped:
        with open(relations_path, 'w', encoding='utf-8') as f:
            for r in relations:
                f.write(json.dumps(r, ensure_ascii=False) + '\n')

    print(f'[StructuralRelations] Entity dedup: {len(id_remap)} duplicates merged, '
          f'{remapped} relation IDs remapped')
    return clean_entities


def _dedup_api_endpoint_variants(entities: list, output) -> list:
    """
    Collapse API endpoint duplicates where the same controller method is extracted
    both as a method-name entity (e.g. MonitoringController.getMonitoringJobs)
    and as an HTTP-path entity (e.g. POST:/getMonitoringJobs).

    These share the same file (and usually same line) but have different names.
    The HTTP-path version is preferred (higher confidence, matches BFF calls_api).

    Generalizes to any Java framework that produces both annotation-based and
    method-based entities from the same source location.
    """
    from collections import defaultdict
    import re

    # Group API endpoints by (repo, file)
    file_groups = defaultdict(list)
    non_api_endpoints = []
    for e in entities:
        if e.get('layer') == 'api' and e.get('type') == 'endpoint':
            key = (e.get('repo', ''), e.get('file', ''))
            if key[1]:  # has file
                file_groups[key].append(e)
            else:
                non_api_endpoints.append(e)
        else:
            non_api_endpoints.append(e)

    id_remap = {}
    survivors = []

    for (repo, file), group in file_groups.items():
        if len(group) < 2:
            survivors.extend(group)
            continue

        # Separate into path-style (starts with / or has HTTP method) and method-style
        path_entities = []
        method_entities = []
        for e in group:
            qual = e.get('qualifier', '') or e.get('name', '') or e['id'].split(':')[-1]
            if qual.startswith('/') or qual.startswith('{') or re.match(r'^(GET|POST|PUT|DELETE|PATCH):', qual):
                path_entities.append(e)
            elif '.' in qual and qual[0].isupper():  # ClassName.methodName pattern
                method_entities.append(e)
            else:
                path_entities.append(e)  # default: keep as-is

        if not method_entities:
            survivors.extend(group)
            continue

        # For each method entity, check if a path entity from the same line exists
        # or if the method name appears in a path entity's qualifier
        used_methods = set()
        for me in method_entities:
            me_line = me.get('line') or 0
            me_name = (me.get('qualifier', '') or me.get('name', '') or '').split('.')[-1].lower()
            if not me_name:
                survivors.append(me)
                continue

            matched = False
            for pe in path_entities:
                pe_line = pe.get('line') or 0
                pe_qual = (pe.get('qualifier', '') or pe.get('name', '') or '').lower()
                # Match if same line, or method name appears in the path
                same_line = me_line and pe_line and abs(me_line - pe_line) <= 3
                name_in_path = me_name in pe_qual
                if same_line or name_in_path:
                    # Merge: path entity wins, absorb method entity's properties
                    for k, v in me.get('properties', {}).items():
                        if k not in pe.get('properties', {}):
                            pe.setdefault('properties', {})[k] = v
                    id_remap[me['id']] = pe['id']
                    matched = True
                    used_methods.add(me['id'])
                    break

            if not matched:
                survivors.append(me)

        survivors.extend(path_entities)

    if not id_remap:
        return entities

    # Rebuild entity list: non-api + survivors (no duplicates)
    seen = set()
    clean = []
    for e in non_api_endpoints + survivors:
        if e['id'] not in seen and e['id'] not in id_remap:
            seen.add(e['id'])
            clean.append(e)

    # Rewrite files
    entities_path = output / 'entities.jsonl'
    with open(entities_path, 'w', encoding='utf-8') as f:
        for e in clean:
            f.write(json.dumps(e, ensure_ascii=False) + '\n')

    relations_path = output / 'relations.jsonl'
    relations = _load_jsonl(relations_path)
    remapped = 0
    for r in relations:
        if r.get('source') in id_remap:
            r['source'] = id_remap[r['source']]
            remapped += 1
        if r.get('target') in id_remap:
            r['target'] = id_remap[r['target']]
            remapped += 1
    if remapped:
        with open(relations_path, 'w', encoding='utf-8') as f:
            for r in relations:
                f.write(json.dumps(r, ensure_ascii=False) + '\n')

    print(f'[StructuralRelations] API endpoint dedup: {len(id_remap)} method-variants merged into path-variants, '
          f'{remapped} relation IDs remapped')
    return clean


# ── SQL string extraction ─────────────────────────────────────────────────────

_RE_SQL_TABLE = re.compile(
    r'\b(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+[`"\']?(\w+)[`"\']?\s*(?:\.\s*[`"\']?(\w+)[`"\']?)?',
    re.IGNORECASE,
)
_RE_SQL_STRING_PY = re.compile(
    r'(?:execute|query|run_query)\s*\(\s*(?:f?[\'\"]{1,3})(.*?)(?:[\'\"]{1,3})',
    re.DOTALL | re.IGNORECASE,
)
_RE_SQL_STRING_JS = re.compile(
    r'(?:query|execute|run)\s*\(\s*(?:[`\'"])(.*?)(?:[`\'"])',
    re.DOTALL | re.IGNORECASE,
)
_SQL_SKIP_WORDS = {
    'select', 'where', 'and', 'or', 'not', 'null', 'true', 'false',
    'int', 'varchar', 'text', 'date', 'timestamp', 'boolean',
    'self', 'none', 'undefined', 'values', 'set',
}


def _extract_sql_strings(manifest: dict, entities: list, entities_by_repo: dict,
                         emitter) -> int:
    """
    Scan Python/JS/TS files for inline SQL strings and extract table references.
    Emits uses_table relations from the enclosing function entity to db:table entities.
    """
    count = 0
    # Build function entity index: (repo, file, line_range) -> entity_id
    fn_ents = [e for e in entities
               if e.get('type') in ('function', 'service', 'endpoint', 'controller', 'repository')]
    fn_by_file = defaultdict(list)
    for e in fn_ents:
        fn_by_file[(e.get('repo', ''), e.get('file', ''))].append(e)

    # Build existing db:table index to avoid duplicates
    db_tables = {}
    for e in entities:
        if e.get('layer') == 'db' and e.get('type') == 'table':
            db_tables[e.get('name', '').lower()] = e['id']

    for repo_meta in manifest.get('repos', []):
        repo_id = repo_meta['repo_id']
        repo_path = repo_meta.get('root_path') or ''
        if not repo_path:
            continue

        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in
                       {'node_modules', '.git', '__pycache__', '.venv', 'venv',
                        'dist', 'build', 'out', 'target', '.next'}]
            for fname in filenames:
                ext = Path(fname).suffix.lower()
                if ext not in ('.py', '.js', '.ts', '.jsx', '.tsx'):
                    continue
                fpath = os.path.join(root, fname)
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read(65536)
                except Exception:
                    continue

                pat = _RE_SQL_STRING_PY if ext == '.py' else _RE_SQL_STRING_JS
                file_fns = sorted(fn_by_file.get((repo_id, rel), []),
                                  key=lambda x: x.get('line') or 0)

                for m in pat.finditer(content):
                    sql_body = m.group(1)
                    if len(sql_body) < 10 or '\n' in sql_body[:5]:
                        continue
                    call_line = content[:m.start()].count('\n') + 1

                    # Find enclosing function entity
                    enc = None
                    for fe in reversed(file_fns):
                        if (fe.get('line') or 0) <= call_line:
                            enc = fe
                            break
                    if not enc:
                        continue

                    # Extract table names from SQL
                    for tm in _RE_SQL_TABLE.finditer(sql_body):
                        schema = tm.group(1)
                        table = tm.group(2)
                        if table:
                            full_name = f'{schema}.{table}'
                        else:
                            full_name = schema
                        if full_name.lower() in _SQL_SKIP_WORDS:
                            continue

                        # Get or create db:table entity
                        tbl_id = db_tables.get(full_name.lower())
                        if not tbl_id:
                            try:
                                tbl_id = emitter.emit_entity(
                                    layer='db', entity_type='table', repo=repo_id,
                                    qualifier=full_name, name=full_name,
                                    file=rel, line=call_line, confidence=0.75,
                                    evidence_file=rel, evidence_method='regex',
                                    evidence_line_start=call_line,
                                    evidence_snippet=sql_body[:100],
                                    properties={'db_type': 'sql', 'source': 'inline_sql'},
                                )
                                db_tables[full_name.lower()] = tbl_id
                            except Exception:
                                continue

                        try:
                            emitter.emit_relation(
                                source_id=enc['id'], target_id=tbl_id,
                                relation_type='uses_table', confidence=0.75,
                                evidence_file=rel, evidence_method='regex',
                                evidence_line_start=call_line,
                                evidence_snippet=sql_body[:100],
                                properties={'source': 'inline_sql'},
                            )
                            count += 1
                        except Exception:
                            pass
    return count


# ── Extended config pattern tracing ──────────────────────────────────────────

_RE_FLASK_CONFIG = re.compile(
    r'app\.config\s*\[\s*[\'"]([A-Z_][A-Z0-9_]*)[\'"]'
)
_RE_DJANGO_SETTINGS = re.compile(
    r'settings\.([A-Z_][A-Z0-9_]*)\b'
)
_RE_CONFIGPARSER = re.compile(
    r'config(?:uration)?\s*\.\s*get\s*\(\s*[\'"][^\'"]+[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]'
)
_RE_PY_GETENV_DEFAULT = re.compile(
    r'os\.getenv\s*\(\s*[\'"]([A-Z_][A-Z0-9_]*)[\'"]'
)


def _trace_extended_config(manifest: dict, entities: list, entities_by_repo: dict,
                            config_entities: dict, emitter) -> int:
    """
    Trace Flask app.config['KEY'], Django settings.KEY, configparser, and
    os.getenv('KEY', default) patterns to config entities.
    """
    count = 0
    for repo_meta in manifest.get('repos', []):
        repo_id = repo_meta['repo_id']
        repo_path = repo_meta.get('root_path') or ''
        if not repo_path:
            continue

        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in
                       {'node_modules', '.git', '__pycache__', '.venv', 'venv',
                        'dist', 'build', 'out', 'target', '.next'}]
            for fname in filenames:
                if not fname.endswith('.py'):
                    continue
                fpath = os.path.join(root, fname)
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read(32768)
                except Exception:
                    continue

                file_ents = [e for e in entities_by_repo.get(repo_id, [])
                             if e.get('file') == rel]
                if not file_ents:
                    continue
                src_id = file_ents[0]['id']

                for pat, label in [
                    (_RE_FLASK_CONFIG, 'flask_config'),
                    (_RE_DJANGO_SETTINGS, 'django_settings'),
                    (_RE_PY_GETENV_DEFAULT, 'os_getenv'),
                ]:
                    for m in pat.finditer(content):
                        key = m.group(1)
                        cfg_id = config_entities.get(key)
                        if cfg_id:
                            try:
                                emitter.emit_relation(
                                    source_id=src_id, target_id=cfg_id,
                                    relation_type='depends_on_config', confidence=0.82,
                                    evidence_file=rel, evidence_method='regex',
                                    evidence_line_start=content[:m.start()].count('\n') + 1,
                                    evidence_snippet=m.group(0)[:200],
                                    properties={'config_name': key, 'pattern': label},
                                )
                                count += 1
                            except Exception:
                                pass
    return count


# ── Symbol-index enhanced cross-file stitching ───────────────────────────────

_RE_OBJ_CALL = re.compile(r'\b(\w+)\s*\.\s*(\w+)\s*\(', re.MULTILINE)


# Language-specific skip words for symbol-index stitching
_SYMBOL_STITCH_SKIP_OBJS = {
    '.py':   {'self', 'cls', 'super'},
    '.java': {'this', 'super', 'System', 'Math', 'String', 'Integer', 'Long',
              'Double', 'Boolean', 'Arrays', 'Collections', 'Objects', 'Optional'},
    '.ts':   {'this', 'super', 'console', 'Math', 'JSON', 'Object', 'Array',
              'Promise', 'Date', 'window', 'document'},
    '.tsx':  {'this', 'super', 'console', 'Math', 'JSON', 'Object', 'Array',
              'Promise', 'Date', 'window', 'document', 'React'},
    '.js':   {'this', 'super', 'console', 'Math', 'JSON', 'Object', 'Array',
              'Promise', 'Date', 'window', 'document'},
    '.jsx':  {'this', 'super', 'console', 'Math', 'JSON', 'Object', 'Array',
              'Promise', 'Date', 'window', 'document', 'React'},
}
_SYMBOL_STITCH_EXTS = {'.py', '.java', '.ts', '.tsx', '.js', '.jsx'}


def _stitch_via_symbol_index(manifest: dict, entities: list, entities_by_repo: dict,
                              symbol_index: dict, emitter) -> int:
    """
    For each Python/Java/TS/JS file, use the symbol index to resolve
    obj.method() calls to their concrete ClassName.method entity.
    Emits calls_function relations with higher confidence than the
    bridge/import strategies.
    """
    if not symbol_index:
        return 0

    count = 0
    # Build method entity lookup: "ClassName.method" -> entity_id
    method_entity = {}
    for e in entities:
        name = e.get('name', '')
        if '.' in name and e.get('type') in ('function', 'service', 'endpoint',
                                              'controller', 'repository'):
            method_entity[name.lower()] = e['id']

    # Build function entity index per file for enclosing-function lookup
    fn_by_file = defaultdict(list)
    for e in entities:
        if e.get('type') in ('function', 'service', 'endpoint', 'controller',
                             'repository'):
            fn_by_file[(e.get('repo', ''), e.get('file', ''))].append(e)

    for repo_meta in manifest.get('repos', []):
        repo_id = repo_meta['repo_id']
        repo_path = repo_meta.get('root_path') or ''
        if not repo_path:
            continue
        repo_syms = symbol_index.get(repo_path, symbol_index.get(str(Path(repo_path)), {}))
        if not repo_syms:
            continue

        var_types = repo_syms.get('var_types', {})
        import_aliases = repo_syms.get('import_aliases', {})
        class_fields = repo_syms.get('class_fields', {})
        if not var_types and not import_aliases and not class_fields:
            continue

        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in
                       {'node_modules', '.git', '__pycache__', '.venv', 'venv',
                        'dist', 'build', 'out', 'target', '.next', '.gradle'}]
            for fname in filenames:
                ext = Path(fname).suffix.lower()
                if ext not in _SYMBOL_STITCH_EXTS:
                    continue
                fpath = os.path.join(root, fname)
                rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                try:
                    with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read(65536)
                except Exception:
                    continue

                skip_objs = _SYMBOL_STITCH_SKIP_OBJS.get(ext, set())
                file_fns = sorted(fn_by_file.get((repo_id, rel), []),
                                  key=lambda x: x.get('line') or 0)

                seen_pairs = set()
                for m in _RE_OBJ_CALL.finditer(content):
                    obj_name, meth_name = m.group(1), m.group(2)
                    if meth_name.startswith('_') or obj_name in skip_objs:
                        continue

                    # Resolve obj_name to a class via:
                    # 1. Direct var_types (var = ClassName(...))
                    # 2. Import aliases (import X from ...)
                    # 3. Class fields (this.field: Type — for Java/TS
                    #    where 'this' is skipped but field name is the obj)
                    cls_name = (var_types.get(obj_name) or
                                import_aliases.get(obj_name) or '')
                    if not cls_name:
                        # Try class_fields: "SomeClass.obj_name" -> Type
                        for cf_key, cf_type in class_fields.items():
                            if cf_key.endswith(f'.{obj_name}'):
                                cls_name = cf_type
                                break
                    if not cls_name:
                        continue

                    target_key = f'{cls_name}.{meth_name}'.lower()
                    tgt_id = method_entity.get(target_key)
                    if not tgt_id:
                        continue

                    call_line = content[:m.start()].count('\n') + 1
                    # Find enclosing function
                    enc = None
                    for fe in reversed(file_fns):
                        if (fe.get('line') or 0) <= call_line:
                            enc = fe
                            break
                    src_id = enc['id'] if enc else None
                    if not src_id or src_id == tgt_id:
                        continue

                    pair = (src_id, tgt_id)
                    if pair in seen_pairs:
                        continue
                    seen_pairs.add(pair)

                    try:
                        emitter.emit_relation(
                            source_id=src_id, target_id=tgt_id,
                            relation_type='calls_function', confidence=0.88,
                            evidence_file=rel, evidence_method='symbol_index',
                            evidence_line_start=call_line,
                            evidence_snippet=m.group(0)[:100],
                            properties={
                                'obj': obj_name, 'class': cls_name,
                                'method': meth_name, 'stitch': 'symbol_index',
                                'language': ext.lstrip('.'),
                            },
                        )
                        count += 1
                    except Exception:
                        pass
    return count
