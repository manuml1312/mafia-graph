"""
MAFIA Phase 3 — Skeleton Extractors
=====================================
Minimal extractors for each layer to validate the framework end-to-end.
Phase 4 will replace these with full extraction logic.
These detect only the most obvious patterns to prove the pipeline works.
"""

import re
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult


# ── BFF Skeleton ─────────────────────────────────────────────────────────────

class BffSkeletonExtractor(BaseExtractor):
    name = "bff_skeleton"
    supported_extensions = {'.ts', '.js'}

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0

        # Detect static constant endpoint definitions
        for m in re.finditer(r'static\s+(?:readonly\s+)?(\w+)\s*=\s*["\'](/[^"\']+)["\']', content):
            var_name, path_val = m.group(1), m.group(2)
            line = content[:m.start()].count('\n') + 1

            if '_bff' in var_name.lower():
                self.emitter.emit_entity(
                    layer="bff", entity_type="endpoint", repo=repo_id,
                    qualifier=path_val, name=path_val,
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                    properties={"variable_name": var_name, "endpoint_path": path_val},
                )
                entities += 1
            elif '_api' in var_name.lower() or '_API' in var_name:
                self.emitter.emit_entity(
                    layer="bff", entity_type="constant", repo=repo_id,
                    qualifier=f"{rel_path}::{var_name}", name=var_name,
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                    properties={"variable_name": var_name, "endpoint_path": path_val, "type": "api_ref"},
                )
                entities += 1

        # Detect route registrations: router.get(Constant.xxx, controller.yyy)
        for m in re.finditer(r'router\.(get|post|put|delete|patch)\s*\(\s*\w+\.(\w+)\s*,\s*\w+\.(\w+)', content, re.IGNORECASE):
            http_method, const_ref, handler = m.group(1).upper(), m.group(2), m.group(3)
            line = content[:m.start()].count('\n') + 1
            self.emitter.emit_entity(
                layer="bff", entity_type="controller", repo=repo_id,
                qualifier=f"{rel_path}::{handler}", name=handler,
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                properties={"http_method": http_method, "constant_ref": const_ref},
            )
            entities += 1
            relations += 1  # routes_to relation will be built in Phase 5

        # Detect middleware exports
        for m in re.finditer(r'export\s+(?:async\s+)?function\s+(\w+)\s*\(', content):
            func_name = m.group(1)
            if 'validate' in func_name.lower() or 'middleware' in func_name.lower() or 'auth' in func_name.lower():
                line = content[:m.start()].count('\n') + 1
                self.emitter.emit_entity(
                    layer="bff", entity_type="middleware", repo=repo_id,
                    qualifier=f"{rel_path}::{func_name}", name=func_name,
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                )
                entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)


# ── API Skeleton ─────────────────────────────────────────────────────────────

class ApiSkeletonExtractor(BaseExtractor):
    name = "api_skeleton"
    supported_extensions = {'.java'}

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0
        relations = 0

        # Class-level @RequestMapping base path
        class_mapping = ""
        cm = re.search(r'@RequestMapping\s*\(\s*["\']([^"\']+)["\']', content)
        if cm:
            class_mapping = cm.group(1)

        # Detect @XxxMapping endpoints
        for m in re.finditer(r'@(Get|Post|Put|Delete|Patch)Mapping\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', content):
            http_method = m.group(1).upper()
            path = m.group(2)
            full_path = class_mapping + path if class_mapping else path
            line = content[:m.start()].count('\n') + 1

            # Find handler method name
            after = content[m.end():m.end()+300]
            method_m = re.search(r'public\s+\w+(?:<[^>]+>)?\s+(\w+)\s*\(', after)
            handler = method_m.group(1) if method_m else "unknown"

            self.emitter.emit_entity(
                layer="api", entity_type="endpoint", repo=repo_id,
                qualifier=f"{http_method}:{full_path}", name=f"{http_method} {full_path}",
                file=rel_path, line=line, confidence=0.95,
                evidence_file=rel_path, evidence_method="regex",
                evidence_line_start=line, evidence_snippet=m.group(0)[:200],
                properties={"http_method": http_method, "endpoint_path": full_path, "handler_method": handler},
            )
            entities += 1

        # Detect @Entity + @Table
        if '@Entity' in content:
            table_m = re.search(r'@Table\s*\([^)]*name\s*=\s*"([^"]+)"', content)
            schema_m = re.search(r'@Table\s*\([^)]*schema\s*=\s*"([^"]+)"', content)
            class_m = re.search(r'public\s+class\s+(\w+)', content)
            if table_m and class_m:
                table = table_m.group(1)
                schema = schema_m.group(1) if schema_m else "dre"
                full_table = f"{schema}.{table}"
                line = content[:table_m.start()].count('\n') + 1

                self.emitter.emit_entity(
                    layer="api", entity_type="entity", repo=repo_id,
                    qualifier=f"{Path(rel_path).name}::{class_m.group(1)}", name=class_m.group(1),
                    file=rel_path, line=line, confidence=0.95,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=table_m.group(0)[:200],
                    properties={"table": full_table, "schema": schema},
                )
                entities += 1

                # Also emit the DB table entity
                self.emitter.emit_entity(
                    layer="db", entity_type="table", repo=repo_id,
                    qualifier=full_table, name=full_table,
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="inferred",
                    evidence_line_start=line, evidence_snippet=f"@Table(name=\"{table}\", schema=\"{schema}\")",
                    properties={"schema": schema, "table_name": table, "db_type": "postgres"},
                    warnings=["Table inferred from @Entity — no SQL source"],
                )
                entities += 1

        # Detect @Query -> pg function
        for m in re.finditer(r'@Query\s*\(\s*(?:value\s*=\s*)?["\']([^"\']+)["\']', content, re.DOTALL):
            query_text = m.group(1)
            fn_m = re.search(r'\bfrom\s+(?:\w+\.)?(\w+)\s*\(', query_text, re.IGNORECASE)
            if fn_m:
                fn_name = fn_m.group(1)
                line = content[:m.start()].count('\n') + 1
                self.emitter.emit_entity(
                    layer="db", entity_type="function", repo=repo_id,
                    qualifier=f"pg:{fn_name}", name=fn_name,
                    file=rel_path, line=line, confidence=0.85,
                    evidence_file=rel_path, evidence_method="regex",
                    evidence_line_start=line, evidence_snippet=query_text[:200],
                    properties={"db_type": "postgres", "source": "inferred_from_query"},
                    warnings=["DB function inferred from @Query"],
                )
                entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status,
                          entities_emitted=entities, relations_emitted=relations)


# ── Config Skeleton (runs on all repos) ──────────────────────────────────────

class ConfigSkeletonExtractor(BaseExtractor):
    name = "config_skeleton"
    supported_extensions = {'.env', '.properties', '.yml', '.yaml'}

    def discover_files(self, repo_path):
        """Override: also pick up dotfiles like .env.local that have no extension."""
        files = super().discover_files(repo_path)
        # Add .env* files
        for root, dirs, filenames in __import__('os').walk(repo_path):
            dirs[:] = [d for d in dirs if d not in self.__class__.__mro__[1].discover_files.__code__.co_varnames]
            for fname in filenames:
                if fname.startswith('.env'):
                    fpath = __import__('os').path.join(root, fname)
                    if fpath not in files:
                        files.append(fpath)
        return files

    def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
        entities = 0

        # Detect KEY=VALUE patterns in .env files
        if '.env' in Path(rel_path).name:
            for line_num, line_text in enumerate(content.splitlines(), 1):
                line_text = line_text.strip()
                if not line_text or line_text.startswith('#'):
                    continue
                m = re.match(r'^([A-Z_][A-Z0-9_]*)\s*=\s*(.*)$', line_text)
                if m:
                    key, value = m.group(1), m.group(2).strip().strip('"').strip("'")
                    self.emitter.emit_entity(
                        layer="config", entity_type="env", repo=repo_id,
                        qualifier=key, name=key,
                        file=rel_path, line=line_num, confidence=0.95,
                        evidence_file=rel_path, evidence_method="regex",
                        evidence_line_start=line_num, evidence_snippet=line_text[:200],
                        properties={"value": value if 'secret' not in key.lower() and 'key' not in key.lower() and 'password' not in key.lower() else "<redacted>"},
                    )
                    entities += 1

        status = "ok" if entities > 0 else "no_entities"
        return FileResult(file_path=rel_path, status=status, entities_emitted=entities)
