"""
MAFIA Cross-Scope Stitching
============================
Base class for stitchers + pipeline runner.
Each stitcher reads entities/relations/manifest and emits new relations.
Runner appends them to relations.jsonl idempotently (deduped by relation id).
"""

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional


class Stitcher(ABC):
    name: str = "base"

    @abstractmethod
    def run(self, entities: list[dict], relations: list[dict],
            manifest: Optional[dict] = None) -> list[dict]:
        """Return list of new relation dicts to append."""
        ...


def _load_jsonl(path: Path) -> list[dict]:
    items = []
    if not path.exists():
        return items
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line:
            items.append(json.loads(line))
    return items


def _load_json(path: Path) -> Optional[dict]:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def run_all_stitchers(output_dir: str, stitchers: Optional[list[Stitcher]] = None):
    """Load artifacts, run each stitcher, append new relations (idempotent)."""
    out = Path(output_dir)
    entities = _load_jsonl(out / "entities.jsonl")
    relations = _load_jsonl(out / "relations.jsonl")
    manifest = _load_json(out / "workspace_manifest.json")

    existing_ids = {r.get("id") for r in relations}

    if stitchers is None:
        stitchers = _default_stitchers()

    total_new = 0
    for stitcher in stitchers:
        try:
            new_rels = stitcher.run(entities, relations, manifest)
        except Exception as e:
            print(f"  [WARN] Stitcher {stitcher.name} failed: {e}")
            continue

        # Dedupe: only append relations with new IDs
        truly_new = [r for r in new_rels if r.get("id") not in existing_ids]
        for r in truly_new:
            existing_ids.add(r.get("id"))
            relations.append(r)
        total_new += len(truly_new)

        if truly_new:
            print(f"  [{stitcher.name}] +{len(truly_new)} relations")

    # Append new relations to file
    if total_new > 0:
        rel_path = out / "relations.jsonl"
        with open(rel_path, "a", encoding="utf-8") as f:
            for r in relations[-total_new:]:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"  Cross-scope stitching: {total_new} new relations total")
    return {"new_relations": total_new}


def _default_stitchers() -> list[Stitcher]:
    from phase3_extraction_framework.cross_scope.workspace_dep_stitcher import WorkspaceDepStitcher
    from phase3_extraction_framework.cross_scope.cross_workspace_imports import CrossWorkspaceImportStitcher
    from phase3_extraction_framework.cross_scope.shared_lib_stitcher import SharedLibStitcher
    from phase3_extraction_framework.cross_scope.shared_table_stitcher import SharedTableStitcher
    from phase3_extraction_framework.cross_scope.shared_env_stitcher import SharedEnvStitcher
    from phase3_extraction_framework.cross_scope.artifact_stitcher import ArtifactStitcher
    return [
        WorkspaceDepStitcher(),
        CrossWorkspaceImportStitcher(),
        SharedLibStitcher(),
        SharedTableStitcher(),
        SharedEnvStitcher(),
        ArtifactStitcher(),
    ]
