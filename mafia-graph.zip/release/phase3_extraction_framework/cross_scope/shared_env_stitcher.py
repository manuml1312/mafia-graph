"""Shared env stitcher — env vars in 2+ workspaces → shares_env_with."""

from collections import defaultdict
from phase3_extraction_framework.cross_scope import Stitcher
from schemas.id_format import make_relation_id


class SharedEnvStitcher(Stitcher):
    name = "shared_env"

    def run(self, entities, relations, manifest=None) -> list[dict]:
        # Group config:env entities by name across scopes
        env_scopes = defaultdict(set)  # env_name → set of scope_paths

        for e in entities:
            if e.get("layer") == "config" and e.get("type") == "env":
                name = e.get("name", "")
                scope = e.get("scope_path", e.get("repo", ""))
                if name and scope:
                    env_scopes[name].add(scope)

        new_rels = []
        for env_name, scopes in env_scopes.items():
            if len(scopes) < 2:
                continue
            scope_list = sorted(scopes)
            for i in range(len(scope_list)):
                for j in range(i + 1, len(scope_list)):
                    rel_id = make_relation_id(
                        f"workspace:{scope_list[i]}",
                        "shares_env_with",
                        f"workspace:{scope_list[j]}",
                    )
                    new_rels.append({
                        "id": rel_id,
                        "source": f"workspace:{scope_list[i]}",
                        "target": f"workspace:{scope_list[j]}",
                        "type": "shares_env_with",
                        "confidence": 0.80,
                        "cross_scope": True,
                        "boundary": "workspace",
                        "evidence": {
                            "file": "entities.jsonl",
                            "extractor": "shared_env_stitcher",
                            "method": "env_aggregation",
                        },
                        "properties": {"env_name": env_name},
                    })

        return new_rels
