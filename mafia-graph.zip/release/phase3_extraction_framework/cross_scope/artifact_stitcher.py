"""Artifact stitcher — Dockerfile FROM / internal deps → consumes_artifact."""

from phase3_extraction_framework.cross_scope import Stitcher
from schemas.id_format import make_relation_id


class ArtifactStitcher(Stitcher):
    name = "artifact"

    def run(self, entities, relations, manifest=None) -> list[dict]:
        if not manifest:
            return []

        # Build workspace package_name index
        pkg_to_ws = {}
        for repo in manifest.get("repos", []):
            for ws in repo.get("workspaces", []):
                pkg = ws.get("package_name", "")
                ws_id = ws.get("id", "")
                if pkg:
                    pkg_to_ws[pkg] = ws_id

        # Look for infra:dockerfile entities referencing internal images
        new_rels = []
        for e in entities:
            if e.get("type") == "dockerfile" or (
                e.get("properties", {}).get("from_image", "")
            ):
                from_image = e.get("properties", {}).get("from_image", "")
                source_scope = e.get("scope_path", e.get("repo", ""))
                for pkg_name, ws_id in pkg_to_ws.items():
                    if pkg_name in from_image and source_scope != ws_id:
                        rel_id = make_relation_id(
                            f"workspace:{source_scope}",
                            "consumes_artifact",
                            f"workspace:{ws_id}",
                        )
                        new_rels.append({
                            "id": rel_id,
                            "source": f"workspace:{source_scope}",
                            "target": f"workspace:{ws_id}",
                            "type": "consumes_artifact",
                            "confidence": 0.75,
                            "cross_scope": True,
                            "boundary": "workspace",
                            "evidence": {
                                "file": e.get("file", ""),
                                "extractor": "artifact_stitcher",
                                "method": "dockerfile_from",
                            },
                            "properties": {"from_image": from_image},
                        })

        return new_rels
