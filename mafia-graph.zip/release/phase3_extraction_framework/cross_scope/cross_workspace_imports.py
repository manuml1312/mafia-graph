"""Cross-workspace import resolver — resolves _unresolved imports across boundaries."""

from phase3_extraction_framework.cross_scope import Stitcher
from schemas.id_format import make_relation_id


class CrossWorkspaceImportStitcher(Stitcher):
    name = "cross_workspace_imports"

    def run(self, entities, relations, manifest=None) -> list[dict]:
        # Build module entity index: package_name/module_name → entity_id
        module_index = {}  # import_spec → entity_id
        scope_of = {}  # entity_id → scope_path

        for e in entities:
            if e.get("type") != "module":
                continue
            eid = e.get("id", "")
            scope = e.get("scope_path", e.get("repo", ""))
            scope_of[eid] = scope

            # Index by qualifier (relative path)
            parts = eid.split(":", 3)
            if len(parts) >= 4:
                qualifier = parts[3]
                # Strip extension for matching
                base = qualifier.rsplit(".", 1)[0] if "." in qualifier else qualifier
                module_index[base] = eid
                module_index[qualifier] = eid

        # Also index by package_name from manifest
        pkg_to_scope = {}
        if manifest:
            for repo in manifest.get("repos", []):
                for ws in repo.get("workspaces", []):
                    pkg = ws.get("package_name", "")
                    ws_id = ws.get("id", "")
                    if pkg:
                        pkg_to_scope[pkg] = ws_id

        new_rels = []
        for rel in relations:
            if rel.get("type") != "imports":
                continue
            target = rel.get("target", "")
            if "_unresolved:" not in target:
                continue

            spec = target.split("_unresolved:")[-1]
            source_id = rel.get("source", "")
            source_scope = scope_of.get(source_id, _extract_scope(source_id))

            # Try to resolve
            resolved_id = module_index.get(spec)
            if not resolved_id:
                # Try partial match: last segment
                last = spec.rsplit("/", 1)[-1].rsplit(".", 1)[-1]
                for key, eid in module_index.items():
                    if key.endswith(last):
                        resolved_id = eid
                        break

            if not resolved_id:
                continue

            target_scope = scope_of.get(resolved_id, _extract_scope(resolved_id))
            if not source_scope or not target_scope:
                continue
            if source_scope == target_scope:
                continue  # same workspace, not cross-scope

            # Determine boundary
            src_parts = source_scope.split("/")
            tgt_parts = target_scope.split("/")
            if len(src_parts) >= 2 and len(tgt_parts) >= 2 and src_parts[0] != tgt_parts[0]:
                rel_type = "cross_repo_import"
                boundary = "repo"
            else:
                rel_type = "cross_workspace_import"
                boundary = "workspace"

            rel_id = make_relation_id(source_id, rel_type, resolved_id)
            new_rels.append({
                "id": rel_id,
                "source": source_id,
                "target": resolved_id,
                "type": rel_type,
                "confidence": 0.80,
                "cross_scope": True,
                "boundary": boundary,
                "evidence": {
                    "file": rel.get("evidence", {}).get("file", ""),
                    "extractor": "cross_workspace_imports",
                    "method": "import_resolution",
                },
                "properties": {"original_spec": spec},
            })

        return new_rels


def _extract_scope(entity_id: str) -> str:
    parts = entity_id.split(":", 3)
    return parts[2] if len(parts) >= 3 else ""
