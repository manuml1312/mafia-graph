"""Shared table stitcher — tables referenced by 2+ workspaces → shares_table_with."""

from collections import defaultdict
from phase3_extraction_framework.cross_scope import Stitcher
from schemas.id_format import make_relation_id


class SharedTableStitcher(Stitcher):
    name = "shared_table"

    def run(self, entities, relations, manifest=None) -> list[dict]:
        # Find all db:table entities
        table_entities = {}  # normalized_name → entity_id
        for e in entities:
            if e.get("layer") == "db" and e.get("type") == "table":
                eid = e.get("id", "")
                name = e.get("name", "").lower().strip()
                if name:
                    table_entities[name] = eid

        # Find which scopes reference each table via reads_from/writes_to/uses_table
        table_scopes = defaultdict(set)  # table_name → set of scope_paths
        table_rel_types = {"reads_from", "writes_to", "uses_table", "entity_maps_to"}

        for rel in relations:
            if rel.get("type") not in table_rel_types:
                continue
            target = rel.get("target", "")
            source_scope = _extract_scope(rel.get("source", ""))
            # Check if target is a table entity
            for tname, tid in table_entities.items():
                if target == tid:
                    if source_scope:
                        table_scopes[tname].add(source_scope)
                    break

        new_rels = []
        for tname, scopes in table_scopes.items():
            if len(scopes) < 2:
                continue
            scope_list = sorted(scopes)
            for i in range(len(scope_list)):
                for j in range(i + 1, len(scope_list)):
                    rel_id = make_relation_id(
                        f"workspace:{scope_list[i]}",
                        "shares_table_with",
                        f"workspace:{scope_list[j]}",
                    )
                    new_rels.append({
                        "id": rel_id,
                        "source": f"workspace:{scope_list[i]}",
                        "target": f"workspace:{scope_list[j]}",
                        "type": "shares_table_with",
                        "confidence": 0.85,
                        "cross_scope": True,
                        "boundary": "workspace",
                        "evidence": {
                            "file": "entities.jsonl",
                            "extractor": "shared_table_stitcher",
                            "method": "table_reference_aggregation",
                        },
                        "properties": {"table_name": tname},
                    })

        return new_rels


def _extract_scope(entity_id: str) -> str:
    parts = entity_id.split(":", 3)
    return parts[2] if len(parts) >= 3 else ""
