"""Shared library stitcher — libs used by 2+ workspaces → shared_lib_used_by."""

from collections import defaultdict
from phase3_extraction_framework.cross_scope import Stitcher
from schemas.id_format import make_relation_id


class SharedLibStitcher(Stitcher):
    name = "shared_lib"

    def run(self, entities, relations, manifest=None) -> list[dict]:
        # Group unresolved import specs by scope
        lib_consumers = defaultdict(set)  # lib_spec → set of scope_paths

        for rel in relations:
            if rel.get("type") != "imports":
                continue
            target = rel.get("target", "")
            if "_unresolved:" not in target:
                continue
            spec = target.split("_unresolved:")[-1]
            # Only consider external-looking imports (not relative paths)
            if spec.startswith(".") or spec.startswith("/"):
                continue
            # Get top-level package name
            top_pkg = spec.split("/")[0].split(".")[0]
            if not top_pkg:
                continue
            source_scope = _extract_scope(rel.get("source", ""))
            if source_scope:
                lib_consumers[top_pkg].add(source_scope)

        new_rels = []
        for lib_name, scopes in lib_consumers.items():
            if len(scopes) < 2:
                continue
            lib_id = f"lib:package:_:{lib_name}"
            for scope in sorted(scopes):
                rel_id = make_relation_id(lib_id, "shared_lib_used_by", f"workspace:{scope}")
                new_rels.append({
                    "id": rel_id,
                    "source": lib_id,
                    "target": f"workspace:{scope}",
                    "type": "shared_lib_used_by",
                    "confidence": 0.80,
                    "cross_scope": True,
                    "boundary": "workspace",
                    "evidence": {
                        "file": "relations.jsonl",
                        "extractor": "shared_lib_stitcher",
                        "method": "import_aggregation",
                    },
                    "properties": {"lib_name": lib_name, "consumer_count": len(scopes)},
                })

        return new_rels


def _extract_scope(entity_id: str) -> str:
    parts = entity_id.split(":", 3)
    return parts[2] if len(parts) >= 3 else ""
