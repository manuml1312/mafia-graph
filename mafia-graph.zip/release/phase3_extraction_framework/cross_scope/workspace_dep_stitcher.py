"""Workspace dependency stitcher — declared deps → workspace_depends_on edges."""

from phase3_extraction_framework.cross_scope import Stitcher
from schemas.id_format import make_relation_id
from typing import Optional


class WorkspaceDepStitcher(Stitcher):
    name = "workspace_dep"

    def run(self, entities, relations, manifest=None) -> list[dict]:
        if not manifest:
            return []

        # Build package_name → workspace_id index
        pkg_to_ws = {}
        ws_ids = {}
        for repo in manifest.get("repos", []):
            for ws in repo.get("workspaces", []):
                ws_id = ws.get("id", "")
                pkg_name = ws.get("package_name", "")
                ws_name = ws.get("name", "")
                if pkg_name:
                    pkg_to_ws[pkg_name] = ws_id
                if ws_name:
                    pkg_to_ws[ws_name] = ws_id
                ws_ids[ws_id] = ws

        new_rels = []
        for repo in manifest.get("repos", []):
            for ws in repo.get("workspaces", []):
                ws_id = ws.get("id", "")
                # Check declared_deps — not in manifest schema yet, check entities
                # For now, look at lib:package entities that match workspace names
                pass

        # Also check entity-level: find lib:package entities matching workspace package_names
        # and emit workspace_depends_on between the consuming workspace and the target
        entity_by_scope = {}
        for e in entities:
            sp = e.get("scope_path", e.get("repo", ""))
            entity_by_scope.setdefault(sp, []).append(e)

        # Simple approach: for each imports relation targeting an unresolved module,
        # check if the import spec matches a known workspace package_name
        for rel in relations:
            if rel.get("type") != "imports":
                continue
            target = rel.get("target", "")
            if "_unresolved:" not in target:
                continue
            spec = target.split("_unresolved:")[-1]
            # Check if spec starts with a known package name
            for pkg_name, target_ws_id in pkg_to_ws.items():
                if spec == pkg_name or spec.startswith(pkg_name + "/"):
                    source_scope = _extract_scope(rel.get("source", ""))
                    target_scope = target_ws_id
                    if source_scope and target_scope and source_scope != target_scope:
                        rel_id = make_relation_id(
                            f"workspace:{source_scope}",
                            "workspace_depends_on",
                            f"workspace:{target_scope}",
                        )
                        new_rels.append(_make_rel(
                            rel_id, f"workspace:{source_scope}",
                            f"workspace:{target_scope}",
                            "workspace_depends_on",
                        ))
                    break

        # Dedupe
        seen = set()
        unique = []
        for r in new_rels:
            if r["id"] not in seen:
                seen.add(r["id"])
                unique.append(r)
        return unique


def _extract_scope(entity_id: str) -> str:
    """Extract scope_path from entity ID."""
    parts = entity_id.split(":", 3)
    return parts[2] if len(parts) >= 3 else ""


def _make_rel(rel_id, source, target, rel_type, confidence=0.85):
    return {
        "id": rel_id,
        "source": source,
        "target": target,
        "type": rel_type,
        "confidence": confidence,
        "cross_scope": True,
        "boundary": "workspace",
        "evidence": {
            "file": "workspace_manifest.json",
            "extractor": "workspace_dep_stitcher",
            "method": "manifest_resolution",
        },
        "properties": {},
    }
