"""
MAFIA Phase 3 — Extractor Registry and Dispatcher
===================================================
Routes repos from repo_manifest.json to the correct extractors based on
classification. Runs all extractors in parallel across repos.

Usage:
    from phase3_extraction_framework.dispatcher import ExtractionDispatcher
    dispatcher = ExtractionDispatcher(manifest, output_dir)
    dispatcher.register("bff", BffExtractor)
    dispatcher.register("api", ApiExtractor)
    dispatcher.run(max_workers=8)
"""

import json
import threading
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Type

from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from schemas.emitter import CanonicalEmitter
from utils.file_cache import FileCache


def _load_plugin_extractors() -> dict[str, list[Type[BaseExtractor]]]:
    """Discover plugin extractors via entry points."""
    try:
        from mafia.plugins import load_plugins
        plugins = load_plugins("mafia.extractors")
        result: dict[str, list[Type[BaseExtractor]]] = {}
        for name, cls in plugins.items():
            classification = getattr(cls, 'classification', '*')
            result.setdefault(classification, []).append(cls)
        return result
    except Exception:
        return {}


class ExtractionDispatcher:
    """
    Reads repo_manifest.json, routes each repo to registered extractors
    based on classification, runs extraction, merges results, flushes artifacts.
    When GenAI is enabled, collects assist requests from extractors and resolves
    them in batch after each repo finishes.
    """

    def __init__(self, manifest_path: str, output_dir: str):
        self.manifest_path = manifest_path
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        with open(manifest_path, 'r', encoding='utf-8') as f:
            self.manifest = json.load(f)

        self._registry: dict[str, list[Type[BaseExtractor]]] = {}
        self._global_extractors: list[Type[BaseExtractor]] = []
        self._all_results: list[dict] = []
        self._lock = threading.Lock()
        self._file_cache = FileCache(output_dir)

        # GenAI integration — set via enable_genai() before run()
        self._genai_resolver = None

        # Discover plugin extractors
        for classification, ext_classes in _load_plugin_extractors().items():
            for ext_cls in ext_classes:
                self.register(classification, ext_cls)

    # ── Registration ─────────────────────────────────────────────────────────

    def register(self, classification: str, extractor_class: Type[BaseExtractor]):
        if classification == "*":
            self._global_extractors.append(extractor_class)
        else:
            self._registry.setdefault(classification, []).append(extractor_class)

    def enable_genai(self, resolver):
        """Attach a GenAI resolver. Called from run_extraction when --enable-genai."""
        self._genai_resolver = resolver

    # ── Dispatch logic ───────────────────────────────────────────────────────

    def _get_extractors_for_repo(self, repo_meta: dict) -> list[Type[BaseExtractor]]:
        """Determine which extractors to run on a repo.
        Global extractors (*) always run. Classification-specific extractors
        run for their registered layer AND for any repo that might contain
        that layer's code (e.g. a Flask app has UI templates AND API routes AND DB calls).
        Each extractor is responsible for returning no_entities on irrelevant files."""
        extractors = list(self._global_extractors)
        classifications = repo_meta.get("classification", [])

        # Always run all registered extractors — a single repo can span multiple layers
        # (e.g. Flask app = api + db + ui all in one repo)
        all_registered = set()
        for cls_extractors in self._registry.values():
            for ext_cls in cls_extractors:
                if ext_cls not in all_registered:
                    all_registered.add(ext_cls)
                    extractors.append(ext_cls)

        # Deduplicate by class identity while preserving order
        seen = set()
        unique = []
        for ext in extractors:
            if id(ext) not in seen:
                seen.add(id(ext))
                unique.append(ext)
        return unique

    # ── Run one repo with all its extractors ─────────────────────────────────

    def _run_repo(self, repo_meta: dict, file_workers: int) -> dict:
        """Run all applicable extractors on one repo. Returns summary dict."""
        repo_id = repo_meta["repo_id"]
        repo_path = repo_meta["root_path"]
        extractor_classes = self._get_extractors_for_repo(repo_meta)

        if not extractor_classes:
            return {
                "repo_id": repo_id,
                "classification": repo_meta.get("classification", []),
                "extractors_run": [],
                "status": "skipped",
                "reason": "No extractors registered for classification",
            }

        repo_result = {
            "repo_id": repo_id,
            "classification": repo_meta.get("classification", []),
            "extractors_run": [],
            "status": "ok",
        }

        for ext_class in extractor_classes:
            extractor = ext_class()
            extractor._file_cache = self._file_cache
            file_results = extractor.run_on_repo(
                repo_id=repo_id,
                repo_path=repo_path,
                repo_meta=repo_meta,
                max_workers=file_workers,
            )

            summary = extractor.summary()
            repo_result["extractors_run"].append(summary)

            # Merge this extractor's emitter into the dispatcher's collection
            with self._lock:
                self._all_results.append({
                    "repo_id": repo_id,
                    "extractor": extractor.name,
                    "emitter": extractor.emitter,
                })

            # Collect assist requests for GenAI resolution
            if self._genai_resolver and extractor.assist_requests:
                with self._lock:
                    self._all_results[-1]["assist_requests"] = extractor.assist_requests

        # ── GenAI inline assist: resolve collected requests for this repo ────
        if self._genai_resolver:
            all_repo_requests = []
            for item in self._all_results:
                if item.get("repo_id") == repo_id and item.get("assist_requests"):
                    all_repo_requests.extend(item["assist_requests"])
            if all_repo_requests:
                genai_emitter = self._genai_resolver.resolve_repo_requests(
                    repo_id=repo_id,
                    repo_path=repo_path,
                    repo_meta=repo_meta,
                    requests=all_repo_requests,
                )
                if genai_emitter:
                    with self._lock:
                        self._all_results.append({
                            "repo_id": repo_id,
                            "extractor": "genai_inline",
                            "emitter": genai_emitter,
                        })
                    genai_stats = genai_emitter.stats()
                    repo_result["genai_assist"] = {
                        "requests": len(all_repo_requests),
                        "entities_added": genai_stats["entity_ids"],
                        "relations_added": genai_stats["relation_ids"],
                    }

        return repo_result

    # ── Main run ─────────────────────────────────────────────────────────────

    def run(self, repo_workers: int = 4, file_workers: int = 8) -> dict:
        """
        Run extraction across all repos in the manifest.
        - repo_workers: how many repos to process in parallel
        - file_workers: how many files to process in parallel within each repo
        Returns the full extraction report.
        """
        repos = self.manifest.get("repos", [])

        print(f"\n{'='*60}")
        print(f"  MAFIA Phase 3+4+5 -- Extraction Dispatch")
        print(f"{'='*60}")
        print(f"  Repos: {len(repos)}")
        print(f"  Registered extractors:")
        for cls, exts in self._registry.items():
            print(f"    {cls}: {[e.name for e in exts]}")
        if self._global_extractors:
            print(f"    *: {[e.name for e in self._global_extractors]}")
        print(f"  Parallelism: {repo_workers} repos x {file_workers} files")
        if self._genai_resolver:
            print(f"  GenAI: ENABLED (inline assist per repo)")
        print()

        repo_summaries = []

        if repo_workers <= 1:
            for repo_meta in repos:
                result = self._run_repo(repo_meta, file_workers)
                repo_summaries.append(result)
                self._print_repo_result(result)
        else:
            with ThreadPoolExecutor(max_workers=repo_workers) as pool:
                future_map = {
                    pool.submit(self._run_repo, repo_meta, file_workers): repo_meta
                    for repo_meta in repos
                }
                for future in as_completed(future_map):
                    repo_meta = future_map[future]
                    try:
                        result = future.result()
                    except Exception as e:
                        result = {
                            "repo_id": repo_meta["repo_id"],
                            "classification": repo_meta.get("classification", []),
                            "extractors_run": [],
                            "status": "failed",
                            "error": str(e),
                        }
                    repo_summaries.append(result)
                    self._print_repo_result(result)

        # ── Merge all emitters and flush ─────────────────────────────────────
        merged = CanonicalEmitter("merged")
        for item in self._all_results:
            merged.merge(item["emitter"])

        # Bayesian confidence adjustment (post-merge, pre-flush)
        merged.adjust_confidence()

        entities_path = str(self.output_dir / "entities.jsonl")
        relations_path = str(self.output_dir / "relations.jsonl")
        warnings_path = str(self.output_dir / "warnings.jsonl")

        # Clear previous output
        for p in (entities_path, relations_path, warnings_path):
            Path(p).unlink(missing_ok=True)

        merged.flush(entities_path, relations_path, warnings_path)

        # ── Build extraction report ──────────────────────────────────────────
        report = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "manifest_path": self.manifest_path,
            "repos_processed": len(repo_summaries),
            "repos_ok": sum(1 for r in repo_summaries if r["status"] == "ok"),
            "repos_skipped": sum(1 for r in repo_summaries if r["status"] == "skipped"),
            "repos_failed": sum(1 for r in repo_summaries if r["status"] == "failed"),
            "merged_stats": merged.stats(),
            "repo_summaries": repo_summaries,
        }

        report_path = self.output_dir / "extraction_report.json"
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        # ── Print summary ────────────────────────────────────────────────────
        ms = merged.stats()
        print(f"\n{'='*60}")
        print(f"  Extraction Complete")
        print(f"{'='*60}")
        print(f"  Repos processed: {report['repos_processed']}")
        print(f"  Repos OK/skipped/failed: {report['repos_ok']}/{report['repos_skipped']}/{report['repos_failed']}")
        print(f"  Total entities: {ms['entity_ids']}")
        print(f"  Total relations: {ms['relation_ids']}")
        print(f"  Duplicates merged: {ms['duplicates']}")
        print(f"  Warnings: {ms['warnings']}")
        print(f"  Output: {self.output_dir}")
        print(f"{'='*60}\n")

        return report

    def _print_repo_result(self, result: dict):
        repo_id = result["repo_id"]
        status = result["status"]
        if status == "skipped":
            print(f"  [SKIP] {repo_id:50s} -> {result.get('reason', '')}")
        elif status == "failed":
            print(f"  [FAIL] {repo_id:50s} -> {result.get('error', '')}")
        else:
            extractors = result.get("extractors_run", [])
            total_e = sum(e.get("total_entities_emitted", 0) for e in extractors)
            total_r = sum(e.get("total_relations_emitted", 0) for e in extractors)
            ext_names = [e["extractor"] for e in extractors]
            genai = result.get("genai_assist", {})
            genai_str = f" +{genai['entities_added']}E/{genai['relations_added']}R genai" if genai.get("entities_added") else ""
            print(f"  [OK]   {repo_id:50s} -> {total_e}E {total_r}R [{', '.join(ext_names)}]{genai_str}")
