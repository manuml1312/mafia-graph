"""
MAFIA — Unified Pipeline Runner
==================================
Single entry point for the entire MAFIA extraction + analysis pipeline.
Replaces both run_extraction.py and orchestrator.py.

Defaults to incremental mode (skip unchanged repos). Use --full to force
full re-extraction. Use --from-phase / --to-phase to run a subset of phases.

Phases:
    2   Repo scanning (external — run repo_scanner separately)
    3   Extraction (dispatcher + all extractors)
    5s  Structural relations (post-extraction cross-file/cross-repo)
    5c  Legacy compatibility artifacts
    6   Coverage analysis
    7a  Mapping confidence evaluation
    7b  GenAI post-hoc gap analysis (requires --enable-genai)
    8   Quality gate
    9   Graph construction + flow assembly + graph validation
    10  AI intelligence (component + flow)
    13  Evaluation against gold datasets (requires --evaluate)
    14  Versioning + run-state persistence (always runs)

Usage:
    python -m phase3_extraction_framework.run_extraction                     # incremental
    python -m phase3_extraction_framework.run_extraction --full              # full re-extract
    python -m phase3_extraction_framework.run_extraction --from-phase 9      # skip extraction, rebuild graph onward
    python -m phase3_extraction_framework.run_extraction --to-phase 8        # extract + validate, stop before graph
    python -m phase3_extraction_framework.run_extraction --snapshot           # archive artifacts for rollback
    python -m phase3_extraction_framework.run_extraction --evaluate           # run Phase 13 eval gate
    python -m phase3_extraction_framework.run_extraction --enable-genai       # enable GenAI assist
"""

import json
import argparse
from pathlib import Path
from datetime import datetime, timezone

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from phase14_orchestration.run_state import RunState
from phase14_orchestration.artifact_versioning import ArtifactVersioner


# ── Phase ordering ───────────────────────────────────────────────────────────
PHASES = [3, 5, 6, 7, 8, 9, 10, 13, 14]
PHASE_LABELS = {
    3:  "Extraction + structural + validation",
    5:  "Legacy compatibility artifacts",
    6:  "Coverage analysis",
    7:  "Mapping confidence + GenAI post-hoc",
    8:  "Quality gate",
    9:  "Graph construction + flow assembly",
    10: "AI intelligence (component + flow)",
    13: "Evaluation against gold datasets",
    14: "Versioning + run-state persistence",
}


def _should_run(phase: int, from_phase: int, to_phase: int) -> bool:
    return from_phase <= phase <= to_phase


# ── Incremental merge helpers ────────────────────────────────────────────────

def _preserve_unchanged_repos(output_dir: str, changed_repo_ids: set):
    output = Path(output_dir)
    preserved_e, preserved_r = [], []
    for item in _load_jsonl(output / "entities.jsonl"):
        if item.get("repo", "") not in changed_repo_ids:
            preserved_e.append(item)
    for item in _load_jsonl(output / "relations.jsonl"):
        repo = item.get("evidence", {}).get("repo", "")
        if repo not in changed_repo_ids:
            preserved_r.append(item)
    return preserved_e, preserved_r


def _inject_preserved(output_dir: str, entities: list, relations: list):
    output = Path(output_dir)
    for path, items in [(output / "entities.jsonl", entities), (output / "relations.jsonl", relations)]:
        if not items:
            continue
        existing = path.read_text(encoding='utf-8') if path.exists() else ""
        with open(path, 'w', encoding='utf-8') as f:
            for item in items:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
            f.write(existing)


def _load_jsonl(path):
    items = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    items.append(json.loads(line))
    except Exception:
        pass
    return items


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description='MAFIA Unified Pipeline — incremental by default, full with --full'
    )
    # Mode
    parser.add_argument('--full', action='store_true',
                        help='Force full re-extraction of all repos (default: incremental)')
    # Phase control
    parser.add_argument('--from-phase', type=int, default=3,
                        help='Start from this phase (default: 3). Phases: 3,5,6,7,8,9,10,13,14')
    parser.add_argument('--to-phase', type=int, default=14,
                        help='Stop after this phase (default: 14)')
    # Features
    parser.add_argument('--snapshot', action='store_true',
                        help='Archive artifacts after this run for rollback')
    parser.add_argument('--evaluate', action='store_true',
                        help='Run Phase 13 evaluation gate after pipeline')
    parser.add_argument('--no-cache', action='store_true',
                        help='Disable file-level extraction cache')
    # GenAI
    parser.add_argument('--enable-genai', action='store_true',
                        help='Enable GenAI inline assist + post-hoc gap analysis')
    parser.add_argument('--gemini-model', default='gemini-2.5-flash')
    parser.add_argument('--sa-key-path', default=None)
    parser.add_argument('--cert-file', default=None)
    # Parallelism
    parser.add_argument('--repo-workers', type=int, default=4)
    parser.add_argument('--file-workers', type=int, default=8)
    # Paths
    parser.add_argument('--manifest', default=None)
    parser.add_argument('--output-dir', default=None)
    args = parser.parse_args()

    base = Path(__file__).resolve().parent.parent
    manifest_path = args.manifest or str(base / "output" / "repo_manifest.json")
    output_dir = args.output_dir or str(base / "output")
    incremental = not args.full
    from_phase = args.from_phase
    to_phase = args.to_phase

    # ── Init orchestration ───────────────────────────────────────────────────
    run_state = RunState(output_dir)
    versioner = ArtifactVersioner(output_dir)
    version = versioner.next_version()

    print(f"\n{'='*60}")
    print(f"  MAFIA Pipeline v{version}")
    print(f"{'='*60}")
    print(f"  Mode:        {'INCREMENTAL' if incremental else 'FULL'}")
    print(f"  Phases:      {from_phase} -> {to_phase}")
    print(f"  Snapshot:    {'YES' if args.snapshot else 'NO'}")
    print(f"  Evaluate:    {'YES' if args.evaluate else 'NO'}")
    print(f"  GenAI:       {'ENABLED' if args.enable_genai else 'DISABLED'}")
    print(f"  Parallelism: {args.repo_workers} repos × {args.file_workers} files")
    print(f"  Manifest:    {manifest_path}")
    print(f"  Output:      {output_dir}")
    print(f"{'='*60}")

    # ── Load manifest ────────────────────────────────────────────────────────
    with open(manifest_path, 'r', encoding='utf-8') as f:
        manifest = json.load(f)
    repos = manifest.get("repos", [])
    genai_resolver = None
    preserved_e, preserved_r = [], []
    active_manifest = manifest_path

    # ── Clear file cache on full run ──────────────────────────────────────────
    if args.full or args.no_cache:
        from utils.file_cache import FileCache
        fc = FileCache(output_dir)
        cleared = fc.clear()
        if cleared:
            print(f"  File cache cleared: {cleared} entries")

    # ── Snapshot current artifacts for graph diff ────────────────────────────
    from phase8_hardening.graph_diff import snapshot_current
    snapshot_current(output_dir)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 3 — Extraction
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(3, from_phase, to_phase):
        # ── Incremental: detect changed repos ────────────────────────────────
        changed = repos
        if incremental:
            changed = []
            skipped = []
            for repo in repos:
                if run_state.repo_changed(repo["repo_id"], repo.get("root_path", "")):
                    changed.append(repo)
                else:
                    skipped.append(repo["repo_id"])

            print(f"\n  Incremental: {len(changed)} changed, {len(skipped)} unchanged")
            if skipped:
                print(f"  Skipping: {', '.join(skipped[:10])}{'...' if len(skipped) > 10 else ''}")

            if not changed:
                print("  No repos changed — skipping extraction.")
            else:
                changed_ids = {r["repo_id"] for r in changed}
                print(f"  Preserving artifacts from {len(skipped)} unchanged repos...")
                preserved_e, preserved_r = _preserve_unchanged_repos(output_dir, changed_ids)
                print(f"  Preserved: {len(preserved_e)} entities, {len(preserved_r)} relations")

                filtered = dict(manifest)
                filtered["repos"] = changed
                filtered_path = str(Path(output_dir) / "_incremental_manifest.json")
                with open(filtered_path, 'w', encoding='utf-8') as f:
                    json.dump(filtered, f, indent=2, ensure_ascii=False)
                active_manifest = filtered_path

        # ── Run extractors (if there are repos to process) ───────────────────
        if changed:
            from phase3_extraction_framework.dispatcher import ExtractionDispatcher
            from phase4_extractors.ui.ui_extractor import UiExtractor
            from phase4_extractors.bff.bff_extractor import BffExtractor
            from phase4_extractors.api.api_extractor import ApiExtractor
            from phase4_extractors.db.databricks_extractor import DatabricksExtractor
            from phase4_extractors.db.pg_sql_extractor import PgSqlExtractor
            from phase4_extractors.ts_extractor import TreeSitterExtractor

            dispatcher = ExtractionDispatcher(active_manifest, output_dir)
            dispatcher.register("*", TreeSitterExtractor)  # AST-first: runs on ALL repos
            dispatcher.register("ui", UiExtractor)
            dispatcher.register("bff", BffExtractor)
            dispatcher.register("api", ApiExtractor)
            dispatcher.register("api", PgSqlExtractor)
            dispatcher.register("db", PgSqlExtractor)
            dispatcher.register("data", DatabricksExtractor)

            if args.enable_genai:
                from phase7_genai.pattern_discovery import GenAIAssistResolver
                from phase7_genai.gemini_client import GeminiClient
                client = GeminiClient(sa_key_path=args.sa_key_path,
                                      cert_file=args.cert_file, model=args.gemini_model)
                if client.is_available:
                    genai_resolver = GenAIAssistResolver(client)
                    dispatcher.enable_genai(genai_resolver)

            report = dispatcher.run(repo_workers=args.repo_workers,
                                    file_workers=args.file_workers)

            # Merge preserved records back
            if incremental and preserved_e:
                _inject_preserved(output_dir, preserved_e, preserved_r)
                print(f"  Merged: preserved + newly extracted artifacts")

            # Update run state
            for repo in changed:
                rid = repo["repo_id"]
                ext_names = [e["extractor"] for s in report.get("repo_summaries", [])
                             if s.get("repo_id") == rid for e in s.get("extractors_run", [])]
                run_state.mark_done(rid, repo.get("root_path", ""), ext_names)

        # ── Structural relations ─────────────────────────────────────────────
        from phase3_extraction_framework.structural_relations import emit_structural_relations
        print("\n  Emitting structural + cross-layer relations...")
        struct_stats = emit_structural_relations(output_dir, manifest_path)
        print(f"  Structural relations: {struct_stats['relation_ids']} emitted")

        # ── Cross-scope stitching (phase 3.5) ─────────────────────────────
        from phase3_extraction_framework.cross_scope import run_all_stitchers
        print("\n  Running cross-scope stitching...")
        stitch_stats = run_all_stitchers(output_dir)
        print(f"  Cross-scope stitching: {stitch_stats.get('new_relations', 0)} new relations")

        # ── Validation ───────────────────────────────────────────────────────
        from schemas.validator import ArtifactValidator
        print("\n  Running artifact validation...")
        validator = ArtifactValidator()
        ep = str(Path(output_dir) / "entities.jsonl")
        rp = str(Path(output_dir) / "relations.jsonl")
        if Path(ep).exists(): validator.load_entities(ep)
        if Path(rp).exists(): validator.load_relations(rp)
        validation = validator.validate()
        validator.print_report(validation)
        validator.save_report(validation, str(Path(output_dir) / "validation_report.json"))

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 5 — Legacy compatibility
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(5, from_phase, to_phase):
        from phase5_compatibility.legacy_generators import generate_legacy_artifacts
        print("\n  Generating legacy compatibility artifacts...")
        generate_legacy_artifacts(output_dir)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 6 — Coverage
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(6, from_phase, to_phase):
        from phase6_coverage.coverage_builder import build_coverage_report
        build_coverage_report(output_dir)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 7 — Mapping + GenAI post-hoc
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(7, from_phase, to_phase):
        from phase7_mapping.mapping_evaluator import build_mapping_confidence_report
        build_mapping_confidence_report(output_dir)

        if genai_resolver and genai_resolver.is_available:
            genai_resolver.run_posthoc_analysis(output_dir, manifest_path)
            if genai_resolver.stats().get("entities_emitted", 0) > 0:
                from phase6_coverage.coverage_builder import build_coverage_report
                build_coverage_report(output_dir)
                build_mapping_confidence_report(output_dir)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 8 — Quality gate
    # ═════════════════════════════════════════════════════════════════════════
    gate_report = {}
    if _should_run(8, from_phase, to_phase):
        from phase8_hardening.quality_gate import run_quality_gate
        gate_report = run_quality_gate(output_dir)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 9 — Graph + flows + topology + visualization
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(9, from_phase, to_phase):
        from phase9_graph.graph_builder import build_graph
        from phase9_graph.graph_validator import validate_graph
        print("\n  Building system graph + e2e flows...")
        build_graph(output_dir)
        print("\n  Validating graph...")
        validate_graph(output_dir)

        # Topology analysis (community detection, god nodes, surprises)
        from phase9_graph.topology_analyzer import analyze_topology
        print("\n  Running topology analysis...")
        topo = analyze_topology(output_dir)
        if topo.get("community_count", 0) > 0:
            print(f"  Communities: {topo['community_count']}, God nodes: {len(topo.get('god_nodes', []))}")

        # Interactive HTML visualization
        from phase9_graph.graph_visualizer import generate_html
        print("\n  Generating interactive visualization...")
        generate_html(output_dir)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 10 — AST enrichment + AI intelligence
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(10, from_phase, to_phase):
        # AST structural summaries enrich entities with method-level detail
        from utils.ts_parser import any_available as ts_available
        if ts_available():
            from phase10_ast.run_ast_summaries import run as run_ast, run_discover as run_ast_discover
            print("\n  Running AST structural summaries...")
            run_ast(output_dir)
            print("\n  Running AST discover mode (gap analysis)...")
            run_ast_discover(output_dir)
        else:
            print("\n  [SKIP] tree-sitter not installed — skipping AST summaries")

        from phase10_intelligence.component_intelligence import generate_component_intelligence
        from phase10_intelligence.flow_intelligence import generate_flow_intelligence
        genai_for_intel = None
        if args.enable_genai and genai_resolver:
            from phase7_genai.gemini_client import GeminiClient
            genai_for_intel = GeminiClient(sa_key_path=args.sa_key_path,
                                           cert_file=args.cert_file, model=args.gemini_model)
        print("\n  Generating component intelligence...")
        generate_component_intelligence(output_dir, gemini_client=genai_for_intel, max_components=200)
        print("\n  Generating flow intelligence...")
        generate_flow_intelligence(output_dir, gemini_client=genai_for_intel)

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 13 — Evaluation (optional, --evaluate)
    # ═════════════════════════════════════════════════════════════════════════
    if _should_run(13, from_phase, to_phase) and args.evaluate:
        bench_dir = Path(output_dir) / "benchmark"
        if (bench_dir / "gold_entities.jsonl").exists():
            from phase13_evaluation.metric_calculators import evaluate
            eval_report = evaluate(output_dir)
            if not eval_report.get("passed", True):
                print("  [WARN] Phase 13 evaluation gate FAILED — gold recall below threshold")
        else:
            print("  [SKIP] No gold datasets — run: python -m phase13_evaluation.gold_dataset_builder")

    # ═════════════════════════════════════════════════════════════════════════
    #  PHASE 14 — Versioning + run-state + graph diff (always runs)
    # ═════════════════════════════════════════════════════════════════════════

    # Structural graph diff against previous run
    from phase8_hardening.graph_diff import compute_diff
    diff = compute_diff(output_dir)
    if diff.get("summary", {}).get("has_prev"):
        ds = diff["summary"]
        print(f"\n  Graph diff: {ds.get('text', 'no changes')}")
        if ds.get("entities_removed", 0) > 0:
            print(f"  [WARN] {ds['entities_removed']} entities removed since last run")

    from phase8_hardening.regression_runner import save_baseline
    print("\n  Saving regression baseline...")
    baseline = save_baseline(output_dir)

    run_state.mark_full_run()
    run_state.save()

    stats = {
        "entity_count": baseline.get("entity_count", 0),
        "relation_count": baseline.get("relation_count", 0),
        "parse_rate": baseline.get("parse_rate", 0),
        "mapping_confidence": baseline.get("mapping_confidence", 0),
        "gate_passed": gate_report.get("gate_passed", False),
    }
    versioner.record(version, stats=stats, snapshot=args.snapshot)

    # Clean up
    inc = Path(output_dir) / "_incremental_manifest.json"
    if inc.exists():
        inc.unlink()

    print(f"\n{'='*60}")
    print(f"  MAFIA Pipeline Complete — v{version}")
    print(f"  Gate: {'PASSED' if stats['gate_passed'] else 'FAILED'}")
    print(f"  Entities: {stats['entity_count']}  Relations: {stats['relation_count']}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
