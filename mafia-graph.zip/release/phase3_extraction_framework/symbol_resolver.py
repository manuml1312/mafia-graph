"""
MAFIA — Symbol Resolution Index
=================================
Runs BEFORE extraction on every repo. Builds a per-repo index of:

  1. Variable assignments  : var_name -> ClassName
       bq = BigQueryService(...)       -> bq: BigQueryService
       db = _get_bq_service()          -> db: BigQueryService  (via return-type trace)
       self.service = UserService()    -> self.service: UserService

  2. Function return types : fn_name -> ClassName
       def _get_bq_service() -> BigQueryService:
       def get_db() -> Database:

  3. Import aliases        : alias -> module.ClassName
       from services import BigQueryService as BQS  -> BQS: BigQueryService
       import services.db as db_mod                 -> db_mod: services.db

  4. Class field types     : ClassName.field -> FieldType
       class App:
           bq: BigQueryService          -> App.bq: BigQueryService
           def __init__(self):
               self.bq = BigQueryService()

Produces: symbol_index.json in output_dir
Used by: structural_relations.py (cross-file stitching), extractors (call resolution)

Works for: Python, TypeScript, JavaScript, Java
"""

import os
import re
import json
from pathlib import Path
from collections import defaultdict

SKIP_DIRS = {
    'node_modules', '.git', '__pycache__', '.venv', 'venv',
    'dist', 'build', 'out', 'target', '.next', '.gradle',
    'test', 'tests', '__tests__', 'spec', 'specs',
}

# ── Python patterns ───────────────────────────────────────────────────────────

# var = ClassName(...)  or  var = ClassName.method(...)
_PY_VAR_ASSIGN = re.compile(
    r'^[ \t]*(?:self\.)?(\w+)\s*=\s*([A-Z]\w+)\s*[\(\.]',
    re.MULTILINE,
)
# var = factory_fn(...)  — lowercase factory, we resolve via return-type index
_PY_VAR_FACTORY = re.compile(
    r'^[ \t]*(?:self\.)?(\w+)\s*=\s*([a-z_]\w*)\s*\(',
    re.MULTILINE,
)
# def fn_name(...) -> ClassName:
_PY_RETURN_TYPE = re.compile(
    r'def\s+(\w+)\s*\([^)]*\)\s*->\s*(?:Optional\[)?([A-Z]\w+)',
)
# def fn_name(...):  with  return ClassName(  in body
_PY_RETURN_INST = re.compile(r'\breturn\s+([A-Z]\w+)\s*\(')
# from module import Name [as alias]
_PY_FROM_IMPORT = re.compile(
    r'^from\s+(\S+)\s+import\s+(.+)$',
    re.MULTILINE,
)
# class Foo:  field: Type  (type annotation)
_PY_FIELD_ANNOT = re.compile(
    r'^[ \t]{4}(\w+)\s*:\s*(?:Optional\[)?([A-Z]\w+)',
    re.MULTILINE,
)

# ── TypeScript / JavaScript patterns ─────────────────────────────────────────

# const/let/var name: Type = new ClassName(...)
_TS_VAR_NEW = re.compile(
    r'(?:const|let|var)\s+(\w+)\s*(?::\s*\w+)?\s*=\s*new\s+([A-Z]\w+)\s*\(',
)
# const/let/var name = factoryFn(...)
_TS_VAR_FACTORY = re.compile(
    r'(?:const|let|var)\s+(\w+)\s*=\s*([a-z_]\w*)\s*\(',
)
# function fn(): ReturnType  or  ): ReturnType =>
_TS_RETURN_TYPE = re.compile(
    r'(?:function\s+(\w+)|(\w+)\s*=\s*(?:async\s*)?\([^)]*\))\s*:\s*(?:Promise<)?([A-Z]\w+)',
)
# import { Name [as alias] } from 'module'
_TS_NAMED_IMPORT = re.compile(
    r'import\s*\{([^}]+)\}\s*from\s*[\'"]([^\'"]+)[\'"]',
)
# import Name from 'module'
_TS_DEFAULT_IMPORT = re.compile(
    r'import\s+(\w+)\s+from\s*[\'"]([^\'"]+)[\'"]',
)
# class field:  private/public/protected name: Type
_TS_FIELD_DECL = re.compile(
    r'(?:private|public|protected|readonly)\s+(\w+)\s*(?:!\s*)?:\s*([A-Z]\w+)',
)

# ── Java patterns ─────────────────────────────────────────────────────────────

# @Autowired / @Inject  FieldType fieldName;
_JAVA_INJECT = re.compile(
    r'@(?:Autowired|Inject|Resource)\s+(?:private\s+)?(\w+)\s+(\w+)\s*;',
)
# private FieldType fieldName;  (constructor injection)
_JAVA_FIELD = re.compile(
    r'(?:private|protected|public)\s+final\s+(\w+)\s+(\w+)\s*;',
)
# ClassName varName = new ClassName(
_JAVA_VAR_NEW = re.compile(
    r'\b([A-Z]\w+)\s+(\w+)\s*=\s*new\s+\1\s*\(',
)


def build_symbol_index(source_roots: list, output_dir: str) -> dict:
    """
    Scan all repos and build a symbol resolution index.
    Saves symbol_index.json to output_dir.
    Returns the index dict.
    """
    print(f"\n{'='*60}")
    print(f"  MAFIA — Symbol Resolution Index")
    print(f"{'='*60}")

    index = {}  # repo_root -> repo_symbol_index

    for root in source_roots:
        root_path = Path(root)
        if not root_path.exists():
            continue
        repo_index = _index_repo(root_path)
        index[str(root_path)] = repo_index
        print(f"  {root_path.name}: "
              f"{len(repo_index['var_types'])} vars, "
              f"{len(repo_index['fn_returns'])} fn returns, "
              f"{len(repo_index['import_aliases'])} aliases, "
              f"{len(repo_index['class_fields'])} class fields")

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / 'symbol_index.json', 'w', encoding='utf-8') as f:
        json.dump(index, f, indent=2, ensure_ascii=False)

    print(f"{'='*60}\n")
    return index


def _index_repo(root_path: Path) -> dict:
    """Build symbol index for one repo."""
    repo = {
        'var_types': {},        # var_name -> ClassName  (module-level + instance)
        'fn_returns': {},       # fn_name -> ClassName
        'import_aliases': {},   # alias -> original_name
        'class_fields': {},     # "ClassName.field" -> FieldType
        'file_symbols': {},     # rel_path -> {vars, fns, imports}
    }

    for fpath in _walk_files(root_path):
        rel = os.path.relpath(fpath, root_path).replace('\\', '/')
        ext = Path(fpath).suffix.lower()
        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(65536)
        except Exception:
            continue

        file_syms = {'vars': {}, 'fns': {}, 'imports': {}}

        if ext == '.py':
            _index_python(content, rel, repo, file_syms)
        elif ext in ('.ts', '.tsx', '.js', '.jsx'):
            _index_typescript(content, rel, repo, file_syms)
        elif ext == '.java':
            _index_java(content, rel, repo, file_syms)

        if file_syms['vars'] or file_syms['fns'] or file_syms['imports']:
            repo['file_symbols'][rel] = file_syms

    # Second pass: resolve factory-assigned vars using fn_returns
    _resolve_factory_vars(repo)

    return repo


def _index_python(content: str, rel: str, repo: dict, file_syms: dict):
    # Import aliases: from module import ClassName [as alias]
    for m in _PY_FROM_IMPORT.finditer(content):
        names_str = m.group(2)
        for part in names_str.split(','):
            part = part.strip()
            if ' as ' in part:
                orig, alias = [x.strip() for x in part.split(' as ', 1)]
            else:
                orig = alias = part.split('(')[0].strip()
            if orig and alias:
                repo['import_aliases'][alias] = orig
                file_syms['imports'][alias] = orig

    # Function return types: def fn() -> ClassName:
    for m in _PY_RETURN_TYPE.finditer(content):
        fn_name, cls_name = m.group(1), m.group(2)
        repo['fn_returns'][fn_name] = cls_name
        file_syms['fns'][fn_name] = cls_name

    # Function return types via body: return ClassName(
    for m in re.finditer(r'def\s+(\w+)\s*\(', content):
        fn_name = m.group(1)
        if fn_name in repo['fn_returns']:
            continue
        # Find function body (next 2000 chars)
        body_start = content.find(':', m.end())
        if body_start < 0:
            continue
        body = content[body_start:body_start + 2000]
        ret_m = _PY_RETURN_INST.search(body)
        if ret_m:
            repo['fn_returns'][fn_name] = ret_m.group(1)
            file_syms['fns'][fn_name] = ret_m.group(1)

    # Variable assignments: var = ClassName(...)
    for m in _PY_VAR_ASSIGN.finditer(content):
        var_name, cls_name = m.group(1), m.group(2)
        if var_name not in ('self', 'cls', 'super'):
            repo['var_types'][var_name] = cls_name
            file_syms['vars'][var_name] = cls_name

    # Variable factory assignments: var = factory_fn(...)  — store for second pass
    for m in _PY_VAR_FACTORY.finditer(content):
        var_name, fn_name = m.group(1), m.group(2)
        if var_name not in repo['var_types'] and var_name not in ('self', 'cls'):
            # Store as pending factory resolution
            repo['var_types'].setdefault(f'__factory__{var_name}', fn_name)

    # Class field annotations: field: ClassName
    current_class = None
    for line in content.splitlines():
        cls_m = re.match(r'^class\s+(\w+)', line)
        if cls_m:
            current_class = cls_m.group(1)
        if current_class:
            ann_m = _PY_FIELD_ANNOT.match(line)
            if ann_m:
                field, ftype = ann_m.group(1), ann_m.group(2)
                key = f'{current_class}.{field}'
                repo['class_fields'][key] = ftype


def _index_typescript(content: str, rel: str, repo: dict, file_syms: dict):
    # Named imports: import { A, B as C } from 'module'
    for m in _TS_NAMED_IMPORT.finditer(content):
        for part in m.group(1).split(','):
            part = part.strip()
            if ' as ' in part:
                orig, alias = [x.strip() for x in part.split(' as ', 1)]
            else:
                orig = alias = part.strip()
            if orig and alias:
                repo['import_aliases'][alias] = orig
                file_syms['imports'][alias] = orig

    # Default imports: import Name from 'module'
    for m in _TS_DEFAULT_IMPORT.finditer(content):
        name = m.group(1)
        repo['import_aliases'][name] = name
        file_syms['imports'][name] = name

    # Variable new: const x = new ClassName(
    for m in _TS_VAR_NEW.finditer(content):
        var_name, cls_name = m.group(1), m.group(2)
        repo['var_types'][var_name] = cls_name
        file_syms['vars'][var_name] = cls_name

    # Variable factory: const x = factoryFn(
    for m in _TS_VAR_FACTORY.finditer(content):
        var_name, fn_name = m.group(1), m.group(2)
        if var_name not in repo['var_types']:
            repo['var_types'].setdefault(f'__factory__{var_name}', fn_name)

    # Function return types
    for m in _TS_RETURN_TYPE.finditer(content):
        fn_name = m.group(1) or m.group(2)
        cls_name = m.group(3)
        if fn_name and cls_name:
            repo['fn_returns'][fn_name] = cls_name
            file_syms['fns'][fn_name] = cls_name

    # Class field declarations
    current_class = None
    for line in content.splitlines():
        cls_m = re.match(r'\s*class\s+(\w+)', line)
        if cls_m:
            current_class = cls_m.group(1)
        if current_class:
            fd_m = _TS_FIELD_DECL.search(line)
            if fd_m:
                field, ftype = fd_m.group(1), fd_m.group(2)
                repo['class_fields'][f'{current_class}.{field}'] = ftype


def _index_java(content: str, rel: str, repo: dict, file_syms: dict):
    # @Autowired FieldType fieldName
    for m in _JAVA_INJECT.finditer(content):
        ftype, fname = m.group(1), m.group(2)
        repo['var_types'][fname] = ftype
        file_syms['vars'][fname] = ftype

    # private final FieldType fieldName
    for m in _JAVA_FIELD.finditer(content):
        ftype, fname = m.group(1), m.group(2)
        if fname not in repo['var_types']:
            repo['var_types'][fname] = ftype
            file_syms['vars'][fname] = ftype

    # ClassName varName = new ClassName(
    for m in _JAVA_VAR_NEW.finditer(content):
        cls_name, var_name = m.group(1), m.group(2)
        repo['var_types'][var_name] = cls_name
        file_syms['vars'][var_name] = cls_name


def _resolve_factory_vars(repo: dict):
    """Second pass: resolve __factory__var entries using fn_returns."""
    fn_returns = repo['fn_returns']
    to_resolve = {k: v for k, v in repo['var_types'].items() if k.startswith('__factory__')}
    for key, fn_name in to_resolve.items():
        var_name = key[len('__factory__'):]
        resolved = fn_returns.get(fn_name)
        if resolved:
            repo['var_types'][var_name] = resolved
        del repo['var_types'][key]


def load_symbol_index(output_dir: str) -> dict:
    """Load existing symbol_index.json if available."""
    path = Path(output_dir) / 'symbol_index.json'
    if path.exists():
        try:
            return json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            pass
    return {}


def resolve_var_type(var_name: str, repo_root: str, symbol_index: dict) -> str:
    """
    Look up what class a variable name resolves to.
    Returns class name string or '' if unknown.
    """
    repo_data = symbol_index.get(repo_root, {})
    return repo_data.get('var_types', {}).get(var_name, '')


def resolve_call(obj_name: str, method_name: str, repo_root: str, symbol_index: dict) -> str:
    """
    Given obj.method(), resolve obj to its class and return 'ClassName.method'.
    Returns '' if obj type is unknown.
    """
    cls = resolve_var_type(obj_name, repo_root, symbol_index)
    if cls:
        return f'{cls}.{method_name}'
    # Try import alias
    repo_data = symbol_index.get(repo_root, {})
    alias_cls = repo_data.get('import_aliases', {}).get(obj_name, '')
    if alias_cls:
        return f'{alias_cls}.{method_name}'
    return ''


def _walk_files(root: Path):
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for fname in files:
            ext = Path(fname).suffix.lower()
            if ext in ('.py', '.ts', '.tsx', '.js', '.jsx', '.java'):
                yield os.path.join(dirpath, fname)
