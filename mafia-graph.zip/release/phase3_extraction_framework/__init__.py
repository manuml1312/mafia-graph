# MAFIA Phase 3 — Extraction Framework and Canonical Emission Pipeline
