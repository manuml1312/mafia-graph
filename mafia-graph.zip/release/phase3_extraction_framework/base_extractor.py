"""
MAFIA Phase 3 — Base Extractor Interface
==========================================
Every extractor subclasses BaseExtractor and implements extract_file().
The framework handles:
  - File discovery and filtering
  - Parallel execution across files (ThreadPoolExecutor)
  - Canonical emission through the shared emitter
  - Per-file error handling and warning collection
  - Checkpointing and resume support
  - File-level result tracking for coverage reporting

Subclass contract:
    class MyExtractor(BaseExtractor):
        name = "my_extractor"
        supported_extensions = {".java"}

        def extract_file(self, file_path, rel_path, content, repo_id, repo_meta):
            # emit entities and relations via self.emitter
            # return FileResult
"""

import os
import json
import re
import threading
from abc import ABC, abstractmethod
from pathlib import Path
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from schemas.emitter import CanonicalEmitter
from schemas.scope import Scope
from utils.file_classifier import classify_file


# ── Per-file result ──────────────────────────────────────────────────────────

@dataclass
class FileResult:
    """Result of extracting one file."""
    file_path: str
    status: str = "ok"           # ok | skipped | failed | no_entities | ineligible
    entities_emitted: int = 0
    relations_emitted: int = 0
    warnings: list[str] = field(default_factory=list)
    error: Optional[str] = None
    eligible: bool = True
    eligibility_reason: str = ""


# ── Base Extractor ───────────────────────────────────────────────────────────

SKIP_DIRS = {
    'node_modules', '.git', 'dist', 'build', 'out', 'target', '.idea',
    '.mvn', '.next', '.gradle', '__pycache__', '.venv', 'venv',
    '_scm_config', '_scm_container', '_scm_jenkins', 'wdyr',
    'test', 'tests', '__tests__', '__test__', 'spec', 'specs',
    'coverage', '.turbo', 'vendor', 'third_party', 'third-party',
}

MAX_FILE_SIZE = 2 * 1024 * 1024  # 2MB — skip huge generated files


class BaseExtractor(ABC):
    """
    Abstract base for all extractors.
    Subclasses must set:
        name: str                       — unique extractor name
        supported_extensions: set[str]  — file extensions this extractor handles
    And implement:
        extract_file(file_path, rel_path, content, repo_id, repo_meta) -> FileResult
    """

    name: str = "base"
    supported_extensions: set[str] = set()

    def __init__(self):
        self.emitter = CanonicalEmitter(self.name)
        self._file_results: list[FileResult] = []
        self._assist_requests: list[dict] = []
        self._lock = threading.Lock()
        self._checkpoint_dir: Optional[str] = None
        self._completed_files: set[str] = set()
        self._file_cache = None  # set by dispatcher when caching is enabled
        self._active_scope: Optional["Scope"] = None  # set during workspace extraction

    # ── GenAI assist request protocol ────────────────────────────────────────

    def request_assist(self, request_type: str, file: str, line: Optional[int] = None,
                       context: Optional[str] = None, what_i_tried: Optional[str] = None,
                       what_i_need: Optional[str] = None, code_snippet: Optional[str] = None,
                       extra: Optional[dict] = None):
        """
        Record an assist request for GenAI. Called by extractors when regex/AST
        hits a wall. Requests are collected during extraction and resolved in
        batch after the repo finishes.

        Known request_types:
          - zero_extraction: file should have entities but regex found nothing
          - unresolved_call_chain: found method X but can't trace what it calls
          - unresolved_field_type: see this.svc.doThing() but can't resolve svc to a file
          - complex_body_parse: method body has lambdas/streams/nested logic
          - dynamic_url_resolution: URL built dynamically, can't extract path
          - wrapper_pattern: file uses a pattern extractor doesn't recognize
          Any other type goes under 'additional'.
        """
        with self._lock:
            self._assist_requests.append({
                "request_type": request_type,
                "extractor": self.name,
                "file": file,
                "line": line,
                "context": (context or "")[:4000],
                "what_i_tried": what_i_tried,
                "what_i_need": what_i_need,
                "code_snippet": (code_snippet or "")[:8000],
                "extra": extra or {},
            })

    @property
    def assist_requests(self) -> list[dict]:
        return list(self._assist_requests)

    # ── Abstract method — subclasses implement this ──────────────────────────

    @abstractmethod
    def extract_file(
        self,
        file_path: str,
        rel_path: str,
        content: str,
        repo_id: str,
        repo_meta: dict,
    ) -> FileResult:
        """
        Extract entities and relations from one file.
        Use self.emitter.emit_entity() and self.emitter.emit_relation().
        Return a FileResult summarizing what was found.
        """
        ...

    # ── Optional hooks for subclasses ────────────────────────────────────────

    def before_repo(self, repo_id: str, repo_path: str, repo_meta: dict):
        """Called once before processing a repo. Override to build indexes."""
        pass

    def before_workspace(self, scope: "Scope"):
        """Called before processing a workspace. Override for workspace-level setup."""
        pass

    def after_workspace(self, scope: "Scope"):
        """Called after processing a workspace. Override for workspace-level teardown."""
        pass

    # ── Checkpoint / resume support ──────────────────────────────────────────

    def enable_checkpointing(self, checkpoint_dir: str):
        """Enable disk-based checkpointing. Call before run_on_repo."""
        self._checkpoint_dir = checkpoint_dir
        Path(checkpoint_dir).mkdir(parents=True, exist_ok=True)

    def _checkpoint_path(self, repo_id: str) -> Path:
        return Path(self._checkpoint_dir) / f"{self.name}_{repo_id}.checkpoint.json"

    def _load_checkpoint(self, repo_id: str):
        """Load set of already-completed file paths for this repo."""
        if not self._checkpoint_dir:
            return
        cp = self._checkpoint_path(repo_id)
        if cp.exists():
            try:
                data = json.loads(cp.read_text(encoding='utf-8'))
                self._completed_files = set(data.get("completed_files", []))
            except Exception:
                self._completed_files = set()

    def _save_checkpoint(self, repo_id: str, rel_path: str):
        """Append a completed file to the checkpoint."""
        if not self._checkpoint_dir:
            return
        with self._lock:
            self._completed_files.add(rel_path)
            cp = self._checkpoint_path(repo_id)
            cp.write_text(json.dumps({"completed_files": sorted(self._completed_files)}), encoding='utf-8')

    def _clear_checkpoint(self, repo_id: str):
        """Remove checkpoint after successful repo completion."""
        if not self._checkpoint_dir:
            return
        cp = self._checkpoint_path(repo_id)
        cp.unlink(missing_ok=True)
        self._completed_files = set()

    def after_repo(self, repo_id: str, repo_path: str, repo_meta: dict):
        """Called once after processing a repo. Override to emit cross-file relations."""
        pass

    # ── File discovery ───────────────────────────────────────────────────────

    def discover_files(self, repo_path: str) -> list[str]:
        """Walk repo and return files matching supported_extensions.
        Respects .mafiaignore patterns if present in repo root."""
        from utils.ignore_loader import load_ignore_patterns, is_ignored
        patterns = load_ignore_patterns(repo_path)
        files = []
        for root, dirs, filenames in os.walk(repo_path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                ext = Path(fname).suffix.lower()
                if ext in self.supported_extensions:
                    fpath = os.path.join(root, fname)
                    rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                    if os.path.getsize(fpath) <= MAX_FILE_SIZE and not is_ignored(rel, patterns):
                        files.append(fpath)
        return files

    # ── Single file processing (with error handling) ─────────────────────────

    def _process_one_file(
        self,
        fpath: str,
        repo_path: str,
        repo_id: str,
        repo_meta: dict,
    ) -> FileResult:
        """Read file, classify eligibility, call extract_file, handle errors."""
        rel_path = os.path.relpath(fpath, repo_path).replace('\\', '/')

        try:
            with open(fpath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            result = FileResult(
                file_path=rel_path,
                status="failed",
                error=f"Read error: {e}",
            )
            self.emitter.emit_warning("read_error", f"Cannot read {rel_path}: {e}", file=rel_path)
            return result

        if not content.strip():
            return FileResult(file_path=rel_path, status="skipped", warnings=["Empty file"],
                              eligible=False, eligibility_reason="empty_stub")

        # Classify file eligibility (fixes denominator problem)
        elig = classify_file(rel_path, content=content, file_size=len(content))
        if not elig.eligible:
            return FileResult(file_path=rel_path, status="ineligible",
                              eligible=False, eligibility_reason=elig.reason)

        # ── File-level cache check ───────────────────────────────────────────
        if self._file_cache is not None:
            cached = self._file_cache.get(fpath, repo_id, rel_path, self.name)
            if cached is not None:
                e_count, r_count = self.emitter.replay_cached(cached)
                result = FileResult(
                    file_path=rel_path, status="ok" if e_count > 0 else "no_entities",
                    entities_emitted=e_count, relations_emitted=r_count,
                    warnings=["from_cache"],
                )
                result.eligible = True
                result.eligibility_reason = elig.reason
                self._save_checkpoint(repo_id, rel_path)
                return result

        try:
            result = self.extract_file(fpath, rel_path, content, repo_id, repo_meta)
        except Exception as e:
            result = FileResult(
                file_path=rel_path,
                status="failed",
                error=f"Extraction error: {e}",
            )
            self.emitter.emit_warning("extraction_error", f"Failed on {rel_path}: {e}", file=rel_path)

        result.eligible = True
        result.eligibility_reason = elig.reason

        # ── Cache successful extraction ──────────────────────────────────────
        if self._file_cache is not None and result.status in ("ok", "no_entities"):
            emissions = self.emitter.get_file_emissions(rel_path)
            if emissions["entities"] or emissions["relations"]:
                self._file_cache.put(fpath, repo_id, rel_path, emissions, self.name)

        # Checkpoint this file as done
        self._save_checkpoint(repo_id, rel_path)

        return result

    # ── Run extraction on one repo (multi-threaded) ──────────────────────────

    def run_on_workspace(
        self,
        scope: "Scope",
        repo_path: str,
        repo_meta: dict,
        max_workers: int = 8,
    ) -> list[FileResult]:
        """Run extraction on a workspace. Delegates to run_on_repo with scope."""
        self._active_scope = scope
        self.before_workspace(scope)
        results = self.run_on_repo(
            repo_id=scope.path,
            repo_path=repo_path,
            repo_meta=repo_meta,
            max_workers=max_workers,
        )
        self.after_workspace(scope)
        self._active_scope = None
        return results

    def run_on_repo(
        self,
        repo_id: str,
        repo_path: str,
        repo_meta: dict,
        max_workers: int = 8,
    ) -> list[FileResult]:
        """
        Discover files, extract in parallel, return per-file results.
        """
        files = self.discover_files(repo_path)
        if not files:
            return []

        self.before_repo(repo_id, repo_path, repo_meta)
        self._load_checkpoint(repo_id)

        # Filter out already-completed files (resume support)
        if self._completed_files:
            before = len(files)
            files = [f for f in files if os.path.relpath(f, repo_path).replace('\\', '/') not in self._completed_files]
            if before != len(files):
                pass  # silently skip already-done files

        results = []

        if max_workers <= 1:
            # Sequential — useful for debugging
            for fpath in files:
                result = self._process_one_file(fpath, repo_path, repo_id, repo_meta)
                results.append(result)
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                future_map = {
                    pool.submit(self._process_one_file, fpath, repo_path, repo_id, repo_meta): fpath
                    for fpath in files
                }
                for future in as_completed(future_map):
                    fpath = future_map[future]
                    try:
                        result = future.result()
                    except Exception as e:
                        rel = os.path.relpath(fpath, repo_path).replace('\\', '/')
                        result = FileResult(file_path=rel, status="failed", error=str(e))
                    results.append(result)

        self.after_repo(repo_id, repo_path, repo_meta)
        self._clear_checkpoint(repo_id)

        with self._lock:
            self._file_results.extend(results)

        return results

    # ── Summary ──────────────────────────────────────────────────────────────

    def summary(self) -> dict:
        """Return extraction summary for coverage reporting."""
        total = len(self._file_results)
        ok = sum(1 for r in self._file_results if r.status == "ok")
        skipped = sum(1 for r in self._file_results if r.status == "skipped")
        failed = sum(1 for r in self._file_results if r.status == "failed")
        no_entities = sum(1 for r in self._file_results if r.status == "no_entities")
        ineligible = sum(1 for r in self._file_results if r.status == "ineligible")
        total_entities = sum(r.entities_emitted for r in self._file_results)
        total_relations = sum(r.relations_emitted for r in self._file_results)
        eligible_total = sum(1 for r in self._file_results if r.eligible)
        eligible_with_entities = sum(1 for r in self._file_results if r.eligible and r.status == "ok")

        return {
            "extractor": self.name,
            "files_discovered": total,
            "files_ok": ok,
            "files_skipped": skipped,
            "files_failed": failed,
            "files_no_entities": no_entities,
            "files_ineligible": ineligible,
            "files_eligible": eligible_total,
            "files_eligible_with_entities": eligible_with_entities,
            "total_entities_emitted": total_entities,
            "total_relations_emitted": total_relations,
            "emitter_stats": self.emitter.stats(),
            "failures": [
                {"file": r.file_path, "error": r.error}
                for r in self._file_results if r.status == "failed"
            ],
        }

    @property
    def file_results(self) -> list[FileResult]:
        return list(self._file_results)
