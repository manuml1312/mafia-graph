/* ═══════════════════════════════════════════════════════════════════════════
   MAFIA Phase 12 — Chat Pane (AI Assistant with RAG + Code Toggle)
   ═══════════════════════════════════════════════════════════════════════════ */

// ── Chat state ──────────────────────────────────────────────────────────────
const chatState = {
  conversationId: null,
  codeMode: false,
  astMode: false,
  sending: false,
};

// ── Init chat ───────────────────────────────────────────────────────────────
function initChat() {
  const chatPane = document.getElementById('chat-pane');
  if (!chatPane) return;

  chatPane.innerHTML = `
    <div class="chat-header">
      <div class="chat-header-left">
        <span class="chat-title" id="chat-title">New Chat</span>
        <button class="chat-btn-sm" onclick="newConversation()" title="New chat">+</button>
        <div class="thread-dropdown-wrap">
          <button class="chat-btn-sm" id="thread-dropdown-btn" onclick="toggleThreadDropdown()" title="Recent chats">▾</button>
          <div class="thread-dropdown" id="thread-dropdown"></div>
        </div>
      </div>
      <div class="chat-header-right">
        <label class="toggle-label" title="When ON, assistant reads source code to suggest fixes">
          <input type="checkbox" id="code-toggle" onchange="toggleCodeMode(this.checked)">
          <span class="toggle-switch"></span>
          <span class="toggle-text">🔧 Code</span>
        </label>
        <label class="toggle-label" title="When ON, assistant includes AST structural summaries (parameters, calls, exceptions)">
          <input type="checkbox" id="ast-toggle" onchange="toggleAstMode(this.checked)">
          <span class="toggle-switch"></span>
          <span class="toggle-text">🔬 AST</span>
        </label>
      </div>
    </div>
    <div class="chat-messages" id="chat-messages">
      <div class="chat-welcome" id="chat-welcome-content">
        <div class="emoji">🫡</div>
        <div><strong>At your service, Boss.</strong></div>
        <div class="muted">Checking AI status…</div>
      </div>
    </div>
    <div class="chat-working-set" id="chat-working-set"></div>
    <div class="chat-input-area">
      <textarea id="chat-input" placeholder="Ask a question..." rows="2" onkeydown="chatKeydown(event)"></textarea>
      <button class="chat-send-btn" id="chat-send-btn" onclick="sendMessage()">Send</button>
    </div>
  `;

  loadConversationList();
  loadAiStatus();
}

// ── Toggle code mode ────────────────────────────────────────────────────────
function toggleCodeMode(on) {
  chatState.codeMode = on;
  const label = document.querySelector('#code-toggle').closest('.toggle-label').querySelector('.toggle-text');
  if (label) label.textContent = on ? '🔧 Code ON' : '🔧 Code';
  if (chatState.conversationId) {
    api('/conversations/' + chatState.conversationId + '/state', {
      method: 'POST', body: { toggle_code: on }
    }).catch(() => {});
  }
}

function toggleAstMode(on) {
  chatState.astMode = on;
  const label = document.querySelector('#ast-toggle').closest('.toggle-label').querySelector('.toggle-text');
  if (label) label.textContent = on ? '🔬 AST ON' : '🔬 AST';
}

// ── Send message ────────────────────────────────────────────────────────────
async function sendMessage() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text || chatState.sending) return;

  chatState.sending = true;
  document.getElementById('chat-send-btn').disabled = true;
  input.value = '';

  // Show user message
  appendMessage('user', text);
  appendMessage('assistant', '<div class="loading">Thinking…</div>', true);

  try {
    const result = await api('/chat', {
      method: 'POST',
      body: {
        message: text,
        conversation_id: chatState.conversationId || '',
        code_mode: chatState.codeMode,
        ast_mode: chatState.astMode,
      },
    });

    // Update conversation ID
    if (result.conversation_id && !chatState.conversationId) {
      chatState.conversationId = result.conversation_id;
      loadConversationList();
    }

    // Remove thinking indicator and show response
    removeLastMessage();
    appendMessage('assistant', formatResponse(result));

    // Show retrieved context as collapsible references
    if (result.sources && result.sources.length) {
      appendRetrievedReferences(result);
    }

    // Update working set display
    updateWorkingSetDisplay(result);

  } catch (e) {
    removeLastMessage();
    appendMessage('assistant', `<div class="chat-error">Error: ${esc(e.message)}</div>`);
  }

  chatState.sending = false;
  document.getElementById('chat-send-btn').disabled = false;
}

function chatKeydown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

// ── Format response ─────────────────────────────────────────────────────────
function formatResponse(result) {
  let html = '';

  // Main response text with provenance highlighting
  const text = result.response || '';
  html += `<div class="chat-response-text">${formatProvenance(text)}</div>`;

  // Sources
  if (result.sources && result.sources.length) {
    html += `<div class="chat-sources">`;
    html += `<div class="chat-sources-title">Sources (${result.sources.length})</div>`;
    result.sources.slice(0, 5).forEach(s => {
      const shortId = s.id.split(':').slice(-2).join(':');
      html += `<span class="chat-source-chip" onclick="openNode('${esc(s.id)}')" title="${esc(s.id)}">${esc(shortId)} ${confBadge(s.confidence)}</span> `;
      if (s.type !== 'flow') {
        html += `<span class="chat-source-chip" onclick="showAstSummary('${esc(s.id)}')" title="View structure" style="cursor:pointer;opacity:0.7">🔬</span> `;
      }
    });
    html += `</div>`;
  }

  // Code files read
  if (result.code_snippets && result.code_snippets.length) {
    html += `<div class="chat-sources">`;
    html += `<div class="chat-sources-title">📁 Code files read (${result.code_snippets.length})</div>`;
    result.code_snippets.forEach(cs => {
      html += `<span class="chat-source-chip" onclick="showCode('${esc(cs.repo + '::' + cs.file)}')">${esc(cs.file)}:${cs.line || '?'}</span> `;
    });
    html += `</div>`;
  }

  // Warnings
  if (result.warnings && result.warnings.length) {
    html += `<div class="chat-warnings">`;
    result.warnings.forEach(w => {
      html += `<span class="warning-chip">${esc(w)}</span> `;
    });
    html += `</div>`;
  }

  // Stats
  const stats = result.retrieval_stats || {};
  html += `<div class="chat-stats muted">${stats.nodes_retrieved || 0} nodes · ${stats.flows_retrieved || 0} flows · ${stats.code_files_read || 0} files · ${result.latency_ms || 0}ms</div>`;

  // Clickable flow references
  if (result.sources) {
    const flowSources = result.sources.filter(s => s.type === 'flow' && s.id);
    if (flowSources.length) {
      html += `<div class="chat-sources">`;
      html += `<div class="chat-sources-title">➿ Referenced Flows</div>`;
      flowSources.forEach(f => {
        const shortId = f.id.split('::').pop() || f.id;
        html += `<span class="chat-flow-chip" onclick="openFlow('${esc(f.id)}', 'standard')" title="Click to view flow">➿ ${esc(trunc(shortId, 40))} ${confBadge(f.confidence)}</span> `;
      });
      html += `</div>`;
    }
  }

  return html;
}

function formatProvenance(text) {
  if (!text) return '';
  let html = text;

  // Escape HTML entities (but preserve markdown)
  html = html.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  // Provenance labels
  html = html.replace(/\[OBSERVED\]/g, '<span class="prov-observed">[OBSERVED]</span>');
  html = html.replace(/\[DERIVED\]/g, '<span class="prov-derived">[DERIVED]</span>');
  html = html.replace(/\[INFERRED\]/g, '<span class="prov-inferred">[INFERRED]</span>');
  html = html.replace(/\[UNKNOWN\]/g, '<span class="prov-unknown">[UNKNOWN]</span>');

  // Code blocks (``` ... ```)
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => {
    return `<pre class="chat-code"><code>${code}</code></pre>`;
  });

  // Inline code (`...`)
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');

  // Bold (**...**)
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

  // Italic (*...*)
  html = html.replace(/(?<![*])\*([^*]+)\*(?![*])/g, '<em>$1</em>');

  // Headers (### ... )
  html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');

  // Horizontal rule
  html = html.replace(/^---$/gm, '<hr>');

  // Unordered lists (- item)
  html = html.replace(/^- (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>\n?)+/g, (match) => `<ul>${match}</ul>`);

  // Ordered lists (1. item)
  html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');

  // Blockquotes (&gt; ...)
  html = html.replace(/^&gt; (.+)$/gm, '<blockquote>$1</blockquote>');

  // Paragraphs: double newlines
  html = html.replace(/\n\n/g, '</p><p>');
  // Single newlines within paragraphs
  html = html.replace(/\n/g, '<br>');

  // Wrap in paragraph if not already wrapped
  if (!html.startsWith('<')) html = '<p>' + html + '</p>';

  // Clean up empty paragraphs
  html = html.replace(/<p><\/p>/g, '');
  html = html.replace(/<p>(<h[123]>)/g, '$1');
  html = html.replace(/(<\/h[123]>)<\/p>/g, '$1');
  html = html.replace(/<p>(<ul>)/g, '$1');
  html = html.replace(/(<\/ul>)<\/p>/g, '$1');
  html = html.replace(/<p>(<pre)/g, '$1');
  html = html.replace(/(<\/pre>)<\/p>/g, '$1');
  html = html.replace(/<p>(<hr>)<\/p>/g, '$1');
  html = html.replace(/<p>(<blockquote>)/g, '$1');
  html = html.replace(/(<\/blockquote>)<\/p>/g, '$1');

  return html;
}

// ── Message rendering ───────────────────────────────────────────────────────
function appendMessage(role, html, isTemp) {
  const container = document.getElementById('chat-messages');
  // Remove welcome on first message
  const welcome = container.querySelector('.chat-welcome');
  if (welcome) welcome.remove();

  const div = document.createElement('div');
  div.className = `chat-msg chat-msg-${role}`;
  if (isTemp) div.classList.add('chat-msg-temp');
  div.innerHTML = `<div class="chat-msg-bubble">${html}</div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function removeLastMessage() {
  const container = document.getElementById('chat-messages');
  const temp = container.querySelector('.chat-msg-temp');
  if (temp) temp.remove();
}

// ── Retrieved references (shown below AI response) ────────────────────────
function appendRetrievedReferences(result) {
  const container = document.getElementById('chat-messages');
  const sources = result.sources || [];
  const codeSnippets = result.code_snippets || [];
  if (!sources.length && !codeSnippets.length) return;

  let html = `<div class="chat-refs-toggle" onclick="this.nextElementSibling.classList.toggle('expanded'); this.querySelector('.ref-arrow').textContent = this.nextElementSibling.classList.contains('expanded') ? '\u25bc' : '\u25b6';">`;
  html += `<span class="ref-arrow">\u25b6</span> Retrieved Context (${sources.length} sources${codeSnippets.length ? ', ' + codeSnippets.length + ' files' : ''})`;
  html += `</div>`;
  html += `<div class="chat-refs-body">`;

  sources.forEach(s => {
    const shortId = (s.id || '').split(':').slice(-2).join(':');
    const typeIcon = s.type === 'flow' ? '\u27bf' : '\ud83e\udde9';
    const clickAction = s.type === 'flow'
      ? "openFlow('" + esc(s.id) + "', 'standard')"
      : "openNode('" + esc(s.id) + "')";
    html += '<div class="chat-ref-item" onclick="' + clickAction + '">';
    html += `<span>${typeIcon} ${esc(shortId)}</span>`;
    html += confBadge(s.confidence);
    html += `<span class="muted">${esc(s.type)}</span>`;
    html += `</div>`;
  });

  codeSnippets.forEach(cs => {
    html += `<div class="chat-ref-item" onclick="showCode('${esc(cs.repo + '::' + cs.file)}')">`;
    html += `<span>\ud83d\udcc4 ${esc(cs.file)}:${cs.line || '?'}</span>`;
    html += `<span class="muted">${esc(cs.repo)}</span>`;
    html += `</div>`;
  });

  html += `</div>`;

  const div = document.createElement('div');
  div.className = 'chat-msg chat-msg-refs';
  div.innerHTML = html;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

// ── Working set display ─────────────────────────────────────────────────────
function updateWorkingSetDisplay(result) {
  const el = document.getElementById('chat-working-set');
  if (!el) return;
  const stats = result.retrieval_stats || {};
  const nodeCount = stats.nodes_retrieved || 0;
  const flowCount = stats.flows_retrieved || 0;
  const codeCount = stats.code_files_read || 0;

  if (nodeCount === 0 && flowCount === 0) {
    el.innerHTML = '';
    return;
  }

  el.innerHTML = `<div class="ws-bar">` +
    `<span class="ws-item">🧩 ${nodeCount} nodes</span>` +
    `<span class="ws-item">🔗 ${flowCount} flows</span>` +
    (codeCount ? `<span class="ws-item">📁 ${codeCount} files</span>` : '') +
    (chatState.codeMode ? `<span class="ws-item ws-code-on">🔧 Code ON</span>` : '') +
    (chatState.astMode ? `<span class="ws-item ws-code-on">🔬 AST ON</span>` : '') +
  `</div>`;
}

// ── Conversation list ───────────────────────────────────────────────────────
async function loadConversationList() {
  const el = document.getElementById('thread-dropdown');
  if (!el) return;
  try {
    const data = await api('/conversations');
    const convs = data.conversations || [];
    if (!convs.length) {
      el.innerHTML = '<div class="thread-dd-empty">No recent chats</div>';
      return;
    }
    let html = '';
    convs.slice(0, 10).forEach(c => {
      const active = c.conversation_id === chatState.conversationId ? 'active' : '';
      html += `<div class="thread-dd-item ${active}" onclick="loadConversation('${c.conversation_id}'); closeThreadDropdown();">` +
        `<span class="thread-dd-title">${esc(trunc(c.title || 'Untitled', 35))}</span>` +
      `</div>`;
    });
    el.innerHTML = html;
  } catch (e) {
    el.innerHTML = '<div class="thread-dd-empty">Failed to load</div>';
  }
}

function toggleThreadDropdown() {
  const dd = document.getElementById('thread-dropdown');
  if (!dd) return;
  dd.classList.toggle('open');
  if (dd.classList.contains('open')) loadConversationList();
}

function closeThreadDropdown() {
  const dd = document.getElementById('thread-dropdown');
  if (dd) dd.classList.remove('open');
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.thread-dropdown-wrap')) closeThreadDropdown();
});

async function loadConversation(convId) {
  chatState.conversationId = convId;
  const container = document.getElementById('chat-messages');
  container.innerHTML = '<div class="loading">Loading…</div>';

  try {
    const data = await api('/conversations/' + convId);
    container.innerHTML = '';
    const msgs = data.messages || [];
    msgs.forEach(m => {
      if (m.role === 'user') {
        appendMessage('user', esc(m.text));
      } else {
        // If metadata exists (sources, code_snippets, stats), render full response
        const meta = m.metadata;
        if (meta && (meta.sources || meta.code_snippets)) {
          const fakeResult = {
            response: m.text,
            sources: meta.sources || [],
            code_snippets: meta.code_snippets || [],
            warnings: meta.warnings || [],
            latency_ms: meta.latency_ms || 0,
            retrieval_stats: meta.retrieval_stats || {},
          };
          appendMessage('assistant', formatResponse(fakeResult));
          if (fakeResult.sources.length) {
            appendRetrievedReferences(fakeResult);
          }
        } else {
          appendMessage('assistant', formatProvenance(m.text));
        }
      }
    });

    // Restore working set
    const ws = data.working_set || {};
    chatState.codeMode = ws.toggle_code_mode || false;
    const toggle = document.getElementById('code-toggle');
    if (toggle) toggle.checked = chatState.codeMode;

    // Update title
    const conv = data.conversation || {};
    document.getElementById('chat-title').textContent = conv.title || 'Chat';

    loadConversationList();
  } catch (e) {
    container.innerHTML = `<div class="chat-error">Failed to load conversation</div>`;
  }
}

async function newConversation() {
  chatState.conversationId = null;
  chatState.codeMode = false;
  const toggle = document.getElementById('code-toggle');
  if (toggle) toggle.checked = false;
  document.getElementById('chat-title').textContent = 'New Chat';
  document.getElementById('chat-messages').innerHTML = `
    <div class="chat-welcome" id="chat-welcome-content">
      <div class="emoji">🫡</div>
      <div><strong>At your service, Boss.</strong></div>
      <div class="muted">Checking AI status…</div>
    </div>`;
  document.getElementById('chat-working-set').innerHTML = '';
  loadConversationList();
  loadAiStatus();
}

// ── AI status + capabilities ────────────────────────────────────────────────
async function loadAiStatus() {
  const el = document.getElementById('chat-welcome-content');
  if (!el) return;
  try {
    const data = await api('/api/ai/status');
    const caps = data.capabilities || [];
    const contact = data.setup_contact || {};
    const available = data.available;

    let html = `<div class="emoji">${available ? '🫡' : '🤖'}</div>`;
    html += `<div><strong>${available ? 'At your service, Boss.' : 'AI Assistant'}</strong></div>`;

    if (available) {
      html += `<div class="muted">Ask me anything about the codebase — endpoints, flows, blast radius, or debug issues.</div>`;
      html += `<div class="muted mt-8">Toggle <strong>Code Mode</strong> to let me read source files. Toggle <strong>AST Mode</strong> to include method structure.</div>`;
    }

    // Capabilities grid
    html += `<div class="ai-capabilities">`;
    caps.forEach(c => {
      html += `<div class="ai-cap-card">`;
      html += `<span class="ai-cap-icon">${c.icon}</span>`;
      html += `<div class="ai-cap-text">`;
      html += `<strong>${esc(c.name)}</strong>`;
      html += `<div class="muted">${esc(c.desc)}</div>`;
      html += `</div></div>`;
    });
    html += `</div>`;

    // Setup notice if AI is not available
    if (!available && contact.name) {
      html += `<div class="ai-setup-notice">`;
      html += `<div class="ai-setup-icon">🔒</div>`;
      html += `<div class="ai-setup-text">`;
      html += `<strong>AI features are not yet configured</strong>`;
      html += `<div class="muted">${esc(contact.message)}</div>`;
      html += `</div></div>`;
    }

    el.innerHTML = html;
  } catch (e) {
    // Fallback if endpoint not available
    el.innerHTML = `
      <div class="emoji">🫡</div>
      <div><strong>At your service, Boss.</strong></div>
      <div class="muted">Ask me anything about the codebase — endpoints, flows, blast radius, or debug issues.</div>
      <div class="muted mt-8">Toggle <strong>Code Mode</strong> to let me read source files. Toggle <strong>AST Mode</strong> to include method structure.</div>
    `;
  }
}

// ── Init on DOM ready ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(initChat, 100);
  initChatResize();
});

// ── Resizable chat pane ─────────────────────────────────────────────────────
function initChatResize() {
  const handle = document.getElementById('chat-resize');
  const pane = document.getElementById('chat-pane');
  if (!handle || !pane) return;

  let dragging = false;
  handle.addEventListener('mousedown', (e) => {
    dragging = true;
    handle.classList.add('dragging');
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const newWidth = Math.max(280, Math.min(700, e.clientX));
    pane.style.width = newWidth + 'px';
  });
  document.addEventListener('mouseup', () => {
    if (dragging) {
      dragging = false;
      handle.classList.remove('dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  });
}
