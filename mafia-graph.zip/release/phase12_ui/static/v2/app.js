﻿/* ═══════════════════════════════════════════════════════════════════
   MAFIA v2 — System Explorer
   All logic lives under the Q namespace.
   ═══════════════════════════════════════════════════════════════════ */

const Q = {};
Q._RCOL=['#4E79A7','#F28E2B','#59A14F','#B07AA1','#9C755F','#76B7B2','#E15759','#FF9DA7','#BAB0AC','#EDC948'];

// ── API ─────────────────────────────────────────────────────────────
Q.api = async (path, opts = {}) => {
  const resp = await fetch(path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : {},
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!resp.ok) {
    const err = await resp.json().catch(() => ({ error: resp.statusText }));
    throw new Error(err.error || resp.statusText);
  }
  return resp.json();
};

// ── Escape ──────────────────────────────────────────────────────────
Q.esc = s => { if (!s) return ''; const d = document.createElement('div'); d.textContent = String(s); return d.innerHTML; };
Q.trunc = (s, n = 80) => (!s ? '' : s.length > n ? s.slice(0, n) + '…' : s);

// ── Badges ──────────────────────────────────────────────────────────
Q.layerBadge = l => {
  const k = (l || '').toLowerCase();
  return `<span class="badge b-${k}">${k.toUpperCase()}</span>`;
};
Q.confBadge = c => {
  if (c == null) return '';
  const v = parseFloat(c);
  const cls = v >= 0.8 ? 'b-hi' : v >= 0.5 ? 'b-md' : 'b-lo';
  return `<span class="badge ${cls}">${(v * 100).toFixed(0)}%</span>`;
};
Q.typeBadge = t => t ? `<span class="badge b-type">${Q.esc(t)}</span>` : '';

// ── Skeleton generators ─────────────────────────────────────────────
Q.skelCards = (n = 3) => Array(n).fill('<div class="skel skel-card"></div>').join('');
Q.skelLines = (n = 4) => Array(n).fill('<div class="skel skel-line"></div>').join('');
Q.skelStats = (n = 4) => `<div class="stat-row">${Array(n).fill('<div class="skel skel-stat"></div>').join('')}</div>`;
Q.loadingHTML = () => '<div class="loading">Loading…</div>';
Q.emptyHTML = msg => `<div class="empty"><div class="empty-icon">∅</div><div class="empty-text">${Q.esc(msg)}</div></div>`;

// ── State ───────────────────────────────────────────────────────────
Q.state = {
  view: 'home',
  selectedNode: null,
  selectedFlow: null,
  chatConvId: null,
  chatSending: false,
};

// ── Router ──────────────────────────────────────────────────────────
Q.navigate = view => {
  Q.state.view = view;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const el = document.getElementById('view-' + view);
  if (el) el.classList.add('active');
  const btn = document.querySelector(`.nav-btn[data-view="${view}"]`);
  if (btn) btn.classList.add('active');

  if (view === 'home') Q.loadHome();
  if (view === 'impact') Q.initImpact();
  if (view === 'explore') Q.autoLoadExplore();
};

// ── Chat toggle ─────────────────────────────────────────────────────
Q.toggleChat = () => {
  document.getElementById('chat-pane').classList.toggle('hidden');
};

// ── Init ────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Nav clicks
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => Q.navigate(btn.dataset.view));
  });

  // Search
  let searchTimer = null;
  const searchEl = document.getElementById('explore-search');
  if (searchEl) {
    searchEl.addEventListener('input', e => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => Q.runSearch(e.target.value), 300);
    });
    searchEl.addEventListener('keydown', e => {
      if (e.key === 'Enter') { clearTimeout(searchTimer); Q.runSearch(e.target.value); }
    });
  }

  // Filter changes
  ['f-layer', 'f-type', 'f-conf'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => {
      const q = document.getElementById('explore-search')?.value;
      if (q) Q.runSearch(q);
    });
  });

  // Chat input
  const chatInput = document.getElementById('chat-input');
  if (chatInput) {
    chatInput.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); Q.sendChat(); }
    });
  }

  // Impact autocomplete
  const impactInput = document.getElementById('impact-input');
  if (impactInput) {
    let acTimer = null;
    impactInput.addEventListener('input', e => {
      clearTimeout(acTimer);
      acTimer = setTimeout(() => Q.impactAC(e.target.value), 250);
    });
    impactInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') Q.runImpact();
      if (e.key === 'Escape') document.getElementById('impact-ac')?.classList.remove('open');
    });
  }

  // Close autocomplete on outside click
  document.addEventListener('click', e => {
    if (!e.target.closest('.ac-wrap')) {
      document.querySelectorAll('.ac-list').forEach(l => l.classList.remove('open'));
    }
  });

  // Session name
  Q.api('/api/sessions/active').then(d => {
    const el = document.getElementById('session-name');
    if (el && d.path) el.textContent = d.path.split(/[/\\]/).pop() || d.path;
  }).catch(() => {});

  // Boot — load home
  Q.navigate('home');
  Q.loadHome();
});


/* ═══════════════════════════════════════════════════════════════════
   Phase B: HOME — System at a Glance
   ═══════════════════════════════════════════════════════════════════ */

Q._homeLoaded = false;

Q.loadHome = async () => {
  const gateEl = document.getElementById('home-gate');
  const cardsEl = document.getElementById('home-cards');
  if (!cardsEl) return;
  if (Q._homeLoaded) return;

  cardsEl.innerHTML = Array(4).fill('<div class="skel skel-card"></div>').join('');

  try {
    const [stats, coverage] = await Promise.all([
      Q.api('/stats').catch(() => ({ graph:{}, flows:0, code_reader:{}, initialized:false })),
      Q.api('/coverage').catch(() => ({})),
    ]);

    if (stats.initialized === false) {
      cardsEl.innerHTML = Q.loadingHTML();
      setTimeout(() => { Q._homeLoaded = false; Q.loadHome(); }, 2000);
      return;
    }

    const g = stats.graph || {}, gate = coverage.quality_gate || {};
    const fc = (coverage.coverage||{}).file_coverage||{}, flowComp = coverage.flow_completeness||{}, orphans = coverage.orphans||{};
    const eyield = ((fc.eligible_yield||fc.extraction_rate||0)*100).toFixed(0);
    const gaps = (coverage.coverage||{}).gaps||[];
    const riskGaps = gaps.filter(x => x.severity==='critical'||x.severity==='warning').length;
    const orphanCount = Object.values(orphans).reduce((s,a) => s+(a?.length||0), 0);

    gateEl.innerHTML = gate.gate_passed!=null
      ? `<div class="gate-banner ${gate.gate_passed?'gate-pass':'gate-fail'}">${gate.gate_passed?'✓':'⚠'} Quality Gate: ${gate.gate_passed?'PASSED':'FAILED'} — ${gate.checks_passed||0}/${gate.checks_total||0} checks</div>` : '';

    const cards = [
      ['📐','Structure',`${Object.keys((coverage.coverage?.entity_coverage||{}).by_layer||{}).length||'—'} layers · ${g.nodes||0} entities · ${riskGaps} gaps`,'Explore structure',() => Q.openStructure()],
      ['⚡','Risk',`${orphanCount} orphan nodes · ${riskGaps} extraction gaps`,'Review risks',() => Q.openRisk(orphans, gaps)],
      ['🔗','Flows',`${flowComp.complete||0} complete · ${flowComp.partial||0} partial flows`,'Browse all flows',() => Q.loadAllFlows()],
      ['📊','Coverage',`${eyield}% eligible yield · ${fc.total_scanned||0} files scanned`,'View dashboard',() => Q.openCoverage(coverage, stats)],
    ];
    cardsEl.innerHTML = cards.map(([icon,title,desc,cta],i) =>
      `<div class="insight-card" id="hc-${i}"><div class="insight-top"><span class="insight-icon">${icon}</span><span class="insight-title">${Q.esc(title)}</span></div><div class="insight-desc">${Q.esc(desc)}</div><div class="insight-cta">${Q.esc(cta)} →</div></div>`
    ).join('');
    cards.forEach(([,,,,fn],i) => document.getElementById('hc-'+i)?.addEventListener('click', fn));

    // Language treemap
    const langs = fc.languages;
    if (langs?.length) Q.renderTreemap(langs);

    Q._homeLoaded = true;
  } catch (e) {
    cardsEl.innerHTML = Q.emptyHTML('Failed to load: ' + e.message);
  }
};


/* ═══════════════════════════════════════════════════════════════════
   Language Treemap (Home)
   ═══════════════════════════════════════════════════════════════════ */

Q.renderTreemap = langs => {
  const section = document.getElementById('home-treemap-section');
  const wrap = document.getElementById('home-treemap');
  if (!wrap || !langs.length) return;
  section.style.display = '';
  // Defer to next frame so container has real width after display change
  requestAnimationFrame(() => Q._drawTreemap(wrap, langs));
};
Q._drawTreemap = (wrap, langs) => {
  const W = wrap.clientWidth || 600, H = 180;
  if (W < 10) return; // still not visible
  const PAL = ['#1A73E8','#7B1FA2','#1B7D3A','#E37400','#CC0000','#F9AB00','#607D8B','#E91E63','#00ACC1','#8BC34A','#FF7043','#5C6BC0'];
  const root = d3.hierarchy({children:langs}).sum(d=>d.lines||0).sort((a,b)=>b.value-a.value);
  d3.treemap().size([W,H]).padding(2).round(true)(root);
  const svg = d3.select(wrap).append('svg').attr('width',W).attr('height',H);
  const cell = svg.selectAll('g').data(root.leaves()).join('g').attr('transform',d=>`translate(${d.x0},${d.y0})`);
  cell.append('rect').attr('width',d=>Math.max(0,d.x1-d.x0)).attr('height',d=>Math.max(0,d.y1-d.y0))
    .attr('fill',(d,i)=>PAL[i%PAL.length]).attr('opacity',.85).attr('rx',3)
    .append('title').text(d=>`.${d.data.ext} — ${d.data.lines} lines (${d.data.pct}%)`);
  cell.filter(d=>(d.x1-d.x0)>36&&(d.y1-d.y0)>18).append('text').attr('x',4).attr('y',13)
    .attr('font-size','10px').attr('font-weight','600').attr('fill','#fff').attr('pointer-events','none').text(d=>`.${d.data.ext}`);
  cell.filter(d=>(d.x1-d.x0)>50&&(d.y1-d.y0)>30).append('text').attr('x',4).attr('y',24)
    .attr('font-size','9px').attr('fill','rgba(255,255,255,.7)').attr('pointer-events','none').text(d=>`${d.data.pct}%`);
};

/* ═══════════════════════════════════════════════════════════════════
   Load All Flows (from Home card)
   ═══════════════════════════════════════════════════════════════════ */

Q.loadAllFlows = async () => {
  Q.navigate('explore');
  const results = document.getElementById('explore-results');
  const focus = document.getElementById('explore-focus');
  results.innerHTML = Q.skelCards(8);
  focus.innerHTML = Q.emptyHTML('Select a flow from the list to see its detail.');
  try {
    const data = await Q.api('/flows?mode=surface&limit=100');
    const flows = data.flows || [];
    if (!flows.length) { results.innerHTML = Q.emptyHTML('No flows found.'); return; }
    let html = `<div class="result-group-title">All Flows (${data.total}${data.truncated?'+':''})</div>`;
    flows.forEach(f => {
      html += `<div class="card" onclick="Q.openFlow('${Q.esc(f.flow_id)}')">
        <div class="card-title">${Q.esc(Q.trunc(f.surface_summary||f.flow_id,70))}</div>
        <div class="card-meta"><span class="badge ${f.completeness==='complete'?'b-ok':'b-warn'}">${f.completeness}</span> ${Q.confBadge(f.confidence)} <span class="muted">${f.hop_count} hops</span></div>
      </div>`;
    });
    results.innerHTML = html;
  } catch (e) { results.innerHTML = Q.emptyHTML('Failed: '+e.message); }
};

/* ═══════════════════════════════════════════════════════════════════
   Risk View — Orphan nodes + extraction gaps
   ═══════════════════════════════════════════════════════════════════ */

Q.openRisk = (orphans, gaps) => {
  Q.navigate('explore');
  const results = document.getElementById('explore-results');
  const focus = document.getElementById('explore-focus');
  Q.closeSide();

  const categories = [
    { key: 'bff_no_ui_caller', label: 'BFF — no UI caller', layer: 'bff' },
    { key: 'api_no_bff_caller', label: 'API — no BFF caller', layer: 'api' },
    { key: 'db_no_api_caller', label: 'DB — no API caller', layer: 'db' },
  ];
  const allOrphans = [];
  let listHTML = `<div class="section-label">⚠ Orphan Nodes</div>`;
  categories.forEach(cat => {
    const items = (orphans || {})[cat.key] || [];
    if (!items.length) return;
    listHTML += `<div class="result-group-title">${Q.esc(cat.label)} (${items.length})</div>`;
    items.forEach(n => {
      allOrphans.push({ ...n, _cat: cat.key, _layer: cat.layer });
      const short = (n.name || n.id || '').split('::').pop();
      listHTML += `<div class="card" onclick="Q.openNode('${Q.esc(n.id)}')">
        <div class="card-title">${Q.esc(Q.trunc(short, 50))}</div>
        <div class="card-meta">${Q.layerBadge(cat.layer)} <span class="muted">orphan</span></div>
      </div>`;
    });
  });
  if (!allOrphans.length) listHTML += `<div class="muted" style="font-size:12px;padding:12px 0">No orphan nodes found.</div>`;
  results.innerHTML = listHTML;

  let focusHTML = `<div class="node-header" style="border-left-color:var(--orange)">`;
  focusHTML += `<h2>⚡ Risk Overview</h2>`;
  focusHTML += `<div class="node-meta"><span class="muted">${allOrphans.length} orphan nodes · ${(gaps||[]).length} extraction gaps</span></div>`;
  focusHTML += `</div>`;

  focusHTML += `<div class="section-label">Orphan Breakdown</div>`;
  focusHTML += `<div class="risk-summary-grid">`;
  categories.forEach(cat => {
    const items = (orphans || {})[cat.key] || [];
    focusHTML += `<div class="risk-summary-card">`;
    focusHTML += `<div class="risk-summary-val">${items.length}</div>`;
    focusHTML += `<div class="risk-summary-label">${Q.esc(cat.label)}</div>`;
    focusHTML += `</div>`;
  });
  focusHTML += `</div>`;

  focusHTML += `<div style="font-size:12px;color:var(--fg-2);line-height:1.6;margin:12px 0 20px;padding:10px 14px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r)">`;
  focusHTML += `Orphan nodes are entities with <strong>no upstream caller</strong> from the expected layer. `;
  focusHTML += `A BFF endpoint with no UI caller means no React component fetches it. `;
  focusHTML += `An API endpoint with no BFF caller means it's unreachable from the frontend. `;
  focusHTML += `Click any orphan in the left panel to inspect it, view its code, and trace its dependencies.`;
  focusHTML += `</div>`;

  if (gaps && gaps.length) {
    focusHTML += `<div class="section-label">Extraction Gaps</div>`;
    gaps.forEach(g => {
      const sevCls = g.severity === 'critical' ? 'sev-critical' : g.severity === 'warning' ? 'sev-high' : 'sev-low';
      focusHTML += `<div class="risk-gap-item">`;
      focusHTML += `<span class="sev-chip ${sevCls}" style="font-size:9px">${Q.esc(g.severity || 'info')}</span>`;
      focusHTML += `<span style="flex:1;font-size:12px">${Q.esc(g.message || g.file || g.description || JSON.stringify(g))}</span>`;
      focusHTML += `</div>`;
    });
  }

  focusHTML += `<div class="section-label mt-3">Actions</div>`;
  focusHTML += `<div style="display:flex;gap:6px;flex-wrap:wrap">`;
  focusHTML += `<button class="btn-ghost btn-sm" onclick="Q.navigate('impact')">Open Impact Analysis</button>`;
  focusHTML += `<button class="btn-ghost btn-sm" onclick="Q.openStructure()">View Structure</button>`;
  focusHTML += `</div>`;

  focus.innerHTML = focusHTML;
};


/* ═══════════════════════════════════════════════════════════════════
   Coverage Dashboard — metrics, quality gate, confidence, flows
   ═══════════════════════════════════════════════════════════════════ */

Q.openCoverage = (coverage, stats) => {
  Q.navigate('explore');
  const results = document.getElementById('explore-results');
  const focus = document.getElementById('explore-focus');
  Q.closeSide();

  const cov = coverage.coverage || {};
  const fc = cov.file_coverage || {};
  const ec = cov.entity_coverage || {};
  const gate = coverage.quality_gate || {};
  const mapping = coverage.mapping || {};
  const flowComp = coverage.flow_completeness || {};
  const bp = coverage.breakpoint_distribution || {};
  const g = (stats || {}).graph || {};
  const checks = gate.checks || gate.details || [];

  // Left panel: quality gate checks
  let listHTML = `<div class="section-label">✅ Quality Gate</div>`;
  if (gate.gate_passed != null) {
    listHTML += `<div style="padding:8px 10px;margin-bottom:8px;border-radius:var(--r);font-size:12px;font-weight:600;${gate.gate_passed ? 'background:var(--green-light);color:var(--green)' : 'background:var(--red-light);color:var(--red)'}">`;
    listHTML += `${gate.gate_passed ? '✓ PASSED' : '✗ FAILED'} — ${gate.checks_passed||0}/${gate.checks_total||0} checks`;
    listHTML += `</div>`;
  }
  if (Array.isArray(checks) && checks.length) {
    checks.forEach(c => {
      const passed = c.passed || c.status === 'pass';
      listHTML += `<div class="card" style="border-left:3px solid ${passed ? 'var(--green)' : 'var(--red)'}">`;
      listHTML += `<div class="card-title" style="font-size:11px">${passed ? '✓' : '✗'} ${Q.esc(c.name || c.check || 'Check')}</div>`;
      if (c.message || c.detail) listHTML += `<div class="card-meta">${Q.esc(Q.trunc(c.message || c.detail, 80))}</div>`;
      listHTML += `</div>`;
    });
  } else {
    listHTML += `<div class="muted" style="font-size:11px;padding:8px 0">No individual check details available.</div>`;
  }
  results.innerHTML = listHTML;

  // Right panel: full dashboard
  let h = '';

  // Header
  h += `<div class="node-header" style="border-left-color:var(--blue)">`;
  h += `<h2>📊 Coverage Dashboard</h2>`;
  h += `<div class="node-meta"><span class="muted">System-wide extraction quality, confidence, and flow metrics</span></div>`;
  h += `</div>`;

  // KPI row
  h += `<div class="cov-kpi-row">`;
  const kpis = [
    [g.nodes || 0, 'Entities'],
    [g.edges || 0, 'Relations'],
    [(stats||{}).flows || 0, 'Flows'],
    [`${((fc.eligible_yield||fc.extraction_rate||0)*100).toFixed(0)}%`, 'Yield'],
    [fc.total_scanned || 0, 'Files Scanned'],
    [fc.total_eligible || fc.total_parsed || 0, 'Eligible Files'],
  ];
  kpis.forEach(([v, l]) => {
    h += `<div class="cov-kpi"><div class="cov-kpi-val">${v}</div><div class="cov-kpi-label">${Q.esc(l)}</div></div>`;
  });
  h += `</div>`;

  // Entity coverage by layer
  const byLayer = ec.by_layer || {};
  if (Object.keys(byLayer).length) {
    h += `<div class="section-label">Entity Coverage by Layer</div>`;
    h += `<div class="cov-layer-grid">`;
    for (const [layer, data] of Object.entries(byLayer)) {
      const count = typeof data === 'number' ? data : (data.count || data.total || 0);
      h += `<div class="cov-layer-card">`;
      h += `<div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">${Q.layerBadge(layer)}<span style="font-weight:700;font-size:15px">${count}</span></div>`;
      if (data.types) {
        h += `<div style="font-size:10px;color:var(--fg-dim)">${Object.entries(data.types).map(([t,c])=>`${t}: ${c}`).join(' · ')}</div>`;
      }
      h += `</div>`;
    }
    h += `</div>`;
  }

  // Confidence distribution
  const confDist = ec.confidence_distribution || cov.confidence_distribution || {};
  if (Object.keys(confDist).length) {
    h += `<div class="section-label">Confidence Distribution</div>`;
    h += `<div class="cov-conf-bars">`;
    const buckets = [['exact','≥90%','var(--green)'],['strong','≥80%','#2563EB'],['inferred','≥60%','var(--orange)'],['weak','<60%','var(--red)']];
    const total = Object.values(confDist).reduce((s,v) => s + (typeof v === 'number' ? v : 0), 0) || 1;
    buckets.forEach(([key, label, color]) => {
      const val = confDist[key] || confDist[label] || 0;
      const pct = ((val / total) * 100).toFixed(1);
      h += `<div class="cov-conf-row">`;
      h += `<span class="cov-conf-label">${label}</span>`;
      h += `<div class="cov-conf-track"><div class="cov-conf-fill" style="width:${pct}%;background:${color}"></div></div>`;
      h += `<span class="cov-conf-val">${val} (${pct}%)</span>`;
      h += `</div>`;
    });
    h += `</div>`;
  }

  // Flow completeness
  h += `<div class="section-label">Flow Completeness</div>`;
  h += `<div class="cov-kpi-row">`;
  h += `<div class="cov-kpi"><div class="cov-kpi-val" style="color:var(--green)">${flowComp.complete||0}</div><div class="cov-kpi-label">Complete</div></div>`;
  h += `<div class="cov-kpi"><div class="cov-kpi-val" style="color:var(--orange)">${flowComp.partial||0}</div><div class="cov-kpi-label">Partial</div></div>`;
  h += `<div class="cov-kpi"><div class="cov-kpi-val">${flowComp.total||0}</div><div class="cov-kpi-label">Total</div></div>`;
  h += `</div>`;

  // Breakpoints by layer
  if (Object.keys(bp).length) {
    h += `<div class="section-label">Low-Confidence Breakpoints by Layer</div>`;
    h += `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">`;
    Object.entries(bp).forEach(([layer, count]) => {
      h += `<div style="display:flex;align-items:center;gap:4px">${Q.layerBadge(layer)}<span style="font-weight:700;font-size:13px;color:var(--orange)">${count}</span></div>`;
    });
    h += `</div>`;
  }

  // Mapping confidence
  const hopQuality = mapping.hop_quality || mapping.hops || {};
  if (Object.keys(hopQuality).length) {
    h += `<div class="section-label">Cross-Layer Mapping Quality</div>`;
    h += `<div class="cov-layer-grid">`;
    for (const [hop, data] of Object.entries(hopQuality)) {
      const avg = typeof data === 'number' ? data : (data.avg_confidence || data.average || 0);
      const count = typeof data === 'object' ? (data.count || data.total || 0) : '';
      h += `<div class="cov-layer-card">`;
      h += `<div style="font-size:11px;font-weight:600;color:var(--fg);margin-bottom:2px">${Q.esc(hop)}</div>`;
      h += `<div style="font-size:18px;font-weight:700;color:${avg >= 0.7 ? 'var(--green)' : avg >= 0.4 ? 'var(--orange)' : 'var(--red)'}">${(avg * 100).toFixed(0)}%</div>`;
      if (count) h += `<div style="font-size:10px;color:var(--fg-dim)">${count} mappings</div>`;
      h += `</div>`;
    }
    h += `</div>`;
  }

  // Extraction gaps
  const gaps = cov.gaps || [];
  if (gaps.length) {
    h += `<div class="section-label">Extraction Gaps (${gaps.length})</div>`;
    gaps.slice(0, 15).forEach(g => {
      const sevCls = g.severity === 'critical' ? 'sev-critical' : g.severity === 'warning' ? 'sev-high' : 'sev-low';
      h += `<div class="risk-gap-item">`;
      h += `<span class="sev-chip ${sevCls}" style="font-size:9px">${Q.esc(g.severity || 'info')}</span>`;
      h += `<span style="flex:1;font-size:12px">${Q.esc(g.message || g.file || g.description || JSON.stringify(g))}</span>`;
      h += `</div>`;
    });
    if (gaps.length > 15) h += `<div class="muted" style="font-size:11px;margin-top:4px">+${gaps.length - 15} more gaps</div>`;
  }

  focus.innerHTML = h;
};


/* ═══════════════════════════════════════════════════════════════════
   STRUCTURE VIEW — Sub-tabs: Code Tree | Graph | AST
   ═══════════════════════════════════════════════════════════════════ */

Q.openStructure = () => {
  Q.navigate('explore');
  const results = document.getElementById('explore-results');
  const focus = document.getElementById('explore-focus');
  Q.closeSide();
  results.innerHTML = `<div class="section-label">Structure</div>
    <div class="card selected" onclick="Q.structTab('codetree')"><div class="card-title">📂 Code Tree</div><div class="card-meta muted">Files → entities → cross-refs</div></div>
    <div class="card" onclick="Q.structTab('graph')"><div class="card-title">🕸 System Graph</div><div class="card-meta muted">Force-directed node graph</div></div>
    <div class="card" onclick="Q.structTab('ast')"><div class="card-title">🌳 AST Methods</div><div class="card-meta muted">Structural summaries</div></div>
    <div class="card" onclick="Q.structTab('arch')"><div class="card-title">🏗 Architecture</div><div class="card-meta muted">Layer diagram · repo dependencies</div></div>
    <div id="graph-left-controls" style="display:none"></div>`;
  Q.structTab('codetree');
};

Q.structTab = tab => {
  document.querySelectorAll('#explore-results .card').forEach((c,i) => {
    c.classList.toggle('selected', ['codetree','graph','ast','arch'][i] === tab);
  });
  const gCtrl = document.getElementById('graph-left-controls');
  if (gCtrl) gCtrl.style.display = tab === 'graph' ? '' : 'none';
  const focus = document.getElementById('explore-focus');
  focus.innerHTML = Q.loadingHTML();
  if (tab === 'codetree') Q.loadCodeTree(focus);
  else if (tab === 'graph') Q.loadSystemGraph(focus);
  else if (tab === 'ast') Q.loadAstView(focus);
  else if (tab === 'arch') Q.loadArchDiagram(focus);
};

// ── Code Tree (d3 top-down hierarchy) ───────────────────────────────
Q.loadCodeTree = async el => {
  try {
    const data = await Q.api('/codetree');
    const tree = data.tree || {};
    window._ctTreeData = tree;
    const repos = Object.keys(tree).sort();

    let html = `<div class="section-label">📂 Code Tree — ${data.total_repos} repos · ${data.total_files} files · ${data.total_nodes} entities</div>`;
    html += `<div class="ct-picker">`;
    html += `<div class="ct-picker-label">Select a repository to visualize</div>`;
    html += `<div class="ct-picker-grid">`;
    repos.forEach(r => {
      const files = Object.keys(tree[r]).length;
      const entities = Object.values(tree[r]).reduce((s, a) => s + a.length, 0);
      html += `<div class="ct-picker-card" onclick="Q.renderTreeForRepo('${Q.esc(r)}')">
        <div class="ct-picker-card-name">${Q.esc(r)}</div>
        <div class="ct-picker-card-meta">${files} files · ${entities} entities</div>
      </div>`;
    });
    html += `</div></div>`;
    html += `<div id="ct-vis-area"></div>`;
    el.innerHTML = html;
  } catch (e) { el.innerHTML = Q.emptyHTML('Failed: ' + e.message); }
};

Q.renderTreeForRepo = repo => {
  const area = document.getElementById('ct-vis-area');
  const tree = window._ctTreeData;
  if (!area || !tree || !tree[repo]) return;

  let html = `<div style="display:flex;gap:8px;margin:16px 0 12px;align-items:center">`;
  html += `<button class="btn-ghost btn-sm" onclick="Q.structTab('codetree')">← All repos</button>`;
  html += `<span style="font-weight:700;font-size:13px">${Q.esc(repo)}</span>`;
  html += `<input type="text" id="ct-filter" placeholder="Filter files or entities…" class="search-input" style="flex:1;padding:7px 12px;font-size:12px" oninput="Q._reRenderTree('${Q.esc(repo)}')">`;
  html += `</div>`;
  html += `<div id="ct-vis" class="ct-vis-wrap"></div>`;
  area.innerHTML = html;

  // Hide the picker
  const picker = area.parentElement.querySelector('.ct-picker');
  if (picker) picker.style.display = 'none';

  Q._drawRepoTree(repo);
};

Q._reRenderTree = repo => Q._drawRepoTree(repo);

Q._drawRepoTree = repo => {
  const wrap = document.getElementById('ct-vis');
  const tree = window._ctTreeData;
  if (!wrap || !tree || !tree[repo]) return;
  wrap.innerHTML = '';
  const files = tree[repo];
  const q = (document.getElementById('ct-filter')?.value || '').toLowerCase();

  // Build hierarchy: repo → dirs → files → entities
  const repoNode = { name: repo, _type: 'repo', children: [] };
  const dirMap = {};
  for (const [fpath, nodes] of Object.entries(files)) {
    const parts = fpath.split('/');
    const fname = parts.pop();
    const dir = parts.join('/') || '.';
    if (!dirMap[dir]) { dirMap[dir] = { name: dir.split('/').pop() || dir, _type: 'dir', _fullDir: dir, children: [] }; repoNode.children.push(dirMap[dir]); }
    const filteredNodes = q ? nodes.filter(n => (n.label||'').toLowerCase().includes(q) || (n.type||'').toLowerCase().includes(q) || fname.toLowerCase().includes(q)) : nodes;
    if (q && !filteredNodes.length && !fname.toLowerCase().includes(q)) continue;
    const fileNode = { name: fname, _type: 'file', children: [] };
    const show = filteredNodes.length ? filteredNodes : nodes;
    show.slice(0, 12).forEach(n => {
      fileNode.children.push({ name: (n.label||'').split('::').pop() || n.id, _type: 'entity', _layer: n.layer, _entityType: n.type, _id: n.id, _conf: n.confidence });
    });
    if (show.length > 12) fileNode.children.push({ name: `+${show.length - 12} more`, _type: 'overflow' });
    dirMap[dir].children.push(fileNode);
  }
  // Remove empty dirs
  repoNode.children = repoNode.children.filter(d => d.children.length);
  if (!repoNode.children.length) { wrap.innerHTML = '<div class="empty"><div class="empty-text">No matching files</div></div>'; return; }

  const hierarchy = d3.hierarchy(repoNode);
  const dx = 22, dy = 190;
  d3.tree().nodeSize([dx, dy])(hierarchy);

  let x0 = Infinity, x1 = -Infinity;
  hierarchy.each(d => { if (d.x < x0) x0 = d.x; if (d.x > x1) x1 = d.x; });
  const W = (hierarchy.height + 1) * dy + 80;
  const H = x1 - x0 + dx * 3;

  const svg = d3.select(wrap).append('svg').attr('width', W).attr('height', H)
    .attr('viewBox', [-40, x0 - dx, W, H]).attr('style', 'max-width:100%;height:auto;overflow:visible');
  const g = svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.3, 3]).on('zoom', e => g.attr('transform', e.transform)));

  const LC = { ui:'#2563EB', bff:'#7C3AED', api:'#059669', db:'#D46B08', config:'#64748B' };

  // Links
  g.append('g').attr('fill','none').attr('stroke','var(--border)').attr('stroke-width',1)
    .selectAll('path').data(hierarchy.links()).join('path')
    .attr('d', d3.linkHorizontal().x(d=>d.y).y(d=>d.x));

  // Nodes
  const node = g.append('g').selectAll('g').data(hierarchy.descendants()).join('g')
    .attr('transform', d => `translate(${d.y},${d.x})`)
    .attr('cursor', d => d.data._type === 'entity' ? 'pointer' : 'default')
    .on('click', (e, d) => { if (d.data._type === 'entity' && d.data._id) Q.openNode(d.data._id); });

  node.append('circle').attr('r', d => {
    const t = d.data._type;
    return t === 'repo' ? 8 : t === 'dir' ? 5 : t === 'file' ? 4 : t === 'entity' ? 3.5 : 2;
  }).attr('fill', d => {
    const t = d.data._type;
    if (t === 'entity') return LC[(d.data._layer||'').toLowerCase()] || '#888';
    if (t === 'repo') return '#CC0000';
    if (t === 'dir') return '#64748B';
    if (t === 'file') return '#1A1917';
    return '#A8A49E';
  }).attr('stroke', '#fff').attr('stroke-width', d => d.data._type === 'repo' ? 2 : 1);

  node.append('text')
    .attr('dy', '0.32em')
    .attr('x', d => d.children ? -10 : 8)
    .attr('text-anchor', d => d.children ? 'end' : 'start')
    .attr('font-size', d => {
      const t = d.data._type;
      return t === 'repo' ? '12px' : t === 'dir' ? '10px' : t === 'file' ? '10px' : '9px';
    })
    .attr('font-weight', d => d.data._type === 'repo' ? '700' : d.data._type === 'file' ? '600' : '400')
    .attr('fill', d => {
      const t = d.data._type;
      if (t === 'entity') return LC[(d.data._layer||'').toLowerCase()] || 'var(--fg-2)';
      if (t === 'overflow') return 'var(--fg-dim)';
      return 'var(--fg)';
    })
    .text(d => Q.trunc(d.data.name, d.data._type === 'entity' ? 35 : 28));

  node.filter(d => d.data._type === 'entity' && d.data._entityType)
    .append('text').attr('dy', '0.32em')
    .attr('x', d => 8 + Math.min((d.data.name||'').length, 35) * 5.5 + 8)
    .attr('font-size', '8px').attr('fill', 'var(--fg-dim)').text(d => d.data._entityType);
};

Q.filterTreeVis = () => {}; // no-op, kept for compat

Q.ctToggle = (id, headEl) => {
  const body = document.getElementById(id);
  if (!body) return;
  const open = body.classList.toggle('open');
  if (headEl) headEl.classList.toggle('open', open);
};

// ── System Graph ────────────────────────────────────────────────────
Q.loadSystemGraph = async el => {
  // Put controls in left panel
  const leftCtrl = document.getElementById('graph-left-controls');
  if (leftCtrl) {
    let lh = `<div class="graph-left-section">`;
    lh += `<div class="section-label" style="margin-top:12px">\u2699 Graph Settings</div>`;
    lh += `<div class="graph-ctrl-group"><label class="graph-ctrl-label">Mode</label><select id="g-mode" onchange="Q.reloadGraph()"><option value="full" selected>All Nodes</option><option value="flows">Flow Paths</option></select></div>`;
    lh += `<div class="graph-ctrl-group"><label class="graph-ctrl-label">Layer</label><select id="g-layer" onchange="Q.reloadGraph()"><option value="">All Layers</option></select></div>`;
    lh += `<div class="graph-ctrl-group"><label class="graph-ctrl-label">Limit</label><select id="g-limit" onchange="Q.reloadGraph()"><option value="200">200</option><option value="500">500</option><option value="1000" selected>1000</option><option value="5000">5000</option><option value="10000">10000</option><option value="25000">25000</option><option value="100000">100000</option></select></div>`;
    lh += `<div class="graph-ctrl-group" style="flex-direction:row;gap:4px"><button class="btn-ghost btn-sm" style="flex:1" onclick="Q.reloadGraph()">Reload</button><button class="btn-ghost btn-sm" style="flex:1" onclick="Q.graphFitView()">\u229e Fit</button></div>`;
    lh += `<div id="g-pills" class="layer-pills"></div>`;
    lh += `<div id="g-depth-bar" class="g-depth-bar" style="display:none">
    <div class="g-mode-toggle">
      <button class="g-mode-btn active" data-hlmode="flow" onclick="Q._setHLMode('flow')">Full Flow</button>
      <button class="g-mode-btn" data-hlmode="depth" onclick="Q._setHLMode('depth')">Hop Depth</button>
    </div>
    <div id="g-depth-btns" class="g-depth-btns" style="display:none">
      <button class="g-depth-btn active" data-depth="1" onclick="Q._setGraphDepth(1)">1</button>
      <button class="g-depth-btn" data-depth="2" onclick="Q._setGraphDepth(2)">2</button>
      <button class="g-depth-btn" data-depth="3" onclick="Q._setGraphDepth(3)">3</button>
      <button class="g-depth-btn" data-depth="4" onclick="Q._setGraphDepth(4)">4</button>
    </div>
    <button class="btn-ghost btn-sm" onclick="Q._clearGraphHL()">Reset</button>
    <span id="g-depth-info" class="muted" style="margin-left:6px;font-size:10px"></span>
  </div>`;
    lh += `</div>`;
    leftCtrl.innerHTML = lh;
    leftCtrl.style.display = '';
  }
  // Graph canvas with floating repo controls
  let html = `<div class="graph-canvas-wrap">`;
  html += `<div id="g-canvas" class="graph-canvas">${Q.loadingHTML()}</div>`;
  html += `<div class="graph-repo-btn"><div class="repo-dd-wrap" id="repo-dd-wrap"><button class="btn-ghost btn-sm" onclick="Q._toggleRepoDd()">\u25bc Repos</button><div class="repo-dd" id="repo-dd" style="display:none"><input type="text" class="repo-dd-search" id="repo-dd-search" placeholder="Search repos\u2026" oninput="Q._filterRepoDd()"><div class="repo-dd-list" id="repo-dd-list"></div></div></div></div>`;
  html += `<div id="g-repo-tags" class="graph-repo-panel"></div>`;
  html += `</div>`;
  el.innerHTML = html;
  Q.reloadGraph();
};

Q.reloadGraph = async () => {
  const canvas = document.getElementById('g-canvas');
  if (!canvas) return;
  canvas.innerHTML = Q.loadingHTML();
  const mode = document.getElementById('g-mode')?.value || 'flows';
  const layer = document.getElementById('g-layer')?.value || '';
  const limit = document.getElementById('g-limit')?.value || '500';
  try {
    let data;
    if (mode === 'flows') data = await Q.api('/graph/flows?limit=' + limit);
    else {
      const p = new URLSearchParams({limit}); if (layer) p.set('layer', layer);
      data = await Q.api('/graph/full?' + p);
    }
    Q._renderForceGraph(canvas, data, mode);
  } catch (e) { canvas.innerHTML = Q.emptyHTML('Failed: ' + e.message); }
};

Q._renderForceGraph = (canvas, data, mode) => {
  canvas.innerHTML = '';
  const nodes = data.nodes || [], edges = data.edges || [];
  if (!nodes.length) { canvas.innerHTML = Q.emptyHTML('No nodes.'); return; }
  const W = canvas.clientWidth || 800, H = canvas.clientHeight || 500;
  const LC = {ui:'#1A73E8',bff:'#7B1FA2',api:'#1B7D3A',db:'#E37400',config:'#607D8B',shared:'#E91E63'};
  const color = n => LC[(n.layer||'').toLowerCase()] || '#888';
  const r = n => Math.max(3, Math.min(10, 3 + (n.confidence||0)*7));

  // Layer pills
  const layers = [...new Set(nodes.map(n=>(n.layer||'').toLowerCase()).filter(Boolean))];
  // Populate layer dropdown dynamically from actual graph data
  const layerSel = document.getElementById('g-layer');
  if (layerSel) {
    const curVal = layerSel.value;
    layerSel.innerHTML = '<option value="">All Layers</option>';
    layers.forEach(l => {
      const opt = document.createElement('option');
      opt.value = l; opt.textContent = l.toUpperCase();
      if (l === curVal) opt.selected = true;
      layerSel.appendChild(opt);
    });
  }
  const pills = document.getElementById('g-pills');
  if (pills) {
    pills.innerHTML = layers.map(l => {
      const c = nodes.filter(n=>(n.layer||'').toLowerCase()===l).length;
      return `<span class="layer-pill" data-layer="${l}"><span class="lp-dot" style="background:${LC[l]||'#888'}"></span>${l.toUpperCase()} <span class="lp-count">${c}</span></span>`;
    }).join('');
    pills.querySelectorAll('.layer-pill').forEach(p => p.addEventListener('click', () => {
      p.classList.toggle('dim');
      Q._applyGraphFilter();
    }));
  }

  const svg = d3.select(canvas).append('svg').attr('width','100%').attr('height','100%').attr('viewBox',[0,0,W,H]);
  const defs = svg.append('defs');
  defs.append('marker').attr('id','ga').attr('viewBox','0 -4 8 8').attr('refX',14).attr('refY',0)
    .attr('markerWidth',5).attr('markerHeight',5).attr('orient','auto')
    .append('path').attr('d','M0,-4L8,0L0,4').attr('fill','#CCC');

  const g = svg.append('g');
  const gZoom = d3.zoom().scaleExtent([0.05,6]).on('zoom',e=>g.attr('transform',e.transform));
  svg.call(gZoom);
  svg.on('click', () => Q._clearGraphHL());

  // Store refs for fit-view
  Q._gSvg = svg; Q._gG = g; Q._gZoom = gZoom; Q._gW = W; Q._gH = H;

  const nd = nodes.map(n=>({...n}));
  const byId = Object.fromEntries(nd.map(n=>[n.id,n]));
  const ld = edges.filter(e=>byId[e.source]&&byId[e.target]).map(e=>({...e,source:byId[e.source],target:byId[e.target]}));

  const link = g.append('g').selectAll('line').data(ld).join('line')
    .attr('stroke',d=>d.completeness==='complete'?'#1B7D3A':'#CCC').attr('stroke-width',d=>d.completeness==='complete'?1.5:1)
    .attr('stroke-opacity',.5).attr('marker-end','url(#ga)');

  const node = g.append('g').selectAll('g').data(nd).join('g').attr('cursor','pointer')
    .on('click',(e,d)=>{e.stopPropagation();Q._hlGraphNode(d.id,nd,ld,node,link)})
    .on('dblclick',(e,d)=>{e.stopPropagation();Q.openNode(d.id)})
    .call(d3.drag().on('start',(e,d)=>{if(!e.active)sim.alphaTarget(.3).restart();d.fx=d.x;d.fy=d.y}).on('drag',(e,d)=>{d.fx=e.x;d.fy=e.y}).on('end',(e,d)=>{if(!e.active)sim.alphaTarget(0);d.fx=null;d.fy=null}));

  node.append('circle').attr('r',d=>r(d)).attr('fill',d=>color(d)).attr('stroke','#fff').attr('stroke-width',1.2);
  node.filter(d=>(d.confidence||0)>=.5).append('text').attr('dy',d=>-r(d)-3).attr('text-anchor','middle')
    .attr('font-size','8px').attr('fill','#555').attr('pointer-events','none')
    .text(d=>{const l=(d.label||d.id||'').split('::').pop();return l.length>18?l.slice(0,16)+'…':l});
  node.append('title').text(d=>`${d.label||d.id}\n${(d.layer||'').toUpperCase()} · ${d.type||''}\nConf: ${((d.confidence||0)*100).toFixed(0)}%\n\nClick=highlight · Dbl-click=open`);

  const LAYER_Y = {ui:.15,bff:.35,api:.6,db:.85,config:.5};
  // Group nodes by repo for vertical separation
  const repos = [...new Set(nd.map(n=>n.repo||'unknown').filter(Boolean))].sort();
  const repoCount = repos.length;
  const repoIdx = {}; repos.forEach((r,i)=>{repoIdx[r]=i;});
  const repoSlotW = repoCount>1 ? W/(repoCount) : W;
  const sim = d3.forceSimulation(nd)
    .force('link',d3.forceLink(ld).id(d=>d.id).distance(70).strength(.3))
    .force('charge',d3.forceManyBody().strength(-200).distanceMax(350))
    .force('center',d3.forceCenter(W/2,H/2).strength(.08))
    .force('collide',d3.forceCollide().radius(d=>r(d)+5))
    .force('y',mode==='flows'?d3.forceY(d=>H*(LAYER_Y[(d.layer||'').toLowerCase()]||.5)).strength(.35):d3.forceY(H/2).strength(.04))
    .force('x-repo',repoCount>1?d3.forceX(d=>{const ri=repoIdx[d.repo||'unknown']??0;return repoSlotW*(ri+0.5);}).strength(.12):null)
    .on('tick',()=>{
      link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
      node.attr('transform',d=>`translate(${d.x},${d.y})`);
    });
  setTimeout(()=>{ sim.alphaTarget(0); setTimeout(()=>{
    Q.graphFitView();
    // Draw repo separator lines after layout settles
    if(repoCount>1){
      const sepG=g.insert('g',':first-child').attr('class','repo-separators');
      // Compute actual x-boundaries per repo from node positions
      const repoBounds={};
      nd.forEach(n=>{const rp=n.repo||'unknown';if(!repoBounds[rp])repoBounds[rp]={minX:Infinity,maxX:-Infinity};if(isFinite(n.x)){repoBounds[rp].minX=Math.min(repoBounds[rp].minX,n.x);repoBounds[rp].maxX=Math.max(repoBounds[rp].maxX,n.x);}});
      const allYs=nd.map(n=>n.y).filter(v=>isFinite(v));
      const yMin=Math.min(...allYs)-60, yMax=Math.max(...allYs)+60;
      // Sort repos by their center x
      const sortedRepos=repos.filter(r=>repoBounds[r]).sort((a,b)=>{const ca=(repoBounds[a].minX+repoBounds[a].maxX)/2;const cb=(repoBounds[b].minX+repoBounds[b].maxX)/2;return ca-cb;});
      // Draw vertical lines between adjacent repos and labels at top
      const RCOL=Q._RCOL;
      for(let i=0;i<sortedRepos.length;i++){
        const rp=sortedRepos[i], b=repoBounds[rp];
        const cx=(b.minX+b.maxX)/2;
        const col=RCOL[i%RCOL.length];
        sepG.append('text').attr('x',cx).attr('y',yMin-10).attr('text-anchor','middle')
          .attr('class','repo-sep-label').attr('data-repo',rp)
          .attr('font-size','11px').attr('font-weight','700').attr('fill',col).attr('opacity',0)
          .text(rp);
        // Vertical separator line between this and next repo
        if(i<sortedRepos.length-1){
          const nextB=repoBounds[sortedRepos[i+1]];
          const sepX=(b.maxX+nextB.minX)/2;
          sepG.append('line').attr('x1',sepX).attr('y1',yMin-25).attr('x2',sepX).attr('y2',yMax+10)
            .attr('class','repo-sep-line').attr('data-repo-left',sortedRepos[i]).attr('data-repo-right',sortedRepos[i+1])
            .attr('stroke','#3a3a5e').attr('stroke-width',1.5).attr('stroke-dasharray','6,4').attr('opacity',0);
        }
        // Light background rect per repo zone
        const x0=i===0?b.minX-40:(repoBounds[sortedRepos[i-1]].maxX+b.minX)/2;
        const x1=i===sortedRepos.length-1?b.maxX+40:(b.maxX+repoBounds[sortedRepos[i+1]].minX)/2;
        sepG.append('rect').attr('x',x0).attr('y',yMin-30).attr('width',x1-x0).attr('height',yMax-yMin+70)
          .attr('class','repo-sep-rect').attr('data-repo',rp).attr('fill',col).attr('opacity',0).attr('rx',8);
      }
    }
  },500); },2500);

  // Store refs for graph interaction
  Q._gNode = node; Q._gLink = link; Q._gData = nd; Q._gEdges = ld;
  Q._gFlowData = data.flows || [];
  Q._gSelectedId = null; Q._gDepth = 1; Q._gHLMode = 'flow';

  // Build repo checkbox dropdown
  Q._activeRepos = new Set();
  Q._allRepos = repos;
  Q._repoColors = {};
  Q._repoCounts = {};
  repos.forEach((rp,i) => {
    Q._repoColors[rp] = Q._RCOL[i % Q._RCOL.length];
    Q._repoCounts[rp] = nd.filter(n=>(n.repo||'unknown')===rp).length;
  });
  Q._renderRepoDdList();
  Q._renderRepoTags();
};

Q._toggleRepoDd = () => {
  const dd = document.getElementById('repo-dd');
  if (!dd) return;
  const open = dd.style.display === 'none';
  dd.style.display = open ? '' : 'none';
  if (open) { document.getElementById('repo-dd-search')?.focus(); Q._renderRepoDdList(); }
};

Q._filterRepoDd = () => Q._renderRepoDdList();

Q._renderRepoDdList = () => {
  const list = document.getElementById('repo-dd-list');
  if (!list) return;
  const q = (document.getElementById('repo-dd-search')?.value || '').toLowerCase();
  const repos = Q._allRepos || [];
  const active = Q._activeRepos || new Set();
  const filtered = q ? repos.filter(r => r.toLowerCase().includes(q)) : repos;
  list.innerHTML = filtered.map(rp => {
    const col = Q._repoColors[rp] || '#888';
    const cnt = Q._repoCounts[rp] || 0;
    const chk = active.has(rp) ? 'checked' : '';
    return '<label style="display:flex;align-items:center;gap:6px;padding:5px 8px;cursor:pointer;font-size:11px;border-bottom:1px solid var(--surface-2)">'
      + '<input type="checkbox" ' + chk + ' onchange="Q._onRepoCheck(\'' + Q.esc(rp) + '\',this.checked)">'
      + '<span style="width:8px;height:8px;border-radius:50%;background:' + col + ';flex-shrink:0"></span>'
      + '<span style="flex:1">' + Q.esc(rp) + '</span>'
      + '<span style="color:var(--fg-dim);font-size:10px">' + cnt + '</span></label>';
  }).join('');
};

Q._onRepoCheck = (repo, checked) => {
  if (checked) Q._activeRepos.add(repo); else Q._activeRepos.delete(repo);
  Q._renderRepoTags();
  Q._applyRepoFilter();
};

Q._renderRepoTags = () => {
  const el = document.getElementById('g-repo-tags');
  if (!el) return;
  const active = Q._activeRepos || new Set();
  if (active.size === 0) {
    el.classList.remove('open');
    el.innerHTML = '';
    return;
  }
  el.classList.add('open');
  let h = '<div class="grp-head"><span class="grp-title">Selected Repos</span><span class="grp-clear" onclick="Q._activeRepos.clear();Q._renderRepoTags();Q._renderRepoDdList();Q._applyRepoFilter()">Clear all</span></div>';
  active.forEach(rp => {
    const col = Q._repoColors[rp] || '#888';
    const cnt = Q._repoCounts[rp] || 0;
    h += '<div class="grp-item">';
    h += '<span class="grp-dot" style="background:' + col + '"></span>';
    h += '<span class="grp-name">' + Q.esc(rp) + '</span>';
    h += '<span class="grp-cnt">' + cnt + '</span>';
    h += '<span class="grp-x" onclick="event.stopPropagation();Q._onRepoCheck(\'' + Q.esc(rp) + '\',false);Q._renderRepoDdList()">&times;</span>';
    h += '</div>';
  });
  el.innerHTML = h;
};

document.addEventListener('click', e => {
  if (!e.target.closest('.repo-dd-wrap')) {
    const dd = document.getElementById('repo-dd');
    if (dd) dd.style.display = 'none';
  }
});

Q._applyRepoFilter = () => {
  if (!Q._gNode) return;
  const active = Q._activeRepos || new Set();
  const isAll = active.size === 0;
  Q._gNode.select('circle').transition().duration(300)
    .attr('opacity', d => isAll || active.has(d.repo||'unknown') ? 1 : .06);
  Q._gNode.select('text').transition().duration(300)
    .attr('opacity', d => isAll || active.has(d.repo||'unknown') ? 1 : .03);
  Q._gLink.transition().duration(300)
    .attr('stroke-opacity', d => {
      if (isAll) return d.completeness === 'complete' ? .6 : .5;
      const s = d.source.repo||'unknown', t = d.target.repo||'unknown';
      return active.has(s) || active.has(t) ? .7 : .03;
    });
  if (Q._gG) {
    // Separator rects: only visible for selected repos
    Q._gG.selectAll('.repo-sep-rect').transition().duration(300)
      .attr('opacity', function() { return isAll ? 0 : active.has(this.dataset.repo) ? .08 : 0; });
    // Separator lines (dashed): only visible when repos selected
    Q._gG.selectAll('line[stroke-dasharray]').transition().duration(300)
      .attr('opacity', isAll ? 0 : .5);
    // Repo labels at top: only visible for selected repos
    Q._gG.selectAll('.repo-sep-label').transition().duration(300)
      .attr('opacity', function() { return isAll ? 0 : active.has(this.dataset.repo) ? .8 : 0; });
  }
};

Q._filterRepo = repo => { Q._onRepoCheck(repo, !Q._activeRepos.has(repo)); Q._renderRepoDdList(); };


Q.graphFitView = () => {
  if (!Q._gSvg || !Q._gData || !Q._gZoom) return;
  const nodes = Q._gData;
  const xs = nodes.map(n=>n.x).filter(v=>isFinite(v));
  const ys = nodes.map(n=>n.y).filter(v=>isFinite(v));
  if (!xs.length) return;
  const x0=Math.min(...xs), x1=Math.max(...xs), y0=Math.min(...ys), y1=Math.max(...ys);
  const pad=50, bw=(x1-x0)+pad*2||1, bh=(y1-y0)+pad*2||1;
  const W=Q._gW, H=Q._gH;
  const scale=Math.min(W/bw, H/bh, 2.5)*0.9;
  const tx=W/2-(x0+x1)/2*scale, ty=H/2-(y0+y1)/2*scale;
  Q._gSvg.transition().duration(600).call(Q._gZoom.transform, d3.zoomIdentity.translate(tx,ty).scale(scale));
};

// ── Graph: highlight mode toggle ─────────────────────────────────
Q._setHLMode = mode => {
  Q._gHLMode = mode;
  document.querySelectorAll('.g-mode-btn').forEach(b => b.classList.toggle('active', b.dataset.hlmode === mode));
  document.getElementById('g-depth-btns').style.display = mode === 'depth' ? 'flex' : 'none';
  if (Q._gSelectedId) Q._applyHL();
};

// ── Graph: click node → highlight based on current mode ─────────
Q._hlGraphNode = (id, nd, ld, nodeSel, linkSel) => {
  Q._gSelectedId = id;
  Q._gDepth = 1;
  document.getElementById('g-depth-bar').style.display = 'flex';
  document.querySelectorAll('.g-depth-btn').forEach(b => b.classList.toggle('active', b.dataset.depth === '1'));
  Q._applyHL();
};

Q._setGraphDepth = depth => {
  Q._gDepth = depth;
  document.querySelectorAll('.g-depth-btn').forEach(b => b.classList.toggle('active', parseInt(b.dataset.depth) === depth));
  Q._applyHL();
};

// ── Unified highlight dispatcher ───────────────────────────────
Q._applyHL = () => {
  if (Q._gHLMode === 'flow') Q._applyFlowHL();
  else Q._applyDepthHL();
};

// ── Full Flow highlight: light up every node in the same flow(s) ──
Q._applyFlowHL = () => {
  const id = Q._gSelectedId;
  if (!id || !Q._gNode) return;
  const nodeSel = Q._gNode, linkSel = Q._gLink, nd = Q._gData;

  // Find which flows this node belongs to
  const clickedNode = nd.find(n => n.id === id);
  const nodeFlowIds = new Set(clickedNode?.flow_ids || []);

  // If no flow data on nodes, fall back to edge flow_id
  if (!nodeFlowIds.size) {
    Q._gEdges.forEach(e => {
      const s = e.source.id || e.source, t = e.target.id || e.target;
      if ((s === id || t === id) && e.flow_id) nodeFlowIds.add(e.flow_id);
    });
  }

  // Collect all nodes that share any of these flows
  const flowNodes = new Set([id]);
  if (nodeFlowIds.size) {
    nd.forEach(n => {
      const nf = n.flow_ids || [];
      if (nf.some(f => nodeFlowIds.has(f))) flowNodes.add(n.id);
    });
    // Also check edges with matching flow_id
    Q._gEdges.forEach(e => {
      if (e.flow_id && nodeFlowIds.has(e.flow_id)) {
        const s = e.source.id || e.source, t = e.target.id || e.target;
        flowNodes.add(s); flowNodes.add(t);
      }
    });
  }

  // Apply visuals
  nodeSel.select('circle')
    .attr('opacity', d => flowNodes.has(d.id) ? 1 : .06)
    .attr('stroke', d => d.id === id ? '#CC0000' : flowNodes.has(d.id) ? '#1B7D3A' : '#fff')
    .attr('stroke-width', d => d.id === id ? 3 : flowNodes.has(d.id) ? 2.5 : 1.2);
  nodeSel.select('text').attr('opacity', d => flowNodes.has(d.id) ? 1 : .04);
  linkSel
    .attr('stroke-opacity', d => {
      const s = d.source.id || d.source, t = d.target.id || d.target;
      return flowNodes.has(s) && flowNodes.has(t) ? .9 : .03;
    })
    .attr('stroke', d => {
      const s = d.source.id || d.source, t = d.target.id || d.target;
      if (flowNodes.has(s) && flowNodes.has(t)) return '#1B7D3A';
      return '#CCC';
    })
    .attr('stroke-width', d => {
      const s = d.source.id || d.source, t = d.target.id || d.target;
      return flowNodes.has(s) && flowNodes.has(t) ? 2.5 : 1;
    });

  const info = document.getElementById('g-depth-info');
  if (info) info.textContent = `${flowNodes.size} nodes in ${nodeFlowIds.size} flow${nodeFlowIds.size !== 1 ? 's' : ''}`;
};

// ── Hop Depth highlight: BFS from selected node ────────────────
Q._applyDepthHL = () => {
  const id = Q._gSelectedId;
  if (!id || !Q._gNode) return;
  const nd = Q._gData, ld = Q._gEdges, nodeSel = Q._gNode, linkSel = Q._gLink;
  const depth = Q._gDepth;

  // BFS from selected node up to `depth` hops
  const adj = {};
  ld.forEach(e => {
    const s = e.source.id || e.source, t = e.target.id || e.target;
    (adj[s] = adj[s] || []).push(t);
    (adj[t] = adj[t] || []).push(s);
  });

  const visited = new Map(); // id -> depth
  visited.set(id, 0);
  const queue = [id];
  let qi = 0;
  while (qi < queue.length) {
    const cur = queue[qi++];
    const curD = visited.get(cur);
    if (curD >= depth) continue;
    for (const nb of (adj[cur] || [])) {
      if (!visited.has(nb)) {
        visited.set(nb, curD + 1);
        queue.push(nb);
      }
    }
  }

  // Depth-based coloring
  const DCOL = ['#CC0000','#E37400','#F9AB00','#2563EB','#7C3AED'];
  nodeSel.select('circle')
    .attr('opacity', d => visited.has(d.id) ? 1 : .06)
    .attr('stroke', d => {
      if (d.id === id) return '#CC0000';
      const dd = visited.get(d.id);
      return dd != null ? DCOL[Math.min(dd, DCOL.length-1)] : '#fff';
    })
    .attr('stroke-width', d => d.id === id ? 3 : visited.has(d.id) ? 2 : 1.2);
  nodeSel.select('text').attr('opacity', d => visited.has(d.id) ? 1 : .04);
  linkSel
    .attr('stroke-opacity', d => {
      const s = d.source.id || d.source, t = d.target.id || d.target;
      return visited.has(s) && visited.has(t) ? .8 : .03;
    })
    .attr('stroke', d => {
      const s = d.source.id || d.source, t = d.target.id || d.target;
      if (!visited.has(s) || !visited.has(t)) return '#CCC';
      const maxD = Math.max(visited.get(s)||0, visited.get(t)||0);
      return DCOL[Math.min(maxD, DCOL.length-1)];
    })
    .attr('stroke-width', d => {
      const s = d.source.id || d.source, t = d.target.id || d.target;
      return visited.has(s) && visited.has(t) ? 2 : 1;
    });

  // Info
  const info = document.getElementById('g-depth-info');
  if (info) info.textContent = `${visited.size} nodes at ≤${depth} hops`;
};

Q._clearGraphHL = () => {
  Q._gSelectedId = null;
  const bar = document.getElementById('g-depth-bar');
  if (bar) bar.style.display = 'none';
  if (!Q._gNode) return;
  Q._gNode.select('circle').attr('opacity', 1).attr('stroke', '#fff').attr('stroke-width', 1.2);
  Q._gNode.select('text').attr('opacity', 1);
  Q._gLink.attr('stroke-opacity', .5).attr('stroke', d => d.completeness === 'complete' ? '#1B7D3A' : '#CCC').attr('stroke-width', d => d.completeness === 'complete' ? 1.5 : 1);
  const info = document.getElementById('g-depth-info');
  if (info) info.textContent = '';
};
Q._applyGraphFilter = () => {
  if(!Q._gNode)return;
  const dimmed = new Set();
  document.querySelectorAll('.layer-pill.dim').forEach(p=>dimmed.add(p.dataset.layer));
  Q._gNode.select('circle').attr('opacity',d=>dimmed.has((d.layer||'').toLowerCase())?.06:1);
  Q._gNode.select('text').attr('opacity',d=>dimmed.has((d.layer||'').toLowerCase())?.03:1);
  Q._gLink.attr('stroke-opacity',d=>{
    const sl=(d.source.layer||'').toLowerCase(),tl=(d.target.layer||'').toLowerCase();
    return dimmed.has(sl)||dimmed.has(tl)?.03:.5;
  });
};

// ── Architecture Diagram ───────────────────────────────────────────────
Q._archMode = 'system';

Q.loadArchDiagram = async el => {
  try {
    const data = await Q.api('/repos');
    Q._archData = data;
    Q._archEl = el;
    Q._renderArchWithToggle(el, data);
  } catch (e) { el.innerHTML = Q.emptyHTML('Failed: ' + e.message); }
};

Q._renderArchWithToggle = (el, data) => {
  const repos = data.repos || [], edges = data.edges || [];
  if (!repos.length) { el.innerHTML = Q.emptyHTML('No repos found.'); return; }
  let html = '<div style="display:flex;align-items:center;gap:6px;margin-bottom:14px">';
  html += '<span style="font-size:11px;font-weight:600;color:var(--fg-3)">View:</span>';
  html += '<button class="btn-ghost btn-sm' + (Q._archMode==='system'?' arch-active':'') + '" onclick="Q._setArchMode(\'system\')">Component Diagram</button>';
  html += '<button class="btn-ghost btn-sm' + (Q._archMode==='repo'?' arch-active':'') + '" onclick="Q._setArchMode(\'repo\')">Repo Level</button>';
  html += '</div><div id="arch-render-area"></div>';
  el.innerHTML = html;
  const area = document.getElementById('arch-render-area');
  if (Q._archMode === 'system') Q._renderSystemArch(area);
  else Q._renderArchDiagram(area, repos, edges);
};

Q._setArchMode = mode => {
  Q._archMode = mode;
  if (Q._archData && Q._archEl) Q._renderArchWithToggle(Q._archEl, Q._archData);
};

Q._renderSystemArch = async (el) => {
  el.innerHTML = Q.loadingHTML();
  let data;
  try { data = await Q.api('/graph/architecture'); } catch(e) { el.innerHTML = Q.emptyHTML('Failed: '+e.message); return; }

  if (!data.exists) {
    // No architecture.md — show the prompt generation UI
    Q._showArchPrompt(el);
    return;
  }

  // Render the diagram from parsed architecture.md
  Q._renderArchD3(el, data);
};

// ── Prompt mode: no architecture.md yet ──────────────────────────────
Q._showArchPrompt = async (el) => {
  let promptData = {};
  try { promptData = await Q.api('/graph/architecture/prompt'); } catch(e) {}

  let h = '<div class="arch-onboard">';
  h += '<div class="arch-onboard-icon">🏗</div>';
  h += '<h2 style="margin-bottom:8px">Generate Architecture Diagram</h2>';
  h += '<p class="muted" style="max-width:520px;line-height:1.6;margin-bottom:20px">';
  h += 'No <code>architecture.md</code> found. Copy the prompt below and give it to your AI agent — ';
  h += 'it will use the extracted graph data to create a structured architecture definition. ';
  h += 'Then paste the result back here or save it as <code>architecture.md</code> in your project.</p>';

  // Copy prompt button
  h += '<div style="display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap">';
  h += '<button class="btn-red" onclick="Q._copyArchPrompt()">Copy Prompt to Clipboard</button>';
  h += '<button class="btn-ghost" onclick="Q._toggleArchPromptPreview()">Preview Prompt</button>';
  h += '<button class="btn-ghost" onclick="Q._showArchEditor()">Paste / Edit Manually</button>';
  h += '</div>';

  // Prompt preview (hidden by default)
  h += '<div id="arch-prompt-preview" style="display:none">';
  h += '<div style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--r-lg);padding:16px;max-height:60vh;overflow-y:auto;margin-bottom:16px">';
  h += '<pre id="arch-prompt-text" style="font-size:11px;line-height:1.6;white-space:pre-wrap;word-break:break-word;color:var(--fg-2);font-family:var(--mono);margin:0;user-select:text">' + Q.esc(promptData.prompt || 'Loading...') + '</pre>';
  h += '</div></div>';

  // Editor (hidden by default)
  h += '<div id="arch-editor-area" style="display:none">';
  h += '<div style="margin-bottom:8px;font-size:12px;font-weight:600;color:var(--fg-2)">Paste your architecture.md content:</div>';
  h += '<textarea id="arch-editor" style="width:100%;min-height:300px;padding:12px;font-family:var(--mono);font-size:11px;line-height:1.6;background:var(--surface);border:1px solid var(--border);border-radius:var(--r);color:var(--fg);resize:vertical" placeholder="# Architecture — My Project\n\n## User Interface\n\n### Web App\n- type: frontend\n- description: React frontend\n\n## Connections\n\nWeb App -> API Gateway : HTTP/REST"></textarea>';
  h += '<div style="display:flex;gap:8px;margin-top:10px">';
  h += '<button class="btn-red" onclick="Q._saveArchMd()">Save & Render</button>';
  h += '<button class="btn-ghost" onclick="Q._loadArchSample()">Load Sample</button>';
  h += '</div></div>';

  // Format reference
  h += '<div style="margin-top:24px;padding-top:16px;border-top:1px solid var(--border)">';
  h += '<div class="section-label">Format Reference</div>';
  h += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:12px;color:var(--fg-2)">';
  h += '<div><strong>Zones</strong> (## headings) become swimlanes<br><code>## Core Services</code></div>';
  h += '<div><strong>Components</strong> (### headings) become boxes<br><code>### User Service</code><br><code>- type: service</code><br><code>- description: Handles user CRUD</code></div>';
  h += '<div><strong>Connections</strong> section defines edges<br><code>## Connections</code><br><code>Web App -> API Gateway : HTTP/REST</code></div>';
  h += '<div><strong>Types</strong>: frontend, gateway, service, database, queue, external, agent, storage, config</div>';
  h += '</div></div>';

  h += '</div>';
  el.innerHTML = h;

  // Store prompt for clipboard
  Q._archPromptText = promptData.prompt || '';
};

Q._copyArchPrompt = () => {
  if (Q._archPromptText) {
    navigator.clipboard.writeText(Q._archPromptText).then(() => {
      const btn = document.querySelector('.arch-onboard .btn-red');
      if (btn) { const orig = btn.textContent; btn.textContent = 'Copied!'; setTimeout(() => btn.textContent = orig, 1500); }
    });
  }
};

Q._toggleArchPromptPreview = () => {
  const el = document.getElementById('arch-prompt-preview');
  if (el) el.style.display = el.style.display === 'none' ? '' : 'none';
};

Q._showArchEditor = () => {
  const el = document.getElementById('arch-editor-area');
  if (el) el.style.display = el.style.display === 'none' ? '' : 'none';
};

Q._loadArchSample = async () => {
  const ta = document.getElementById('arch-editor');
  if (!ta) return;
  try {
    const resp = await fetch('/static/v2/architecture_sample.md');
    if (resp.ok) ta.value = await resp.text();
    else ta.value = '# Architecture — Sample\n\n## Services\n\n### My Service\n- type: service\n- description: Main backend\n\n## Connections\n';
  } catch(e) { ta.value = '# Architecture — Sample\n\n## Services\n\n### My Service\n- type: service\n- description: Main backend\n\n## Connections\n'; }
};

Q._saveArchMd = async () => {
  const ta = document.getElementById('arch-editor');
  if (!ta || !ta.value.trim()) return;
  try {
    await Q.api('/graph/architecture/save', {method:'POST', body:{content: ta.value}});
    // Re-render — now it should find the file
    const focus = document.getElementById('explore-focus');
    if (focus) Q._renderSystemArch(focus);
  } catch(e) { alert('Save failed: ' + e.message); }
};

// ── Diagram mode: render parsed architecture.md as D3 ────────────────
Q._renderArchD3 = (el, data) => {
  const components = data.components || [], edges = data.edges || [], zones = data.zones || [];
  const title = data.title || 'System Architecture';

  const TYPE_COLORS = {
    frontend:{bg:'#2563EB',fg:'#fff',b:'#1d4ed8'},
    gateway:{bg:'#D97706',fg:'#fff',b:'#b45309'},
    service:{bg:'#059669',fg:'#fff',b:'#047857'},
    database:{bg:'#7C3AED',fg:'#fff',b:'#6d28d9'},
    queue:{bg:'#E11D48',fg:'#fff',b:'#be123c'},
    external:{bg:'#64748B',fg:'#fff',b:'#475569'},
    agent:{bg:'#10B981',fg:'#fff',b:'#059669'},
    storage:{bg:'#0891B2',fg:'#fff',b:'#0e7490'},
    config:{bg:'#78716C',fg:'#fff',b:'#57534e'},
  };
  const DEF_COL = {bg:'#059669',fg:'#fff',b:'#047857'};
  const ZCOL = ['#2563EB','#D97706','#059669','#7C3AED','#E11D48','#0891B2','#64748B','#10B981'];

  const compById = {};
  components.forEach(c => { compById[c.id] = c; });

  // ── Build adjacency for flow-aware ordering ────────────────────────
  const downstream = {};  // comp_id -> Set of target comp_ids
  const upstream = {};
  edges.forEach(e => {
    if (!compById[e.source] || !compById[e.target]) return;
    (downstream[e.source] = downstream[e.source] || new Set()).add(e.target);
    (upstream[e.target] = upstream[e.target] || new Set()).add(e.source);
  });

  // ── Assign each component a "column" based on its connections ──────
  // Components that feed into others in the same zone should be left,
  // components that receive should be right. Cross-zone: align by
  // the median column of their cross-zone partners.
  const compZone = {};
  zones.forEach(z => z.component_ids.forEach(id => { compZone[id] = z.id; }));

  // For each zone, order components so that sources come before targets
  // Use a simple heuristic: sort by (outgoing_cross - incoming_cross) descending
  // so "source" components are on the left
  const zoneComps = {};
  zones.forEach(z => {
    const items = z.component_ids.map(id => compById[id]).filter(Boolean);
    // Score: positive = more of a source, negative = more of a sink
    items.forEach(c => {
      let outCross = 0, inCross = 0, outSame = 0, inSame = 0;
      (downstream[c.id] || new Set()).forEach(t => {
        if (compZone[t] === compZone[c.id]) outSame++; else outCross++;
      });
      (upstream[c.id] || new Set()).forEach(s => {
        if (compZone[s] === compZone[c.id]) inSame++; else inCross++;
      });
      c._score = (outCross + outSame) - (inCross + inSame);
      c._outCross = outCross;
      c._inCross = inCross;
    });
    items.sort((a, b) => b._score - a._score);
    zoneComps[z.id] = items;
  });

  // ── Compute global column assignments ──────────────────────────────
  // Find the max number of components in any zone to set the column grid
  const maxCols = Math.max(...Object.values(zoneComps).map(a => a.length), 1);
  const globalCols = Math.min(maxCols, 6);

  // ── Layout constants ───────────────────────────────────────────────
  const BOX_W = 180, BOX_H = 50, BOX_RX = 10;
  const COL_GAP = 40, ROW_GAP = 30;
  const ZONE_PX = 30, ZONE_PY = 48, ZONE_GAP = 56, TOP = 60;
  const colW = BOX_W + COL_GAP;

  // ── Position zones and components ──────────────────────────────────
  const pos = {};
  const zoneLayouts = [];
  let curY = TOP;

  zones.forEach((zone, zi) => {
    const items = zoneComps[zone.id] || [];
    if (!items.length) return;
    const cols = Math.min(items.length, globalCols);
    const rows = Math.ceil(items.length / cols);
    const contentW = cols * colW - COL_GAP;
    const contentH = rows * (BOX_H + ROW_GAP) - ROW_GAP;
    const zw = contentW + ZONE_PX * 2;
    const zh = contentH + ZONE_PY + 20;
    const zx = ZONE_PX + 40;
    zoneLayouts.push({...zone, x: zx, y: curY, w: zw, h: zh, cols, rows, items, _zi: zi});

    items.forEach((c, i) => {
      const col = i % cols, row = Math.floor(i / cols);
      const x = zx + ZONE_PX + col * colW;
      const y = curY + ZONE_PY + row * (BOX_H + ROW_GAP);
      pos[c.id] = {x, y, cx: x + BOX_W / 2, cy: y + BOX_H / 2, col, row, zoneIdx: zi};
    });
    curY += zh + ZONE_GAP;
  });

  const maxZW = Math.max(...zoneLayouts.map(z => z.w), 500);
  const totalW = maxZW + ZONE_PX * 2 + 120;
  const totalH = curY - ZONE_GAP + 60;

  // ── Render HTML shell ──────────────────────────────────────────────
  let html = '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
  html += '<div class="sec-head" style="margin:0;border:0;padding:0">' + Q.esc(title.toUpperCase()) + ' ARCHITECTURE</div>';
  html += '<div style="display:flex;gap:6px">';
  html += '<button class="btn-ghost btn-sm" onclick="Q._archFitView()">Fit View</button>';
  html += '<button class="btn-ghost btn-sm" onclick="Q._archResetLayout()">Reset Layout</button>';
  html += '<button class="btn-ghost btn-sm" onclick="Q._editArchMd()">Edit</button>';
  html += '</div></div>';
  html += '<div id="arch-main-canvas" style="width:100%;height:' + Math.max(totalH + 40, 520) + 'px;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-lg);overflow:hidden;position:relative"></div>';
  // Legend
  html += '<div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:10px;font-size:11px;color:var(--fg-3)">';
  const usedTypes = [...new Set(components.map(c => c.type))];
  usedTypes.forEach(t => {
    const tc = TYPE_COLORS[t] || DEF_COL;
    html += '<span style="display:flex;align-items:center;gap:4px"><span style="width:12px;height:12px;border-radius:3px;background:'+tc.bg+'"></span>'+Q.esc(t.charAt(0).toUpperCase()+t.slice(1))+'</span>';
  });
  html += '</div>';
  el.innerHTML = html;

  const canvas = document.getElementById('arch-main-canvas');
  if (!canvas) return;
  const svg = d3.select(canvas).append('svg').attr('width','100%').attr('height','100%')
    .attr('viewBox',[0,0,totalW,totalH]);
  const g = svg.append('g');
  const zoom = d3.zoom().scaleExtent([0.15,3]).on('zoom',e=>g.attr('transform',e.transform));
  svg.call(zoom);
  Q._archSvg = svg; Q._archZoom = zoom; Q._archTW = totalW; Q._archTH = totalH;

  const defs = svg.append('defs');
  defs.append('marker').attr('id','arch-arr').attr('viewBox','0 -5 10 10').attr('refX',10).attr('refY',0)
    .attr('markerWidth',7).attr('markerHeight',7).attr('orient','auto')
    .append('path').attr('d','M0,-4L10,0L0,4').attr('fill','#94a3b8');

  // ── Zone backgrounds ───────────────────────────────────────────────
  zoneLayouts.forEach(zl => {
    const zcol = ZCOL[zl._zi % ZCOL.length];
    g.append('rect').attr('x',zl.x-12).attr('y',zl.y-8).attr('width',zl.w+24).attr('height',zl.h+16)
      .attr('fill','none').attr('stroke',zcol).attr('stroke-width',1.5)
      .attr('stroke-dasharray','8,5').attr('stroke-opacity',.18).attr('rx',14);
    g.append('text').attr('x',zl.x-8).attr('y',zl.y+16)
      .attr('font-size','10px').attr('font-weight','800').attr('fill',zcol)
      .attr('letter-spacing','.12em').attr('opacity',.4)
      .text(zl.label.toUpperCase());
  });

  // ── Edges — smart routing ──────────────────────────────────────────
  // Classify edges: vertical (same column, adjacent zones) vs cross
  const edgeG = g.append('g');
  const usedChannels = {};  // y-key -> next available x offset

  edges.forEach((e) => {
    const s = pos[e.source], t = pos[e.target];
    if (!s || !t) return;

    const sameCol = Math.abs(s.cx - t.cx) < colW / 2;
    const sBelow = s.cy < t.cy;
    const srcBot = s.y + BOX_H, srcTop = s.y;
    const tgtTop = t.y, tgtBot = t.y + BOX_H;

    let pathD;
    let labelX, labelY, labelAnchor = 'start';

    if (sameCol && Math.abs(s.col - t.col) <= 1) {
      // Mostly vertical — draw a straight or slightly curved line
      const x1 = s.cx, y1 = sBelow ? srcBot : srcTop;
      const x2 = t.cx, y2 = sBelow ? tgtTop : tgtBot;
      const midY = (y1 + y2) / 2;
      if (Math.abs(x1 - x2) < 5) {
        pathD = `M${x1},${y1} L${x2},${y2}`;
      } else {
        pathD = `M${x1},${y1} C${x1},${midY} ${x2},${midY} ${x2},${y2}`;
      }
      labelX = Math.max(x1, x2) + 8;
      labelY = midY;
    } else {
      // Cross-column: orthogonal routing
      // Exit from bottom of source, go down to a channel, go horizontal, go down to target
      const x1 = s.cx, y1 = sBelow ? srcBot : srcTop;
      const x2 = t.cx, y2 = sBelow ? tgtTop : tgtBot;

      // Find a free horizontal channel between the two zones
      const channelY = (y1 + y2) / 2;
      const channelKey = Math.round(channelY / 20) * 20;
      if (!usedChannels[channelKey]) usedChannels[channelKey] = 0;
      const offset = usedChannels[channelKey] * 12;
      usedChannels[channelKey]++;
      const cy = channelKey + offset;

      pathD = `M${x1},${y1} L${x1},${cy} L${x2},${cy} L${x2},${y2}`;
      labelX = (x1 + x2) / 2;
      labelY = cy - 5;
      labelAnchor = 'middle';
    }

    edgeG.append('path').attr('d', pathD)
      .attr('fill','none').attr('stroke','#94a3b8').attr('stroke-width',1.5)
      .attr('stroke-dasharray','6,4').attr('stroke-opacity',.4)
      .attr('marker-end','url(#arch-arr)')
      .attr('data-src',e.source).attr('data-tgt',e.target);

    if (e.label) {
      edgeG.append('text').attr('x',labelX).attr('y',labelY)
        .attr('text-anchor',labelAnchor).attr('dominant-baseline','auto')
        .attr('font-size','8px').attr('fill','#94a3b8').attr('font-style','italic')
        .text(e.label);
    }
  });

  // ── Component boxes ────────────────────────────────────────────────
  components.forEach(c => {
    const p = pos[c.id];
    if (!p) return;
    const tc = c.color ? {bg:c.color,fg:'#fff',b:c.color} : (TYPE_COLORS[c.type] || DEF_COL);

    const grp = g.append('g').attr('cursor','pointer').attr('class','arch-c').attr('data-cid',c.id)
      .on('mouseenter', function() {
        const conn = new Set([c.id]);
        edges.forEach(e => { if(e.source===c.id) conn.add(e.target); if(e.target===c.id) conn.add(e.source); });
        g.selectAll('.arch-c').each(function(){ if(!conn.has(this.dataset.cid)) d3.select(this).transition().duration(150).attr('opacity',.1); });
        edgeG.selectAll('path').each(function(){
          const hit = this.dataset.src===c.id||this.dataset.tgt===c.id;
          d3.select(this).transition().duration(150)
            .attr('stroke-opacity',hit?.85:.03).attr('stroke',hit?tc.bg:'#ddd').attr('stroke-width',hit?2.5:1);
        });
        edgeG.selectAll('text').each(function(){
          const prev=this.previousElementSibling;
          const hit=prev&&(prev.dataset.src===c.id||prev.dataset.tgt===c.id);
          d3.select(this).transition().duration(150).attr('opacity',hit?1:.03).attr('fill',hit?tc.bg:'#94a3b8');
        });
      })
      .on('mouseleave', function() {
        g.selectAll('.arch-c').transition().duration(200).attr('opacity',1);
        edgeG.selectAll('path').transition().duration(200).attr('stroke-opacity',.4).attr('stroke','#94a3b8').attr('stroke-width',1.5);
        edgeG.selectAll('text').transition().duration(200).attr('opacity',1).attr('fill','#94a3b8');
      });

    // Shadow
    grp.append('rect').attr('x',p.x+2).attr('y',p.y+2).attr('width',BOX_W).attr('height',BOX_H)
      .attr('fill','#000').attr('opacity',.04).attr('rx',BOX_RX);
    // Box
    grp.append('rect').attr('x',p.x).attr('y',p.y).attr('width',BOX_W).attr('height',BOX_H)
      .attr('fill',tc.bg).attr('stroke',tc.b).attr('stroke-width',1.5).attr('rx',BOX_RX);
    // Label
    const hasDesc = c.description && c.description.length > 0;
    grp.append('text').attr('x',p.cx).attr('y',p.cy + (hasDesc ? -5 : 0)).attr('text-anchor','middle')
      .attr('dominant-baseline','middle')
      .attr('font-size','12px').attr('font-weight','700').attr('fill',tc.fg)
      .text(Q.trunc(c.label, 22));
    if (hasDesc) {
      grp.append('text').attr('x',p.cx).attr('y',p.cy + 11).attr('text-anchor','middle')
        .attr('dominant-baseline','middle')
        .attr('font-size','8px').attr('fill',tc.fg).attr('opacity',.65)
        .text(Q.trunc(c.description, 28));
    }
    grp.append('title').text(c.label + (c.description ? '\n' + c.description : '') + '\nType: ' + c.type);
  });

  setTimeout(() => Q._archFitView(), 100);
};

Q._archFitView = () => {
  if (!Q._archSvg || !Q._archZoom) return;
  const canvas = document.getElementById('arch-main-canvas');
  if (!canvas) return;
  const W = canvas.clientWidth, H = canvas.clientHeight;
  const scale = Math.min(W / Q._archTW, H / Q._archTH, 2) * 0.88;
  const tx = (W - Q._archTW * scale) / 2, ty = (H - Q._archTH * scale) / 2;
  Q._archSvg.transition().duration(500).call(Q._archZoom.transform,
    d3.zoomIdentity.translate(tx, ty).scale(scale));
};

Q._archResetLayout = () => {
  if (!Q._archSvg || !Q._archZoom) return;
  Q._archSvg.transition().duration(400).call(Q._archZoom.transform, d3.zoomIdentity);
};

Q._editArchMd = async () => {
  const focus = document.getElementById('explore-focus');
  if (!focus) return;
  let content = '';
  try {
    const data = await Q.api('/graph/architecture');
    if (data.exists) content = Q._reconstructArchMd(data);
  } catch(e) {}
  Q._showArchPrompt(focus);
  setTimeout(() => {
    Q._showArchEditor();
    const ta = document.getElementById('arch-editor');
    if (ta && content) ta.value = content;
  }, 100);
};

Q._reconstructArchMd = (data) => {
  let md = '# Architecture \u2014 ' + (data.title || 'System') + '\n\n';
  (data.zones || []).forEach(z => {
    md += '## ' + z.label + '\n\n';
    (z.component_ids || []).forEach(cid => {
      const c = (data.components || []).find(x => x.id === cid);
      if (!c) return;
      md += '### ' + c.label + '\n';
      md += '- type: ' + c.type + '\n';
      if (c.description) md += '- description: ' + c.description + '\n';
      if (c.color) md += '- color: ' + c.color + '\n';
      md += '\n';
    });
  });
  md += '## Connections\n\n';
  const cById = {};
  (data.components || []).forEach(c => { cById[c.id] = c; });
  (data.edges || []).forEach(e => {
    const s = cById[e.source], t = cById[e.target];
    if (s && t) md += s.label + ' -> ' + t.label + (e.label ? ' : ' + e.label : '') + '\n';
  });
  return md;
};

Q._renderArchDiagram = (el, repos, edges) => {
  const LC = {ui:'#2563EB',bff:'#7C3AED',api:'#059669',db:'#D46B08',data:'#B8860B',config:'#64748B',unknown:'#888'};
  const LAYER_ORDER = ['ui','bff','api','db','data','config','unknown'];
  const LAYER_LABELS = {ui:'UI Layer',bff:'BFF Layer',api:'API Layer',db:'DB Layer',data:'Data Layer',config:'Config',unknown:'Other'};

  const byLayer = {};
  repos.forEach(r => { const cls = (r.classification || ['unknown'])[0] || 'unknown'; (byLayer[cls] = byLayer[cls] || []).push(r); });
  const layers = LAYER_ORDER.filter(l => byLayer[l]?.length);

  // Horizontal layout: layers as columns left-to-right
  const BOX_W = 140, BOX_H = 48, BOX_GAP = 10, LANE_PX = 12, LANE_PY = 10;
  const LANE_GAP = 22, LABEL_H = 28, MAX_ROWS = 8;
  const positions = {};
  const laneInfo = [];
  let curX = 16;

  layers.forEach(layer => {
    const items = byLayer[layer];
    const rows = Math.min(items.length, MAX_ROWS);
    const cols = Math.ceil(items.length / MAX_ROWS);
    const laneContentH = rows * (BOX_H + BOX_GAP) - BOX_GAP;
    const laneH = laneContentH + LANE_PY * 2;
    const laneW = cols * (BOX_W + BOX_GAP) - BOX_GAP + LANE_PX * 2;
    const laneY = LABEL_H + 16;
    laneInfo.push({layer, x: curX, w: laneW, h: laneH, y: laneY, cols, rows});
    items.forEach((r, i) => {
      const row = i % MAX_ROWS, col = Math.floor(i / MAX_ROWS);
      const x = curX + LANE_PX + col * (BOX_W + BOX_GAP);
      const y = laneY + LANE_PY + row * (BOX_H + BOX_GAP);
      positions[r.id] = {x, y, w: BOX_W, h: BOX_H, cx: x + BOX_W/2, cy: y + BOX_H/2, layer};
    });
    curX += laneW + LANE_GAP;
  });

  const totalW = curX - LANE_GAP + 16;
  const maxLaneH = Math.max(...laneInfo.map(l => l.h));
  const totalH = LABEL_H + 16 + maxLaneH + 16;

  let html = '<div class="sec-head">Architecture Diagram \u2014 ' + repos.length + ' repos \u00b7 ' + edges.length + ' cross-repo edges</div>';
  html += '<div class="arch-hint muted">Repos by architectural layer. Orthogonal arrows = cross-repo dependencies. Hover to highlight connections. Click to open code tree.</div>';
  html += '<div class="arch-depth-toggle" style="display:flex;align-items:center;gap:8px;margin-bottom:10px">';
  html += '<label style="font-size:11px;display:flex;align-items:center;gap:4px;cursor:pointer"><input type="checkbox" id="arch-depth-check" onchange="Q._archToggleDepthMode(this.checked)"><span>Depth Explorer</span></label>';
  html += '<div id="arch-depth-btns" style="display:none;gap:4px;align-items:center"><span class="muted" style="font-size:10px">Depth:</span>';
  for (let d = 1; d <= 3; d++) html += '<button class="btn-ghost btn-xs arch-dbtn' + (d===1?' arch-dbtn-active':'') + '" data-depth="' + d + '" onclick="Q._archSetDepth(' + d + ')">' + d + '</button>';
  html += '<button class="btn-ghost btn-xs" onclick="Q._archClearDepth()">Clear</button></div>';
  html += '</div>';
  html += '<div id="arch-canvas" class="arch-canvas"></div>';
  el.innerHTML = html;

  const canvas = document.getElementById('arch-canvas');
  if (!canvas) return;

  const svg = d3.select(canvas).append('svg')
    .attr('width', '100%').attr('height', totalH)
    .attr('viewBox', [0, 0, totalW, totalH])
    .style('max-width', '100%').style('display', 'block').style('margin', '0 auto');
  const g = svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.4, 2.5]).on('zoom', e => g.attr('transform', e.transform)));

  const defs = svg.append('defs');
  defs.append('marker').attr('id','arch-arr').attr('viewBox','0 -4 8 8').attr('refX',8).attr('refY',0)
    .attr('markerWidth',5).attr('markerHeight',5).attr('orient','auto')
    .append('path').attr('d','M0,-3L8,0L0,3').attr('fill','#666');

  // Lane backgrounds + labels
  laneInfo.forEach(li => {
    const col = LC[li.layer] || '#888';
    g.append('rect').attr('x', li.x).attr('y', li.y).attr('width', li.w).attr('height', li.h)
      .attr('fill', col).attr('opacity', .04).attr('rx', 5)
      .attr('stroke', col).attr('stroke-opacity', .1).attr('stroke-width', 1);
    g.append('text').attr('x', li.x + li.w / 2).attr('y', li.y - 6)
      .attr('text-anchor', 'middle').attr('dominant-baseline', 'auto')
      .attr('font-size', '10px').attr('font-weight', '700').attr('fill', col)
      .attr('letter-spacing', '.05em')
      .text(LAYER_LABELS[li.layer] || li.layer.toUpperCase());
  });

  // Orthogonal edges with right-angle bends
  const edgeG = g.append('g').attr('class', 'arch-edges');
  edges.forEach((e, ei) => {
    const src = positions[e.source], tgt = positions[e.target];
    if (!src || !tgt) return;
    const thickness = Math.max(1.5, Math.min(4, Math.log2(e.count || 1) + 1.5));
    const goRight = tgt.cx > src.cx;
    const x1 = goRight ? src.x + src.w : src.x, y1 = src.cy;
    const x2 = goRight ? tgt.x : tgt.x + tgt.w, y2 = tgt.cy;
    const midX = (x1 + x2) / 2 + (ei % 7 - 3) * 2;
    const path = 'M' + x1 + ',' + y1 + ' L' + midX + ',' + y1 + ' L' + midX + ',' + y2 + ' L' + x2 + ',' + y2;
    edgeG.append('path').attr('d', path)
      .attr('fill', 'none').attr('stroke', '#666').attr('stroke-width', thickness)
      .attr('stroke-opacity', .55).attr('marker-end', 'url(#arch-arr)')
      .attr('data-source', e.source).attr('data-target', e.target).attr('data-count', e.count || 1)
      .append('title').text(e.source + ' \u2192 ' + e.target + ' (' + e.count + ' edges)');
  });

  // Repo boxes
  const maxEnt = Math.max(1, ...repos.map(r => r.entity_count || 1));
  repos.forEach(r => {
    const p = positions[r.id];
    if (!p) return;
    const col = LC[p.layer] || '#888';
    const intensity = .2 + .8 * ((r.entity_count || 1) / maxEnt);
    const grp = g.append('g').attr('cursor', 'pointer').attr('class', 'arch-repo-grp').attr('data-repo', r.id)
      .on('click', () => {
        if (Q._archDepthMode) Q._archToggleRepo(r.id);
        else Q._archClickRepo(r.id);
      })
      .on('mouseenter', function() {
        if (Q._archDepthMode) return; // depth mode handles its own highlighting
        const connected = new Set([r.id]);
        edges.forEach(e => { if (e.source === r.id) connected.add(e.target); if (e.target === r.id) connected.add(e.source); });
        d3.select(this).select('.arch-box').attr('stroke', col).attr('stroke-width', 2);
        g.selectAll('.arch-repo-grp').each(function() {
          const rid = this.dataset.repo;
          if (rid !== r.id && connected.has(rid)) d3.select(this).select('.arch-box').attr('stroke', LC[(positions[rid]||{}).layer]||'#888').attr('stroke-width', 2);
          else if (!connected.has(rid)) d3.select(this).attr('opacity', .25);
        });
        edgeG.selectAll('path')
          .attr('stroke-opacity', function() { return this.dataset.source === r.id || this.dataset.target === r.id ? .85 : .04; })
          .attr('stroke', function() { return this.dataset.source === r.id || this.dataset.target === r.id ? col : '#ccc'; })
          .attr('stroke-width', function() { return this.dataset.source === r.id || this.dataset.target === r.id ? 2.5 : .8; });
      })
      .on('mouseleave', function() {
        if (Q._archDepthMode) return;
        g.selectAll('.arch-repo-grp').attr('opacity', 1).each(function() { d3.select(this).select('.arch-box').attr('stroke', '#D8D5D0').attr('stroke-width', 1); });
        edgeG.selectAll('path').attr('stroke-opacity', .55).attr('stroke', '#666').attr('stroke-width', function() {
          return Math.max(1.5, Math.min(4, Math.log2(parseFloat(this.dataset.count)||1) + 1.5));
        });
      });

    // Shadow
    grp.append('rect').attr('x', p.x+1).attr('y', p.y+1).attr('width', p.w).attr('height', p.h)
      .attr('fill', '#000').attr('opacity', .025).attr('rx', 4);
    // Box
    grp.append('rect').attr('class', 'arch-box').attr('x', p.x).attr('y', p.y).attr('width', p.w).attr('height', p.h)
      .attr('fill', '#fff').attr('stroke', '#D8D5D0').attr('stroke-width', 1).attr('rx', 4);
    // Left accent
    grp.append('rect').attr('x', p.x).attr('y', p.y).attr('width', 3).attr('height', p.h)
      .attr('fill', col).attr('opacity', intensity).attr('rx', 1.5);
    // Name
    grp.append('text').attr('x', p.x + 10).attr('y', p.y + 18)
      .attr('font-size', '11px').attr('font-weight', '600').attr('fill', '#1A1917')
      .text(Q.trunc(r.id, 20));
    // Stats
    grp.append('text').attr('x', p.x + 10).attr('y', p.y + 32)
      .attr('font-size', '9px').attr('fill', '#7A7770')
      .text((r.entity_count || 0) + ' entities \u00b7 ' + (r.relation_count || 0) + ' rels');
    // Stack
    const stack = (r.stack || []).slice(0, 3);
    if (stack.length) {
      grp.append('text').attr('x', p.x + 10).attr('y', p.y + 44)
        .attr('font-size', '8px').attr('fill', '#A8A49E')
        .text(stack.join(' \u00b7 '));
    }
    // Confidence bar
    const conf = r.confidence || 0;
    if (conf > 0) {
      grp.append('rect').attr('x', p.x + 3).attr('y', p.y + p.h - 3)
        .attr('width', (p.w - 6) * conf).attr('height', 2)
        .attr('fill', col).attr('opacity', .25).attr('rx', 1);
    }
  });
};

Q.openRepoDetail = async repoId => {
  Q.navigate('explore');
  const results = document.getElementById('explore-results');
  const focus = document.getElementById('explore-focus');
  results.innerHTML = Q.skelCards(6);
  focus.innerHTML = Q.loadingHTML();
  try {
    const data = await Q.api('/search?q=' + encodeURIComponent(repoId) + '&top_k=50&expand_depth=0');
    Q.renderResults(data, repoId);
    focus.innerHTML = Q.emptyHTML('Select an entity from ' + repoId + ' to explore.');
  } catch (e) {
    results.innerHTML = Q.emptyHTML('Failed: ' + e.message);
  }
};

// ── Architecture: click repo → Code Tree ────────────────────────────────────
Q._archClickRepo = repoId => {
  // Load code tree and auto-select this repo
  Q.openStructure();
  setTimeout(() => {
    Q.structTab('codetree');
    // Wait for code tree to load, then render for this repo
    const waitForTree = setInterval(() => {
      if (window._ctTreeData && window._ctTreeData[repoId]) {
        clearInterval(waitForTree);
        Q.renderTreeForRepo(repoId);
      }
    }, 200);
    setTimeout(() => clearInterval(waitForTree), 5000);
  }, 100);
};

// ── Architecture: depth exploration mode ────────────────────────────────────
Q._archDepthMode = false;
Q._archSelectedRepos = new Set();
Q._archDepth = 1;

Q._archToggleDepthMode = on => {
  Q._archDepthMode = on;
  Q._archSelectedRepos.clear();
  const btns = document.getElementById('arch-depth-btns');
  if (btns) btns.style.display = on ? 'flex' : 'none';
  Q._archClearDepth();
};

Q._archSetDepth = d => {
  Q._archDepth = d;
  document.querySelectorAll('.arch-dbtn').forEach(b => b.classList.toggle('arch-dbtn-active', parseInt(b.dataset.depth) === d));
  if (Q._archSelectedRepos.size) Q._archApplyDepthHL();
};

Q._archToggleRepo = repoId => {
  if (Q._archSelectedRepos.has(repoId)) Q._archSelectedRepos.delete(repoId);
  else { Q._archSelectedRepos.clear(); Q._archSelectedRepos.add(repoId); }
  if (Q._archSelectedRepos.size) Q._archApplyDepthHL();
  else Q._archClearDepth();
};

Q._archApplyDepthHL = () => {
  const data = Q._archData;
  if (!data) return;
  const edges = data.edges || [];
  const adj = {};
  edges.forEach(e => {
    (adj[e.source] = adj[e.source] || []).push(e.target);
    (adj[e.target] = adj[e.target] || []).push(e.source);
  });
  // BFS from selected repos up to depth
  const visited = new Map();
  const queue = [];
  Q._archSelectedRepos.forEach(r => { visited.set(r, 0); queue.push(r); });
  let qi = 0;
  while (qi < queue.length) {
    const cur = queue[qi++], curD = visited.get(cur);
    if (curD >= Q._archDepth) continue;
    for (const nb of (adj[cur] || [])) {
      if (!visited.has(nb)) { visited.set(nb, curD + 1); queue.push(nb); }
    }
  }
  const canvas = document.getElementById('arch-canvas');
  if (!canvas) return;
  const svg = d3.select(canvas).select('svg').select('g');
  svg.selectAll('.arch-repo-grp').each(function() {
    const rid = this.dataset.repo;
    const inSet = visited.has(rid);
    const isOrigin = Q._archSelectedRepos.has(rid);
    d3.select(this).attr('opacity', inSet ? 1 : .15);
    d3.select(this).select('.arch-box')
      .attr('stroke', isOrigin ? '#CC0000' : inSet ? '#1B7D3A' : '#D8D5D0')
      .attr('stroke-width', isOrigin ? 2.5 : inSet ? 2 : 1);
  });
  svg.select('.arch-edges').selectAll('path').each(function() {
    const s = this.dataset.source, t = this.dataset.target;
    const show = visited.has(s) && visited.has(t);
    d3.select(this).attr('stroke-opacity', show ? .8 : .04).attr('stroke', show ? '#1B7D3A' : '#ccc');
  });
};

Q._archClearDepth = () => {
  Q._archSelectedRepos.clear();
  const canvas = document.getElementById('arch-canvas');
  if (!canvas) return;
  const svg = d3.select(canvas).select('svg').select('g');
  svg.selectAll('.arch-repo-grp').attr('opacity', 1).each(function() {
    d3.select(this).select('.arch-box').attr('stroke', '#D8D5D0').attr('stroke-width', 1);
  });
  svg.select('.arch-edges').selectAll('path').attr('stroke-opacity', .55).attr('stroke', '#666').each(function() {
    const cnt = parseFloat(this.dataset.count) || 1;
    d3.select(this).attr('stroke-width', Math.max(1.5, Math.min(4, Math.log2(cnt) + 1.5)));
  });
};

// ── AST View ────────────────────────────────────────────────────────
Q.loadAstView = async el => {
  try {
    const data = await Q.api('/ast/all?limit=500');
    const sums = data.summaries || [];
    if (!sums.length) { el.innerHTML = Q.emptyHTML('No AST summaries. Run: python -m phase10_ast.run_ast_summaries'); return; }

    const byFile = {};
    sums.forEach(s => {
      const k = `${s.repo||''}/${s.file||'?'}`;
      (byFile[k] = byFile[k] || []).push(s);
    });
    window._astByFile = byFile;
    window._astSums = sums;

    let html = `<div class="section-label">🌳 AST Call Flows — ${sums.length} methods · ${Object.keys(byFile).length} files</div>`;
    html += `<div class="ast-filter"><input type="text" id="ast-q" placeholder="Filter by name or file…" oninput="Q.filterAst()"></div>`;
    html += `<div id="ast-list">`;
    for (const [file, methods] of Object.entries(byFile).sort((a,b)=>b[1].length-a[1].length)) {
      const fid = 'af-' + file.replace(/\W/g,'_');
      html += `<div class="ast-file-group" data-file="${Q.esc(file)}">`;
      html += `<div class="ct-repo-head" onclick="Q._openAstFile('${Q.esc(file)}','${Q.esc(fid)}')"><span class="muted" style="font-size:11px">${Q.esc(file)}</span><span class="muted">${methods.length} methods</span><span class="ct-toggle">▶</span></div>`;
      html += `<div class="ct-body" id="${fid}"></div>`;
      html += `</div>`;
    }
    html += `</div>`;
    el.innerHTML = html;
  } catch (e) { el.innerHTML = Q.emptyHTML('Failed: ' + e.message); }
};

Q._openAstFile = (fileKey, fid) => {
  const body = document.getElementById(fid);
  if (!body) return;
  const isOpen = body.classList.contains('open');
  // Close all others
  document.querySelectorAll('.ct-body.open').forEach(b => { b.classList.remove('open'); b.innerHTML = ''; });
  document.querySelectorAll('.ct-repo-head .ct-toggle').forEach(t => t.textContent = '▶');
  if (isOpen) return;
  body.classList.add('open');
  const head = body.previousElementSibling;
  if (head) { const tog = head.querySelector('.ct-toggle'); if (tog) tog.textContent = '▼'; }
  const methods = (window._astByFile || {})[fileKey] || [];
  body.innerHTML = '<div style="padding:12px 0 4px;font-size:11px;color:var(--fg-dim)">Rendering call flow…</div>';
  requestAnimationFrame(() => Q._renderAstCallFlow(body, methods, fileKey));
};

Q._renderAstCallFlow = (container, methods, fileKey) => {
  if (!methods.length) { container.innerHTML = Q.emptyHTML('No methods'); return; }
  methods = [...methods].sort((a,b) => (a.line_start||0)-(b.line_start||0));

  // Build internal call map: which methods call which other methods in this file
  const nameToMethod = {};
  methods.forEach(m => { nameToMethod[m.name] = m; });

  // Nodes: one per method + external call targets
  const nodes = [];
  const nodeById = {};
  methods.forEach(m => {
    const id = m.entity_id || m.discovered_id || m.name;
    const n = { id, name: m.name, method: m, external: false,
      sig: m.signature || {}, comp: m.complexity || {},
      calls: m.calls || [], line_start: m.line_start, line_end: m.line_end };
    nodes.push(n); nodeById[m.name] = n;
  });

  // Collect unique external targets
  const extTargets = new Set();
  methods.forEach(m => {
    (m.calls||[]).forEach(c => {
      if (!nameToMethod[c.target]) extTargets.add(c.target);
    });
  });
  // Limit external nodes to keep graph readable
  const extArr = [...extTargets].slice(0, 20);
  extArr.forEach(t => {
    const n = { id: 'ext:'+t, name: t, external: true, calls: [], comp: {} };
    nodes.push(n); nodeById[t] = n;
  });

  // Edges
  const edges = [];
  const seenEdge = new Set();
  methods.forEach(m => {
    const src = nodeById[m.name];
    (m.calls||[]).forEach(c => {
      const tgt = nodeById[c.target];
      if (!tgt) return;
      const key = src.id + '|' + tgt.id;
      if (seenEdge.has(key)) return;
      seenEdge.add(key);
      edges.push({ source: src, target: tgt, line: c.line, conditional: c.conditional });
    });
  });

  // Layout: internal methods in a vertical column (sorted by line), external nodes on the right
  const BOX_W = 200, BOX_H = 56, GAP_Y = 36, EXT_W = 130, EXT_H = 32;
  const COL_X = 40, EXT_X = 320;
  const internalNodes = nodes.filter(n => !n.external);
  const externalNodes = nodes.filter(n => n.external);

  internalNodes.forEach((n, i) => { n.x = COL_X; n.y = i * (BOX_H + GAP_Y); });

  // Position external nodes: align to the first caller's y
  const extCallerY = {};
  edges.forEach(e => {
    if (e.target.external && extCallerY[e.target.id] === undefined)
      extCallerY[e.target.id] = e.source.y;
  });
  externalNodes.forEach((n, i) => {
    n.x = EXT_X + 60;
    n.y = extCallerY[n.id] !== undefined ? extCallerY[n.id] : i * (EXT_H + 20);
  });

  const totalH = Math.max(
    internalNodes.length * (BOX_H + GAP_Y) + 40,
    externalNodes.length * (EXT_H + 20) + 40,
    200
  );
  const totalW = externalNodes.length ? EXT_X + EXT_W + 80 : COL_X + BOX_W + 60;

  container.innerHTML = `<div id="ast-flow-${fileKey.replace(/\W/g,'_')}" style="width:100%;overflow:auto"></div>`;
  const wrap = container.querySelector('div');

  const svg = d3.select(wrap).append('svg')
    .attr('width', totalW).attr('height', totalH)
    .style('display','block');

  const defs = svg.append('defs');
  // Arrow markers
  defs.append('marker').attr('id','ast-arr').attr('viewBox','0 -4 8 8').attr('refX',8).attr('refY',0)
    .attr('markerWidth',6).attr('markerHeight',6).attr('orient','auto')
    .append('path').attr('d','M0,-3L8,0L0,3').attr('fill','var(--fg-dim)');
  defs.append('marker').attr('id','ast-arr-cond').attr('viewBox','0 -4 8 8').attr('refX',8).attr('refY',0)
    .attr('markerWidth',6).attr('markerHeight',6).attr('orient','auto')
    .append('path').attr('d','M0,-3L8,0L0,3').attr('fill','var(--orange)');

  // Column label
  if (externalNodes.length) {
    svg.append('text').attr('x', COL_X).attr('y', 14)
      .attr('font-size','9px').attr('font-weight','700').attr('fill','var(--fg-dim)').attr('letter-spacing','.1em')
      .text('INTERNAL METHODS');
    svg.append('text').attr('x', EXT_X + 60).attr('y', 14)
      .attr('font-size','9px').attr('font-weight','700').attr('fill','var(--fg-dim)').attr('letter-spacing','.1em')
      .text('EXTERNAL CALLS');
    svg.append('line').attr('x1', EXT_X + 40).attr('y1', 0).attr('x2', EXT_X + 40).attr('y2', totalH)
      .attr('stroke','var(--border)').attr('stroke-dasharray','4,4').attr('stroke-width',1);
  }

  // Edges
  const edgeG = svg.append('g');
  edges.forEach(e => {
    const sx = e.source.x + BOX_W, sy = e.source.y + BOX_H / 2;
    const tx = e.target.external ? e.target.x : e.target.x + BOX_W / 2;
    const ty = e.target.external ? e.target.y + EXT_H / 2 : e.target.y;
    const isDown = !e.target.external && e.target.y > e.source.y;
    const isSelf = e.source === e.target;
    if (isSelf) return;

    let pathD;
    if (e.target.external) {
      // Horizontal to external
      const midX = (sx + tx) / 2;
      pathD = `M${sx},${sy} C${midX},${sy} ${midX},${ty} ${tx},${ty}`;
    } else if (isDown) {
      // Internal downward: exit right side, curve down
      const cx = sx + 30;
      pathD = `M${sx},${sy} C${cx},${sy} ${cx},${ty} ${e.target.x + BOX_W},${ty}`;
    } else {
      // Internal upward: exit left side, curve up
      const lx = e.source.x - 30;
      pathD = `M${e.source.x},${sy} C${lx},${sy} ${lx},${ty} ${e.target.x},${ty}`;
    }

    edgeG.append('path').attr('d', pathD)
      .attr('fill','none')
      .attr('stroke', e.conditional ? 'var(--orange)' : 'var(--fg-dim)')
      .attr('stroke-width', e.conditional ? 1.2 : 1.5)
      .attr('stroke-dasharray', e.conditional ? '5,3' : 'none')
      .attr('stroke-opacity', 0.6)
      .attr('marker-end', e.conditional ? 'url(#ast-arr-cond)' : 'url(#ast-arr)')
      .append('title').text(`${e.source.name} → ${e.target.name} (L${e.line}${e.conditional?' conditional':''})`);

    // Line number label on edge
    const lx2 = e.target.external ? sx + 18 : (e.source.x + BOX_W + 8);
    const ly2 = e.target.external ? sy - 5 : (sy + ty) / 2;
    edgeG.append('text').attr('x', lx2).attr('y', ly2)
      .attr('font-size','8px').attr('fill', e.conditional ? 'var(--orange)' : 'var(--fg-dim)')
      .attr('opacity', 0.7).text('L' + e.line);
  });

  // Internal method boxes
  const LANG_COL = { python:'#3572A5', java:'#b07219', typescript:'#2b7489', javascript:'#f1e05a', go:'#00ADD8' };
  internalNodes.forEach(n => {
    const m = n.method;
    const sig = n.sig, comp = n.comp;
    const params = (sig.parameters||[]).map(p=>`${p.type||''} ${p.name||''}`.trim()).join(', ');
    const langCol = LANG_COL[(m.language||'').toLowerCase()] || 'var(--fg-dim)';
    const callCount = edges.filter(e => e.source === n).length;
    const calledByCount = edges.filter(e => e.target === n && !e.source.external).length;
    const complexity = (comp.branches||0) + (comp.try_catch||0);
    const complexColor = complexity > 5 ? 'var(--red)' : complexity > 2 ? 'var(--orange)' : 'var(--green)';

    const g = svg.append('g').attr('cursor','pointer')
      .on('click', () => Q.openNode(n.id))
      .on('mouseenter', function() {
        // Highlight connected edges
        edgeG.selectAll('path').attr('stroke-opacity', e =>
          (e.source === n || e.target === n) ? 1 : 0.1);
        d3.select(this).select('.ast-box').attr('stroke-width', 2.5);
      })
      .on('mouseleave', function() {
        edgeG.selectAll('path').attr('stroke-opacity', 0.6);
        d3.select(this).select('.ast-box').attr('stroke-width', 1.5);
      });

    // Box shadow
    g.append('rect').attr('x', n.x+2).attr('y', n.y+2).attr('width', BOX_W).attr('height', BOX_H)
      .attr('fill','#000').attr('opacity',.04).attr('rx',6);
    // Box
    g.append('rect').attr('class','ast-box').attr('x', n.x).attr('y', n.y).attr('width', BOX_W).attr('height', BOX_H)
      .attr('fill','var(--surface)').attr('stroke','var(--border)').attr('stroke-width',1.5).attr('rx',6);
    // Left accent (language color)
    g.append('rect').attr('x', n.x).attr('y', n.y).attr('width', 4).attr('height', BOX_H)
      .attr('fill', langCol).attr('rx', 3);
    // Method name
    g.append('text').attr('x', n.x+14).attr('y', n.y+18)
      .attr('font-size','12px').attr('font-weight','700').attr('fill','var(--fg)')
      .text(Q.trunc(sig.name || n.name, 22));
    // Signature params
    if (params) {
      g.append('text').attr('x', n.x+14).attr('y', n.y+30)
        .attr('font-size','9px').attr('fill','var(--fg-dim)').attr('font-family','var(--mono)')
        .text(Q.trunc('(' + params + ')', 30));
    }
    // Line range
    g.append('text').attr('x', n.x + BOX_W - 6).attr('y', n.y+18)
      .attr('text-anchor','end').attr('font-size','9px').attr('fill','var(--fg-dim)')
      .text(`L${n.line_start}–${n.line_end}`);
    // Stats row
    g.append('text').attr('x', n.x+14).attr('y', n.y+44)
      .attr('font-size','9px').attr('fill','var(--fg-dim)')
      .text(`${comp.lines||0} lines`);
    if (callCount) {
      g.append('text').attr('x', n.x+60).attr('y', n.y+44)
        .attr('font-size','9px').attr('fill','var(--c-api)').text(`↓${callCount} calls`);
    }
    if (calledByCount) {
      g.append('text').attr('x', n.x+100).attr('y', n.y+44)
        .attr('font-size','9px').attr('fill','var(--c-bff)').text(`↑${calledByCount} callers`);
    }
    // Complexity dot
    if (complexity > 0) {
      g.append('circle').attr('cx', n.x + BOX_W - 10).attr('cy', n.y + BOX_H - 10).attr('r', 5)
        .attr('fill', complexColor).attr('opacity', 0.7)
        .append('title').text(`Complexity: ${complexity} (${comp.branches||0} branches, ${comp.try_catch||0} try/catch)`);
    }
    // Return type badge
    if (sig.return_type) {
      g.append('text').attr('x', n.x + BOX_W - 6).attr('y', n.y + 30)
        .attr('text-anchor','end').attr('font-size','8px').attr('fill', langCol).attr('font-family','var(--mono)')
        .text(Q.trunc(sig.return_type, 12));
    }
  });

  // External call nodes (pill shape)
  externalNodes.forEach(n => {
    const g = svg.append('g').attr('opacity', 0.75);
    g.append('rect').attr('x', n.x).attr('y', n.y).attr('width', EXT_W).attr('height', EXT_H)
      .attr('fill','var(--surface-2)').attr('stroke','var(--border)').attr('stroke-width',1)
      .attr('stroke-dasharray','4,2').attr('rx', EXT_H/2);
    g.append('text').attr('x', n.x + EXT_W/2).attr('y', n.y + EXT_H/2 + 1)
      .attr('text-anchor','middle').attr('dominant-baseline','middle')
      .attr('font-size','10px').attr('fill','var(--fg-dim)').attr('font-family','var(--mono)')
      .text(Q.trunc(n.name, 18));
  });

  // Legend
  const legY = totalH - 18;
  svg.append('line').attr('x1',COL_X).attr('y1',legY+6).attr('x2',COL_X+20).attr('y2',legY+6)
    .attr('stroke','var(--fg-dim)').attr('stroke-width',1.5);
  svg.append('text').attr('x',COL_X+24).attr('y',legY+9).attr('font-size','9px').attr('fill','var(--fg-dim)').text('call');
  svg.append('line').attr('x1',COL_X+55).attr('y1',legY+6).attr('x2',COL_X+75).attr('y2',legY+6)
    .attr('stroke','var(--orange)').attr('stroke-width',1.2).attr('stroke-dasharray','5,3');
  svg.append('text').attr('x',COL_X+79).attr('y',legY+9).attr('font-size','9px').attr('fill','var(--fg-dim)').text('conditional');
  svg.append('circle').attr('cx',COL_X+140).attr('cy',legY+6).attr('r',4).attr('fill','var(--green)').attr('opacity',.7);
  svg.append('text').attr('x',COL_X+148).attr('y',legY+9).attr('font-size','9px').attr('fill','var(--fg-dim)').text('low complexity');
  svg.append('circle').attr('cx',COL_X+220).attr('cy',legY+6).attr('r',4).attr('fill','var(--red)').attr('opacity',.7);
  svg.append('text').attr('x',COL_X+228).attr('y',legY+9).attr('font-size','9px').attr('fill','var(--fg-dim)').text('high complexity');
};

Q.filterAst = () => {
  const q = (document.getElementById('ast-q')?.value||'').toLowerCase();
  document.querySelectorAll('.ast-file-group').forEach(g => {
    if (!q) { g.style.display = ''; return; }
    const match = g.dataset.file.toLowerCase().includes(q);
    g.style.display = match ? '' : 'none';
  });
};


/* ═══════════════════════════════════════════════════════════════════
   Phase C: EXPLORE — Search + Results
   ═══════════════════════════════════════════════════════════════════ */

Q._exploreLoaded = false;
Q.autoLoadExplore = () => {
  if (Q._exploreLoaded) return;
  Q._exploreLoaded = true;
  Q.openStructure();
};

Q.runSearch = async query => {
  if (!query || query.length < 2) return;
  Q.navigate('explore');
  const results = document.getElementById('explore-results');
  results.innerHTML = Q.skelCards(5);

  const layer = document.getElementById('f-layer')?.value || '';
  const conf = document.getElementById('f-conf')?.value || '';
  const params = new URLSearchParams({ q: query, top_k: 30, expand_depth: 1 });
  if (layer) params.set('layer', layer);
  if (conf) params.set('min_confidence', conf);

  try {
    const data = await Q.api('/search?' + params);
    Q.renderResults(data, query);
  } catch (e) {
    results.innerHTML = Q.emptyHTML('Search failed: ' + e.message);
  }
};

Q.renderResults = (data, query) => {
  const el = document.getElementById('explore-results');
  const nodes = data.node_results || [];
  const flows = data.flow_results || [];

  if (!nodes.length && !flows.length) {
    el.innerHTML = Q.emptyHTML('No results for "' + Q.esc(query) + '"');
    return;
  }

  let html = '';

  // Group nodes by layer
  if (nodes.length) {
    const groups = {};
    nodes.forEach(n => {
      const l = (n.metadata.layer || 'other').toUpperCase();
      (groups[l] = groups[l] || []).push(n);
    });
    for (const [layer, items] of Object.entries(groups)) {
      html += `<div class="result-group"><div class="result-group-title">${Q.esc(layer)} (${items.length})</div>`;
      items.forEach(n => {
        const m = n.metadata;
        const short = (m.node_id || '').split(':').pop();
        html += `<div class="card" onclick="Q.openNode('${Q.esc(m.node_id)}')">
          <div class="card-title">${Q.esc(short)}</div>
          <div class="card-meta">${Q.layerBadge(m.layer)} ${Q.typeBadge(m.type)} ${Q.confBadge(m.confidence)}</div>
        </div>`;
      });
      html += `</div>`;
    }
  }

  // Flow results
  if (flows.length) {
    html += `<div class="result-group"><div class="result-group-title">Flows (${flows.length})</div>`;
    flows.forEach(f => {
      const m = f.metadata;
      html += `<div class="card" onclick="Q.openFlow('${Q.esc(m.flow_id)}')">
        <div class="card-title">${Q.esc(Q.trunc(f.text, 60))}</div>
        <div class="card-meta"><span class="badge ${m.completeness === 'complete' ? 'b-ok' : 'b-warn'}">${m.completeness}</span> ${Q.confBadge(m.confidence)}</div>
      </div>`;
    });
    html += `</div>`;
  }

  html += `<div class="muted" style="font-size:11px;margin-top:12px">${data.total_results || 0} results</div>`;
  el.innerHTML = html;
};


/* ═══════════════════════════════════════════════════════════════════
   Phase D: EXPLORE — Node Profile (Focus + Side)
   ═══════════════════════════════════════════════════════════════════ */

Q.openNode = async nodeId => {
  Q.navigate('explore');
  const focus = document.getElementById('explore-focus');
  focus.innerHTML = Q.loadingHTML();

  try {
    const node = await Q.api('/node/' + encodeURIComponent(nodeId));
    Q.state.selectedNode = node;
    Q.renderNodeProfile(node);
    Q.loadNodeSide(node);
  } catch (e) {
    // Node not in graph — try AST summary fallback (e.g. discovered_id from AST view)
    try {
      const ast = await Q.api('/ast_summary/' + encodeURIComponent(nodeId));
      Q.renderAstNodeProfile(ast, focus);
    } catch (_) {
      focus.innerHTML = Q.emptyHTML('Node not found: ' + e.message);
    }
  }
};

Q.renderAstNodeProfile = (ast, focus) => {
  const sig = ast.signature || {}, calls = ast.calls || [], comp = ast.complexity || {};
  const params = (sig.parameters || []).map(p => `${p.type||''} ${p.name||''}`.trim()).join(', ');
  let html = `<div class="node-header" style="border-left-color:var(--fg-dim)">`;
  html += `<h2>${Q.esc(sig.name || ast.name || ast.discovered_id || '?')}</h2>`;
  html += `<div class="node-meta">`;
  html += `<span class="badge b-type">${Q.esc(ast.language || '')}</span>`;
  html += `<span class="muted">${Q.esc(ast.repo || '')} · ${Q.esc(ast.file || '')} L${ast.line_start||'?'}–${ast.line_end||'?'}</span>`;
  html += `${Q.confBadge(ast.confidence)}</div>`;
  if (sig.return_type || params) {
    html += `<div class="muted" style="font-size:12px;margin-top:4px;font-family:var(--mono)">`;
    if (sig.return_type) html += `<span style="color:var(--c-api)">${Q.esc(sig.return_type)}</span> `;
    html += `${Q.esc(sig.name||ast.name||'')}(${Q.esc(params)})</div>`;
  }
  html += `</div>`;
  if (calls.length) {
    html += `<div class="section-label">Calls (${calls.length})</div>`;
    html += `<div class="ast-calls">`;
    calls.forEach(c => html += `<div class="ast-call"><span>→ ${Q.esc(c.target)}</span><span class="ast-call-line">L${c.line}</span></div>`);
    html += `</div>`;
  }
  if (comp.branches || comp.lines) {
    html += `<div class="section-label">Complexity</div>`;
    html += `<div class="ast-complexity">`;
    if (comp.branches) html += `<span>${comp.branches} branches</span>`;
    if (comp.try_catch) html += `<span>${comp.try_catch} try/catch</span>`;
    if (comp.lines) html += `<span>${comp.lines} lines</span>`;
    html += `</div>`;
  }
  focus.innerHTML = html;
};

Q.renderNodeProfile = node => {
  const focus = document.getElementById('explore-focus');
  const nd = node.node || {};
  const nid = nd.id;

  let html = '';

  // Header
  const layerColor = { ui: 'var(--c-ui)', bff: 'var(--c-bff)', api: 'var(--c-api)', db: 'var(--c-db)', config: 'var(--c-config)' };
  const borderColor = layerColor[(nd.layer || '').toLowerCase()] || 'var(--red)';
  html += `<div class="node-header" style="border-left-color:${borderColor}">
    <h2>${Q.esc(nd.label || nd.id)}</h2>
    <div class="node-meta">
      ${Q.layerBadge(nd.layer)} ${Q.typeBadge(nd.type)} ${Q.confBadge(nd.confidence)}
      <span class="muted">${Q.esc(nd.repo)}</span>
      ${nd.file ? `<span class="muted">· ${Q.esc(nd.file)}${nd.line ? ':' + nd.line : ''}</span>` : ''}
    </div>
    <div class="node-meta mt-1">
      <span class="muted">↑ ${node.upstream_count || 0} callers</span>
      <span class="muted">↓ ${node.downstream_count || 0} targets</span>
    </div>
    <div class="node-actions">
      <button class="btn-ghost btn-sm" onclick="Q.showCode('${Q.esc(nid)}')">💻 Code</button>
      <button class="btn-ghost btn-sm" onclick="Q.showUpstream('${Q.esc(nid)}')">↑ Upstream</button>
      <button class="btn-ghost btn-sm" onclick="Q.showDownstream('${Q.esc(nid)}')">↓ Downstream</button>
      <button class="btn-ghost btn-sm" onclick="Q.goImpact('${Q.esc(nid)}')">⚡ Impact</button>
    </div>
  </div>`;

  // Flows section (lazy)
  html += `<div class="section-label">Flows through this entity</div>`;
  html += `<div id="node-flows">${Q.skelCards(3)}</div>`;

  // Dependencies section (lazy)
  html += `<div class="section-label mt-3">Dependencies</div>`;
  html += `<div id="node-deps">${Q.skelCards(3)}</div>`;

  focus.innerHTML = html;

  // Load flows + deps async
  Q.loadNodeFlows(nid);
  Q.loadNodeDeps(nid);
};

Q.loadNodeFlows = async nodeId => {
  const el = document.getElementById('node-flows');
  if (!el) return;
  try {
    const data = await Q.api(`/flows?start_node=${encodeURIComponent(nodeId)}&mode=surface&limit=20`);
    const flows = data.flows || [];
    if (!flows.length) { el.innerHTML = `<div class="muted" style="font-size:12px;padding:8px 0">No flows pass through this entity.</div>`; return; }
    let html = '';
    flows.forEach(f => {
      html += `<div class="flow-card" onclick="Q.openFlow('${Q.esc(f.flow_id)}')">
        <div class="card-title">${Q.esc(Q.trunc(f.surface_summary || f.flow_id, 80))}</div>
        <div class="card-meta">
          <span class="badge ${f.completeness === 'complete' ? 'b-ok' : 'b-warn'}">${f.completeness}</span>
          ${Q.confBadge(f.confidence)}
          <span class="muted">${f.hop_count} hops</span>
        </div>
      </div>`;
    });
    el.innerHTML = html;
  } catch (e) {
    el.innerHTML = `<div class="muted" style="font-size:12px">Failed to load flows.</div>`;
  }
};

Q.loadNodeDeps = async nodeId => {
  const el = document.getElementById('node-deps');
  if (!el) return;
  try {
    const data = await Q.api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=both&limit=30`);
    const neighbors = data.neighbors || [];
    if (!neighbors.length) { el.innerHTML = `<div class="muted" style="font-size:12px;padding:8px 0">No dependencies found.</div>`; return; }

    const up = neighbors.filter(n => n.direction === 'upstream');
    const dn = neighbors.filter(n => n.direction === 'downstream');
    let html = '';

    if (up.length) {
      html += `<div class="result-group-title">↑ Upstream (${up.length})</div>`;
      up.forEach(n => {
        html += `<div class="card" onclick="Q.openNode('${Q.esc(n.id)}')">
          <div class="card-title">${Q.esc(n.label)}</div>
          <div class="card-meta">${Q.layerBadge(n.layer)} ${Q.typeBadge(n.type)} <span class="muted">${Q.esc(n.relation)}</span></div>
        </div>`;
      });
    }
    if (dn.length) {
      html += `<div class="result-group-title mt-2">↓ Downstream (${dn.length})</div>`;
      dn.forEach(n => {
        html += `<div class="card" onclick="Q.openNode('${Q.esc(n.id)}')">
          <div class="card-title">${Q.esc(n.label)}</div>
          <div class="card-meta">${Q.layerBadge(n.layer)} ${Q.typeBadge(n.type)} <span class="muted">${Q.esc(n.relation)}</span></div>
        </div>`;
      });
    }
    el.innerHTML = html;
  } catch (e) {
    el.innerHTML = `<div class="muted" style="font-size:12px">Failed to load dependencies.</div>`;
  }
};

// Side panel — confidence, warnings, intelligence
Q.loadNodeSide = node => {
  const side = document.getElementById('explore-side');
  side.classList.add('open');
  const nd = node.node || {};

  let html = `<div class="section-label">Confidence & Evidence</div>`;
  html += `<div style="font-size:12px;margin-bottom:12px">`;
  html += `<div class="mb-1">${Q.confBadge(nd.confidence)} <span class="muted">${Q.esc(nd.evidence_method || 'unknown')}</span></div>`;

  const c = nd.confidence || 0;
  let rationale = c >= 0.9 ? 'Exact AST/regex match' : c >= 0.8 ? 'Strong heuristic' : c >= 0.6 ? 'Cross-file inference' : c >= 0.4 ? 'Partial evidence' : 'Low evidence — review needed';
  html += `<div class="muted">${Q.esc(rationale)}</div>`;
  html += `</div>`;

  // Warnings
  const warns = nd.warnings || [];
  if (warns.length) {
    html += `<div class="section-label">Warnings</div>`;
    warns.forEach(w => {
      html += `<div style="font-size:11px;color:var(--orange);padding:3px 0">⚠ ${Q.esc(Q.trunc(w, 80))}</div>`;
    });
  }

  // Intelligence
  if (node.intelligence) {
    html += `<div class="section-label mt-3">AI Summary</div>`;
    html += `<div style="font-size:12px;color:var(--fg-2);line-height:1.6">${Q.esc(node.intelligence)}</div>`;
  }

  html += `<div class="mt-3"><button class="btn-ghost btn-sm" onclick="Q.closeSide()">Close panel</button></div>`;
  side.innerHTML = html;
};

Q.closeSide = () => {
  const side = document.getElementById('explore-side');
  side.classList.remove('open');
  side.innerHTML = '';
};

// Code viewer in side panel
Q.showCode = async entityId => {
  const side = document.getElementById('explore-side');
  side.classList.add('open');
  side.innerHTML = Q.loadingHTML();
  try {
    const data = await Q.api('/code/' + encodeURIComponent(entityId) + '?context_lines=25');
    if (data.error) { side.innerHTML = Q.emptyHTML(data.error); return; }
    let html = `<div class="section-label">Source Code</div>`;
    html += `<div style="font-size:11px;color:var(--fg-3);margin-bottom:8px">${Q.esc(data.repo)}/${Q.esc(data.file)}${data.entity_line ? ':' + data.entity_line : ''}</div>`;
    html += `<div class="code-block">`;
    (data.code || '').split('\n').forEach((line, i) => {
      const num = (data.focus_start || 1) + i;
      const hl = num === data.entity_line ? ' line-hl' : '';
      html += `<span class="code-line${hl}"><span class="line-num">${num}</span>${Q.esc(line)}</span>`;
    });
    html += `</div>`;
    html += `<div class="mt-2"><button class="btn-ghost btn-sm" onclick="Q.closeSide()">Close</button></div>`;
    side.innerHTML = html;
  } catch (e) {
    side.innerHTML = Q.emptyHTML('Failed: ' + e.message);
  }
};

// Upstream/downstream in side panel
Q.showUpstream = async nodeId => { Q._showNeighbors(nodeId, 'upstream', '↑ Upstream Callers'); };
Q.showDownstream = async nodeId => { Q._showNeighbors(nodeId, 'downstream', '↓ Downstream Targets'); };

Q._showNeighbors = async (nodeId, direction, title) => {
  const side = document.getElementById('explore-side');
  side.classList.add('open');
  side.innerHTML = Q.loadingHTML();
  try {
    const data = await Q.api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=${direction}&limit=50`);
    const neighbors = data.neighbors || [];
    if (!neighbors.length) { side.innerHTML = Q.emptyHTML(`No ${direction} neighbors.`); return; }
    let html = `<div class="section-label">${Q.esc(title)} (${neighbors.length})</div>`;
    neighbors.forEach(n => {
      html += `<div class="card" onclick="Q.openNode('${Q.esc(n.id)}')">
        <div class="card-title">${Q.esc(n.label)}</div>
        <div class="card-meta">${Q.layerBadge(n.layer)} ${Q.typeBadge(n.type)} ${Q.confBadge(n.confidence)} <span class="muted">${Q.esc(n.relation)}</span></div>
      </div>`;
    });
    html += `<div class="mt-2"><button class="btn-ghost btn-sm" onclick="Q.closeSide()">Close</button></div>`;
    side.innerHTML = html;
  } catch (e) {
    side.innerHTML = Q.emptyHTML('Failed: ' + e.message);
  }
};


/* ═══════════════════════════════════════════════════════════════════
   Phase E: EXPLORE — Flow Detail
   ═══════════════════════════════════════════════════════════════════ */

Q.openFlow = async flowId => {
  Q.navigate('explore');
  const focus = document.getElementById('explore-focus');
  focus.innerHTML = Q.loadingHTML();

  try {
    const flow = await Q.api(`/flow/${encodeURIComponent(flowId)}?depth=standard`);
    Q.state.selectedFlow = flow;
    Q.renderFlowDetail(flow);
  } catch (e) {
    focus.innerHTML = Q.emptyHTML('Flow not found: ' + e.message);
  }
};

Q.renderFlowDetail = flow => {
  const focus = document.getElementById('explore-focus');
  const hops = flow.hop_narration || [];
  const cr = flow.confidence_range || {};

  let html = '';

  // Header
  html += `<div class="node-header" style="border-left-color:var(--c-bff)">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
      <button class="btn-ghost btn-sm" onclick="Q.clearFocus()">← Back</button>
    </div>
    <h2>${Q.esc(flow.surface_summary || flow.flow_id)}</h2>
    <div class="node-meta">
      <span class="badge ${flow.completeness === 'complete' ? 'b-ok' : 'b-warn'}">${flow.completeness}</span>
      ${Q.confBadge(cr.avg)}
      <span class="muted">${flow.hop_count} hops</span>
      <span class="muted">${(flow.repos_involved || []).join(', ')}</span>
    </div>
    ${flow.standard_summary ? `<div class="card-desc mt-2">${Q.esc(flow.standard_summary)}</div>` : ''}
  </div>`;

  // Failure points
  if (flow.failure_points?.length) {
    html += `<div style="background:var(--yellow-light);border:1px dashed rgba(249,171,0,.3);border-radius:var(--r);padding:10px 14px;margin-bottom:var(--sp-md);font-size:12px">`;
    html += `<div style="font-weight:600;color:var(--orange);margin-bottom:4px">⚠ Failure Points</div>`;
    flow.failure_points.forEach(fp => { html += `<div class="muted">${Q.esc(fp)}</div>`; });
    html += `</div>`;
  }

  // Hop chain
  if (hops.length) {
    html += `<div class="section-label">Flow Path</div>`;
    html += `<div class="hop-chain">`;
    hops.forEach((h, i) => {
      html += `<div class="hop-item" data-layer="${Q.esc(h.layer)}">
        <div>
          <span class="hop-name" onclick="Q.openNode('${Q.esc(h.id)}')">${Q.esc(h.name)}</span>
          ${Q.layerBadge(h.layer)} ${Q.typeBadge(h.type)} ${Q.confBadge(h.confidence)}
        </div>
        ${h.description ? `<div class="muted" style="font-size:11px;margin-top:2px">${Q.esc(Q.trunc(h.description, 150))}</div>` : ''}
        ${h.relation_to_next ? `<div class="hop-rel">${Q.esc(h.relation_to_next)}</div>` : ''}
      </div>`;
    });
    html += `</div>`;
  }

  // Files
  if (flow.files?.length) {
    html += `<div class="section-label mt-3">Files Involved</div>`;
    flow.files.forEach(f => {
      html += `<div class="muted" style="font-size:11px;padding:2px 0;cursor:pointer" onclick="Q.showCode('${Q.esc(f.entity_id)}')">${Q.esc(f.repo)}/${Q.esc(f.file)}${f.line ? ':' + f.line : ''}</div>`;
    });
  }

  focus.innerHTML = html;
};

Q.clearFocus = () => {
  Q.state.selectedNode = null;
  Q.state.selectedFlow = null;
  document.getElementById('explore-focus').innerHTML = `<div class="empty"><div class="empty-icon">◇</div><div class="empty-text">Select an entity from the results to see its profile, flows, and dependencies.</div></div>`;
  Q.closeSide();
};


/* ═══════════════════════════════════════════════════════════════════
   Phase F: IMPACT — Blast Radius
   ═══════════════════════════════════════════════════════════════════ */

Q.initImpact = () => {
  const summary = document.getElementById('impact-summary');
  const graph = document.getElementById('impact-graph');
  if (summary && !summary.innerHTML) summary.innerHTML = Q.emptyHTML('Select a component and click Compute.');
  if (graph && !graph.innerHTML) graph.innerHTML = '';
  Q._initImpactBrowser();
};

// ── Clear functions ─────────────────────────────────────────────────
Q.clearImpact = () => {
  const input = document.getElementById('impact-input');
  if (input) input.value = '';
  const summary = document.getElementById('impact-summary');
  if (summary) summary.innerHTML = Q.emptyHTML('Select a component and click Compute.');
  const graph = document.getElementById('impact-graph');
  if (graph) graph.innerHTML = '';
  const ai = document.getElementById('impact-ai');
  if (ai) { ai.style.display = 'none'; ai.innerHTML = ''; }
};

Q.clearExplore = () => {
  const search = document.getElementById('explore-search');
  if (search) search.value = '';
  document.getElementById('f-layer').value = '';
  document.getElementById('f-conf').value = '';
  document.getElementById('explore-results').innerHTML = '<div class="empty"><div class="empty-text">Search or pick a tile from Home</div></div>';
  document.getElementById('explore-focus').innerHTML = '<div class="empty"><div class="empty-text">Select something to explore</div></div>';
  Q.closeSide();
  Q.state.selectedNode = null;
  Q.state.selectedFlow = null;
};

// ── Impact Entity Browser ───────────────────────────────────────────
Q._impBrowseCache = null;

Q._initImpactBrowser = () => {
  const qEl = document.getElementById('imp-browse-q');
  const layerEl = document.getElementById('imp-browse-layer');
  const typeEl = document.getElementById('imp-browse-type');
  if (!qEl) return;

  // Debounced search
  let timer = null;
  const run = () => { clearTimeout(timer); timer = setTimeout(() => Q._browseEntities(), 250); };
  // Only bind once
  if (!qEl._bound) {
    qEl.addEventListener('input', run);
    qEl.addEventListener('keydown', e => { if (e.key === 'Enter') { clearTimeout(timer); Q._browseEntities(); } });
    layerEl.addEventListener('change', run);
    typeEl.addEventListener('change', run);
    qEl._bound = true;
  }

  // Load popular entities on first visit
  if (!Q._impBrowseCache) Q._loadBrowseInventory();
  else Q._renderBrowseRecs('');
};

Q._loadBrowseInventory = async () => {
  try {
    const data = await Q.api('/inventory');
    const all = [];
    for (const [layer, types] of Object.entries(data.nodes_by_layer || {})) {
      for (const [type, nodes] of Object.entries(types)) {
        nodes.forEach(n => all.push({ ...n, layer, type }));
      }
    }
    // Sort by confidence desc, then by connection count (heuristic: endpoints/controllers first)
    const priority = ['endpoint','controller','service','function','component','table'];
    all.sort((a, b) => {
      const pa = priority.indexOf(a.type), pb = priority.indexOf(b.type);
      const ra = pa >= 0 ? pa : 99, rb = pb >= 0 ? pb : 99;
      if (ra !== rb) return ra - rb;
      return (b.confidence || 0) - (a.confidence || 0);
    });
    Q._impBrowseCache = all;
    Q._renderBrowseRecs('');
  } catch (e) {
    Q._impBrowseCache = [];
  }
};

Q._renderBrowseRecs = query => {
  const el = document.getElementById('imp-browse-recs');
  if (!el || !Q._impBrowseCache) return;
  const q = (query || '').toLowerCase();

  // Recommend: if user typed something, fuzzy-match and show top suggestions
  // If empty, show high-value entities (endpoints, controllers with high confidence)
  let recs;
  if (q) {
    recs = Q._impBrowseCache.filter(n =>
      (n.label || '').toLowerCase().includes(q) ||
      (n.id || '').toLowerCase().includes(q) ||
      (n.type || '').toLowerCase().includes(q)
    ).slice(0, 5);
  } else {
    // Show top recommended entities for impact analysis
    recs = Q._impBrowseCache.filter(n =>
      ['endpoint','controller','service','function'].includes(n.type)
    ).slice(0, 5);
  }

  if (!recs.length) { el.innerHTML = ''; return; }
  let html = `<div class="imp-recs-label">${q ? 'Suggestions' : 'Recommended for impact'}</div>`;
  recs.forEach(n => {
    const short = (n.label || n.id || '').split('::').pop();
    html += `<div class="imp-rec-chip" onclick="Q.pickImpact('${Q.esc(n.id)}', true)">
      ${Q.layerBadge(n.layer)}<span class="imp-rec-name">${Q.esc(Q.trunc(short, 40))}</span><span class="badge b-type">${Q.esc(n.type)}</span>
    </div>`;
  });
  el.innerHTML = html;
};

Q._browseEntities = () => {
  const q = (document.getElementById('imp-browse-q')?.value || '').toLowerCase();
  const layer = document.getElementById('imp-browse-layer')?.value || '';
  const type = document.getElementById('imp-browse-type')?.value || '';
  const list = document.getElementById('imp-browse-list');
  if (!list) return;

  // Update recommendations
  Q._renderBrowseRecs(q);

  if (!Q._impBrowseCache) { list.innerHTML = Q.loadingHTML(); return; }
  if (!q && !layer && !type) {
    list.innerHTML = '<div class="empty"><div class="empty-text">Type to search entities</div></div>';
    return;
  }

  let filtered = Q._impBrowseCache;
  if (q) filtered = filtered.filter(n =>
    (n.label || '').toLowerCase().includes(q) ||
    (n.id || '').toLowerCase().includes(q)
  );
  if (layer) filtered = filtered.filter(n => n.layer === layer);
  if (type) filtered = filtered.filter(n => n.type === type);

  const shown = filtered.slice(0, 50);
  if (!shown.length) { list.innerHTML = '<div class="empty"><div class="empty-text">No matching entities</div></div>'; return; }

  let html = `<div class="imp-browse-count">${filtered.length} entities${filtered.length > 50 ? ' (showing 50)' : ''}</div>`;
  shown.forEach(n => {
    const short = (n.label || n.id || '').split('::').pop();
    html += `<div class="imp-browse-item" onclick="Q.pickImpact('${Q.esc(n.id)}')">
      <div class="imp-browse-item-top">
        ${Q.layerBadge(n.layer)}
        <span class="imp-browse-item-name">${Q.esc(Q.trunc(short, 45))}</span>
        ${Q.confBadge(n.confidence)}
      </div>
      <div class="imp-browse-item-meta">
        <span class="badge b-type">${Q.esc(n.type)}</span>
        <span class="muted">${Q.esc(Q.trunc(n.repo, 25))}</span>
      </div>
    </div>`;
  });
  list.innerHTML = html;
};

Q.impactAC = async query => {
  const list = document.getElementById('impact-ac');
  if (!list) return;
  if (!query || query.length < 2) { list.classList.remove('open'); return; }
  try {
    const data = await Q.api(`/search?q=${encodeURIComponent(query)}&top_k=8&expand_depth=0`);
    const items = (data.node_results || []).slice(0, 8);
    if (!items.length) { list.classList.remove('open'); return; }
    list.innerHTML = items.map(n => {
      const m = n.metadata;
      return `<div class="ac-item" onclick="Q.pickImpact('${Q.esc(m.node_id)}')">
        ${Q.layerBadge(m.layer)} <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${Q.esc((m.node_id || '').split(':').pop())}</span>
        <span class="muted" style="font-size:10px">${Q.esc(m.type)}</span>
      </div>`;
    }).join('');
    list.classList.add('open');
  } catch (e) { list.classList.remove('open'); }
};

Q.pickImpact = (nodeId, autoRun) => {
  document.getElementById('impact-input').value = nodeId;
  document.getElementById('impact-ac')?.classList.remove('open');
  if (autoRun) Q.runImpact();
};

Q.goImpact = nodeId => {
  Q.navigate('impact');
  document.getElementById('impact-input').value = nodeId;
  Q.runImpact();
};

Q.runImpact = async () => {
  const nodeId = document.getElementById('impact-input')?.value.trim();
  if (!nodeId) return;
  const direction = document.getElementById('impact-dir')?.value || 'downstream';
  const summary = document.getElementById('impact-summary');
  const graphEl = document.getElementById('impact-graph');
  summary.innerHTML = Q.loadingHTML();
  graphEl.innerHTML = '';

  try {
    const data = await Q.api('/blast_radius', { method: 'POST', body: { component_id: nodeId, direction, max_depth: 4 } });
    Q.renderImpactSummary(data);
    Q.renderImpactGraph(data);
    Q.fetchImpactAI(data);
  } catch (e) {
    summary.innerHTML = Q.emptyHTML('Failed: ' + e.message);
  }
};

Q.renderImpactSummary = data => {
  const el = document.getElementById('impact-summary');
  if (data.error) { el.innerHTML = Q.emptyHTML(data.error); return; }

  const sc = data.severity_counts || {};
  let html = '';

  // Origin
  html += `<div class="section-label">Origin</div>`;
  html += `<div style="font-size:13px;font-weight:600;margin-bottom:4px">${Q.esc(data.origin_label || data.origin)}</div>`;
  html += `<div class="card-meta mb-3">${Q.layerBadge(data.origin_layer)} <span class="muted">${data.total_impacted} impacted</span></div>`;

  // Severity
  html += `<div class="section-label">Severity</div>`;
  html += `<div class="sev-bar">`;
  if (sc.critical) html += `<span class="sev-chip sev-critical">${sc.critical} Critical</span>`;
  if (sc.high) html += `<span class="sev-chip sev-high">${sc.high} High</span>`;
  if (sc.medium) html += `<span class="sev-chip sev-medium">${sc.medium} Medium</span>`;
  if (sc.low) html += `<span class="sev-chip sev-low">${sc.low} Low</span>`;
  html += `</div>`;

  // By layer
  if (data.by_layer) {
    html += `<div class="section-label">Affected Layers</div>`;
    html += `<div class="card-meta mb-3">`;
    Object.entries(data.by_layer).forEach(([l, c]) => { html += `${Q.layerBadge(l)} <span class="muted">${c}</span> `; });
    html += `</div>`;
  }

  // Node list
  html += `<div class="section-label">Impacted Nodes</div>`;
  (data.nodes || []).slice(0, 40).forEach(n => {
    const sevCls = 'sev-' + (n.bucket || 'low');
    html += `<div class="impact-node" onclick="Q.openNode('${Q.esc(n.id)}')">
      <span class="impact-score ${sevCls}">${n.severity.toFixed(0)}</span>
      ${Q.layerBadge(n.layer)}
      <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${Q.esc(Q.trunc(n.label, 35))}</span>
      <span class="muted" style="font-size:10px">d${n.depth}</span>
    </div>`;
  });

  el.innerHTML = html;
};

Q.renderImpactGraph = data => {
  const canvas = document.getElementById('impact-graph');
  if (!canvas || typeof d3 === 'undefined') return;
  canvas.innerHTML = '';

  const W = canvas.clientWidth || 600;
  const H = canvas.clientHeight || 340;

  const sevColors = { critical: '#CC0000', high: '#E37400', medium: '#F9AB00', low: '#888888' };

  const origin = { id: data.origin, label: data.origin_label || data.origin, layer: data.origin_layer, depth: -1, bucket: 'origin', severity: 100 };
  const impacted = (data.nodes || []).slice(0, 60);
  const allNodes = [origin, ...impacted].map(n => ({ ...n }));
  const nodeById = Object.fromEntries(allNodes.map(n => [n.id, n]));

  // Build edges from path arrays
  const edges = [];
  const seenPairs = new Set();
  impacted.forEach(n => {
    const path = n.path || [];
    if (path.length >= 2) {
      const pid = path[path.length - 2];
      const cid = path[path.length - 1];
      const key = pid + '|' + cid;
      if (!seenPairs.has(key) && nodeById[pid] && nodeById[cid]) {
        seenPairs.add(key);
        edges.push({ source: nodeById[pid], target: nodeById[cid] });
      }
    }
  });
  // Direct children
  impacted.filter(n => n.depth === 1).forEach(n => {
    const key = data.origin + '|' + n.id;
    if (!seenPairs.has(key) && nodeById[data.origin] && nodeById[n.id]) {
      seenPairs.add(key);
      edges.push({ source: nodeById[data.origin], target: nodeById[n.id] });
    }
  });

  const svg = d3.select(canvas).append('svg').attr('width', '100%').attr('height', '100%').attr('viewBox', [0, 0, W, H]);
  const defs = svg.append('defs');
  defs.append('marker').attr('id', 'arr').attr('viewBox', '0 -4 8 8').attr('refX', 12).attr('refY', 0)
    .attr('markerWidth', 5).attr('markerHeight', 5).attr('orient', 'auto')
    .append('path').attr('d', 'M0,-4L8,0L0,4').attr('fill', '#AAAAAA');

  const g = svg.append('g');
  const zoomBehavior = d3.zoom().scaleExtent([0.1, 6]).on('zoom', e => g.attr('transform', e.transform));
  svg.call(zoomBehavior);

  // Store refs for toolbar controls
  Q._impactSvg = svg;
  Q._impactG = g;
  Q._impactZoom = zoomBehavior;
  Q._impactW = W;
  Q._impactH = H;
  Q._impactOrigin = origin;
  Q._impactNodes = allNodes;
  document.getElementById('imp-graph-toolbar').style.display = '';

  const link = g.append('g').selectAll('line').data(edges).join('line')
    .attr('stroke', '#CCCCCC').attr('stroke-width', 1).attr('marker-end', 'url(#arr)');

  const r = n => n.depth === -1 ? 12 : Math.max(4, 10 - (n.depth || 0) * 1.5);
  const color = n => n.depth === -1 ? '#CC0000' : (sevColors[n.bucket] || '#AAAAAA');

  const node = g.append('g').selectAll('g').data(allNodes).join('g')
    .attr('cursor', 'pointer')
    .on('click', (e, d) => { if (d.depth !== -1) Q.openNode(d.id); })
    .call(d3.drag()
      .on('start', (e, d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
      .on('drag', (e, d) => { d.fx = e.x; d.fy = e.y; })
      .on('end', (e, d) => { if (!e.active) sim.alphaTarget(0); d.fx = null; d.fy = null; }));

  node.append('circle').attr('r', d => r(d)).attr('fill', d => color(d))
    .attr('stroke', d => d.depth === -1 ? '#990000' : '#FFFFFF').attr('stroke-width', 1.5);

  node.append('text').attr('dy', d => -r(d) - 3).attr('text-anchor', 'middle')
    .attr('font-size', d => d.depth === -1 ? '10px' : '8px')
    .attr('fill', '#555555').attr('pointer-events', 'none')
    .text(d => { const l = (d.label || d.id || '').split('::').pop(); return l.length > 16 ? l.slice(0, 14) + '…' : l; });

  node.append('title').text(d => `${d.label || d.id}\n${(d.layer || '').toUpperCase()} · depth ${d.depth}\nSeverity: ${d.severity || 0}`);

  const sim = d3.forceSimulation(allNodes)
    .force('link', d3.forceLink(edges).id(d => d.id).distance(50).strength(0.6))
    .force('charge', d3.forceManyBody().strength(-180).distanceMax(300))
    .force('center', d3.forceCenter(W / 2, H / 2).strength(0.08))
    .force('collide', d3.forceCollide().radius(d => r(d) + 6))
    .force('radial', d3.forceRadial(d => d.depth === -1 ? 0 : (d.depth || 1) * 55, W / 2, H / 2).strength(0.5))
    .on('tick', () => {
      link.attr('x1', d => d.source.x).attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x).attr('y2', d => d.target.y);
      node.attr('transform', d => `translate(${d.x},${d.y})`);
    });

  // Auto-fit after simulation settles
  setTimeout(() => {
    sim.alphaTarget(0);
    setTimeout(() => Q.impactFitView(), 500);
  }, 2500);
};

// ── Graph toolbar functions ─────────────────────────────────────────────────────
Q.impactFitView = () => {
  if (!Q._impactSvg || !Q._impactG || !Q._impactNodes || !Q._impactZoom) return;
  const nodes = Q._impactNodes;
  if (!nodes.length) return;
  const xs = nodes.map(n => n.x).filter(v => isFinite(v));
  const ys = nodes.map(n => n.y).filter(v => isFinite(v));
  if (!xs.length) return;
  const x0 = Math.min(...xs), x1 = Math.max(...xs);
  const y0 = Math.min(...ys), y1 = Math.max(...ys);
  const pad = 40;
  const bw = (x1 - x0) + pad * 2 || 1;
  const bh = (y1 - y0) + pad * 2 || 1;
  const W = Q._impactW, H = Q._impactH;
  const scale = Math.min(W / bw, H / bh, 2.5) * 0.9;
  const tx = W / 2 - (x0 + x1) / 2 * scale;
  const ty = H / 2 - (y0 + y1) / 2 * scale;
  Q._impactSvg.transition().duration(600)
    .call(Q._impactZoom.transform, d3.zoomIdentity.translate(tx, ty).scale(scale));
};

Q.impactFocusOrigin = () => {
  if (!Q._impactSvg || !Q._impactOrigin || !Q._impactZoom) return;
  const o = Q._impactOrigin;
  if (!isFinite(o.x) || !isFinite(o.y)) return;
  const W = Q._impactW, H = Q._impactH;
  const scale = 1.8;
  const tx = W / 2 - o.x * scale;
  const ty = H / 2 - o.y * scale;
  Q._impactSvg.transition().duration(500)
    .call(Q._impactZoom.transform, d3.zoomIdentity.translate(tx, ty).scale(scale));
};

Q.impactZoomIn = () => {
  if (!Q._impactSvg || !Q._impactZoom) return;
  Q._impactSvg.transition().duration(300).call(Q._impactZoom.scaleBy, 1.5);
};

Q.impactZoomOut = () => {
  if (!Q._impactSvg || !Q._impactZoom) return;
  Q._impactSvg.transition().duration(300).call(Q._impactZoom.scaleBy, 0.67);
};

Q.fetchImpactAI = async data => {
  const el = document.getElementById('impact-ai');
  if (!el) return;
  el.style.display = '';
  el.innerHTML = '<div class="ai-box-head">🤖 AI Impact Analysis</div><div class="loading">Generating…</div>';
  try {
    const payload = {
      origin: data.origin, origin_label: data.origin_label, origin_layer: data.origin_layer,
      direction: data.direction, change_type: data.change_type,
      severity_counts: data.severity_counts, by_layer: data.by_layer,
      nodes: (data.nodes||[]).slice(0,20).map(n => ({id:n.id,label:n.label,layer:n.layer,type:n.type,bucket:n.bucket,depth:n.depth,relation_from_parent:n.relation_from_parent})),
    };
    const result = await Q.api('/blast_radius/explain', { method:'POST', body:payload });
    if (result.error) { el.style.display = 'none'; return; }
    el.innerHTML = `<div class="ai-box-head">🤖 AI Impact Analysis</div><div>${Q._formatProvenance(result.explanation)}</div>`;
  } catch (e) { el.style.display = 'none'; }
};


/* ═══════════════════════════════════════════════════════════════════
   Phase G: CHAT
   ═══════════════════════════════════════════════════════════════════ */

Q.sendChat = async () => {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text || Q.state.chatSending) return;

  Q.state.chatSending = true;
  document.getElementById('chat-send').disabled = true;
  input.value = '';

  Q._appendChat('user', Q.esc(text));
  Q._appendChat('assistant', '<div class="loading">Thinking…</div>', true);

  try {
    const result = await Q.api('/chat', {
      method: 'POST',
      body: { message: text, conversation_id: Q.state.chatConvId || '', code_mode: false },
    });
    if (result.conversation_id) Q.state.chatConvId = result.conversation_id;
    Q._removeTemp();
    Q._appendChat('assistant', Q._formatChat(result));
  } catch (e) {
    Q._removeTemp();
    Q._appendChat('assistant', `<span style="color:var(--red)">Error: ${Q.esc(e.message)}</span>`);
  }

  Q.state.chatSending = false;
  document.getElementById('chat-send').disabled = false;
};

Q.newChat = () => {
  Q.state.chatConvId = null;
  const el = document.getElementById('chat-messages');
  el.innerHTML = `<div class="chat-welcome"><div class="chat-welcome-icon">🫡</div><p><strong>At your service.</strong></p><p class="muted">Ask about endpoints, flows, blast radius, or anything in the codebase.</p></div>`;
};

Q._appendChat = (role, html, temp) => {
  const container = document.getElementById('chat-messages');
  const welcome = container.querySelector('.chat-welcome');
  if (welcome) welcome.remove();
  const div = document.createElement('div');
  div.className = `chat-msg chat-msg-${role}`;
  if (temp) div.classList.add('chat-temp');
  div.innerHTML = `<div class="bubble">${html}</div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
};

Q._removeTemp = () => {
  const t = document.querySelector('.chat-temp');
  if (t) t.remove();
};

Q._formatChat = result => {
  let html = Q._formatProvenance(result.response || '');

  if (result.sources?.length) {
    html += `<div style="margin-top:8px;padding-top:6px;border-top:1px solid var(--border);font-size:11px">`;
    html += `<div style="font-weight:600;color:var(--fg-3);margin-bottom:4px">Sources</div>`;
    result.sources.slice(0, 5).forEach(s => {
      const short = (s.id || '').split(':').slice(-2).join(':');
      html += `<span style="display:inline-block;padding:1px 6px;margin:2px;background:var(--surface-2);border:1px solid var(--border);border-radius:var(--r-pill);cursor:pointer;font-size:10px" onclick="Q.openNode('${Q.esc(s.id)}')">${Q.esc(short)}</span> `;
    });
    html += `</div>`;
  }

  const stats = result.retrieval_stats || {};
  html += `<div class="muted" style="font-size:10px;margin-top:6px">${stats.nodes_retrieved || 0} nodes · ${stats.flows_retrieved || 0} flows · ${result.latency_ms || 0}ms</div>`;
  return html;
};

Q._formatProvenance = text => {
  if (!text) return '';
  let h = Q.esc(text);
  h = h.replace(/\[OBSERVED\]/g, '<span style="background:var(--green-light);color:var(--green);padding:0 4px;border-radius:3px;font-size:9px;font-weight:700">OBSERVED</span>');
  h = h.replace(/\[DERIVED\]/g, '<span style="background:var(--blue-light);color:var(--blue);padding:0 4px;border-radius:3px;font-size:9px;font-weight:700">DERIVED</span>');
  h = h.replace(/\[INFERRED\]/g, '<span style="background:var(--yellow-light);color:#7B6100;padding:0 4px;border-radius:3px;font-size:9px;font-weight:700">INFERRED</span>');
  h = h.replace(/\[UNKNOWN\]/g, '<span style="background:var(--surface-3);color:var(--fg-3);padding:0 4px;border-radius:3px;font-size:9px;font-weight:700">UNKNOWN</span>');
  h = h.replace(/```(\w*)\n([\s\S]*?)```/g, (_, lang, code) => `<pre style="background:var(--surface-2);border:1px solid var(--border);border-radius:var(--r-sm);padding:8px;margin:6px 0;font-size:11px;overflow-x:auto;white-space:pre"><code>${code}</code></pre>`);
  h = h.replace(/`([^`]+)`/g, '<code>$1</code>');
  h = h.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  h = h.replace(/\n/g, '<br>');
  return h;
};
