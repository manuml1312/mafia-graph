# Architecture — {Project Name}

<!-- 
  MAFIA Architecture Diagram Definition
  ======================================
  This file defines the system architecture for visualization in the MAFIA explorer.
  
  FORMAT RULES:
  - Each ## section is a ZONE (swimlane) in the diagram
  - Each ### under a zone is a COMPONENT (box) in the diagram  
  - Components have YAML-like metadata: type, color, description
  - The ## Connections section defines all edges between components
  - Connection format: Source -> Target : label
  
  COMPONENT TYPES (determines default color):
    frontend, gateway, service, database, queue, external, agent, storage, config
  
  COLOR OVERRIDE (optional, any CSS color):
    color: #D97706
-->

## User Interface

### Web Application
- type: frontend
- description: React/Next.js frontend for user interaction

### Admin Dashboard  
- type: frontend
- description: Internal admin panel for monitoring

## API & Orchestration

### API Gateway
- type: gateway
- description: Main entry point, routes requests to services

### Auth Service
- type: service
- description: JWT authentication and authorization

## Core Services

### User Service
- type: service
- description: User profile management and CRUD operations

### Order Service
- type: service
- description: Order processing and lifecycle management

### Notification Service
- type: service
- description: Email, SMS, push notification dispatch

## Data Stores

### Users DB
- type: database
- description: PostgreSQL — user profiles, credentials

### Orders DB
- type: database
- description: PostgreSQL — orders, line items, history

### Cache Layer
- type: database
- color: #0891B2
- description: Redis — session cache, rate limiting

## External Services

### Payment Provider
- type: external
- description: Stripe/PayPal payment processing

### Email Service
- type: external
- description: SendGrid transactional email delivery

## Connections

Web Application -> API Gateway : HTTP/REST
Admin Dashboard -> API Gateway : HTTP/REST
API Gateway -> Auth Service : Authenticate
API Gateway -> User Service : Route Request
API Gateway -> Order Service : Route Request
Auth Service -> Users DB : Verify Credentials
User Service -> Users DB : CRUD
User Service -> Cache Layer : Session Cache
Order Service -> Orders DB : Read/Write
Order Service -> Notification Service : Trigger Notification
Order Service -> Payment Provider : Process Payment
Notification Service -> Email Service : Send Email
