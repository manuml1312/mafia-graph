/* ═══════════════════════════════════════════════════════════════════════════
   MAFIA Landing — Upload → Process → Explore
   Drag-drop uploads files to server, pipeline runs on server-side paths.
   ═══════════════════════════════════════════════════════════════════════════ */

const sources = [];   // {type, name, kind, files?, path?}
let pollTimer = null;

// ── Screen switching ────────────────────────────────────────────────────────
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ── Drag & drop ─────────────────────────────────────────────────────────────
function handleDragOver(e) { e.preventDefault(); e.stopPropagation(); document.getElementById('drop-zone').classList.add('drag-over'); }
function handleDragLeave(e) { e.preventDefault(); document.getElementById('drop-zone').classList.remove('drag-over'); }

function handleDrop(e) {
  e.preventDefault();
  document.getElementById('drop-zone').classList.remove('drag-over');
  const items = e.dataTransfer.items;
  if (!items || !items.length) return;

  // Collect all file entries recursively
  const promises = [];
  for (let i = 0; i < items.length; i++) {
    const entry = items[i].webkitGetAsEntry ? items[i].webkitGetAsEntry() : null;
    if (entry) {
      promises.push(traverseEntry(entry, entry.name));
    }
  }

  Promise.all(promises).then(results => {
    const allFiles = results.flat();
    if (allFiles.length === 0) return;
    const roots = new Set();
    allFiles.forEach(f => { roots.add(f.relPath.split('/')[0]); });
    roots.forEach(root => {
      const filesForRoot = allFiles.filter(f => f.relPath.startsWith(root + '/') || f.relPath === root);
      addUploadSource(root, filesForRoot);
    });
  });
}

// Recursively traverse a dropped directory entry
function traverseEntry(entry, pathPrefix) {
  return new Promise(resolve => {
    if (entry.isFile) {
      entry.file(file => {
        resolve([{ file, relPath: pathPrefix }]);
      }, () => resolve([]));
    } else if (entry.isDirectory) {
      const reader = entry.createReader();
      const allEntries = [];
      const readBatch = () => {
        reader.readEntries(entries => {
          if (entries.length === 0) {
            Promise.all(allEntries.map(e => traverseEntry(e, pathPrefix + '/' + e.name)))
              .then(results => resolve(results.flat()));
          } else {
            allEntries.push(...entries);
            readBatch();
          }
        }, () => resolve([]));
      };
      readBatch();
    } else {
      resolve([]);
    }
  });
}

// ── Click to browse (folder mode) ──────────────────────────────────────────
document.getElementById('drop-zone').addEventListener('click', () => {
  document.getElementById('file-input').click();
});

function handleFileSelect(e) {
  const fileList = e.target.files;
  if (!fileList.length) return;
  const roots = new Set();
  const allFiles = [];
  for (const f of fileList) {
    const rel = f.webkitRelativePath || f.name;
    allFiles.push({ file: f, relPath: rel });
    roots.add(rel.split('/')[0]);
  }
  roots.forEach(root => {
    const filesForRoot = allFiles.filter(f => f.relPath.startsWith(root + '/'));
    addUploadSource(root, filesForRoot);
  });
  e.target.value = '';
}

function handleZipSelect(e) {
  const invalid = [];
  for (const f of e.target.files) {
    if (!f.name.toLowerCase().endsWith('.zip')) {
      invalid.push(f.name);
      continue;
    }
    addUploadSource(f.name, [{ file: f, relPath: f.name }]);
  }
  if (invalid.length) {
    alert(`Only .zip files are accepted.\nRejected: ${invalid.join(', ')}`);
  }
  e.target.value = '';
}

// ── Local path input (power user option) ────────────────────────────────────
function addLocalPath() {
  const input = document.getElementById('path-input');
  const path = input.value.trim();
  if (!path) return;
  sources.push({ type: 'path', name: path.split(/[/\\]/).pop() || path, kind: 'local', path });
  input.value = '';
  renderSources();
}
document.getElementById('path-input').addEventListener('keydown', e => { if (e.key === 'Enter') addLocalPath(); });

// ── Source management ───────────────────────────────────────────────────────
function addUploadSource(name, files) {
  if (sources.some(s => s.name === name)) return;
  sources.push({ type: 'upload', name, kind: 'folder', files });
  renderSources();
}

function removeSource(idx) { sources.splice(idx, 1); renderSources(); }
function clearSources() { sources.length = 0; renderSources(); }

function renderSources() {
  const container = document.getElementById('selected-sources');
  const list = document.getElementById('sources-list');
  const count = document.getElementById('sources-count');
  if (!sources.length) { container.classList.add('hidden'); return; }
  container.classList.remove('hidden');
  count.textContent = `${sources.length} source${sources.length > 1 ? 's' : ''} selected`;
  const icons = { folder: '📁', zip: '📦', file: '📄', local: '💻' };
  list.innerHTML = sources.map((s, i) => {
    const fileCount = s.files ? ` (${s.files.length} files)` : '';
    return `<div class="source-item">
      <span class="source-icon">${icons[s.kind] || '📁'}</span>
      <span class="source-path" title="${esc(s.path || s.name)}">${esc(s.name)}${fileCount}</span>
      <span class="source-type">${s.kind}</span>
      <button class="source-remove" onclick="removeSource(${i})" aria-label="Remove">✕</button>
    </div>`;
  }).join('');
}

// ── Start pipeline ──────────────────────────────────────────────────────────
async function startPipeline() {
  if (!sources.length) return;
  showScreen('screen-processing');
  setProgressMessage('Preparing files...');

  try {
    // 1) Upload any browser-selected files to the server
    const uploadSources = sources.filter(s => s.type === 'upload' && s.files);
    const localPaths = sources.filter(s => s.type === 'path').map(s => s.path);
    let serverRoots = [...localPaths];

    if (uploadSources.length) {
      setProgressMessage('Checking for local paths...');

      // Try to resolve each upload source as a local path first (avoids uploading)
      const stillNeedUpload = [];
      for (const src of uploadSources) {
        try {
          const r = await fetch('/api/resolve-local', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: src.name }),
          });
          if (r.ok) {
            const d = await r.json();
            if (d.found && d.path) {
              serverRoots.push(d.path);
              setProgressMessage(`Found local path: ${d.path}`);
            } else {
              stillNeedUpload.push(src);
            }
          } else {
            stillNeedUpload.push(src);
          }
        } catch (e) {
          stillNeedUpload.push(src);
        }
      }

      // Only upload what couldn't be resolved locally
      if (stillNeedUpload.length) {
        setProgressMessage(`Uploading ${stillNeedUpload.reduce((n,s) => n + (s.files?.length||0), 0)} files to server...`);
        const formData = new FormData();
        for (const src of stillNeedUpload) {
          for (const entry of src.files) {
            formData.append('files', entry.file);
            formData.append('paths', entry.relPath);
          }
        }
        const upResp = await fetch('/api/upload-repos', { method: 'POST', body: formData });
        const upData = await upResp.json();
        if (upData.error) { showError(upData.error); return; }
        serverRoots.push(...(upData.source_roots || []));
        setProgressMessage(`Uploaded ${upData.saved} files → ${(upData.root_folders || []).join(', ')}`);
      }
    }

    if (!serverRoots.length) { showError('No source roots resolved.'); return; }

    // 2) Create a new session folder for this run
    setProgressMessage('Creating session...');
    const sessionName = sources.map(s => s.name).join(', ').slice(0, 60);
    const sessionResp = await fetch('/api/sessions/new', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: sessionName }),
    });
    const sessionData = await sessionResp.json();
    if (sessionData.error) { showError(sessionData.error); return; }
    const outputDir = sessionData.path;
    updateActiveSessionBadge(outputDir);

    // 3) Start the pipeline writing to the new session folder
    setProgressMessage('Starting analysis pipeline...');
    const enableVectorIndex = document.getElementById('toggle-vector-index')?.checked || false;
    const resp = await fetch('/api/pipeline/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source_roots: serverRoots,
        enable_vector_index: enableVectorIndex,
        output_dir: outputDir,
      }),
    });
    const data = await resp.json();
    if (data.error) { showError(data.error); return; }
    startPolling();
  } catch (e) {
    showError('Failed to start pipeline: ' + e.message);
  }
}

function setProgressMessage(msg) {
  const el = document.getElementById('progress-label');
  if (el) el.textContent = msg;
}

// ── Poll for progress ───────────────────────────────────────────────────────
function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(pollProgress, 800);
  pollProgress();
}

async function pollProgress() {
  try {
    const resp = await fetch('/api/pipeline/status');
    const data = await resp.json();
    updateProgress(data);
    if (data.status === 'complete') {
      clearInterval(pollTimer); pollTimer = null;
      setTimeout(() => showComplete(data.stats), 600);
    } else if (data.status === 'failed') {
      clearInterval(pollTimer); pollTimer = null;
      showError(data.error);
    }
  } catch (e) { /* retry silently */ }
}

function updateProgress(data) {
  const pct = data.total_phases > 0 ? Math.min(95, (data.phase_num / data.total_phases) * 100) : 0;
  document.getElementById('progress-bar').style.width = pct + '%';
  document.getElementById('progress-label').textContent = data.message || 'Processing...';

  const phaseNums = [2, 3, 5, 6, 7, 8, 9, 10, 11, 14];
  phaseNums.forEach(pn => {
    const el = document.querySelector(`.phase-item[data-phase="${pn}"]`);
    if (!el) return;
    el.classList.remove('active', 'done', 'error');
    const st = el.querySelector('.phase-state');
    if (pn < data.phase_num) { el.classList.add('done'); st.textContent = '✓ done'; }
    else if (pn === data.phase_num) { el.classList.add('active'); st.textContent = 'running…'; }
    else { st.textContent = 'pending'; }
  });

  if (data.status === 'failed') {
    const active = document.querySelector('.phase-item.active');
    if (active) { active.classList.remove('active'); active.classList.add('error'); active.querySelector('.phase-state').textContent = 'failed'; }
  }

  // Event log — append only new entries
  const logBody = document.getElementById('log-body');
  const events = data.events || [];
  const cur = logBody.children.length;
  for (let i = cur; i < events.length; i++) {
    const ev = events[i];
    const div = document.createElement('div');
    div.className = `log-entry ${ev.kind === 'error' ? 'error' : ev.kind === 'warn' ? 'warn' : 'info'}`;
    const t = ev.time ? new Date(ev.time).toLocaleTimeString() : '';
    div.innerHTML = `<span class="log-time">${t}</span>${esc(ev.message)}`;
    logBody.appendChild(div);
  }
  logBody.scrollTop = logBody.scrollHeight;
}

function showError(msg) {
  const el = document.getElementById('proc-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

function showComplete(stats) {
  showScreen('screen-complete');
  document.getElementById('progress-bar').style.width = '100%';
  const s = stats || {};
  document.getElementById('complete-stats').innerHTML =
    `<div class="stat-pill"><div class="stat-val">${s.repos || 0}</div><div class="stat-lbl">Repos</div></div>` +
    `<div class="stat-pill"><div class="stat-val">${s.entities || 0}</div><div class="stat-lbl">Entities</div></div>` +
    `<div class="stat-pill"><div class="stat-val">${s.relations || 0}</div><div class="stat-lbl">Relations</div></div>` +
    `<div class="stat-pill"><div class="stat-val">${s.gate_passed ? '✅' : '⚠'}</div><div class="stat-lbl">Quality Gate</div></div>`;
}

function navigateToExplorer() { _flowNavigate('/explorer'); }
function goToExplorer() { _flowNavigate('/explorer'); }

function _flowNavigate(url) {
  const overlay = document.getElementById('transition-overlay');
  if (!overlay) { window.location.href = url; return; }
  overlay.classList.add('active');
  const wipe = document.getElementById('flow-wipe');
  if (wipe) { wipe.classList.add('wiping'); }
  setTimeout(() => { window.location.href = url; }, 700);
}

async function goToExplorerFromBanner() {
  try {
    const resp = await fetch('/api/pipeline/has-data');
    const data = await resp.json();
    if (data.initialized) { _flowNavigate('/explorer'); return; }
    const sResp = await fetch('/api/sessions');
    const sData = await sResp.json();
    const active = sData.active || (sData.sessions || []).find(s => s.has_data)?.path;
    if (active) {
      await fetch('/api/sessions/set', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: active }),
      });
    }
  } catch (e) { /* proceed */ }
  _flowNavigate('/explorer');
}

function goToLanding() {
  clearSources();
  document.getElementById('proc-error').classList.add('hidden');
  document.getElementById('log-body').innerHTML = '';
  document.getElementById('progress-bar').style.width = '0%';
  document.querySelectorAll('.phase-item').forEach(el => {
    el.classList.remove('active', 'done', 'error');
    el.querySelector('.phase-state').textContent = 'pending';
  });
  showScreen('screen-landing');
}

// ── Utility ─────────────────────────────────────────────────────────────────
function esc(s) { if (!s) return ''; const d = document.createElement('div'); d.textContent = String(s); return d.innerHTML; }

// ── Sessions Drawer ──────────────────────────────────────────────────────────
function toggleDrawer(open) {
  document.getElementById('sessions-drawer').classList.toggle('open', open);
  document.getElementById('drawer-overlay').classList.toggle('open', open);
  if (open) {
    loadSessions();
    prefillDefaultPath();
  }
}

async function loadSessions() {
  const list = document.getElementById('sessions-list');
  list.innerHTML = '<div class="session-empty">Loading…</div>';
  try {
    const resp = await fetch('/api/sessions');
    const data = await resp.json();
    renderSessionList(data.sessions || [], data.active || '');
  } catch (e) {
    list.innerHTML = '<div class="session-empty" style="color:var(--crimson)">Failed to load sessions</div>';
  }
}

function renderSessionList(sessions, active) {
  const list = document.getElementById('sessions-list');
  if (!sessions.length) {
    list.innerHTML = '<div class="session-empty">No sessions yet. Set an output path to create one.</div>';
    return;
  }
  list.innerHTML = sessions.map(s => {
    const isActive = s.path === active;
    const date = s.last_used ? new Date(s.last_used).toLocaleDateString() : '';
    const repos = s.repos && s.repos.length ? s.repos.slice(0, 3).join(', ') : '—';
    return `<div class="session-card ${isActive ? 'active' : ''}">
      <div class="session-card-top">
        <span class="session-name">${esc(s.name)}</span>
        ${isActive ? '<span class="session-badge">active</span>' : ''}
        <button class="session-delete" onclick="deleteSession(${_sessionPath(s.path)})" title="Remove">✕</button>
      </div>
      <div class="session-meta">${esc(s.path)}</div>
      <div class="session-meta" style="display:flex;justify-content:space-between">
        <span>${s.has_data ? '✓ has data' : '○ no data'}</span>
        <span>${date}</span>
      </div>
      <div class="session-actions-primary">
        ${!isActive ? `<button class="btn btn-ghost btn-sm" onclick="activateSession(${_sessionPath(s.path)})">Activate</button>` : ''}
        ${s.has_data ? `<button class="btn btn-accent btn-sm" onclick="loadAndExplore(${_sessionPath(s.path)})">&#128269; Explore</button>` : ''}
      </div>
      ${s.has_data ? `<div class="session-actions-secondary">
        <button class="btn btn-ghost btn-sm" onclick="rerunSession(${_sessionPath(s.path)}, false)" title="Incremental: only changed repos">↻ Update</button>
        <button class="btn btn-ghost btn-sm" onclick="rerunSession(${_sessionPath(s.path)}, true)" title="Full re-extract all repos">⟳ Full Re-run</button>
        <button class="btn btn-ghost btn-sm" onclick="addSourcesToSession(${_sessionPath(s.path)})" title="Add new source paths">＋ Sources</button>
        <button class="btn btn-ghost btn-sm" onclick="showVersions(${_sessionPath(s.path)})" title="Version history">⏱ Versions</button>
      </div>` : ''}
    </div>`;
  }).join('');
}

async function setOutputPath() {
  const input = document.getElementById('output-path-input');
  const path = input.value.trim();
  if (!path) return;
  const status = document.getElementById('output-path-status');
  status.textContent = 'Setting…';
  try {
    const resp = await fetch('/api/sessions/set', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path }),
    });
    const data = await resp.json();
    if (data.error) { status.style.color = 'var(--crimson)'; status.textContent = data.error; return; }
    status.style.color = 'var(--green)';
    status.textContent = data.loaded ? '✓ Loaded existing data' : '✓ Session created';
    input.value = '';
    loadSessions();
    updateActiveSessionBadge(path);
    if (data.loaded) showExistingDataBanner();
  } catch (e) {
    status.style.color = 'var(--crimson)';
    status.textContent = 'Request failed';
  }
}

async function activateSession(path) {
  try {
    const resp = await fetch('/api/sessions/set', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path }),
    });
    const data = await resp.json();
    if (data.error) { alert(data.error); return; }
    updateActiveSessionBadge(path);
    // Navigate to explorer home after activation
    toggleDrawer(false);
    _flowNavigate('/explorer');
  } catch (e) { alert('Failed to activate session'); }
}

async function loadAndExplore(path) {
  toggleDrawer(false);
  // Fire session set in background — don't wait for it
  fetch('/api/sessions/set', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  }).catch(() => {});
  updateActiveSessionBadge(path);
  // Show hero screen immediately, navigate right away
  // The explorer page will poll /api/init/status and slash when ready
  _flowNavigate('/explorer');
}

async function deleteSession(path) {
  await fetch('/api/sessions/delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  });
  loadSessions();
}

function newSession() {
  const name = prompt('Session name (optional):') ?? '';
  const path = prompt('Output directory path:')?.trim();
  if (!path) return;
  fetch('/api/sessions/set', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path, name }),
  }).then(r => r.json()).then(data => {
    if (data.error) { alert(data.error); return; }
    loadSessions();
    updateActiveSessionBadge(path);
  });
}

async function rerunSession(path, full) {
  const mode = full ? 'full re-run' : 'incremental update';
  if (!confirm(`Run ${mode} on this session?\n${path}`)) return;
  // Activate the session first
  await fetch('/api/sessions/set', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  });
  updateActiveSessionBadge(path);
  // Trigger rerun
  const resp = await fetch('/api/pipeline/rerun', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ full }),
  });
  const data = await resp.json();
  if (data.error) { alert(data.error); return; }
  toggleDrawer(false);
  showScreen('screen-processing');
  pollProgress();
}

async function addSourcesToSession(path) {
  const newPath = prompt('Enter new source path to add:')?.trim();
  if (!newPath) return;
  // Activate session first
  await fetch('/api/sessions/set', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  });
  updateActiveSessionBadge(path);
  const resp = await fetch('/api/sessions/add-sources', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ source_roots: [newPath], run: true }),
  });
  const data = await resp.json();
  if (data.error) { alert(data.error); return; }
  alert(`Added ${data.added?.length || 0} new source(s). Pipeline started (incremental).`);
  toggleDrawer(false);
  showScreen('screen-processing');
  pollProgress();
}

async function showVersions(path) {
  try {
    const resp = await fetch(`/api/sessions/versions?path=${encodeURIComponent(path)}`);
    const data = await resp.json();
    const versions = data.versions || [];
    if (!versions.length) { alert('No version history yet for this session.'); return; }
    const lines = versions.map(v => {
      const ts = new Date(v.timestamp).toLocaleString();
      const s = v.stats || {};
      const mode = s.mode || 'full';
      return `v${v.version}  ${ts}  [${mode}]  ${s.entity_count ?? '?'}E  ${s.relation_count ?? '?'}R`;
    });
    const diff = data.latest_diff;
    let diffText = '';
    if (diff && diff.changes && Object.keys(diff.changes).length) {
      diffText = '\n\nLatest changes (v' + diff.v1 + ' → v' + diff.v2 + '):\n';
      for (const [k, v] of Object.entries(diff.changes)) {
        const sign = v.delta > 0 ? '+' : '';
        diffText += `  ${k}: ${v.old} → ${v.new} (${sign}${v.delta})\n`;
      }
    }
    alert('Version History:\n\n' + lines.join('\n') + diffText);
  } catch (e) { alert('Failed to load versions: ' + e.message); }
}

function _sessionPath(path) {
  return JSON.stringify(path).replace(/"/g, '&quot;');
}

function updateActiveSessionBadge(path) {
  const badge = document.getElementById('active-session-badge');
  if (!badge) return;
  const name = path.split(/[\/\\]/).pop() || path;
  badge.innerHTML = `<span style="font-size:11px;color:var(--fg-3);margin-top:8px;display:block">📂 ${esc(name)}</span>`;
}

document.getElementById('output-path-input').addEventListener('keydown', e => { if (e.key === 'Enter') setOutputPath(); });

// Auto-suggest as user types
let _suggestTimer = null;
document.getElementById('output-path-input').addEventListener('input', e => {
  clearTimeout(_suggestTimer);
  _suggestTimer = setTimeout(() => fetchSuggestions(e.target.value.trim()), 300);
});

async function prefillDefaultPath() {
  const input = document.getElementById('output-path-input');
  if (input.value) return;
  try {
    const resp = await fetch('/api/sessions/suggest?q=');
    const data = await resp.json();
    const def = (data.suggestions || []).find(s => s.has_data) || data.suggestions?.[0];
    if (def) input.value = def.path;
    renderSuggestions(data.suggestions || []);
  } catch (e) {}
}

async function fetchSuggestions(q) {
  try {
    const resp = await fetch('/api/sessions/suggest?q=' + encodeURIComponent(q));
    const data = await resp.json();
    renderSuggestions(data.suggestions || []);
  } catch (e) {}
}

function renderSuggestions(suggestions) {
  let box = document.getElementById('path-suggestions');
  if (!box) {
    box = document.createElement('div');
    box.id = 'path-suggestions';
    box.className = 'path-suggestions';
    document.getElementById('output-path-input').parentNode.appendChild(box);
  }
  if (!suggestions.length) { box.innerHTML = ''; box.style.display = 'none'; return; }
  box.style.display = 'block';
  box.innerHTML = suggestions.map(s =>
    `<div class="path-suggestion-item ${s.has_data ? 'has-data' : ''}" onclick="pickSuggestion(${_sessionPath(s.path)})">
      <span class="suggestion-name">${esc(s.name)}</span>
      <span class="suggestion-path">${esc(s.path)}</span>
      ${s.has_data ? '<span class="suggestion-badge">\u2713 data</span>' : ''}
    </div>`
  ).join('');
}

function pickSuggestion(path) {
  document.getElementById('output-path-input').value = path;
  const box = document.getElementById('path-suggestions');
  if (box) { box.innerHTML = ''; box.style.display = 'none'; }
}

// ── On load: check if pipeline running or data exists ───────────────────────
async function checkExistingData() {
  try {
    const resp = await fetch('/api/pipeline/status');
    const data = await resp.json();
    if (data.status === 'running') { showScreen('screen-processing'); startPolling(); return; }
  } catch (e) {}
  try {
    const resp = await fetch('/api/pipeline/has-data');
    const data = await resp.json();
    if (data.has_data) {
      const btn = document.querySelector('.sessions-toggle');
      if (btn) btn.textContent = '\u2611 Sessions';
      showExistingDataBanner();
    }
  } catch (e) {}
}

function showExistingDataBanner() {
  const el = document.getElementById('existing-data-banner');
  if (!el) return;
  el.innerHTML = `<span style="color:#4ade80;font-weight:600">✓ Previous analysis found</span>`
    + `<button class="btn btn-ghost" style="padding:5px 12px;font-size:12px" onclick="goToExplorerFromBanner()">Open Explorer →</button>`
    + `<span style="color:var(--fg-3);font-size:11px">or drop new repos below</span>`;
}

document.addEventListener('DOMContentLoaded', checkExistingData);


// ═══════════════════════════════════════════════════════════════════════════
// Abstract mesh canvas — procedural random network with animated pulses
// ═══════════════════════════════════════════════════════════════════════════

(function initMeshCanvas() {
  const canvas = document.getElementById('mesh-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  // Hi-DPI support
  const dpr = window.devicePixelRatio || 1;
  const W = 600, H = 700;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';
  ctx.scale(dpr, dpr);

  // Generate random nodes
  const NODE_COUNT = 55;
  const nodes = [];
  const padding = 40;
  for (let i = 0; i < NODE_COUNT; i++) {
    nodes.push({
      x: padding + Math.random() * (W - padding * 2),
      y: padding + Math.random() * (H - padding * 2),
      r: 2.5 + Math.random() * 3,
      phase: Math.random() * Math.PI * 2,
    });
  }

  // Connect nearby nodes (Delaunay-ish via distance threshold)
  const MAX_DIST = 130;
  const edges = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      const d = Math.sqrt(dx * dx + dy * dy);
      if (d < MAX_DIST) {
        edges.push({ a: i, b: j, d });
      }
    }
  }

  // Animated particles traveling along edges
  const PARTICLE_COUNT = 12;
  const particles = [];
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push({
      edge: Math.floor(Math.random() * edges.length),
      t: Math.random(),
      speed: 0.003 + Math.random() * 0.005,
      forward: Math.random() > 0.5,
    });
  }

  function draw(time) {
    ctx.clearRect(0, 0, W, H);

    // Draw edges
    for (const e of edges) {
      const a = nodes[e.a], b = nodes[e.b];
      const alpha = 0.06 + 0.06 * (1 - e.d / MAX_DIST);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.strokeStyle = `rgba(204,0,0,${alpha})`;
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }

    // Draw nodes with pulse
    const t = time * 0.001;
    for (const n of nodes) {
      const pulse = 0.5 + 0.5 * Math.sin(t * 1.2 + n.phase);
      const r = n.r * (0.8 + 0.4 * pulse);
      const alpha = 0.2 + 0.4 * pulse;
      ctx.beginPath();
      ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(204,0,0,${alpha})`;
      ctx.fill();
    }

    // Draw traveling particles
    for (const p of particles) {
      const e = edges[p.edge];
      if (!e) continue;
      const a = nodes[e.a], b = nodes[e.b];
      const x = a.x + (b.x - a.x) * p.t;
      const y = a.y + (b.y - a.y) * p.t;

      ctx.beginPath();
      ctx.arc(x, y, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(204,0,0,0.7)';
      ctx.fill();

      // Glow
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(204,0,0,0.08)';
      ctx.fill();

      // Advance
      p.t += p.forward ? p.speed : -p.speed;
      if (p.t > 1 || p.t < 0) {
        // Jump to a new random edge
        p.edge = Math.floor(Math.random() * edges.length);
        p.t = p.forward ? 0 : 1;
        p.forward = Math.random() > 0.5;
      }
    }

    requestAnimationFrame(draw);
  }

  requestAnimationFrame(draw);
})();


// ═══════════════════════════════════════════════════════════════════════════
// Scroll-reveal: fade-in elements as they enter the viewport
// ═══════════════════════════════════════════════════════════════════════════

(function initScrollReveal() {
  const targets = document.querySelectorAll(
    '.feature-card, .pipeline-step, .pipeline-connector, .ribbon-stat'
  );
  if (!targets.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

  targets.forEach(el => observer.observe(el));
})();
