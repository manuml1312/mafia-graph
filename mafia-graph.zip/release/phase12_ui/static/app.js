/* ═══════════════════════════════════════════════════════════════════════════
   MAFIA Phase 12 — System Explorer SPA
   Task 1: Core framework — router, API, nav, page switching, helpers
   ═══════════════════════════════════════════════════════════════════════════ */

const API = '';  // same origin — search_api1 serves both UI and API

// ── Tooltip definitions for UI terms ────────────────────────────────────────
const TOOLTIPS = {
  confidence: {
    title: 'Confidence Score',
    text: 'How certain the extraction pipeline is about this entity.\n\u2022 \u226590% (Exact): Deterministic match from AST or known code pattern\n\u2022 \u226580% (Strong): High-confidence heuristic with naming convention + context\n\u2022 \u226560% (Inferred): Cross-file resolution or URL segment match\n\u2022 \u226540% (Weak): Partial evidence, some ambiguity\n\u2022 <40% (Guess): Very low evidence \u2014 flagged for human review',
  },
  layer: {
    title: 'Architectural Layer',
    text: 'The system tier this component belongs to:\n\u2022 UI \u2014 React/Next.js frontend components, hooks, routes\n\u2022 BFF \u2014 Backend-for-Frontend (Koa/Express) that proxies API calls\n\u2022 API \u2014 Spring Boot Java backend services\n\u2022 DB \u2014 PostgreSQL functions, tables, Databricks notebooks\n\u2022 Config \u2014 Environment variables, feature toggles, secrets',
  },
  evidence_method: {
    title: 'Evidence Method',
    text: 'How this entity was discovered:\n\u2022 regex \u2014 Pattern matching on source code\n\u2022 ast \u2014 Abstract Syntax Tree parsing\n\u2022 genai \u2014 AI-assisted discovery (capped at 70% confidence)\n\u2022 heuristic \u2014 Naming convention or structural inference',
  },
  completeness: {
    title: 'Flow Completeness',
    text: '\u2022 Complete \u2014 Every hop in the flow (UI\u2192BFF\u2192API\u2192DB) has a traced connection\n\u2022 Partial \u2014 One or more hops are missing, unresolved, or low-confidence',
  },
  entity_type: {
    title: 'Entity Type',
    text: 'The specific kind of code artifact:\n\u2022 endpoint \u2014 A registered HTTP route\n\u2022 controller \u2014 Method handling a request\n\u2022 service \u2014 Business logic layer\n\u2022 repository \u2014 Data access layer\n\u2022 component \u2014 React UI component\n\u2022 hook \u2014 React custom hook\n\u2022 function \u2014 DB stored procedure\n\u2022 table \u2014 Database table',
  },
  hop_count: {
    title: 'Hop Count',
    text: 'Number of steps in this flow chain. Each hop is a cross-component call (e.g. UI\u2192BFF is 1 hop, BFF\u2192API is another).',
  },
  severity_score: {
    title: 'Impact Severity',
    text: 'Computed blast radius severity (0\u2013100):\n\u2022 Critical (\u226580): Direct downstream dependency, high confidence\n\u2022 High (60\u201379): Close dependency, likely affected\n\u2022 Medium (40\u201359): Indirect dependency, moderate risk\n\u2022 Low (<40): Distant or low-confidence connection',
  },
  depth: {
    title: 'Dependency Depth',
    text: 'How many hops away this node is from the origin component in the blast radius graph. Depth 1 = direct dependency.',
  },
  relation_type: {
    title: 'Relation Type',
    text: 'The kind of connection between components:\n\u2022 fetches \u2014 UI calls BFF endpoint\n\u2022 calls_api \u2014 BFF calls API endpoint\n\u2022 delegates_to \u2014 Controller \u2192 Service\n\u2022 uses_repo \u2014 Service \u2192 Repository\n\u2022 calls_function \u2014 Repository \u2192 DB function\n\u2022 reads_from / writes_to \u2014 DB function \u2192 table',
  },
  orphan: {
    title: 'Orphan Node',
    text: 'A component with no upstream callers \u2014 nothing in the system calls it. Could be dead code, an entry point, or a gap in extraction.',
  },
  provenance: {
    title: 'Provenance Labels',
    text: 'How the AI knows what it tells you:\n\u2022 [OBSERVED] \u2014 Directly from code evidence\n\u2022 [DERIVED] \u2014 Computed from the dependency graph\n\u2022 [INFERRED] \u2014 AI interpretation (may be wrong)\n\u2022 [UNKNOWN] \u2014 No evidence available',
  },
  eligible_yield: {
    title: 'Eligible Yield',
    text: 'Percentage of ELIGIBLE files (core + supporting code) that produced at least one entity. Excludes generated code, vendor libs, minified bundles, test files, and assets from the denominator. This is the primary quality metric.',
  },
  overall_yield: {
    title: 'Overall Yield',
    text: 'Percentage of ALL scanned files that produced at least one entity. Includes noise files (compiled JS, vendor libs, assets) in the denominator \u2014 always lower than Eligible Yield. Useful for tracking denominator hygiene.',
  },
  file_eligibility: {
    title: 'File Eligibility',
    text: 'Before extraction, every file is classified:\n\u2022 Core code (TS, Java, SQL, JS) \u2014 eligible, should emit\n\u2022 Supporting (SCSS, CSS, .env, .properties) \u2014 eligible, may emit\n\u2022 Generated/vendor (minified, bundles, dist/) \u2014 ineligible\n\u2022 Test files \u2014 ineligible\n\u2022 Assets (images, fonts, PDFs) \u2014 ineligible',
  },
};

function tooltip(key, triggerHtml) {
  const t = TOOLTIPS[key];
  if (!t) return triggerHtml;
  const escapedText = esc(t.text).replace(/\\n/g, '<br>').replace(/\n/g, '<br>');
  return `<span class="has-tooltip">${triggerHtml}<span class="tooltip-popup"><strong>${esc(t.title)}</strong><br>${escapedText}</span></span>`;
}

// ── State ───────────────────────────────────────────────────────────────────
const state = {
  currentPage: 'search',
  selectedNode: null,      // full node object from /node/{id}
  selectedFlow: null,      // full flow object from /flow/{id}
  flowDepth: 'surface',    // surface | standard | deep
  explorerTab: 'flows',    // flows | dependencies | blast_radius
  configOverlay: false,
};

// ── Navigation history stack ────────────────────────────────────────────────
const _navHistory = [];  // [{page, nodeId?, flowId?}]
let _navPushing = true;  // false when going back (don't push)

function _pushNav() {
  if (!_navPushing) return;
  const entry = { page: state.currentPage };
  if (state.selectedNode?.node?.id) entry.nodeId = state.selectedNode.node.id;
  if (state.selectedFlow?.flow_id) entry.flowId = state.selectedFlow.flow_id;
  // Don't push duplicates
  const prev = _navHistory[_navHistory.length - 1];
  if (prev && prev.page === entry.page && prev.nodeId === entry.nodeId && prev.flowId === entry.flowId) return;
  _navHistory.push(entry);
  if (_navHistory.length > 50) _navHistory.shift();
  _updateBackBtn();
}

function _updateBackBtn() {
  const btn = document.getElementById('nav-back-btn');
  if (btn) btn.disabled = _navHistory.length < 2;
}

function goBack() {
  if (_navHistory.length < 2) return;
  _navHistory.pop(); // remove current
  const prev = _navHistory[_navHistory.length - 1];
  if (!prev) return;
  _navPushing = false;
  if (prev.nodeId) {
    openNode(prev.nodeId);
  } else if (prev.flowId) {
    openFlow(prev.flowId, 'standard');
  } else {
    navigateTo(prev.page);
  }
  _navPushing = true;
  _updateBackBtn();
}

function goHome() {
  state.selectedNode = null;
  state.selectedFlow = null;
  _pushNav();
  navigateTo('explorer');
  loadExplorerLanding();
}

// ── API helper ──────────────────────────────────────────────────────────────
async function api(path, opts = {}) {
  const url = API + path;
  try {
    const resp = await fetch(url, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json' } : {},
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({ error: resp.statusText }));
      throw new Error(err.error || resp.statusText);
    }
    return await resp.json();
  } catch (e) {
    console.error(`API ${path}:`, e);
    throw e;
  }
}

// ── Badge helpers ───────────────────────────────────────────────────────────
function layerBadge(layer) {
  const l = (layer || '').toLowerCase();
  return tooltip('layer', `<span class="badge badge-${l}">${l.toUpperCase()}</span>`);
}

function confBadge(conf) {
  if (conf == null) return '';
  const c = parseFloat(conf);
  let cls = 'badge-conf-med';
  if (c >= 0.80) cls = 'badge-conf-high';
  else if (c < 0.50) cls = 'badge-conf-low';
  return tooltip('confidence', `<span class="badge ${cls}">${(c * 100).toFixed(0)}%</span>`);
}

function methodBadge(method) {
  if (!method) return '';
  const cls = method === 'genai' ? 'badge-genai' : 'badge-method';
  return tooltip('evidence_method', `<span class="badge ${cls}">${method}</span>`);
}

function completenessBadge(comp) {
  if (comp === 'complete') return tooltip('completeness', `<span class="badge badge-complete">✅ complete</span>`);
  return tooltip('completeness', `<span class="badge badge-partial">⚠ partial</span>`);
}

function typeBadge(type, withTip = true) {
  const badge = `<span class="badge badge-type">${type || ''}</span>`;
  return withTip ? tooltip('entity_type', badge) : badge;
}

function confBadgePlain(conf) {
  if (conf == null) return '';
  const c = parseFloat(conf);
  let cls = 'badge-conf-med';
  if (c >= 0.80) cls = 'badge-conf-high';
  else if (c < 0.50) cls = 'badge-conf-low';
  return `<span class="badge ${cls}">${(c * 100).toFixed(0)}%</span>`;
}

function renderLegendBar() {
  return `<div class="legend-bar">`
    + tooltip('entity_type', `<span class="legend-trigger">📦 Entity Types</span>`)
    + tooltip('confidence', `<span class="legend-trigger">📊 Confidence Scores</span>`)
    + `</div>`;
}

// ── HTML escape ─────────────────────────────────────────────────────────────
function esc(s) {
  if (!s) return '';
  const d = document.createElement('div');
  d.textContent = String(s);
  return d.innerHTML;
}

// ── Truncate ────────────────────────────────────────────────────────────────
function trunc(s, n = 80) {
  if (!s) return '';
  return s.length > n ? s.slice(0, n) + '…' : s;
}

// ── Navigation ──────────────────────────────────────────────────────────────
function navigateTo(page, skipPush) {
  state.currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const pageEl = document.getElementById('page-' + page);
  if (pageEl) pageEl.classList.add('active');
  const navEl = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (navEl) navEl.classList.add('active');
  if (!skipPush) history.pushState({ page }, '', '#' + page);
  _pushNav();

  // Trigger page load if needed
  if (page === 'coverage') loadCoverage();
  if (page === 'repos') loadRepos();
  if (page === 'docs') loadDocs();
  if (page === 'explorer' && !state.selectedNode) {
    loadExplorerLanding();
  }
  if (page === 'flows' && !state.selectedFlow) loadAllFlows();
  if (page === 'blast') {
    const blastPage = document.getElementById('page-blast');
    if (!blastPage.dataset.loaded) {
      blastPage.dataset.loaded = '1';
      runBlastRadius(null);
    }
  }
}

// ── Right panel ─────────────────────────────────────────────────────────────
function openPanel(title, html) {
  document.getElementById('panel-title').textContent = title;
  document.getElementById('panel-content').innerHTML = html;
  document.getElementById('right-panel').classList.remove('hidden');
  document.getElementById('panel-resize').classList.remove('hidden');
}

function closePanel() {
  document.getElementById('right-panel').classList.add('hidden');
  document.getElementById('panel-resize').classList.add('hidden');
}

// ── Loading / empty states ──────────────────────────────────────────────────
function loadingHTML() {
  return '<div class="loading">Loading…</div>';
}

function emptyHTML(msg) {
  return `<div class="empty-state"><div class="empty-icon">⌀</div><div class="empty-text">${esc(msg)}</div></div>`;
}

// ── Init ────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Nav clicks
  document.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', e => {
      e.preventDefault();
      navigateTo(el.dataset.page);
    });
  });

  // Global search
  let searchTimer = null;
  document.getElementById('global-search').addEventListener('input', e => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => runSearch(e.target.value), 300);
  });
  document.getElementById('global-search').addEventListener('keydown', e => {
    if (e.key === 'Enter') { clearTimeout(searchTimer); runSearch(e.target.value); }
  });

  // Filter changes trigger search
  ['filter-layer', 'filter-confidence', 'filter-repo', 'filter-sort'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => {
      const q = document.getElementById('global-search').value;
      if (q) runSearch(q);
    });
  });

  // Browser back/forward
  window.addEventListener('popstate', e => {
    if (e.state && e.state.page) navigateTo(e.state.page, true);
  });

  // Show welcome on search page
  document.getElementById('page-search').innerHTML = emptyHTML('Start typing to search endpoints, functions, tables, components…');

  // Dismiss the entry overlay once data is truly ready, THEN load the page
  const entryOverlay = document.getElementById('entry-overlay');
  if (entryOverlay) {
    _pollUntilReady(entryOverlay, () => {
      // Called once overlay dismisses — now safe to load data-dependent pages
      const hash = location.hash.replace('#', '') || 'explorer';
      navigateTo(hash, true);
      loadRepoFilter();
    });
  } else {
    // No overlay (already removed) — load immediately
    const hash = location.hash.replace('#', '') || 'explorer';
    navigateTo(hash, true);
    loadRepoFilter();
  }

  // Show active session name in nav
  fetch('/api/sessions/active').then(r => r.json()).then(data => {
    const el = document.getElementById('nav-session');
    if (!el || !data.path) return;
    const name = data.path.split(/[\/\\]/).pop() || data.path;
    el.textContent = name;
    el.title = data.path;
  }).catch(() => {});
});

async function loadRepoFilter() {
  try {
    const data = await api('/repos');
    const sel = document.getElementById('filter-repo');
    (data.repos || []).forEach(r => {
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = r.id;
      sel.appendChild(opt);
    });
  } catch (e) { /* ignore */ }
}

async function loadExplorerLanding() {
  const page = document.getElementById('page-explorer');
  page.innerHTML = loadingHTML();
  try {
    const stats = await api('/stats');
    if (!stats.initialized) {
      // Server not ready yet — show loading, retry in 2s
      page.innerHTML = loadingHTML();
      setTimeout(loadExplorerLanding, 2000);
      return;
    }

    let html = `<div class="section-title">System Explorer</div>`;

    // Quick search hint
    html += `<div class="node-profile">`;
    html += `<h3>Start Exploring</h3>`;
    html += `<p class="muted mt-2">Search for any endpoint, function, table, or component in the search bar above, then click a result to explore its flows, dependencies, and impact.</p>`;
    html += `</div>`;

    // Info section: How the system works
    html += `<div class="info-section">`;
    html += `<div class="info-header" onclick="this.parentElement.classList.toggle('expanded')">`;
    html += `<span>ℹ️ How This System Works</span><span class="info-toggle">▶</span></div>`;
    html += `<div class="info-body">`;
    html += `<div class="info-block">`;
    html += `<h4>📥 Code Indexing</h4>`;
    html += `<p>The pipeline scans all repositories, classifies them by architectural layer (UI, BFF, API, DB) using a <strong>weighted signal ensemble</strong> (dependency files are trusted most, folder names least), then runs deterministic extractors that use regex and AST parsing to discover entities (endpoints, controllers, services, functions, tables, DTOs, config classes, stylesheets) and their relationships.</p>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>📁 File Eligibility</h4>`;
    html += `<p>Before extraction, every file is classified as <strong>eligible</strong> or <strong>ineligible</strong>. Compiled/minified JS, vendor libraries, build output, test files, and binary assets are marked ineligible — they don't count against the extraction rate. This gives an honest metric: <strong>Eligible Yield</strong> measures how much of your actual source code the pipeline understands.</p>`;
    html += `<div class="info-expand">`;
    html += `<div class="info-expand-trigger" onclick="this.parentElement.classList.toggle('open'); this.textContent = this.parentElement.classList.contains('open') ? '▼ What gets classified how?' : '▶ What gets classified how?'">▶ What gets classified how?</div>`;
    html += `<div class="info-expand-body">`;
    html += `<table class="info-table">`;
    html += `<tr><th>Category</th><th>Examples</th><th>Eligible?</th></tr>`;
    html += `<tr><td>Core code</td><td>.ts, .tsx, .java, .sql, .py, .js, .jsx</td><td>✅ Yes</td></tr>`;
    html += `<tr><td>Supporting code</td><td>.scss, .css, .env, .properties, .yaml</td><td>✅ Yes</td></tr>`;
    html += `<tr><td>Generated / vendor</td><td>*.min.js, chunk-*.js, dist/, node_modules/, webpack bundles</td><td>❌ No</td></tr>`;
    html += `<tr><td>Test files</td><td>test/, __tests__/, *.test.ts, *.spec.js</td><td>❌ No</td></tr>`;
    html += `<tr><td>Assets</td><td>.png, .jpg, .svg, .woff, .pdf, .zip</td><td>❌ No</td></tr>`;
    html += `<tr><td>Config noise</td><td>package.json, pom.xml, lockfiles, .md docs</td><td>❌ No</td></tr>`;
    html += `</table>`;
    html += `<p>Detection uses path-based rules (dist/, vendor/, build/) plus content heuristics (long lines = minified, <code>__webpack_require__</code> = bundle, <code>sourceMappingURL</code> = compiled output).</p>`;
    html += `</div></div>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>🔗 Graph Construction</h4>`;
    html += `<p>Extracted entities become nodes and relations become edges in a system graph. Cross-file and cross-repo connections are traced (e.g. a BFF controller calling an API endpoint, which calls a service, which queries a DB function). Each connection carries a confidence score. <strong>Fuzzy matching</strong> (Jaro-Winkler similarity) recovers connections that exact name lookup misses — e.g. <code>flagSvc</code> → <code>FlagServiceImpl.java</code>.</p>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>🧮 Heuristic Algorithms</h4>`;
    html += `<p>Three algorithms improve extraction quality without any AI/ML dependencies:</p>`;
    html += `<div class="info-expand">`;
    html += `<div class="info-expand-trigger" onclick="this.parentElement.classList.toggle('open'); this.textContent = this.parentElement.classList.contains('open') ? '▼ What algorithms are used?' : '▶ What algorithms are used?'">▶ What algorithms are used?</div>`;
    html += `<div class="info-expand-body">`;
    html += `<table class="info-table">`;
    html += `<tr><th>Algorithm</th><th>Where</th><th>What it does</th></tr>`;
    html += `<tr><td><strong>Jaro-Winkler fuzzy matching</strong></td><td>API, BFF, UI extractors</td><td>When exact file/constant lookup fails, fuzzy string similarity (≥0.85 threshold) recovers matches like <code>flagSvc</code> → <code>FlagServiceImpl</code>. Fuzzy-resolved entities are capped at 70% confidence.</td></tr>`;
    html += `<tr><td><strong>Bayesian confidence adjustment</strong></td><td>Post-extraction (emitter)</td><td>After all extractors merge, confidence is adjusted: +0.05 per additional extractor confirmation, +0.03 if entity has both upstream and downstream relations, −0.05 if isolated (no relations), −0.10 if in a test file path.</td></tr>`;
    html += `<tr><td><strong>Weighted signal ensemble</strong></td><td>Repo classification</td><td>Classification signals are weighted by reliability tier: dependency files (×1.0) > content sampling (×0.70) > directory structure (×0.40) > folder name (×0.30). Prevents folder-name-only repos from being misclassified.</td></tr>`;
    html += `</table>`;
    html += `<p>All three are pure Python, zero external dependencies, and run deterministically on every pipeline execution.</p>`;
    html += `</div></div>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>🔍 Search & Retrieval</h4>`;
    html += `<p>Entities are embedded into a vector index for semantic search. When you search, the system finds the closest matches, then expands results using the graph (neighbors, flows). This hybrid approach finds results even when your query doesn't exactly match the code.</p>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>📊 Confidence Scores</h4>`;
    html += `<p>Every entity and relation has a confidence score (0\u2013100%). <strong>\u226590%</strong> = exact AST/regex match. <strong>\u226580%</strong> = strong heuristic. <strong>\u226560%</strong> = cross-file inference. <strong>\u226540%</strong> = partial evidence. <strong>&lt;40%</strong> = flagged for review. Low-confidence items are shown with dashed borders.</p>`;
    html += `<div class="info-expand">`;
    html += `<div class="info-expand-trigger" onclick="this.parentElement.classList.toggle('open'); this.textContent = this.parentElement.classList.contains('open') ? '▼ How is it calculated?' : '▶ How is it calculated?'">▶ How is it calculated?</div>`;
    html += `<div class="info-expand-body">`;
    html += `<p>Think of MAFIA as a <strong>detective reading through your codebase</strong>. Each layer has its own detective (extractor) — one for UI, one for BFF, one for API, one for DB.</p>`;
    html += `<p>When a detective finds something — say, an API endpoint — it stamps a confidence level based on <strong>how strong the evidence was</strong>:</p>`;
    html += `<table class="info-table">`;
    html += `<tr><th>Score</th><th>When it's used</th><th>Real example</th></tr>`;
    html += `<tr><td><span class="badge badge-conf-high">95%</span></td><td>"I see the exact declaration. No doubt."</td><td><code>@GetMapping("/flagTypes")</code> — literally a Spring Boot endpoint</td></tr>`;
    html += `<tr><td><span class="badge badge-conf-high">85–90%</span></td><td>"Strong pattern with context, but required some interpretation."</td><td>Found <code>flagService.getFlagTypes()</code> inside a controller body</td></tr>`;
    html += `<tr><td><span class="badge badge-conf-med">70%</span></td><td>"Had to follow breadcrumbs across multiple files."</td><td>Field <code>flagService</code> → looked up <code>FlagServiceImpl.java</code> in another folder</td></tr>`;
    html += `<tr><td><span class="badge badge-conf-low">50%</span></td><td>"Partial evidence, something's ambiguous."</td><td><code>@Entity</code> class exists but no <code>@Table</code> annotation — table name is a guess</td></tr>`;
    html += `<tr><td><span class="badge badge-conf-low">30%</span></td><td>"GenAI suggested this, or barely any evidence."</td><td>AI looked at an unresolved file and guessed what it does</td></tr>`;
    html += `</table>`;
    html += `<p>The score is <strong>stamped once at extraction time</strong>, then adjusted by the Bayesian post-processor: entities confirmed by multiple extractors get boosted, isolated entities get penalized, test-file entities get penalized. If two detectives find the same thing, the higher confidence wins. It does <strong>not</strong> mean importance or usage frequency — that's what the blast radius severity score measures (a separate calculation based on depth, layer criticality, and fan-out).</p>`;
    html += `</div></div>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>🤖 AI Chat</h4>`;
    html += `<p>The chat assistant retrieves relevant entities and flows via vector search, then sends them as context to a language model. Every AI statement is labeled with provenance: [OBSERVED] (from code), [DERIVED] (from graph), [INFERRED] (AI interpretation), or [UNKNOWN]. Toggle Code Mode to let the AI read actual source files.</p>`;
    html += `</div>`;
    html += `<div class="info-block">`;
    html += `<h4>📊 Extraction Metrics</h4>`;
    html += `<p>Two yield metrics are tracked:</p>`;
    html += `<table class="info-table">`;
    html += `<tr><th>Metric</th><th>Formula</th><th>What it tells you</th></tr>`;
    html += `<tr><td><strong>Eligible Yield</strong></td><td>eligible files with entities ÷ total eligible files</td><td>How much of your actual source code the pipeline understands. This is the primary quality metric shown in the Coverage dashboard.</td></tr>`;
    html += `<tr><td><strong>Overall Yield</strong></td><td>all files with entities ÷ all scanned files</td><td>Raw rate including noise (compiled JS, vendor, assets). Always lower than Eligible Yield. Useful for tracking denominator hygiene.</td></tr>`;
    html += `</table>`;
    html += `<p>The quality gate checks Eligible Yield ≥ 50%. A healthy codebase should aim for 70%+ eligible yield — the remaining files are typically config YAML, build scripts, and edge-case patterns the extractors don't yet handle.</p>`;
    html += `</div>`;
    html += `</div></div>`;

    // Sub-tabs: Code Tree | Graph | AST
    html += `<div class="tabs mt-6">`;
    html += `<div class="tab active" id="exp-tab-codetree" onclick="switchExplorerLandingTab('codetree')">\ud83d\udcc2 Code Tree</div>`;
    html += `<div class="tab" id="exp-tab-graph" onclick="switchExplorerLandingTab('graph')">🕸 Graph</div>`;
    html += `<div class="tab" id="exp-tab-ast" onclick="switchExplorerLandingTab('ast')">🌳 AST</div>`;
    html += `</div>`;
    html += `<div id="explorer-landing-tab-content">${loadingHTML()}</div>`;

    page.innerHTML = html;
    loadCodeTreeTab();
  } catch (e) {
    // If server not ready, retry silently instead of showing error
    if (e.message && (e.message.includes('503') || e.message.includes('not loaded'))) {
      page.innerHTML = loadingHTML();
      setTimeout(loadExplorerLanding, 2000);
    } else {
      page.innerHTML = emptyHTML('Failed to load explorer: ' + e.message);
    }
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   Placeholder functions — will be implemented in subsequent tasks
   ═══════════════════════════════════════════════════════════════════════════ */

// Task 2: Search
async function runSearch(query) {
  if (!query || query.length < 2) {
    document.getElementById('page-search').innerHTML = emptyHTML('Start typing to search endpoints, functions, tables, components…');
    return;
  }
  navigateTo('search', true);
  document.getElementById('page-search').innerHTML = loadingHTML();

  const filters = {};
  const layer = document.getElementById('filter-layer').value;
  const conf = document.getElementById('filter-confidence').value;
  const repo = document.getElementById('filter-repo').value;
  if (layer) filters.layer = layer;
  if (conf) filters.min_confidence = conf;  // threshold, not exact bucket
  if (repo) filters.repo = repo;

  const params = new URLSearchParams({ q: query, top_k: 30, expand_depth: 1 });
  Object.entries(filters).forEach(([k, v]) => params.set(k, v));

  try {
    const data = await api('/search?' + params);
    renderSearchResults(data, query);
  } catch (e) {
    document.getElementById('page-search').innerHTML = emptyHTML('Search failed: ' + e.message);
  }
}

function renderSearchResults(data, query) {
  const page = document.getElementById('page-search');
  const nodes = data.node_results || [];
  const flows = data.flow_results || [];
  const repos = data.repo_results || [];

  if (!nodes.length && !flows.length && !repos.length) {
    page.innerHTML = emptyHTML('No results for "' + esc(query) + '". Try endpoint path, file name, or function name.');
    return;
  }

  // Sort nodes
  const sortMode = document.getElementById('filter-sort')?.value || 'relevance';
  if (sortMode === 'confidence') {
    nodes.sort((a, b) => (b.metadata.confidence || 0) - (a.metadata.confidence || 0));
  } else if (sortMode === 'connected') {
    nodes.sort((a, b) => (b.final_score || b.score || 0) - (a.final_score || a.score || 0));
  }

  let html = '';

  // Group nodes by layer
  if (nodes.length) {
    const groups = {};
    nodes.forEach(n => {
      const l = (n.metadata.layer || 'other').toUpperCase();
      if (!groups[l]) groups[l] = [];
      groups[l].push(n);
    });

    for (const [layer, items] of Object.entries(groups)) {
      html += `<div class="result-group">`;
      html += `<div class="result-group-title">${esc(layer)} Components (${items.length})</div>`;
      items.forEach(n => {
        const m = n.metadata;
        html += `<div class="card" data-layer="${esc(m.layer)}" onclick="openNode('${esc(m.node_id)}')">` +
          `<div class="card-title">${esc(m.node_id.split(':').pop())}</div>` +
          `<div class="card-meta">` +
            layerBadge(m.layer) + typeBadge(m.type) + confBadge(m.confidence) + methodBadge(m.evidence_method) +
            `<span class="muted">${esc(m.repo)}</span>` +
          `</div>` +
          (n.text ? `<div class="card-desc">${esc(trunc(n.text, 150))}</div>` : '') +
        `</div>`;
      });
      html += `</div>`;
    }
  }

  // Flow results
  if (flows.length) {
    html += `<div class="result-group">`;
    html += `<div class="result-group-title">Flows (${flows.length})</div>`;
    flows.forEach(f => {
      const m = f.metadata;
      html += `<div class="card" onclick="openFlow('${esc(m.flow_id)}', 'standard')">` +
        `<div class="card-title">${esc(trunc(f.text, 100))}</div>` +
        `<div class="card-meta">` +
          completenessBadge(m.completeness) + confBadge(m.confidence) +
          `<span class="muted">${m.hop_count || '?'} hops</span>` +
        `</div>` +
      `</div>`;
    });
    html += `</div>`;
  }

  // Repo results
  if (repos.length) {
    html += `<div class="result-group">`;
    html += `<div class="result-group-title">Repos (${repos.length})</div>`;
    repos.forEach(r => {
      html += `<div class="card">` +
        `<div class="card-title">${esc(r.doc_id)}</div>` +
        `<div class="card-desc">${esc(trunc(r.text, 120))}</div>` +
      `</div>`;
    });
    html += `</div>`;
  }

  html += `<div class="muted mt-8">` +
    `${data.total_results} results` +
    (data.graph_expanded ? ` (${data.graph_expanded} graph-expanded)` : '') +
    (data.truncated ? ' — truncated' : '') +
  `</div>`;

  page.innerHTML = html;
}

// Task 3: Explorer — Node profile + meaning tabs
async function openNode(nodeId) {
  navigateTo('explorer', true);
  const page = document.getElementById('page-explorer');
  page.innerHTML = loadingHTML();

  try {
    const node = await api('/node/' + encodeURIComponent(nodeId));
    state.selectedNode = node;
    state.explorerTab = 'flows';
    renderExplorer();
  } catch (e) {
    page.innerHTML = emptyHTML('Node not found: ' + e.message);
  }
}

function renderExplorer() {
  const page = document.getElementById('page-explorer');
  const n = state.selectedNode;
  if (!n || !n.node) { page.innerHTML = emptyHTML('Select a node from search results.'); return; }

  const nd = n.node;
  const nid = nd.id;

  // Node profile card
  let html = renderLegendBar();
  html += `<div class="node-profile">`;
  html += `<h2>${esc(nd.label || nd.id)}</h2>`;
  html += `<div class="meta-row">`;
  html += layerBadge(nd.layer) + typeBadge(nd.type, false) + confBadgePlain(nd.confidence) + methodBadge(nd.evidence_method);
  html += `</div>`;
  html += `<div class="meta-row"><span class="muted">Repo:</span> ${esc(nd.repo)}`;
  if (nd.file) html += ` &nbsp;|&nbsp; <span class="muted">File:</span> ${esc(nd.file)}`;
  if (nd.line) html += `:<span>${nd.line}</span>`;
  html += `</div>`;

  // Connectivity summary
  const up = n.upstream_count || 0;
  const dn = n.downstream_count || 0;
  html += `<div class="meta-row"><span class="muted">↑ ${up} callers &nbsp;|&nbsp; ↓ ${dn} targets</span>`;
  html += `<button class="action-btn" style="font-size:11px;margin-left:auto" onclick="clearExplorer()">↻ Back to Explorer</button>`;
  html += `</div>`;

  // Cross-layer completeness summary
  const connLayers = new Set();
  connLayers.add(nd.layer);
  // We derive this from the node's neighbors if available
  if (n.files) {
    // files come from the API, but we need neighbor layers — use a quick heuristic from node ID patterns
  }
  // Build completeness label from upstream/downstream layer info (will be enriched when neighbors load)
  html += `<div id="completeness-summary" class="meta-row muted"></div>`;

  // Warnings
  const warns = nd.warnings || [];
  if (warns.length) {
    html += `<div class="mt-8">`;
    warns.slice(0, 3).forEach(w => { html += `<span class="warning-chip">${esc(trunc(w, 50))}</span> `; });
    if (warns.length > 3) html += `<span class="muted">+${warns.length - 3} more</span>`;
    html += `</div>`;
  }

  // Intelligence text from panel
  if (n.intelligence) {
    html += `<div class="card-desc mt-8">${esc(trunc(n.intelligence, 250))}</div>`;
  }

  // Action bar
  html += `<div class="action-bar">`;
  html += `<button class="action-btn" onclick="showUpstream('${esc(nid)}')">↑ Upstream</button>`;
  html += `<button class="action-btn" onclick="showDownstream('${esc(nid)}')">↓ Downstream</button>`;
  html += `<button class="action-btn" onclick="showEvidence('${esc(nid)}')">📄 Evidence</button>`;
  html += `<button class="action-btn" onclick="showCode('${esc(nid)}')">💻 Code</button>`;
  html += `<button class="action-btn" onclick="showAstSummary('${esc(nid)}')">🔬 Structure</button>`;
  html += `<button class="action-btn" onclick="runBlastRadius('${esc(nid)}')">💥 Blast Radius</button>`;
  html += `<button class="action-btn" onclick="loadNodeFlowsPanel('${esc(nid)}')">⟿ Flows</button>`;
  html += `</div>`;
  html += `</div>`;

  // Meaning tabs
  html += `<div class="tabs">`;
  ['flows', 'dependencies', 'blast_radius'].forEach(t => {
    const label = t === 'flows' ? '🔗 Flows' : t === 'dependencies' ? '🧩 Dependencies' : '💥 Blast Radius';
    html += `<div class="tab ${state.explorerTab === t ? 'active' : ''}" onclick="switchExplorerTab('${t}')">${label}</div>`;
  });
  html += `</div>`;

  html += `<div id="explorer-tab-content">${loadingHTML()}</div>`;
  page.innerHTML = html;

  // Load tab content
  loadExplorerTab(nid);

  // Load cross-layer completeness summary
  loadCompletenessSummary(nid);
}

async function loadCompletenessSummary(nodeId) {
  const el = document.getElementById('completeness-summary');
  if (!el) return;
  try {
    const data = await api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=both&limit=50`);
    const layers = new Set();
    const nd = state.selectedNode?.node;
    if (nd) layers.add(nd.layer);
    (data.neighbors || []).forEach(n => layers.add(n.layer));
    const order = ['ui','bff','api','db'];
    const chain = order.filter(l => layers.has(l));
    if (chain.length > 1) {
      el.innerHTML = `Cross-layer: ${chain.map(l => l.toUpperCase()).join(' → ')}`;
    } else if (chain.length === 1) {
      el.innerHTML = `Single layer: ${chain[0].toUpperCase()} (no cross-layer connections)`;
    }
  } catch(e) { /* ignore */ }
}

function switchExplorerTab(tab) {
  state.explorerTab = tab;
  // Update tab active state
  document.querySelectorAll('#page-explorer .tab').forEach(t => t.classList.remove('active'));
  document.querySelector(`#page-explorer .tab:nth-child(${tab === 'flows' ? 1 : tab === 'dependencies' ? 2 : 3})`).classList.add('active');
  if (tab === 'blast_radius') {
    const nid = state.selectedNode?.node?.id;
    if (nid) runBlastRadiusOnPage(nid);
    else navigateTo('blast');
    return;
  }
  const nid = state.selectedNode?.node?.id;
  if (nid) loadExplorerTab(nid);
}

async function loadExplorerTab(nodeId) {
  const container = document.getElementById('explorer-tab-content');
  if (!container) return;
  container.innerHTML = loadingHTML();

  try {
    if (state.explorerTab === 'flows') {
      await loadNodeFlows(nodeId);
    } else if (state.explorerTab === 'dependencies') {
      // Budget controls
      let html = `<div class="budget-controls">`;
      html += `<span>Depth:</span> <select id="dep-depth" onchange="reloadDeps('${esc(nodeId)}')"><option value="1" selected>1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select>`;
      html += `<span>Budget:</span> <span id="dep-budget">50</span> nodes`;
      html += `</div><div id="dep-results">${loadingHTML()}</div>`;
      container.innerHTML = html;
      const data = await api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=both&limit=50`);
      renderDependencies(document.getElementById('dep-results') || container, data);
    }
  } catch (e) {
    container.innerHTML = emptyHTML('Failed to load: ' + e.message);
  }
}

async function reloadDeps(nodeId) {
  const depth = parseInt(document.getElementById('dep-depth')?.value || '1');
  const container = document.getElementById('dep-results');
  if (!container) return;
  container.innerHTML = loadingHTML();
  try {
    // Use subgraph for multi-depth
    if (depth > 1) {
      const data = await api(`/subgraph?center=${encodeURIComponent(nodeId)}&direction=both&depth=${depth}&limit=50&edge_types=flow`);
      let html = '';
      const nodes = (data.nodes || []).filter(n => n.id !== nodeId);
      if (!nodes.length) { container.innerHTML = emptyHTML('No neighbors at this depth.'); return; }
      nodes.forEach(n => {
        html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
          `<div class="card-title">${esc(n.label || n.id)}</div>` +
          `<div class="card-meta">${layerBadge(n.layer)} ${typeBadge(n.type, false)} ${confBadgePlain(n.confidence)}</div></div>`;
      });
      if (data.metadata?.truncated) html += `<button class="show-more-btn" onclick="alert('Increase depth or budget')">Truncated at ${data.metadata.limit} nodes</button>`;
      container.innerHTML = html;
    } else {
      const data = await api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=both&limit=50`);
      renderDependencies(container, data);
    }
  } catch (e) {
    container.innerHTML = emptyHTML('Failed: ' + e.message);
  }
}

function renderDependencies(container, data) {
  const neighbors = data.neighbors || [];
  if (!neighbors.length) { container.innerHTML = emptyHTML('No neighbors found.'); return; }

  const upstream = neighbors.filter(n => n.direction === 'upstream');
  const downstream = neighbors.filter(n => n.direction === 'downstream');

  let html = '';
  if (upstream.length) {
    html += `<div class="section-title">↑ Upstream Callers (${upstream.length})</div>`;
    upstream.forEach(n => {
      html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
        `<div class="card-title">${esc(n.label)}</div>` +
        `<div class="card-meta">${layerBadge(n.layer)} ${typeBadge(n.type, false)} ${confBadgePlain(n.confidence)} ` +
        `<span class="muted">${esc(n.relation)}</span></div></div>`;
    });
  }
  if (downstream.length) {
    html += `<div class="section-title mt-16">↓ Downstream Targets (${downstream.length})</div>`;
    downstream.forEach(n => {
      html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
        `<div class="card-title">${esc(n.label)}</div>` +
        `<div class="card-meta">${layerBadge(n.layer)} ${typeBadge(n.type, false)} ${confBadgePlain(n.confidence)} ` +
        `<span class="muted">${esc(n.relation)}</span></div></div>`;
    });
  }
  if (data.truncated) html += `<button class="show-more-btn" onclick="loadMoreNeighbors('${esc(data.node_id)}','both',${neighbors.length})">Show more (+50 nodes)</button>`;
  container.innerHTML = html;
}

// Task 4: Flow viewer — Surface / Standard / Deep + breakpoints

function clearFlows() {
  state.selectedFlow = null;
  loadAllFlows();
}

function clearExplorer() {
  state.selectedNode = null;
  loadExplorerLanding();
}

function clearCoverage() {
  const page = document.getElementById('page-coverage');
  delete page.dataset.loaded;
  loadCoverage();
}

function clearRepos() {
  const page = document.getElementById('page-repos');
  delete page.dataset.loaded;
  loadRepos();
}

async function loadAllFlows() {
  const page = document.getElementById('page-flows');
  page.innerHTML = loadingHTML();
  try {
    const data = await api('/flows?mode=surface&limit=50');
    const flows = data.flows || [];
    if (!flows.length) { page.innerHTML = emptyHTML('No flows found.'); return; }
    let html = `<div class="flex items-center justify-between mb-4">`;
    html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">All Flows (${data.total}${data.truncated ? '+' : ''})</div>`;
    html += `<button class="action-btn" onclick="clearFlows()">↻ Refresh</button>`;
    html += `</div>`;
    flows.forEach(f => {
      html += `<div class="flow-card" onclick="openFlow('${esc(f.flow_id)}', 'standard')">`;
      html += `<div class="card-title">${esc(trunc(f.surface_summary || f.flow_id, 100))}</div>`;
      html += `<div class="flow-meta">`;
      html += completenessBadge(f.completeness);
      html += confBadge(f.confidence);
      html += `<span class="muted">${f.hop_count} hops</span>`;
      html += `</div></div>`;
    });
    if (data.truncated) html += `<div class="muted mt-4">Showing first 50 flows.</div>`;
    page.innerHTML = html;
  } catch (e) {
    page.innerHTML = emptyHTML('Failed to load flows: ' + e.message);
  }
}

async function openFlow(flowId, depth) {
  depth = depth || 'standard';
  state.flowDepth = depth;
  navigateTo('flows', true);
  const page = document.getElementById('page-flows');
  page.innerHTML = loadingHTML();

  try {
    const flow = await api(`/flow/${encodeURIComponent(flowId)}?depth=${depth}`);
    state.selectedFlow = flow;
    renderFlowDetail(page, flow, depth);
  } catch (e) {
    page.innerHTML = emptyHTML('Flow not found: ' + e.message);
  }
}

async function loadNodeFlows(nodeId) {
  const container = document.getElementById('explorer-tab-content');
  if (!container) return;
  container.innerHTML = loadingHTML();

  try {
    const data = await api(`/flows?start_node=${encodeURIComponent(nodeId)}&mode=surface&limit=50`);
    renderFlowSurface(container, data, nodeId);
  } catch (e) {
    container.innerHTML = emptyHTML('Failed to load flows: ' + e.message);
  }
}

function renderFlowSurface(container, data, contextNodeId) {
  const flows = data.flows || [];
  if (!flows.length) { container.innerHTML = emptyHTML('No flows pass through this node.'); return; }

  let html = `<div class="section-title">Flows (${data.total}${data.truncated ? '+' : ''})</div>`;

  flows.forEach(f => {
    const summary = f.surface_summary || f.flow_id;
    html += `<div class="flow-card" onclick="openFlow('${esc(f.flow_id)}', 'standard')">`;
    html += `<div class="card-title">${esc(trunc(summary, 100))}</div>`;
    html += `<div class="flow-meta">`;
    html += completenessBadge(f.completeness);
    html += confBadge(f.confidence);
    html += `<span class="muted">${f.hop_count} hops</span>`;
    html += `</div></div>`;
  });

  if (data.truncated) html += `<div class="muted mt-8">Showing first 50 flows.</div>`;
  container.innerHTML = html;
}

function renderFlowDetail(container, flow, depth) {
  let html = renderLegendBar();

  // Flow header
  html += `<div class="flex items-center justify-between mb-4">`;
  html += `<span></span>`;
  html += `<button class="action-btn" onclick="clearFlows()">← All Flows</button>`;
  html += `</div>`;
  html += `<div class="node-profile">`;
  html += `<h2>${esc(flow.surface_summary || flow.flow_id)}</h2>`;
  html += `<div class="meta-row">`;
  html += completenessBadge(flow.completeness);
  const cr = flow.confidence_range || {};
  html += confBadgePlain(cr.avg);
  html += `<span class="muted">${flow.hop_count} hops</span>`;
  html += `<span class="muted">${(flow.repos_involved || []).join(', ')}</span>`;
  html += `</div>`;
  if (flow.standard_summary) html += `<div class="card-desc mt-8">${esc(flow.standard_summary)}</div>`;
  if (flow.data_flow) html += `<div class="card-desc">${esc(flow.data_flow)}</div>`;
  if (flow.business_intent) html += `<div class="card-desc"><em>[Inferred]</em> ${esc(flow.business_intent)}</div>`;
  html += `<div class="action-bar" style="margin-top:8px">`;
  html += `<button class="action-btn" onclick="runFlowBlastRadius('${esc(flow.flow_id)}')">\u26a1 Flow Blast Radius</button>`;
  html += `</div>`;
  html += `</div>`;

  // Depth mode switcher
  html += `<div class="tabs">`;
  ['surface', 'standard', 'deep'].forEach(d => {
    html += `<div class="tab ${depth === d ? 'active' : ''}" onclick="openFlow('${esc(flow.flow_id)}', '${d}')">${d.charAt(0).toUpperCase() + d.slice(1)}</div>`;
  });
  html += `</div>`;

  // Failure points with suggested actions (Gap 8 breakpoint suggestions)
  if (flow.failure_points && flow.failure_points.length) {
    html += `<div class="breakpoint">`;
    html += `<div class="bp-reason">⚠ Failure Points</div>`;
    flow.failure_points.forEach(fp => {
      html += `<div>${esc(fp)}</div>`;
      // Suggest next debug action based on failure text
      if (fp.toLowerCase().includes('confidence')) {
        html += `<div class="muted" style="font-size:11px;margin-left:12px">→ Suggested: Inspect evidence for low-confidence hops, check extraction method</div>`;
      } else if (fp.toLowerCase().includes('break') || fp.toLowerCase().includes('not_traced')) {
        html += `<div class="muted" style="font-size:11px;margin-left:12px">→ Suggested: Expand service calls, show structural imports for the break point</div>`;
      } else if (fp.toLowerCase().includes('unresolved') || fp.toLowerCase().includes('candidate')) {
        html += `<div class="muted" style="font-size:11px;margin-left:12px">→ Suggested: Show candidates, review alternative targets</div>`;
      }
    });
    html += `</div>`;
  }

  // Hop chain
  const hops = flow.hop_narration || [];
  if (depth === 'surface') {
    // Compact one-line hop chain
    html += `<div class="flow-hops" style="font-size:13px; margin-top:12px;">`;
    hops.forEach((h, i) => {
      html += `<span class="flow-hop badge-${(h.layer||'').toLowerCase()}" style="cursor:pointer" onclick="openNode('${esc(h.id)}')">${esc(h.name)}</span>`;
      if (i < hops.length - 1) html += `<span class="flow-arrow">→</span>`;
    });
    html += `</div>`;
  } else {
    // Standard / Deep hop chain
    html += `<div class="hop-chain">`;
    hops.forEach((h, i) => {
      const isLowConf = h.confidence < 0.5;
      const collapsed = depth === 'standard' ? 'collapsed' : '';
      html += `<div class="hop-item" data-layer="${esc(h.layer)}">`;
      html += `<div class="hop-header" onclick="toggleHop(this)">`;
      html += `<span class="hop-name" onclick="event.stopPropagation(); openNode('${esc(h.id)}')">${esc(h.name)}</span> `;
      html += layerBadge(h.layer) + typeBadge(h.type, false) + confBadgePlain(h.confidence);
      if (isLowConf) html += ` <span class="warning-chip">low confidence</span>`;
      if (depth === 'standard') html += ` <span class="hop-toggle muted">▶</span>`;
      html += `</div>`;
      if (h.relation_to_next) html += `<span class="hop-relation">${esc(h.relation_to_next)}</span>`;
      html += `<div class="hop-body ${collapsed}">`;
      if (h.description) html += `<div class="hop-desc">${esc(trunc(h.description, 200))}</div>`;
      // Evidence button for this hop
      html += `<button class="action-btn mt-8" style="font-size:11px" onclick="event.stopPropagation(); showEvidence('${esc(h.id)}')">📄 Evidence</button> `;
      html += `<button class="action-btn mt-8" style="font-size:11px" onclick="event.stopPropagation(); showCode('${esc(h.id)}')">💻 Code</button>`;
      html += `<button class="action-btn mt-8" style="font-size:11px" onclick="event.stopPropagation(); showAstSummary('${esc(h.id)}')">🔬 Structure</button>`;

      // Deep mode: show inline evidence
      if (depth === 'deep') {
        html += renderHopEvidence(h, flow);
      }
      html += `</div>`; // hop-body
      html += `</div>`; // hop-item
    });
    html += `</div>`;
  }

  // Deep mode: source code files
  if (depth === 'deep' && flow.source_code && flow.source_code.files) {
    html += `<div class="section-title mt-16">💻 Source Code</div>`;
    flow.source_code.files.forEach(f => {
      html += `<div class="mb-4">`;
      html += `<div class="flex items-center justify-between">`;
      html += `<span class="ev-file">${esc(f.repo)}/${esc(f.file)} (line ${f.entity_line || '?'})</span>`;
      html += `<button class="jump-btn" onclick="showFullFile('${esc(f.hop_entity || f.entity_id || '')}')" style="font-size:10px">View Full File</button>`;
      html += `</div>`;
      html += `<div class="code-block">`;
      const lines = (f.code || '').split('\n');
      const startLine = f.focus_start || 1;
      lines.forEach((line, i) => {
        const lineNum = startLine + i;
        const isTarget = lineNum === f.entity_line;
        html += `<span class="code-line ${isTarget ? 'line-highlight' : ''}"><span class="line-num">${lineNum}</span>${esc(line)}</span>`;
      });
      html += `</div></div>`;
    });
    if (flow.source_code.truncated) html += `<div class="muted">Source code truncated at ${flow.source_code.files_read} files.</div>`;
  }

  // File listing
  if (flow.files && flow.files.length) {
    html += `<div class="section-title mt-16">📁 Files Involved</div>`;
    flow.files.forEach(f => {
      html += `<div class="muted" style="font-size:11px; padding:2px 0; cursor:pointer" onclick="showCode('${esc(f.entity_id)}')">`;
      html += `${esc(f.repo)}/${esc(f.file)}${f.line ? ':' + f.line : ''} ${f.exists ? '' : '❌ not found'}`;
      html += `</div>`;
    });
  }

  container.innerHTML = html;
}

function renderHopEvidence(hop, flow) {
  const fileInfo = (flow.files || []).find(f => f.entity_id === hop.id);
  let html = `<div class="hop-evidence">`;
  if (fileInfo) {
    html += `<div class="ev-file">${esc(fileInfo.repo)}/${esc(fileInfo.file)}${fileInfo.line ? ':' + fileInfo.line : ''}</div>`;
  }
  html += `<div class="muted">Provenance: ${esc(hop.provenance || 'derived')} &nbsp;|&nbsp; Confidence: ${((hop.confidence || 0) * 100).toFixed(0)}%</div>`;
  if (hop.description) {
    html += `<div class="mt-8">${esc(hop.description)}</div>`;
  }

  // Gap 4: Candidate alternatives (if ambiguous)
  // These come from the relation's candidates array in the raw data
  // We surface them if the hop has low confidence
  if (hop.confidence < 0.7) {
    html += `<div class="warning-chip mt-8">⚠ Confidence below 0.70 — may have alternative targets</div>`;
  }

  // Gap 5: Structural drilldown buttons (Deep-only opt-in)
  html += `<div class="mt-8" style="display:flex;gap:4px;flex-wrap:wrap">`;
  html += `<button class="action-btn" style="font-size:10px" onclick="event.stopPropagation(); showStructural('${esc(hop.id)}','imports')">Show imports</button>`;
  html += `<button class="action-btn" style="font-size:10px" onclick="event.stopPropagation(); showStructural('${esc(hop.id)}','exports')">Show exports</button>`;
  html += `<button class="action-btn" style="font-size:10px" onclick="event.stopPropagation(); showStructural('${esc(hop.id)}','defined_in')">Show defined_in</button>`;
  html += `<button class="action-btn" style="font-size:10px" onclick="event.stopPropagation(); showAstSummary('${esc(hop.id)}')">🔬 Structure</button>`;
  html += `</div>`;

  html += `</div>`;
  return html;
}

// Gap 5: Structural drilldown (opt-in)
async function showStructural(nodeId, relType) {
  openPanel(`Structural: ${relType}`, loadingHTML());
  try {
    const data = await api(`/subgraph?center=${encodeURIComponent(nodeId)}&direction=both&depth=1&limit=20&edge_types=structural`);
    const nodes = data.nodes || [];
    if (!nodes.length) { openPanel(`Structural: ${relType}`, emptyHTML('No structural relations found.')); return; }
    let html = `<div class="section-title">${relType} for ${esc(nodeId.split(':').pop())}</div>`;
    nodes.forEach(n => {
      if (n.id === nodeId) return;
      html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
        `<div class="card-title">${esc(n.label || n.id)}</div>` +
        `<div class="card-meta">${layerBadge(n.layer)} ${typeBadge(n.type)} <span class="muted">${esc(n.file || '')}</span></div>` +
      `</div>`;
    });
    openPanel(`Structural (${nodes.length - 1})`, html);
  } catch (e) {
    openPanel('Structural', emptyHTML('Failed: ' + e.message));
  }
}

// Task 5: Right panel — Evidence, code viewer, upstream/downstream drawers
async function showEvidence(nodeId) {
  openPanel('Evidence', loadingHTML());
  try {
    const node = await api('/node/' + encodeURIComponent(nodeId));
    const nd = node.node || {};
    let html = '';
    html += `<div class="mb-8"><strong>${esc(nd.label)}</strong></div>`;
    html += `<div class="meta-row mb-8">${layerBadge(nd.layer)} ${typeBadge(nd.type)} ${confBadge(nd.confidence)} ${methodBadge(nd.evidence_method)}</div>`;
    if (nd.file) html += `<div class="ev-file mb-8">${esc(nd.repo)}/${esc(nd.file)}${nd.line ? ':' + nd.line : ''}</div>`;

    // Confidence rationale
    const c = nd.confidence || 0;
    let rationale = '';
    if (c >= 0.90) rationale = 'Deterministic match from known pattern (AST/regex).';
    else if (c >= 0.80) rationale = 'High-confidence heuristic with context.';
    else if (c >= 0.60) rationale = 'Cross-file resolution or URL segment match.';
    else if (c >= 0.40) rationale = 'Partial evidence, some ambiguity.';
    else rationale = 'Very low evidence — flagged for review.';
    // Evidence method description
    const em = nd.evidence_method || 'unknown';
    let emDesc = '';
    if (em === 'regex') emDesc = 'Discovered by pattern-matching source code with regular expressions.';
    else if (em === 'ast') emDesc = 'Discovered by parsing the Abstract Syntax Tree of the source file.';
    else if (em === 'genai') emDesc = 'Discovered by AI-assisted analysis (capped at 70% confidence, requires human review).';
    else if (em === 'heuristic') emDesc = 'Discovered by naming convention or structural inference.';
    else emDesc = 'Extraction method not recorded.';
    html += `<div class="muted mb-8">${tooltip('confidence', '📊')} ${rationale}</div>`;
    html += `<div class="muted mb-8">${tooltip('evidence_method', '🔬')} <em>${esc(em)}</em> — ${emDesc}</div>`;

    // Warnings
    const warns = nd.warnings || [];
    if (warns.length) {
      html += `<div class="section-title mt-8">Warnings (${warns.length})</div>`;
      warns.forEach(w => { html += `<div class="warning-chip mb-8">${esc(w)}</div>`; });
    }

    // Try to get snippet from code reader
    html += `<div class="mt-8"><button class="action-btn" onclick="showCode('${esc(nodeId)}')">View Source Code</button></div>`;

    openPanel('Evidence: ' + trunc(nd.label, 30), html);
  } catch (e) {
    openPanel('Evidence', emptyHTML('Failed: ' + e.message));
  }
}

async function showCode(entityId) {
  openPanel('Source Code', loadingHTML());
  try {
    const data = await api('/code/' + encodeURIComponent(entityId) + '?context_lines=30');
    if (data.error) {
      openPanel('Source Code', emptyHTML(data.error));
      return;
    }
    let html = `<div class="ev-file mb-2">${esc(data.repo)}/${esc(data.file)}${data.entity_line ? ':' + data.entity_line : ''}</div>`;
    html += `<div class="flex items-center justify-between mb-3">`;
    html += `<span class="muted text-xs">Lines ${data.focus_start}–${data.focus_end} of ${data.total_lines}</span>`;
    html += `<button class="jump-btn" onclick="showFullFile('${esc(entityId)}')">View Full File</button>`;
    html += `</div>`;
    html += `<div class="code-block">`;
    const lines = (data.code || '').split('\n');
    lines.forEach((line, i) => {
      const lineNum = (data.focus_start || 1) + i;
      const isTarget = lineNum === data.entity_line;
      html += `<span class="code-line ${isTarget ? 'line-highlight' : ''}"><span class="line-num">${lineNum}</span>${esc(line)}</span>`;
    });
    html += `</div>`;
    openPanel('Code: ' + trunc(data.file, 30), html);
  } catch (e) {
    openPanel('Source Code', emptyHTML('Failed: ' + e.message));
  }
}

async function showFullFile(entityId) {
  openPanel('Full File', loadingHTML());
  try {
    const data = await api('/codefile?id=' + encodeURIComponent(entityId));
    if (data.error) {
      openPanel('Full File', emptyHTML(data.error));
      return;
    }

    const hl_start = data.highlight_start || 1;
    const hl_end = data.highlight_end || 1;
    const target_line = data.entity_line || 1;

    let html = `<div class="full-file-header">`;
    html += `<span class="file-path">${esc(data.repo)}/${esc(data.file)}</span>`;
    html += `<span class="file-stats">${data.total_lines} lines &nbsp;|&nbsp; Highlight: L${hl_start}–L${hl_end}</span>`;
    html += `<button class="jump-btn" id="jump-to-highlight" onclick="jumpToHighlight()">Jump to highlight</button>`;
    html += `</div>`;

    html += `<div class="code-block-full" id="full-file-code">`;
    const lines = (data.code || '').split('\n');
    lines.forEach((line, i) => {
      const lineNum = i + 1;
      let cls = 'code-line';
      if (lineNum === target_line) {
        cls += ' line-highlight-target';
      } else if (lineNum >= hl_start && lineNum <= hl_end) {
        cls += ' line-highlight-region';
      } else {
        cls += ' line-dim';
      }
      const lineId = lineNum === target_line ? ' id="target-line"' : '';
      html += `<span class="${cls}"${lineId}><span class="line-num">${lineNum}</span>${esc(line)}</span>`;
    });
    html += `</div>`;

    openPanel('Full: ' + trunc(data.file, 25), html);

    // Auto-scroll to highlighted region
    setTimeout(jumpToHighlight, 100);
  } catch (e) {
    openPanel('Full File', emptyHTML('Failed: ' + e.message));
  }
}

function jumpToHighlight() {
  const target = document.getElementById('target-line');
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

async function showUpstream(nodeId) {
  openPanel('Upstream Callers', loadingHTML());
  try {
    const data = await api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=upstream&limit=50`);
    const neighbors = data.neighbors || [];
    if (!neighbors.length) { openPanel('Upstream Callers', emptyHTML('No upstream callers found.')); return; }

    // Group by layer
    const crossLayer = neighbors.filter(n => n.layer !== state.selectedNode?.node?.layer);
    const sameLayer = neighbors.filter(n => n.layer === state.selectedNode?.node?.layer);

    let html = '';
    if (crossLayer.length) {
      html += `<div class="section-title">Cross-Layer (↑ ${crossLayer.length})</div>`;
      crossLayer.forEach(n => {
        html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
          `<div class="card-title">${esc(n.label)}</div>` +
          `<div class="card-meta">${layerBadge(n.layer)} ${typeBadge(n.type)} ${confBadge(n.confidence)} <span class="muted">${esc(n.relation)}</span></div>` +
        `</div>`;
      });
    }
    if (sameLayer.length) {
      html += `<div class="section-title mt-8">Same Layer (↑ ${sameLayer.length})</div>`;
      sameLayer.forEach(n => {
        html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
          `<div class="card-title">${esc(n.label)}</div>` +
          `<div class="card-meta">${layerBadge(n.layer)} <span class="muted">${esc(n.relation)}</span></div>` +
        `</div>`;
      });
    }
    html += `<div class="mt-8"><button class="action-btn" onclick="loadNodeFlowsPanel('${esc(nodeId)}')">Show flow chains through this node</button></div>`;
    if (data.truncated) html += `<div class="muted mt-8">Truncated at ${data.total} nodes.</div>`;
    openPanel(`Upstream (${neighbors.length})`, html);
  } catch (e) {
    openPanel('Upstream', emptyHTML('Failed: ' + e.message));
  }
}

async function showDownstream(nodeId) {
  openPanel('Downstream Targets', loadingHTML());
  try {
    const data = await api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=downstream&limit=50`);
    const neighbors = data.neighbors || [];
    if (!neighbors.length) { openPanel('Downstream Targets', emptyHTML('No downstream targets found.')); return; }

    const crossLayer = neighbors.filter(n => n.layer !== state.selectedNode?.node?.layer);
    const sameLayer = neighbors.filter(n => n.layer === state.selectedNode?.node?.layer);

    let html = '';
    if (crossLayer.length) {
      html += `<div class="section-title">Cross-Layer (↓ ${crossLayer.length})</div>`;
      crossLayer.forEach(n => {
        html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
          `<div class="card-title">${esc(n.label)}</div>` +
          `<div class="card-meta">${layerBadge(n.layer)} ${typeBadge(n.type)} ${confBadge(n.confidence)} <span class="muted">${esc(n.relation)}</span></div>` +
        `</div>`;
      });
    }
    if (sameLayer.length) {
      html += `<div class="section-title mt-8">Same Layer (↓ ${sameLayer.length})</div>`;
      sameLayer.forEach(n => {
        html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
          `<div class="card-title">${esc(n.label)}</div>` +
          `<div class="card-meta">${layerBadge(n.layer)} <span class="muted">${esc(n.relation)}</span></div>` +
        `</div>`;
      });
    }
    if (data.truncated) html += `<div class="muted mt-8">Truncated at ${data.total} nodes.</div>`;
    openPanel(`Downstream (${neighbors.length})`, html);
  } catch (e) {
    openPanel('Downstream', emptyHTML('Failed: ' + e.message));
  }
}

async function loadNodeFlowsPanel(nodeId) {
  openPanel('Flows through node', loadingHTML());
  try {
    const data = await api(`/flows?start_node=${encodeURIComponent(nodeId)}&mode=standard&limit=50`);
    const flows = data.flows || [];
    if (!flows.length) { openPanel('Flows', emptyHTML('No flows pass through this node.')); return; }

    // If exactly one flow — open it directly with the node highlighted
    if (flows.length === 1) {
      renderNodeFlowInline(flows[0], nodeId);
      return;
    }

    // Multiple flows — show list grouped by completeness, each with inline chain preview
    const complete = flows.filter(f => f.completeness === 'complete');
    const partial  = flows.filter(f => f.completeness !== 'complete');

    let html = `<div class="muted" style="font-size:11px;margin-bottom:8px">${flows.length} flow(s) pass through this node</div>`;

    const renderGroup = (label, group) => {
      if (!group.length) return '';
      let h = `<div class="section-label" style="margin-top:12px">${label}</div>`;
      group.forEach(f => {
        const hops = f.hop_narration || [];
        h += `<div class="flow-card" onclick="renderNodeFlowInline(${JSON.stringify(f).replace(/</g,'\u003c')}, '${esc(nodeId)}')">`;
        h += `<div class="card-title">${esc(trunc(f.surface_summary || f.flow_id, 80))}</div>`;
        // Inline hop chain preview with current node highlighted
        if (hops.length) {
          h += `<div class="flow-hops" style="font-size:11px;margin-top:4px;flex-wrap:wrap">`;
          hops.forEach((hop, i) => {
            const isThis = hop.id === nodeId;
            h += `<span class="flow-hop badge-${(hop.layer||'').toLowerCase()}${isThis ? ' hop-highlight' : ''}">${esc(hop.name)}</span>`;
            if (i < hops.length - 1) h += `<span class="flow-arrow">→</span>`;
          });
          h += `</div>`;
        }
        h += `<div class="flow-meta" style="margin-top:4px">${completenessBadge(f.completeness)} ${confBadge(f.confidence)} <span class="muted">${f.hop_count} hops · ${(f.repos_involved||[]).length} repo(s)</span></div>`;
        h += `</div>`;
      });
      return h;
    };

    html += renderGroup('✅ Complete flows', complete);
    html += renderGroup('⚠ Partial flows', partial);

    openPanel(`Flows (${flows.length})`, html);
  } catch (e) {
    openPanel('Flows', emptyHTML('Failed: ' + e.message));
  }
}

// Render a single flow inline in the panel with the origin node highlighted
function renderNodeFlowInline(flow, originNodeId) {
  const hops = flow.hop_narration || [];
  let html = `<div style="margin-bottom:8px">`;
  html += `<button class="action-btn" style="font-size:11px" onclick="loadNodeFlowsPanel('${esc(originNodeId)}')">← All flows</button>`;
  html += `</div>`;

  // Flow header
  html += `<div class="node-profile">`;
  html += `<h2>${esc(flow.surface_summary || flow.flow_id)}</h2>`;
  html += `<div class="meta-row">`;
  html += completenessBadge(flow.completeness);
  const cr = flow.confidence_range || {};
  html += confBadgePlain(cr.avg);
  html += `<span class="muted">${flow.hop_count} hops</span>`;
  html += `<span class="muted">${(flow.repos_involved || []).join(', ')}</span>`;
  html += `</div>`;
  if (flow.data_flow) html += `<div class="card-desc">${esc(flow.data_flow)}</div>`;
  html += `</div>`;

  // Full hop chain — each hop is clickable, origin node is highlighted
  html += `<div style="margin-top:12px">`;
  hops.forEach((hop, i) => {
    const isOrigin = hop.id === originNodeId;
    const layerClass = `badge-${(hop.layer || '').toLowerCase()}`;
    html += `<div class="hop-row${isOrigin ? ' hop-row-highlight' : ''}" style="display:flex;align-items:flex-start;gap:8px;padding:6px 0;border-bottom:1px solid var(--border)">`;

    // Step number + layer badge
    html += `<div style="min-width:28px;text-align:right;color:var(--muted);font-size:11px;padding-top:2px">${i + 1}</div>`;
    html += `<div style="flex:1">`;
    html += `<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">`;
    html += `<span class="flow-hop ${layerClass}${isOrigin ? ' hop-highlight' : ''}" style="cursor:pointer" onclick="openNode('${esc(hop.id)}')">${esc(hop.name)}</span>`;
    html += `<span class="muted" style="font-size:10px">${esc(hop.layer || '')} · ${esc(hop.type || '')}</span>`;
    if (hop.repo) html += `<span class="muted" style="font-size:10px">${esc(hop.repo)}</span>`;
    html += `</div>`;

    // Description if available
    if (hop.description) {
      html += `<div class="card-desc" style="font-size:11px;margin-top:2px">${esc(trunc(hop.description, 120))}</div>`;
    }

    // Relation to next
    if (hop.relation_to_next) {
      html += `<div class="muted" style="font-size:10px;margin-top:2px">→ ${esc(hop.relation_to_next)}</div>`;
    }

    // Quick action buttons per hop
    html += `<div style="margin-top:4px;display:flex;gap:4px;flex-wrap:wrap">`;
    html += `<button class="action-btn" style="font-size:10px" onclick="event.stopPropagation();showCode('${esc(hop.id)}')">💻 Code</button>`;
    html += `<button class="action-btn" style="font-size:10px" onclick="event.stopPropagation();showEvidence('${esc(hop.id)}')">📄 Evidence</button>`;
    html += `</div>`;

    html += `</div></div>`;

    // Arrow between hops
    if (i < hops.length - 1) {
      html += `<div style="text-align:center;color:var(--muted);font-size:16px;padding:2px 0 2px 28px">↓</div>`;
    }
  });
  html += `</div>`;

  // Breakpoint if partial
  if (flow.completeness !== 'complete' && flow.breakpoint) {
    const bp = flow.breakpoint;
    html += `<div class="breakpoint" style="margin-top:12px">`;
    html += `<div class="bp-reason">⚠ Stopped: ${esc(bp.reason_code || '')}</div>`;
    html += `<div>${esc(bp.message || '')}</div>`;
    html += `</div>`;
  }

  openPanel(`Flow: ${trunc(flow.surface_summary || flow.flow_id, 40)}`, html);
}

// Task 6: Blast Radius — dedicated page
function clearBlastRadius() {
  const page = document.getElementById('page-blast');
  delete page.dataset.loaded;
  runBlastRadius(null);
}

// Flow-level blast radius — what breaks if this entire flow fails
async function runFlowBlastRadius(flowId) {
  navigateTo('blast', true);
  const page = document.getElementById('page-blast');
  page.dataset.loaded = '1';
  page.innerHTML = loadingHTML();
  try {
    const data = await api('/blast_radius/flow', {
      method: 'POST',
      body: { flow_id: flowId, direction: 'both', change_type: 'failure', max_depth: 4 },
    });
    if (data.error) { page.innerHTML = emptyHTML(data.error); return; }
    let html = `<div class="flex items-center justify-between mb-4">`;
    html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">\u26a1 Flow Blast Radius</div>`;
    html += `<button class="action-btn" onclick="clearBlastRadius()">\u2715 Clear &amp; Reset</button>`;
    html += `</div>`;

    // Flow info
    html += `<div class="node-profile">`;
    html += `<h2>${esc(flowId.split('::').pop())}</h2>`;
    html += `<div class="meta-row"><span class="muted">${data.flow_node_count} nodes in flow</span></div>`;
    html += `</div>`;

    // Severity summary
    const sc = data.severity_counts || {};
    html += `<div class="severity-bar">`;
    if (sc.critical) html += `<span class="severity-chip sev-critical">${sc.critical} Critical</span>`;
    if (sc.high)     html += `<span class="severity-chip sev-high">${sc.high} High</span>`;
    if (sc.medium)   html += `<span class="severity-chip sev-medium">${sc.medium} Medium</span>`;
    if (sc.low)      html += `<span class="severity-chip sev-low">${sc.low} Low</span>`;
    html += `</div>`;

    if (data.by_layer) {
      html += `<div class="flex gap-8 flex-wrap mb-8">`;
      Object.entries(data.by_layer).forEach(([layer, count]) => {
        html += `${layerBadge(layer)} <span class="muted">${count}</span>&nbsp;&nbsp;`;
      });
      html += `</div>`;
    }

    // Collateral flows
    const cflows = data.collateral_flows || [];
    if (cflows.length) {
      html += `<div class="section-title mt-16">\u26a0 Collateral Flows (${cflows.length})</div>`;
      html += `<div class="muted mb-8" style="font-size:11px">Other flows that share nodes with the impacted zone \u2014 these would also break or degrade.</div>`;
      cflows.forEach(cf => {
        html += `<div class="flow-card" onclick="openFlow('${esc(cf.flow_id)}', 'standard')">`;
        html += `<div class="card-title">${esc(cf.surface || cf.flow_id)}</div>`;
        html += `<div class="flow-meta">`;
        html += completenessBadge(cf.completeness);
        html += `<span class="muted">${cf.hop_count} hops</span>`;
        html += `<span class="muted">${cf.shared_node_count} shared node${cf.shared_node_count > 1 ? 's' : ''}</span>`;
        html += `</div></div>`;
      });
    }

    // Impacted external nodes
    html += `<div class="section-title mt-16">Impacted Components (${data.total_impacted})</div>`;
    const nodes = (data.nodes || []).slice(0, 50);
    nodes.forEach(n => {
      const sevCls = 'sev-' + (n.bucket || 'low');
      html += `<div class="impact-node" onclick="openNodeInExplorer('${esc(n.id)}')">`;
      html += `<span class="impact-score ${sevCls}">${n.severity.toFixed(0)}</span>`;
      html += layerBadge(n.layer);
      html += `<span>${esc(trunc(n.label, 40))}</span>`;
      html += typeBadge(n.type);
      html += `<span class="muted">depth ${n.depth}</span>`;
      html += `</div>`;
    });
    if (data.total_impacted > 50) html += `<div class="muted mt-8">Showing 50 of ${data.total_impacted} impacted nodes.</div>`;

    page.innerHTML = html;
  } catch (e) {
    page.innerHTML = emptyHTML('Flow blast radius failed: ' + e.message);
  }
}

// Called from Explorer tab — navigates to the blast page with a pre-filled node
function runBlastRadiusOnPage(nodeId) {
  const page = document.getElementById('page-blast');
  delete page.dataset.loaded;
  page.dataset.loaded = '1';
  navigateTo('blast', true);
  page.innerHTML = loadingHTML();
  api('/blast_radius', { method: 'POST', body: { component_id: nodeId, direction: 'downstream', max_depth: 4 } })
    .then(data => {
      let html = `<div class="flex items-center justify-between mb-4">`;
      html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">💥 Blast Radius: ${esc(data.origin_label || data.origin)}</div>`;
      html += `<button class="action-btn" onclick="clearBlastRadius()">✕ Clear &amp; Reset</button>`;
      html += `</div>`;
      html += renderImpactContent(data);
      page.innerHTML = html;
      _renderBlastGraph(data);
      fetchAIImpactAnalysis(data);
    })
    .catch(e => {
      page.innerHTML = `<div class="flex items-center justify-between mb-4">` +
        `<span></span><button class="action-btn" onclick="clearBlastRadius()">✕ Clear &amp; Reset</button></div>` +
        emptyHTML('Blast radius failed: ' + e.message);
    });
}

async function runBlastRadius(nodeId) {
  const page = document.getElementById('page-blast');
  page.dataset.loaded = '1';

  if (!nodeId) {
    page.innerHTML = `<div class="section-title">💥 Blast Radius Analysis</div>` +
      `<div class="mb-4"><div class="autocomplete-wrap"><input type="text" id="impact-node-input" placeholder="Search for a component…" autocomplete="off" oninput="impactAutocomplete(this.value)" onkeydown="impactAcKeydown(event)"><div id="impact-ac-list" class="autocomplete-list"></div></div></div>` +
      `<div class="flex gap-2 mb-6">` +
        `<select id="impact-direction"><option value="downstream">Downstream (what breaks)</option><option value="upstream">Upstream (what depends)</option><option value="both">Both</option></select>` +
        `<select id="impact-change"><option value="failure">Failure</option><option value="degradation">Degradation</option><option value="contract">Contract change</option></select>` +
        `<button class="action-btn" onclick="submitBlastRadius()">Compute</button>` +
      `</div>` +
      `<div id="impact-results">${emptyHTML('Enter a component ID and click Compute.')}</div>`;
    return;
  }

  navigateTo('blast', true);
  page.innerHTML = loadingHTML();
  try {
    const data = await api('/blast_radius', { method: 'POST', body: { component_id: nodeId, direction: 'downstream', max_depth: 4 } });
    let html = `<div class="flex items-center justify-between mb-4">`;
    html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">💥 Blast Radius: ${esc(data.origin_label || data.origin)}</div>`;
    html += `<button class="action-btn" onclick="clearBlastRadius()">✕ Clear &amp; Reset</button>`;
    html += `</div>`;
    html += renderImpactContent(data);
    page.innerHTML = html;
    _renderBlastGraph(data);
    fetchAIImpactAnalysis(data);
  } catch (e) {
    page.innerHTML = `<div class="flex items-center justify-between mb-4">` +
      `<span></span><button class="action-btn" onclick="clearBlastRadius()">✕ Clear &amp; Reset</button></div>` +
      emptyHTML('Blast radius failed: ' + e.message);
  }
}

async function submitBlastRadius() {
  const nodeId = document.getElementById('impact-node-input').value.trim();
  if (!nodeId) return;
  const direction = document.getElementById('impact-direction').value;
  const changeType = document.getElementById('impact-change').value;
  const container = document.getElementById('impact-results');
  if (!container) return;
  container.innerHTML = loadingHTML();

  try {
    const data = await api('/blast_radius', { method: 'POST', body: { component_id: nodeId, direction, change_type: changeType, max_depth: 4 } });
    let html = `<div class="flex items-center justify-between mb-4">`;
    html += `<span class="muted">${data.total_impacted || 0} impacted nodes</span>`;
    html += `<button class="action-btn" onclick="clearBlastRadius()">✕ Clear &amp; Reset</button>`;
    html += `</div>`;
    html += renderImpactContent(data);
    container.innerHTML = html;
    _renderBlastGraph(data);
    fetchAIImpactAnalysis(data);
  } catch (e) {
    container.innerHTML = emptyHTML('Failed: ' + e.message);
  }
}


function renderImpactContent(data) {
  if (data.error) return emptyHTML(data.error);

  const sc = data.severity_counts || {};
  let html = '';

  // AI Impact Analysis placeholder
  html += `<div id="ai-impact-box" class="ai-explain-box"><div class="loading">Generating AI impact analysis…</div></div>`;

  html += `<div class="meta-row mb-8">`;
  html += `<span class="muted">Origin:</span> ${esc(data.origin_label || data.origin)} `;
  html += layerBadge(data.origin_layer);
  html += `<span class="muted">&nbsp;|&nbsp; ${data.total_impacted} impacted nodes</span>`;
  html += `</div>`;

  html += `<div class="severity-bar">`;
  if (sc.critical) html += `<span class="severity-chip sev-critical">${sc.critical} Critical</span>`;
  if (sc.high)     html += `<span class="severity-chip sev-high">${sc.high} High</span>`;
  if (sc.medium)   html += `<span class="severity-chip sev-medium">${sc.medium} Medium</span>`;
  if (sc.low)      html += `<span class="severity-chip sev-low">${sc.low} Low</span>`;
  html += `</div>`;

  if (data.by_layer) {
    html += `<div class="flex gap-8 flex-wrap mb-8">`;
    Object.entries(data.by_layer).forEach(([layer, count]) => {
      html += `${layerBadge(layer)} <span class="muted">${count}</span>&nbsp;&nbsp;`;
    });
    html += `</div>`;
  }

  // ── Blast radius graph ──────────────────────────────────────────────
  html += `<div id="blast-graph-canvas" style="width:100%;height:340px;background:#0a0a14;border-radius:8px;position:relative;overflow:hidden;margin-bottom:16px"></div>`;

  // ── Node list ───────────────────────────────────────────────────────
  const nodes = (data.nodes || []).slice(0, 50);
  nodes.forEach(n => {
    const sevCls = 'sev-' + (n.bucket || 'low');
    html += `<div class="impact-node" onclick="openNodeInExplorer('${esc(n.id)}')">`;
    html += tooltip('severity_score', `<span class="impact-score ${sevCls}">${n.severity.toFixed(0)}</span>`);
    html += layerBadge(n.layer);
    html += `<span>${esc(trunc(n.label, 40))}</span>`;
    html += typeBadge(n.type);
    html += tooltip('depth', `<span class="muted">depth ${n.depth}</span>`);
    if (n.relation_from_parent) html += tooltip('relation_type', `<span class="muted">${esc(n.relation_from_parent)}</span>`);
    html += `</div>`;
  });

  if (data.total_impacted > 50) html += `<div class="muted mt-8">Showing 50 of ${data.total_impacted} impacted nodes.</div>`;
  return html;
}

function _renderBlastGraph(data) {
  const canvas = document.getElementById('blast-graph-canvas');
  if (!canvas || typeof d3 === 'undefined') return;

  const W = canvas.clientWidth || 700;
  const H = 340;

  const sevColors = { critical: '#ef4444', high: '#f97316', medium: '#eab308', low: '#22c55e' };
  const layerColors = { ui:'#60a5fa', bff:'#c084fc', api:'#4ade80', db:'#fb923c', config:'#94a3b8', shared:'#e879f9' };

  // Build nodes: origin + impacted
  const origin = { id: data.origin, label: data.origin_label || data.origin, layer: data.origin_layer, depth: -1, bucket: 'origin', severity: 100 };
  const impacted = (data.nodes || []).slice(0, 80);
  const allNodes = [origin, ...impacted].map(n => ({...n}));
  const nodeById = Object.fromEntries(allNodes.map(n => [n.id, n]));

  // Build edges from actual path arrays in the blast radius result
  // Each impacted node has a `path` array: [origin, hop1, hop2, ..., nodeId]
  // This gives us the real parent-child connections, not a guess.
  const edges = [];
  const seenEdgePairs = new Set();
  impacted.forEach(n => {
    const path = n.path || [];
    if (path.length >= 2) {
      const parentId = path[path.length - 2];
      const childId  = path[path.length - 1];
      const key = parentId + '|' + childId;
      if (!seenEdgePairs.has(key) && nodeById[parentId] && nodeById[childId]) {
        seenEdgePairs.add(key);
        edges.push({
          source: nodeById[parentId],
          target: nodeById[childId],
          type: n.relation_from_parent || ''
        });
      }
    }
  });
  // Also add edges from origin to its direct children (depth=1 nodes)
  impacted.filter(n => n.depth === 1).forEach(n => {
    const key = data.origin + '|' + n.id;
    if (!seenEdgePairs.has(key) && nodeById[data.origin] && nodeById[n.id]) {
      seenEdgePairs.add(key);
      edges.push({
        source: nodeById[data.origin],
        target: nodeById[n.id],
        type: n.relation_from_parent || ''
      });
    }
  });

  const svg = d3.select(canvas).append('svg').attr('width','100%').attr('height','100%').attr('viewBox',[0,0,W,H]);
  const defs = svg.append('defs');
  defs.append('marker').attr('id','barr').attr('viewBox','0 -4 8 8').attr('refX',12).attr('refY',0)
    .attr('markerWidth',5).attr('markerHeight',5).attr('orient','auto')
    .append('path').attr('d','M0,-4L8,0L0,4').attr('fill','#475569').attr('opacity',0.8);

  const g = svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.1,4]).on('zoom', e => g.attr('transform', e.transform)));

  const link = g.append('g').selectAll('line').data(edges).join('line')
    .attr('stroke','#475569').attr('stroke-width',1).attr('stroke-opacity',0.5)
    .attr('marker-end','url(#barr)');

  const r = n => n.depth === -1 ? 14 : Math.max(5, 12 - (n.depth||0) * 1.5);
  const nodeColor = n => n.depth === -1 ? '#f59e0b' : (sevColors[n.bucket] || '#64748b');

  const node = g.append('g').selectAll('g').data(allNodes).join('g')
    .attr('cursor','pointer')
    .on('click', (e,d) => { e.stopPropagation(); if (d.depth !== -1) openNodeInExplorer(d.id); })
    .call(d3.drag()
      .on('start',(e,d)=>{ if(!e.active) sim.alphaTarget(0.3).restart(); d.fx=d.x; d.fy=d.y; })
      .on('drag', (e,d)=>{ d.fx=e.x; d.fy=e.y; })
      .on('end',  (e,d)=>{ if(!e.active) sim.alphaTarget(0); d.fx=null; d.fy=null; }));

  node.append('circle')
    .attr('r', d => r(d))
    .attr('fill', d => nodeColor(d))
    .attr('stroke', d => d.depth === -1 ? '#fff' : '#0f1319')
    .attr('stroke-width', d => d.depth === -1 ? 2.5 : 1.5)
    .on('mouseenter', function(e,d) { d3.select(this).attr('stroke','#fff').attr('stroke-width',2.5); })
    .on('mouseleave', function(e,d) { d3.select(this).attr('stroke', d.depth===-1?'#fff':'#0f1319').attr('stroke-width',d.depth===-1?2.5:1.5); });

  node.append('text')
    .attr('dy', d => -r(d)-3).attr('text-anchor','middle')
    .attr('font-size', d => d.depth === -1 ? '10px' : '8px')
    .attr('fill', d => d.depth === -1 ? '#fbbf24' : '#94a3b8')
    .attr('pointer-events','none')
    .text(d => { const l=(d.label||d.id||'').split('::').pop(); return l.length>18?l.slice(0,16)+'…':l; });

  node.append('title').text(d => `${d.label||d.id}\n[${(d.layer||'').toUpperCase()}] depth=${d.depth}\nSeverity: ${d.severity||0}\n${d.relation_from_parent||''}`);

  const sim = d3.forceSimulation(allNodes)
    .force('link',   d3.forceLink(edges).id(d=>d.id).distance(d => 40 + (d.target.depth||0)*20).strength(0.7))
    .force('charge', d3.forceManyBody().strength(-200).distanceMax(350))
    .force('center', d3.forceCenter(W/2, H/2).strength(0.08))
    .force('collide',d3.forceCollide().radius(d=>r(d)+8).strength(0.9))
    .force('radial',  d3.forceRadial(d => d.depth === -1 ? 0 : (d.depth||1) * 65, W/2, H/2).strength(0.6))
    .on('tick', () => {
      link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y)
          .attr('x2',d=>{ const dx=d.target.x-d.source.x,dy=d.target.y-d.source.y,dist=Math.sqrt(dx*dx+dy*dy)||1; return d.target.x-(dx/dist)*(r(d.target)+4); })
          .attr('y2',d=>{ const dx=d.target.x-d.source.x,dy=d.target.y-d.source.y,dist=Math.sqrt(dx*dx+dy*dy)||1; return d.target.y-(dy/dist)*(r(d.target)+4); });
      node.attr('transform',d=>`translate(${d.x},${d.y})`);
    });

  setTimeout(()=>sim.alphaTarget(0), 3500);

  // Legend
  const leg = canvas.appendChild(document.createElement('div'));
  leg.style.cssText = 'position:absolute;bottom:6px;left:8px;display:flex;gap:10px;font-size:10px;color:#64748b;pointer-events:none';
  leg.innerHTML = Object.entries(sevColors).map(([k,c])=>`<span><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${c};margin-right:3px"></span>${k}</span>`).join('')
    + `<span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#f59e0b;margin-right:3px"></span>origin</span>`;
}

function renderImpactResults(container, data) {
  container.innerHTML = renderImpactContent(data);
}

// AI Impact Analysis — calls /blast_radius/explain, gracefully hides on failure
async function fetchAIImpactAnalysis(data) {
  const el = document.getElementById('ai-impact-box');
  if (!el) return;
  try {
    const payload = {
      origin: data.origin,
      origin_label: data.origin_label,
      origin_layer: data.origin_layer,
      direction: data.direction,
      change_type: data.change_type,
      severity_counts: data.severity_counts,
      by_layer: data.by_layer,
      nodes: (data.nodes || []).slice(0, 20).map(n => ({
        id: n.id, label: n.label, layer: n.layer, type: n.type,
        bucket: n.bucket, depth: n.depth, relation_from_parent: n.relation_from_parent,
      })),
    };
    const result = await api('/blast_radius/explain', { method: 'POST', body: payload });
    if (result.error) {
      el.style.display = 'none';
    } else {
      el.style.display = 'block';
      el.innerHTML = `<div class="ai-explain-header">🤖 AI Impact Analysis</div>` +
        `<div class="ai-explain-text">${formatProvenance(result.explanation)}</div>`;
    }
  } catch (e) {
    el.style.display = 'none';
  }
}

// Navigate to Explorer for a specific node (used by blast radius clicks)
function openNodeInExplorer(nodeId) {
  openNode(nodeId);
}



// Task 7: Coverage dashboard
async function loadCoverage() {
  const page = document.getElementById('page-coverage');
  if (page.dataset.loaded) return;
  page.innerHTML = loadingHTML();

  try {
    const data = await api('/coverage');
    page.dataset.loaded = '1';
    renderCoverage(page, data);
  } catch (e) {
    page.innerHTML = emptyHTML('Failed to load coverage: ' + e.message);
  }
}

function renderCoverage(page, data) {
  const cov = data.coverage || {};
  const fc = cov.file_coverage || {};
  const ec = cov.entity_coverage || {};
  const rc = cov.relation_coverage || {};
  const flowComp = data.flow_completeness || {};
  const gate = data.quality_gate || {};

  let html = `<div class="flex items-center justify-between mb-4">`;
  html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">📊 Coverage Dashboard</div>`;
  html += `<button class="action-btn" onclick="clearCoverage()">↻ Refresh</button>`;
  html += `</div>`;

  // Gate status
  const gatePass = gate.gate_passed;
  html += `<div class="card mb-16" style="border-color:${gatePass ? 'var(--green)' : 'var(--red)'}">`;
  html += `<div class="card-title">Quality Gate: ${gatePass ? '✅ PASSED' : '❌ FAILED'}</div>`;
  html += `<div class="card-meta">${gate.checks_passed || 0}/${gate.checks_total || 0} checks passed</div>`;
  html += `</div>`;

  // Stats grid
  html += `<div class="stat-grid">`;
  html += statCard(fc.total_scanned || 0, 'Files Scanned');
  html += statCard(((fc.parse_rate || 0) * 100).toFixed(1) + '%', 'Parse Rate');
  const eyVal = ((fc.eligible_yield || fc.extraction_rate || 0) * 100).toFixed(1) + '%';
  const oyVal = ((fc.extraction_rate || 0) * 100).toFixed(1) + '%';
  html += `<div class="stat-card">${tooltip('eligible_yield', `<div class="stat-value">${eyVal}</div>`)}<div class="stat-label">Eligible Yield</div></div>`;
  html += `<div class="stat-card">${tooltip('overall_yield', `<div class="stat-value">${oyVal}</div>`)}<div class="stat-label">Overall Yield</div></div>`;
  html += statCard(ec.total_entities || 0, 'Entities');
  html += statCard(rc.total_relations || 0, 'Relations');
  html += statCard(flowComp.complete || 0, 'Complete Flows');
  html += statCard(flowComp.partial || 0, 'Partial Flows');
  html += statCard(rc.dangling_references || 0, 'Dangling Refs');
  html += `</div>`;

  // Language treemap — only render if language breakdown is available
  const langs = (data.coverage && data.coverage.file_coverage && data.coverage.file_coverage.languages)
    ? data.coverage.file_coverage.languages
    : null;
  if (langs && langs.length) {
    html += `<div class="section-title">Language Distribution</div>`;
    html += `<div class="lang-treemap-wrap" id="lang-treemap-container"><div class="lang-treemap-tooltip"></div></div>`;
  }

  // Entity coverage by layer
  if (ec.by_layer) {
    html += `<div class="section-title mt-16">Entities by Layer</div>`;
    html += `<div class="stat-grid">`;
    Object.entries(ec.by_layer).forEach(([layer, count]) => {
      html += statCard(count, layer.toUpperCase());
    });
    html += `</div>`;
  }

  // Gaps
  const gaps = cov.gaps || [];
  if (gaps.length) {
    html += `<div class="section-title mt-16">⚠ Gaps (${gaps.length})</div>`;
    gaps.forEach(g => {
      const sevCls = g.severity === 'critical' ? 'sev-critical' : g.severity === 'warning' ? 'sev-medium' : 'sev-low';
      html += `<div class="card"><div class="card-meta"><span class="severity-chip ${sevCls}">${g.severity}</span> <span class="muted">${esc(g.category)}</span></div>`;
      html += `<div class="card-desc">${esc(g.description)}</div></div>`;
    });
  }

  // Orphan queries
  const orphans = data.orphans || {};
  html += `<div class="section-title mt-16">👻 Orphan Queries (Dead Code Candidates)</div>`;
  html += renderOrphanSection('BFF endpoints with no UI caller', orphans.bff_no_ui_caller);
  html += renderOrphanSection('DB functions with no API caller', orphans.db_no_api_caller);
  html += renderOrphanSection('API endpoints not called by any BFF', orphans.api_no_bff_caller);

  // Breakpoint distribution
  const bpDist = data.breakpoint_distribution || {};
  if (Object.keys(bpDist).length) {
    html += `<div class="section-title mt-16">Low-Confidence Hops by Layer</div>`;
    html += `<div class="flex gap-8 flex-wrap">`;
    Object.entries(bpDist).forEach(([layer, count]) => {
      html += `${layerBadge(layer)} <span class="muted">${count} low-conf hops</span>&nbsp;&nbsp;`;
    });
    html += `</div>`;
  }

  page.innerHTML = html;

  // Render treemap after DOM is ready
  if (langs && langs.length) {
    renderLangTreemap('lang-treemap-container', langs);
  }
}

function statCard(value, label) {
  return `<div class="stat-card"><div class="stat-value">${value}</div><div class="stat-label">${esc(label)}</div></div>`;
}

function renderLangTreemap(containerId, languages) {
  const wrap = document.getElementById(containerId);
  if (!wrap || !languages || !languages.length) return;

  const W = wrap.clientWidth || 600;
  const H = 260;

  const PALETTE = [
    '#60a5fa','#c084fc','#4ade80','#fb923c','#f472b6',
    '#facc15','#22d3ee','#a78bfa','#34d399','#f87171',
    '#818cf8','#fb7185','#38bdf8','#a3e635','#e879f9',
  ];

  const root = d3.hierarchy({ children: languages })
    .sum(d => d.lines || 0)
    .sort((a, b) => b.value - a.value);

  d3.treemap().size([W, H]).padding(2).round(true)(root);

  const svg = d3.select(wrap).append('svg')
    .attr('width', W).attr('height', H);

  const tip = wrap.querySelector('.lang-treemap-tooltip');

  const cell = svg.selectAll('g')
    .data(root.leaves())
    .join('g')
    .attr('transform', d => `translate(${d.x0},${d.y0})`);

  cell.append('rect')
    .attr('width',  d => Math.max(0, d.x1 - d.x0))
    .attr('height', d => Math.max(0, d.y1 - d.y0))
    .attr('fill',   (d, i) => PALETTE[i % PALETTE.length])
    .attr('opacity', 0.85)
    .attr('rx', 3)
    .on('mouseenter', function(event, d) {
      d3.select(this).attr('opacity', 1);
      if (!tip) return;
      tip.style.display = 'block';
      tip.innerHTML = `<strong>.${esc(d.data.ext)}</strong> ${d.data.lines.toLocaleString()} lines &nbsp;·&nbsp; ${d.data.pct}%`;
    })
    .on('mousemove', function(event) {
      if (!tip) return;
      const rect = wrap.getBoundingClientRect();
      let x = event.clientX - rect.left + 12;
      let y = event.clientY - rect.top - 10;
      if (x + 160 > W) x -= 170;
      tip.style.left = x + 'px';
      tip.style.top  = y + 'px';
    })
    .on('mouseleave', function() {
      d3.select(this).attr('opacity', 0.85);
      if (tip) tip.style.display = 'none';
    });

  cell.filter(d => (d.x1 - d.x0) > 36 && (d.y1 - d.y0) > 20)
    .append('text')
    .attr('x', 5).attr('y', 14)
    .attr('font-size', d => (d.x1 - d.x0) > 60 ? '11px' : '9px')
    .attr('font-weight', '600')
    .attr('fill', '#fff')
    .attr('pointer-events', 'none')
    .text(d => `.${d.data.ext}`);

  cell.filter(d => (d.x1 - d.x0) > 60 && (d.y1 - d.y0) > 34)
    .append('text')
    .attr('x', 5).attr('y', 26)
    .attr('font-size', '9px')
    .attr('fill', 'rgba(255,255,255,0.7)')
    .attr('pointer-events', 'none')
    .text(d => `${d.data.pct}%`);
}

function renderOrphanSection(title, items) {
  if (!items || !items.length) return '';
  const sectionId = 'orphan-' + title.replace(/\W+/g, '-').toLowerCase();
  let html = `<div class="orphan-section"><h4>${esc(title)} (${items.length})</h4>`;
  items.slice(0, 10).forEach(o => {
    html += `<div class="orphan-item" onclick="openNode('${esc(o.id)}')">${esc(o.name || o.id)}</div>`;
  });
  if (items.length > 10) {
    html += `<div id="${sectionId}-extra" style="display:none">`;
    items.slice(10).forEach(o => {
      html += `<div class="orphan-item" onclick="openNode('${esc(o.id)}')">${esc(o.name || o.id)}</div>`;
    });
    html += `</div>`;
    html += `<div class="orphan-more" id="${sectionId}-toggle" onclick="toggleOrphanExpand('${sectionId}')">+${items.length - 10} more — click to expand</div>`;
  }
  html += `</div>`;
  return html;
}

function toggleOrphanExpand(sectionId) {
  const extra = document.getElementById(sectionId + '-extra');
  const toggle = document.getElementById(sectionId + '-toggle');
  if (!extra) return;
  const showing = extra.style.display !== 'none';
  extra.style.display = showing ? 'none' : 'block';
  toggle.textContent = showing ? toggle.dataset.moreText || 'Show more' : 'Collapse';
  if (!toggle.dataset.moreText) toggle.dataset.moreText = toggle.textContent;
}

async function loadRepos() {
  const page = document.getElementById('page-repos');
  if (page.dataset.loaded) return;
  page.innerHTML = loadingHTML();
  try {
    const data = await api('/repos');
    page.dataset.loaded = '1';
    renderRepos(page, data);
  } catch (e) {
    page.innerHTML = emptyHTML('Failed to load repos: ' + e.message);
  }
}

function renderRepos(page, data) {
  const repos = data.repos || [];
  const edges = data.edges || [];

  let html = `<div class="flex items-center justify-between mb-4">`;
  html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">🏗 Repository Dependency View (${repos.length} repos, ${edges.length} cross-repo edges)</div>`;
  html += `<button class="action-btn" onclick="clearRepos()">↻ Refresh</button>`;
  html += `</div>`;

  // Sort by classification then name
  const order = { ui: 0, bff: 1, api: 2, db: 3, data: 4, config: 5, unknown: 9 };
  repos.sort((a, b) => {
    const ca = order[(a.classification || [])[0]] ?? 9;
    const cb = order[(b.classification || [])[0]] ?? 9;
    return ca - cb || a.id.localeCompare(b.id);
  });

  // Group by classification
  const groups = {};
  repos.forEach(r => {
    const cls = (r.classification || ['unknown'])[0];
    if (!groups[cls]) groups[cls] = [];
    groups[cls].push(r);
  });

  for (const [cls, items] of Object.entries(groups)) {
    html += `<div class="result-group">`;
    html += `<div class="result-group-title">${layerBadge(cls)} ${cls.toUpperCase()} Repos (${items.length})</div>`;
    items.forEach(r => {
      // Find edges for this repo
      const outEdges = edges.filter(e => e.source === r.id);
      const inEdges = edges.filter(e => e.target === r.id);
      const targets = outEdges.map(e => e.target).slice(0, 5);

      html += `<div class="repo-card">`;
      html += `<div class="repo-name">${esc(r.id)}</div>`;
      html += `<div class="repo-meta">`;
      html += `${confBadge(r.confidence)} `;
      html += `<span class="muted">Stack: ${(r.stack || []).slice(0, 4).join(', ')}</span> &nbsp;|&nbsp; `;
      html += `<span class="muted">${r.entity_count} entities, ${r.relation_count} relations</span> &nbsp;|&nbsp; `;
      html += `<span class="muted">↑${inEdges.length} ↓${outEdges.length} cross-repo</span>`;
      html += `</div>`;
      if (targets.length) {
        html += `<div class="card-desc">Calls: ${targets.map(t => esc(t)).join(', ')}${outEdges.length > 5 ? ' +' + (outEdges.length - 5) + ' more' : ''}</div>`;
      }
      html += `</div>`;
    });
    html += `</div>`;
  }

  // Top cross-repo edges
  if (edges.length) {
    const sorted = [...edges].sort((a, b) => b.count - a.count);
    html += `<div class="section-title mt-16">Top Cross-Repo Connections</div>`;
    sorted.slice(0, 20).forEach(e => {
      html += `<div class="card">`;
      html += `<div class="card-title">${esc(e.source)} → ${esc(e.target)}</div>`;
      html += `<div class="card-meta"><span class="muted">${e.count} edges</span></div>`;
      html += `</div>`;
    });
  }

  page.innerHTML = html;
}

/* ═══════════════════════════════════════════════════════════════════════════
   Utility functions for gaps 3-8
   ═══════════════════════════════════════════════════════════════════════════ */

// Gap 3: Expand/collapse hop
function toggleHop(headerEl) {
  const body = headerEl.parentElement.querySelector('.hop-body');
  const toggle = headerEl.querySelector('.hop-toggle');
  if (body) {
    body.classList.toggle('collapsed');
    if (toggle) toggle.textContent = body.classList.contains('collapsed') ? '▶' : '▼';
  }
}

// Gap 7: Config overlay toggle
function toggleConfigOverlay() {
  state.configOverlay = !state.configOverlay;
  const btn = document.getElementById('config-toggle');
  btn.textContent = `⚙ Config: ${state.configOverlay ? 'ON' : 'OFF'}`;
  btn.classList.toggle('active', state.configOverlay);

  // If on explorer page with a selected node, re-render to show config annotations
  if (state.configOverlay && state.selectedNode) {
    annotateConfigDeps();
  }
}

async function annotateConfigDeps() {
  if (!state.selectedNode?.node?.id) return;
  // Find config dependencies in downstream neighbors
  try {
    const data = await api(`/node/${encodeURIComponent(state.selectedNode.node.id)}/neighbors?direction=downstream&limit=50`);
    const configNeighbors = (data.neighbors || []).filter(n => n.layer === 'config');
    if (configNeighbors.length) {
      let html = `<div class="section-title">⚙ Config Dependencies (${configNeighbors.length})</div>`;
      configNeighbors.forEach(n => {
        html += `<div class="card" onclick="openNode('${esc(n.id)}')">` +
          `<div class="card-title">${esc(n.label)}</div>` +
          `<div class="card-meta">${layerBadge('config')} ${typeBadge(n.type)} ${confBadge(n.confidence)} ` +
          `<span class="muted">${esc(n.relation)}</span></div>` +
        `</div>`;
      });
      openPanel('Config Dependencies', html);
    } else {
      openPanel('Config Dependencies', emptyHTML('No config dependencies found for this node.'));
    }
  } catch (e) { /* ignore */ }
}

// Gap 8: Show more + budget controls
// Enhance dependencies view with show-more
async function loadMoreNeighbors(nodeId, direction, currentCount) {
  const newLimit = currentCount + 50;
  const container = document.getElementById('explorer-tab-content');
  if (!container) return;
  try {
    const data = await api(`/node/${encodeURIComponent(nodeId)}/neighbors?direction=${direction}&limit=${newLimit}`);
    renderDependencies(container, data);
  } catch (e) { /* ignore */ }
}

// ── Blast radius autocomplete ───────────────────────────────────────────
let _impactAcTimer = null;
let _impactAcIdx = -1;

async function impactAutocomplete(query) {
  clearTimeout(_impactAcTimer);
  const list = document.getElementById('impact-ac-list');
  if (!list) return;
  if (!query || query.length < 2) { list.classList.remove('open'); return; }
  _impactAcTimer = setTimeout(async () => {
    try {
      const data = await api(`/search?q=${encodeURIComponent(query)}&top_k=8&expand_depth=0`);
      const items = (data.node_results || []).slice(0, 8);
      if (!items.length) { list.classList.remove('open'); return; }
      _impactAcIdx = -1;
      list.innerHTML = items.map((n, i) => {
        const m = n.metadata;
        const nid = m.node_id || '';
        const label = nid.split(':').pop();
        return `<div class="autocomplete-item" data-id="${esc(nid)}" onclick="pickImpactAc('${esc(nid)}')" onmouseenter="_impactAcIdx=${i}">`
          + `<span class="badge badge-${(m.layer||'').toLowerCase()}" style="font-size:9px;padding:1px 5px">${(m.layer||'').toUpperCase()}</span>`
          + `<span class="ac-label">${esc(label)}</span>`
          + `<span class="ac-meta">${m.type || ''}</span>`
          + `</div>`;
      }).join('');
      list.classList.add('open');
    } catch (e) { list.classList.remove('open'); }
  }, 200);
}

function pickImpactAc(nodeId) {
  const input = document.getElementById('impact-node-input');
  const list = document.getElementById('impact-ac-list');
  if (input) input.value = nodeId;
  if (list) list.classList.remove('open');
}

function impactAcKeydown(e) {
  const list = document.getElementById('impact-ac-list');
  if (!list || !list.classList.contains('open')) {
    if (e.key === 'Enter') submitBlastRadius();
    return;
  }
  const items = list.querySelectorAll('.autocomplete-item');
  if (e.key === 'ArrowDown') { e.preventDefault(); _impactAcIdx = Math.min(_impactAcIdx + 1, items.length - 1); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); _impactAcIdx = Math.max(_impactAcIdx - 1, 0); }
  else if (e.key === 'Enter') {
    e.preventDefault();
    if (_impactAcIdx >= 0 && items[_impactAcIdx]) pickImpactAc(items[_impactAcIdx].dataset.id);
    else submitBlastRadius();
    return;
  } else if (e.key === 'Escape') { list.classList.remove('open'); return; }
  else return;
  items.forEach((it, i) => it.classList.toggle('active', i === _impactAcIdx));
}

// Close autocomplete on outside click
document.addEventListener('click', (e) => {
  if (!e.target.closest('.autocomplete-wrap')) {
    const list = document.getElementById('impact-ac-list');
    if (list) list.classList.remove('open');
  }
});

// ── AST Structure panel ───────────────────────────────────────────────────────
async function showAstSummary(entityId) {
  openPanel('🔬 Structure', loadingHTML());
  try {
    // Fetch AST data and downstream graph neighbors in parallel
    const [fileData, neighborsData] = await Promise.all([
      api('/ast_file/' + encodeURIComponent(entityId)).catch(() => ({})),
      api(`/node/${encodeURIComponent(entityId)}/neighbors?direction=downstream&limit=50`).catch(() => ({neighbors: []})),
    ]);

    // Build call-target → {nodeId, label, layer} lookup from graph neighbors
    // Match on the last segment of the label (e.g. "FlagService.getFlagTypes" matches "getFlagTypes")
    const resolvedIds = {};
    for (const n of (neighborsData.neighbors || [])) {
      const label = n.label || '';
      const segments = label.split(/[.:]+/);
      // Index every suffix: "FlagService.getFlagTypes" → both "getFlagTypes" and "FlagService.getFlagTypes"
      for (let i = 0; i < segments.length; i++) {
        const key = segments.slice(i).join('.').toLowerCase();
        if (key && !resolvedIds[key]) resolvedIds[key] = n;
      }
    }

    if (!fileData.methods || !fileData.methods.length) {
      const data = await api('/ast_summary/' + encodeURIComponent(entityId)).catch(() => ({}));
      if (!data.entity_id) {
        openPanel('🔬 Structure', emptyHTML(
          'AST summary not available for this entity.\nRun: python -m phase10_ast.run_ast_summaries'
        ));
        return;
      }
      openPanel('🔬 Structure: ' + trunc(data.signature?.name || entityId.split(':').pop(), 30),
                renderAstFileView({target_id: data.entity_id, file: data.file, repo: data.repo, methods: [data], total_methods: 1}, resolvedIds));
      setTimeout(() => { const t = document.getElementById('ast-target'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 100);
      return;
    }
    const shortFile = fileData.file.split('/').pop();
    openPanel('🔬 ' + trunc(shortFile, 25) + ' (' + fileData.total_methods + ' methods)',
              renderAstFileView(fileData, resolvedIds));
    setTimeout(() => { const t = document.getElementById('ast-target'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 100);
  } catch (e) {
    openPanel('🔬 Structure', emptyHTML('AST summary not available. Run: python -m phase10_ast.run_ast_summaries'));
  }
}

function renderAstFileView(fileData, resolvedIds = {}) {
  const targetId = fileData.target_id;
  const methods = fileData.methods || [];
  const file = fileData.file || '';
  const repo = fileData.repo || '';

  let html = '';
  html += `<div class="ast-file-header">`;
  html += `<span class="ev-file">${esc(repo)}/${esc(file)}</span>`;
  html += `<span class="muted">${methods.length} methods</span>`;
  html += `</div>`;

  methods.forEach(m => {
    const isTarget = m.entity_id === targetId;
    const cls = isTarget ? 'ast-method-target' : 'ast-method-dim';
    html += `<div class="ast-method-block ${cls}" id="${isTarget ? 'ast-target' : ''}">`;
    html += renderAstSummary(m, isTarget ? resolvedIds : {});
    html += `</div>`;
  });

  html += `<div id="ast-scroll-target" style="display:none"></div>`;
  return html;
}

function renderAstSummary(data, resolvedIds = {}) {
  const sig = data.signature || {};
  const calls = data.calls || [];
  const exc = data.exception_handling || [];
  const config = data.config_refs || [];
  const comp = data.complexity || {};
  const anns = data.annotations || [];

  let html = `<div class="ast-flow">`;

  // ── Entry node: annotations + signature ──────────────────────────────
  if (anns.length) {
    html += `<div class="ast-annotations">${anns.map(a => `<span class="ast-ann">${esc(a)}</span>`).join(' ')}</div>`;
  }

  const params = (sig.parameters || []).map(p => {
    let s = p.type ? `<span class="ast-type">${esc(p.type)}</span> ` : '';
    return s + esc(p.name);
  }).join(', ');

  html += `<div class="ast-entry-node">`;
  html += `<div class="ast-entry-sig">`;
  if (sig.access) html += `<span class="ast-kw">${esc(sig.access)}</span> `;
  if (sig.return_type) html += `<span class="ast-type">${esc(sig.return_type)}</span> `;
  html += `<span class="ast-entry-name">${esc(sig.name || '?')}</span>`;
  html += `<span class="ast-entry-params">(${params})</span>`;
  html += `</div>`;
  html += `<span class="ast-lines">L${data.line_start || '?'}–${data.line_end || '?'}</span>`;
  html += `</div>`;

  // ── Call flow: downward arrows ────────────────────────────────────────
  if (calls.length) {
    html += `<div class="ast-flow-arrow-down">↓</div>`;
    html += `<div class="ast-call-flow">`;

    const groups = _groupCallsByCondition(calls);
    groups.forEach((g, gi) => {
      const isLast = gi === groups.length - 1;

      if (g.condition) {
        // Conditional branch: show as a labelled fork
        html += `<div class="ast-branch-block">`;
        html += `<div class="ast-branch-label">if <code>${esc(trunc(g.condition, 60))}</code></div>`;
        html += `<div class="ast-branch-calls">`;
        g.calls.forEach(c => { html += _renderCallNode(c, resolvedIds, true); });
        html += `</div></div>`;
      } else {
        g.calls.forEach(c => { html += _renderCallNode(c, resolvedIds, false); });
      }

      if (!isLast) html += `<div class="ast-flow-arrow-down">↓</div>`;
    });
    html += `</div>`;
  }

  // ── Return node ───────────────────────────────────────────────────────
  if (sig.return_type && sig.return_type !== 'void') {
    html += `<div class="ast-flow-arrow-down">↓</div>`;
    html += `<div class="ast-return-node">return <span class="ast-type">${esc(sig.return_type)}</span></div>`;
  }

  // ── Exception + config as side annotations ────────────────────────────
  if (exc.length || config.length) {
    html += `<div class="ast-side-notes">`;
    exc.forEach(e => {
      html += `<div class="ast-exc"><span class="ast-exc-type">${esc(e.type)}</span> → ${esc(e.action)} <span class="ast-call-line">L${e.line}</span></div>`;
    });
    config.forEach(cr => {
      html += `<div class="ast-config">⚙ <code>${esc(cr)}</code></div>`;
    });
    html += `</div>`;
  }

  html += `</div>`; // .ast-flow

  // ── Complexity footer ─────────────────────────────────────────────────
  if (comp.lines) {
    html += `<div class="ast-complexity">`;
    html += `<span>${comp.branches || 0} branches</span>`;
    html += `<span>${comp.try_catch || 0} try/catch</span>`;
    html += `<span>${comp.lines || 0} lines</span>`;
    html += confBadge(data.confidence);
    html += `</div>`;
  }

  return html;
}

// Render one AST call node — resolved to a graph link if a neighbor matches
function _renderCallNode(c, resolvedIds, conditional) {
  const cls = 'ast-call-node' + (conditional ? ' ast-call-conditional' : '');
  // Try full target, then last segment (e.g. "flagService.getFlagTypes" → "getFlagTypes")
  const key = c.target.toLowerCase();
  const keyShort = c.target.split('.').pop().toLowerCase();
  const resolved = resolvedIds[key] || resolvedIds[keyShort] || null;

  if (resolved) {
    const shortFile = (resolved.file || '').split('/').pop();
    return `<div class="${cls} ast-call-resolved" onclick="openNode('${esc(resolved.id)}')" title="Opens ${esc(resolved.id)}">`
      + `<span class="ast-call-name">${esc(c.target)}</span>`
      + `<span class="ast-call-xref">${layerBadge(resolved.layer)}<span class="muted" style="font-size:10px">${esc(shortFile)}</span></span>`
      + `<span class="ast-call-line">L${c.line}</span>`
      + `</div>`;
  }
  return `<div class="${cls}">`
    + `<span class="ast-call-name">${esc(c.target)}</span>`
    + `<span class="ast-call-line">L${c.line}</span>`
    + `</div>`;
}

// Group calls by shared condition to form visual branches
function _groupCallsByCondition(calls) {
  const groups = [];
  let current = null;

  calls.forEach(c => {
    const cond = c.conditional ? (c.condition || 'conditional') : null;
    if (cond) {
      if (current && current.condition === cond) {
        current.calls.push(c);
      } else {
        current = { condition: cond, calls: [c] };
        groups.push(current);
      }
    } else {
      current = null;
      groups.push({ condition: null, calls: [c] });
    }
  });
  return groups;
}

// Provenance formatting for AI responses
function formatProvenance(text) {
  if (!text) return '';
  return esc(text)
    .replace(/\[OBSERVED\]/g, '<span class="badge badge-conf-high" style="font-size:9px">OBSERVED</span>')
    .replace(/\[DERIVED\]/g, '<span class="badge badge-conf-med" style="font-size:9px">DERIVED</span>')
    .replace(/\[INFERRED\]/g, '<span class="badge badge-conf-low" style="font-size:9px">INFERRED</span>')
    .replace(/\[UNKNOWN\]/g, '<span class="badge" style="font-size:9px;background:#333">UNKNOWN</span>')
    .replace(/\n/g, '<br>');
}

// ── Entry overlay: poll until data is truly ready, then fade out ────────────
function _pollUntilReady(overlay, onReady) {
  const captionEl = document.getElementById('entry-caption');
  const statusEl = document.getElementById('entry-status');
  const progressBar = document.getElementById('entry-progress-bar');
  const layers = overlay.querySelectorAll('.entry-layer');
  const arrows = overlay.querySelectorAll('.entry-layer-arrow');
  let attempts = 0;
  const MAX = 120;
  let dismissed = false;
  let captionIdx = 0;

  const CAPTIONS = [
    'Waking up the family…',
    'Gathering the evidence…',
    'Tracing the connections…',
    'Following the money trail…',
    'Interrogating the codebase…',
    'Building the case file…',
    'Mapping the territory…',
    'Connecting the dots…',
    'Reading between the lines…',
    'Assembling the dossier…',
    "Making offers they can't refuse…",
    'Checking the family tree…',
    'Reviewing the operation…',
    'Preparing the sit-down…',
  ];

  const PHASE_MAP = {
    'Loading search index':    { status: 'Loading search index…', progress: 15, layer: -1 },
    'Loading graph retriever': { status: 'Building the graph…', progress: 35, layer: 0 },
    'Loading code reader':     { status: 'Reading source files…', progress: 50, layer: 1 },
    'Loading blast radius':    { status: 'Preparing blast radius…', progress: 65, layer: 2 },
    'Loading flow':            { status: 'Tracing flows…', progress: 80, layer: 3 },
    'Chat engine':             { status: 'Initializing AI…', progress: 90, layer: 3 },
    'Ready':                   { status: 'Almost there…', progress: 95, layer: 3 },
  };

  function _setProgress(pct) {
    if (progressBar) progressBar.style.width = Math.min(100, pct) + '%';
  }

  function _lightLayers(upTo) {
    layers.forEach((el, i) => el.classList.toggle('lit', i <= upTo));
    arrows.forEach((el, i) => el.classList.toggle('lit', i < upTo));
  }

  function _updatePhase(msg) {
    for (const [key, info] of Object.entries(PHASE_MAP)) {
      if (msg && msg.includes(key)) {
        if (statusEl) statusEl.textContent = info.status;
        _setProgress(info.progress);
        if (info.layer >= 0) _lightLayers(info.layer);
        return;
      }
    }
  }

  // Rotate captions every 3s
  const captionTimer = setInterval(() => {
    captionIdx = (captionIdx + 1) % CAPTIONS.length;
    if (captionEl) captionEl.textContent = CAPTIONS[captionIdx];
  }, 3000);

  function _dismiss() {
    if (dismissed) return;
    dismissed = true;
    clearInterval(captionTimer);
    _setProgress(100);
    _lightLayers(3);
    if (captionEl) captionEl.textContent = 'Welcome to the family.';
    if (statusEl) statusEl.textContent = 'Ready.';
    setTimeout(() => {
      overlay.classList.add('fade-out');
      setTimeout(() => { overlay.remove(); if (onReady) onReady(); }, 500);
    }, 600);
  }

  // Don't dismiss until the explorer page can actually render data
  async function _verifyDataReady() {
    try {
      const resp = await fetch('/stats');
      if (!resp.ok) return false;
      const stats = await resp.json();
      return stats.initialized && (stats.graph?.nodes > 0 || stats.flows > 0);
    } catch { return false; }
  }

  function poll() {
    if (dismissed) return;
    attempts++;
    if (attempts >= MAX) { _dismiss(); return; }

    fetch('/api/init/status')
      .then(r => {
        if (r.status === 404) return fetch('/api/pipeline/has-data').then(r2 => r2.json()).then(d => ({ initialized: d.initialized, state: d.initialized ? 'ready' : 'loading', message: '' }));
        if (!r.ok) throw new Error(r.status);
        return r.json();
      })
      .then(async data => {
        if (data.message) _updatePhase(data.message);
        if (data.initialized || data.state === 'ready') {
          const ready = await _verifyDataReady();
          if (ready) { _dismiss(); return; }
          if (statusEl) statusEl.textContent = 'Loading graph data…';
          _setProgress(92);
          setTimeout(poll, 800);
          return;
        }
        if (data.state === 'error') {
          if (captionEl) captionEl.textContent = 'Something went sideways…';
          if (statusEl) statusEl.textContent = 'Entering anyway.';
          setTimeout(_dismiss, 1200);
          return;
        }
        setTimeout(poll, 500);
      })
      .catch(() => setTimeout(poll, 800));
  }

  setTimeout(poll, 400);
}



async function loadDocs() {
  const page = document.getElementById('page-docs');
  if (!page) return;
  page.innerHTML = loadingHTML();
  try {
    const data = await api('/docs');
    renderDocsPage(page, data);
  } catch (e) {
    page.innerHTML = emptyHTML('Failed to load documents: ' + e.message);
  }
}

function renderDocsPage(page, data) {
  const docs = data.documents || [];
  let html = `<div class="flex items-center justify-between mb-4">`;
  html += `<div class="section-title" style="margin-bottom:0;border-bottom:none;padding-bottom:0">`;
  html += `\ud83d\udcc4 Supplementary Documents (${docs.length})</div>`;
  html += `<button class="action-btn" onclick="loadDocs()">\u21bb Refresh</button>`;
  html += `</div>`;

  // Upload form
  html += `<div class="card mb-16" style="padding:16px">`;
  html += `<h3 style="margin-bottom:12px;font-size:14px">Upload Document</h3>`;
  html += `<form id="doc-upload-form" enctype="multipart/form-data" onsubmit="uploadDoc(event)">`;
  html += `<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end">`;
  html += `<div><label class="muted" style="font-size:11px;display:block">File (PDF, DOCX, XLSX, MD, TXT, images)</label>`;
  html += `<input type="file" name="file" id="doc-file" required style="font-size:12px;margin-top:4px"></div>`;
  html += `<div><label class="muted" style="font-size:11px;display:block">Title (optional)</label>`;
  html += `<input type="text" name="title" id="doc-title" placeholder="Design doc title" style="font-size:12px;padding:4px 8px;background:#0f0f1a;border:1px solid #3a3a5e;color:#e0e0e0;border-radius:4px;margin-top:4px"></div>`;
  html += `<div><label class="muted" style="font-size:11px;display:block">Tags (comma-separated)</label>`;
  html += `<input type="text" name="tags" id="doc-tags" placeholder="architecture, runbook" style="font-size:12px;padding:4px 8px;background:#0f0f1a;border:1px solid #3a3a5e;color:#e0e0e0;border-radius:4px;margin-top:4px"></div>`;
  html += `<button type="submit" class="action-btn" style="height:30px">\u2b06 Upload</button>`;
  html += `</div></form>`;
  html += `<div id="upload-status" style="margin-top:8px;font-size:12px"></div>`;
  html += `</div>`;

  // Info
  html += `<div class="muted mb-8" style="font-size:11px">`;
  html += `Upload design documents, architecture diagrams, runbooks, or any reference material. `;
  html += `Uploaded documents are extracted and indexed so the AI assistant can reference them when answering questions. `;
  html += `After uploading, re-index the search to include new documents.`;
  html += `</div>`;

  // Document list
  if (docs.length) {
    docs.forEach(d => {
      const did = d.doc_id;
      html += `<div class="card" style="padding:12px">`;
      html += `<div style="display:flex;align-items:center;gap:12px">`;
      html += `<div style="flex:1">`;
      html += `<div class="card-title">${esc(d.title || d.file_name)}</div>`;
      html += `<div class="card-meta">`;
      html += `<span class="badge badge-method">${esc(d.doc_type)}</span> `;
      html += `<span class="muted">${esc(d.file_name)}</span> `;
      const meta = d.metadata || {};
      if (meta.word_count) html += `<span class="muted">${meta.word_count} words</span> `;
      if (meta.page_count) html += `<span class="muted">${meta.page_count} pages</span> `;
      if (d.chunk_count) html += `<span class="muted">${d.chunk_count} chunks</span> `;
      if (d.tags && d.tags.length) html += d.tags.map(t => `<span class="badge badge-type" style="font-size:9px">${esc(t)}</span>`).join(' ');
      html += `</div></div>`;
      html += `<button class="action-btn" style="font-size:10px" onclick="viewDocSections('${esc(did)}')">\ud83d\udcc4 Sections</button>`;
      html += `<button class="action-btn" style="font-size:10px;color:#E15759" onclick="deleteDoc('${esc(did)}')">\u2715 Delete</button>`;
      html += `</div>`;
      html += `<div id="doc-sections-${esc(did.replace(/[^a-zA-Z0-9]/g, '_'))}" class="doc-sections-container"></div>`;
      html += `</div>`;
    });
  } else {
    html += emptyHTML('No documents uploaded yet. Use the form above to add design docs, runbooks, or architecture diagrams.');
  }

  page.innerHTML = html;
}

async function uploadDoc(event) {
  event.preventDefault();
  const status = document.getElementById('upload-status');
  const fileInput = document.getElementById('doc-file');
  if (!fileInput.files.length) return;

  status.innerHTML = '<span class="loading">Uploading...</span>';
  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  formData.append('title', document.getElementById('doc-title').value);
  formData.append('tags', document.getElementById('doc-tags').value);

  try {
    const resp = await fetch(API + '/docs/upload', { method: 'POST', body: formData });
    const data = await resp.json();
    if (data.error) {
      status.innerHTML = `<span style="color:#E15759">\u2717 ${esc(data.error)}</span>`;
    } else {
      status.innerHTML = `<span style="color:#59A14F">\u2713 ${esc(data.file_name)} ingested (${data.text_length} chars, ${data.chunk_count || '?'} chunks)</span>`;
      fileInput.value = '';
      document.getElementById('doc-title').value = '';
      document.getElementById('doc-tags').value = '';
      setTimeout(loadDocs, 500);
    }
  } catch (e) {
    status.innerHTML = `<span style="color:#E15759">\u2717 Upload failed: ${esc(e.message)}</span>`;
  }
}

async function deleteDoc(docId) {
  if (!confirm('Delete this document?')) return;
  try {
    await api('/docs/' + encodeURIComponent(docId), { method: 'DELETE' });
    loadDocs();
  } catch (e) {
    alert('Delete failed: ' + e.message);
  }
}

async function viewDocSections(docId) {
  const containerId = 'doc-sections-' + docId.replace(/[^a-zA-Z0-9]/g, '_');
  const container = document.getElementById(containerId);
  if (!container) return;

  // Toggle: if already showing, collapse
  if (container.innerHTML) {
    container.innerHTML = '';
    return;
  }

  container.innerHTML = '<div class="loading" style="padding:8px">Loading sections…</div>';

  try {
    const doc = await api('/docs/' + encodeURIComponent(docId));
    const chunks = doc.chunks || [];

    if (!chunks.length) {
      container.innerHTML = '<div class="muted" style="padding:8px;font-size:11px">No sections extracted.</div>';
      return;
    }

    let html = `<div class="doc-sections">`;
    html += `<div class="doc-sections-header">${chunks.length} extracted sections</div>`;

    chunks.forEach((chunk, i) => {
      const heading = chunk.heading || '(no heading)';
      const preview = chunk.text.length > 200 ? chunk.text.slice(0, 200) + '…' : chunk.text;
      const fullId = `doc-chunk-${containerId}-${i}`;

      html += `<div class="doc-chunk">`;
      html += `<div class="doc-chunk-header" onclick="toggleDocChunk('${fullId}')">`;
      html += `<span class="doc-chunk-idx">${i + 1}</span>`;
      html += `<span class="doc-chunk-heading">${esc(heading)}</span>`;
      html += `<span class="doc-chunk-len">${chunk.text.length} chars</span>`;
      html += `<span class="doc-chunk-toggle">▶</span>`;
      html += `</div>`;
      html += `<div class="doc-chunk-body" id="${fullId}">`;
      html += `<pre class="doc-chunk-text">${esc(chunk.text)}</pre>`;
      html += `</div>`;
      html += `</div>`;
    });

    html += `</div>`;
    container.innerHTML = html;
  } catch (e) {
    container.innerHTML = `<div class="muted" style="padding:8px;font-size:11px;color:var(--red)">Failed to load: ${esc(e.message)}</div>`;
  }
}

function toggleDocChunk(chunkId) {
  const body = document.getElementById(chunkId);
  if (!body) return;
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open');
  const toggle = body.previousElementSibling?.querySelector('.doc-chunk-toggle');
  if (toggle) toggle.textContent = isOpen ? '▶' : '▼';
}

// ── Explorer Landing Sub-Tabs: Inventory | Graph | AST ──────────────────────

function switchExplorerLandingTab(tab) {
  ['codetree','graph','ast'].forEach(t => {
    const el = document.getElementById('exp-tab-' + t);
    if (el) el.classList.toggle('active', t === tab);
  });
  if (tab === 'codetree') loadCodeTreeTab();
  else if (tab === 'graph') loadGraphTab();
  else if (tab === 'ast') loadAstTab();
}

// ── Code Tree Tab ─────────────────────────────────────────────────────────

async function loadCodeTreeTab() {
  const container = document.getElementById('explorer-landing-tab-content');
  if (!container) return;
  container.innerHTML = loadingHTML();
  try {
    const data = await api('/codetree');
    renderCodeTree(container, data);
  } catch (e) {
    container.innerHTML = emptyHTML('Failed to load code tree: ' + e.message);
  }
}

function renderCodeTree(container, data) {
  const tree = data.tree || {};

  // Build markdown for markmap
  let md = '# System\n';
  for (const [repo, files] of Object.entries(tree)) {
    md += `## ${repo}\n`;
    const dirMap = {};
    for (const [fpath, nodes] of Object.entries(files)) {
      const parts = fpath.split('/');
      const dir = parts.length > 1 ? parts.slice(0, -1).join('/') : '.';
      if (!dirMap[dir]) dirMap[dir] = [];
      dirMap[dir].push({ fname: parts[parts.length - 1], fpath, nodes });
    }
    for (const [dir, fileList] of Object.entries(dirMap).sort((a,b) => a[0].localeCompare(b[0]))) {
      const indent = dir === '.' ? '' : `### ${dir}/\n`;
      if (indent) md += indent;
      for (const { fname, nodes } of fileList.sort((a,b) => a.fname.localeCompare(b.fname))) {
        const prefix = dir === '.' ? '###' : '####';
        md += `${prefix} 📄 ${fname}\n`;
        for (const n of nodes) {
          const label = (n.label || '').split('::').pop() || n.id;
          md += `- ${label}\n`;
        }
      }
    }
  }

  container.innerHTML = `
    <div class="graph-controls mb-8">
      <input type="text" id="ct-filter" placeholder="Filter components…"
        oninput="filterCodeTree()"
        style="width:280px;padding:4px 8px;background:#0f0f1a;border:1px solid #3a3a5e;color:#e0e0e0;border-radius:4px;font-size:12px">
      <span class="muted" style="font-size:11px;margin-left:8px">Scroll to zoom · Drag to pan · Click nodes to expand/collapse</span>
    </div>
    <div id="ct-markmap-wrap" style="width:100%;height:620px;background:#0a0a14;border-radius:8px;overflow:hidden;position:relative">
      <svg id="ct-markmap-svg" style="width:100%;height:100%"></svg>
    </div>`;

  window._ctMarkdown = md;
  _renderMarkmap(md);
}

function _renderMarkmap(md) {
  if (typeof markmap === 'undefined' || !markmap.Transformer || !markmap.Markmap) {
    // libs not yet loaded — retry
    setTimeout(() => _renderMarkmap(md), 200);
    return;
  }
  const { Transformer, Markmap, loadCSS, loadJS } = markmap;
  const transformer = new Transformer();
  const { root, features } = transformer.transform(md);
  const { styles, scripts } = transformer.getUsedAssets(features);
  if (styles) loadCSS(styles);
  if (scripts) loadJS(scripts, { getMarkmap: () => markmap });

  const svg = document.getElementById('ct-markmap-svg');
  if (!svg) return;
  // Destroy previous instance if any
  if (window._ctMarkmapInst) { try { window._ctMarkmapInst.destroy(); } catch(e) {} }
  window._ctMarkmapInst = Markmap.create(svg, {
    color: (node) => {
      const LAYER_COLORS = { ui:'#60a5fa', bff:'#c084fc', api:'#4ade80', db:'#fb923c', config:'#94a3b8', shared:'#e879f9' };
      const d = node.depth || 0;
      if (d === 0) return '#f59e0b';
      if (d === 1) return '#e879f9';
      if (d === 2) return '#60a5fa';
      return '#4ade80';
    },
    duration: 350,
    maxWidth: 200,
    zoom: true,
    pan: true,
  }, root);
}

function filterCodeTree() {
  const q = (document.getElementById('ct-filter')?.value || '').trim().toLowerCase();
  if (!window._ctMarkdown) return;
  if (!q || q.length < 2) { _renderMarkmap(window._ctMarkdown); return; }
  // Filter markdown lines: keep structure lines + matching leaf lines
  const lines = window._ctMarkdown.split('\n');
  const filtered = [];
  const headingStack = [];
  lines.forEach(line => {
    const hMatch = line.match(/^(#{1,6})\s/);
    if (hMatch) {
      headingStack.push(line);
      filtered.push(line);
    } else if (line.startsWith('- ')) {
      if (line.toLowerCase().includes(q)) filtered.push(line);
    } else {
      filtered.push(line);
    }
  });
  _renderMarkmap(filtered.join('\n'));
}

function toggleInvSection(sectionId) {
  const el = document.getElementById(sectionId);
  const toggle = document.getElementById(sectionId + '-toggle');
  if (!el) return;
  const open = el.style.display !== 'none';
  el.style.display = open ? 'none' : 'block';
  if (toggle) toggle.textContent = open ? '▶' : '▼';
}

// ── Graph Tab ───────────────────────────────────────────────────────────────

let _graphData = null;
let _graphSvg = null;

async function loadGraphTab() {
  const container = document.getElementById('explorer-landing-tab-content');
  if (!container) return;

  // Controls + canvas
  let html = `<div class="graph-controls">`;
  html += `<select id="graph-mode" onchange="reloadGraph()">`;
  html += `<option value="full" selected>All Nodes & Edges</option>`;
  html += `<option value="flows">Flow Chains Only</option>`;
  html += `</select>`;
  html += `<label class="toggle-label" style="font-size:11px;gap:4px;margin:0 4px"><input type="checkbox" id="graph-color-layers" checked onchange="reloadGraph()"><span class="toggle-switch"></span><span class="toggle-text">Color by layer</span></label>`;
  html += `<select id="graph-limit" onchange="reloadGraph()">`;
  html += `<option value="200">200 nodes</option><option value="500">500 nodes</option>`;
  html += `<option value="1000" selected>1000 nodes</option><option value="2000">2000 nodes</option>`;
  html += `<option value="5000">5000 nodes</option><option value="10000">10000 nodes</option>`;
  html += `<option value="25000">25000 nodes</option><option value="100000">100000 nodes</option>`;
  html += `</select>`;
  html += `<input type="text" id="graph-focus-input" placeholder="Focus on node…" style="width:200px;padding:4px 8px;background:#0f0f1a;border:1px solid #3a3a5e;color:#e0e0e0;border-radius:4px;font-size:12px">`;
  html += `<button class="action-btn" onclick="focusGraphNode()">Focus</button>`;
  html += `<button class="action-btn" onclick="reloadGraph()">Reload</button>`;
  html += `</div>`;
  // Layer toggle pills — populated after graph loads
  html += `<div id="graph-layer-pills" class="graph-layer-pills"></div>`;
  // Layer filter dropdown — populated dynamically after graph loads
  html += `<div id="graph-layer-filter-wrap" style="margin:4px 0"><select id="graph-layer-filter" onchange="reloadGraph()" style="padding:4px 8px;background:#0f0f1a;border:1px solid #3a3a5e;color:#e0e0e0;border-radius:4px;font-size:12px"><option value="">All Layers</option></select></div>`;
  html += `<div id="graph-stats" style="font-size:11px;color:#64748b;padding:2px 0 4px 0"></div>`;
  html += `<div id="graph-canvas" style="width:100%;height:560px;background:#0a0a14;border-radius:8px;position:relative;overflow:hidden">${loadingHTML()}</div>`;
  container.innerHTML = html;
  reloadGraph();
}

async function reloadGraph() {
  const canvas = document.getElementById('graph-canvas');
  if (!canvas) return;
  canvas.innerHTML = loadingHTML();

  const mode = document.getElementById('graph-mode')?.value || 'full';
  const limit = document.getElementById('graph-limit')?.value || '1000';

  try {
    let data;
    if (mode === 'flows') {
      // Flow paths mode: only show nodes that are part of complete/partial flow chains
      data = await api('/graph/flows?limit=' + limit);
      // Annotate nodes with flow membership for coloring
      data._mode = 'flows';
    } else {
      const params = new URLSearchParams({limit});
      data = await api('/graph/full?' + params);
      data._mode = 'full';
    }
    _graphData = data;

    // Update stats bar
    const statsEl = document.getElementById('graph-stats');
    if (statsEl) {
      if (mode === 'flows') {
        const complete = (data.flows || []).filter(f => f.completeness === 'complete').length;
        const partial = (data.flows || []).filter(f => f.completeness === 'partial').length;
        statsEl.textContent = `${data.nodes?.length || 0} nodes · ${data.edges?.length || 0} edges · ${complete} complete flows · ${partial} partial flows`;
      } else {
        statsEl.textContent = `${data.nodes?.length || 0} nodes · ${data.edges?.length || 0} edges` +
          (data.flow_chain_edges_injected ? ` · ${data.flow_chain_edges_injected} flow-chain edges injected` : '');
      }
    }

    renderForceGraph(canvas, data);
  } catch (e) {
    canvas.innerHTML = emptyHTML('Failed to load graph: ' + e.message);
  }
}

// Layer toggle state for the D3 graph
let _graphHiddenLayers = new Set();
let _graphSoloLayer = null;
let _graphNodeSel = null;  // D3 selection of node circles — updated by toggle
let _graphSim = null;      // D3 simulation reference
let _graphNodeData = null; // live node data for highlight
let _graphLinkSel = null;  // D3 link selection
let _graphNodeGroup = null; // D3 node group selection
let _graphHighlightDepth = 2; // current highlight depth
let _graphLockedNode = null; // click-locked node ID

function _applyGraphLayerVisibility() {
  if (!_graphNodeGroup || !_graphLinkSel) return;
  const hasFilter = _graphSoloLayer !== null || _graphHiddenLayers.size > 0;

  _graphNodeGroup.each(function(d) {
    const layer = (d.layer || '').toLowerCase();
    let dimmed = false;
    if (_graphSoloLayer !== null) dimmed = layer !== _graphSoloLayer;
    else dimmed = _graphHiddenLayers.has(layer);
    d3.select(this).select('circle').attr('opacity', dimmed ? 0.08 : 1);
    d3.select(this).select('text').attr('opacity', dimmed ? 0.05 : 1);
  });

  _graphLinkSel.attr('stroke-opacity', d => {
    if (!hasFilter) return 0.4;
    const sl = (d.source.layer || '').toLowerCase();
    const tl = (d.target.layer || '').toLowerCase();
    const srcDim = _graphSoloLayer !== null ? sl !== _graphSoloLayer : _graphHiddenLayers.has(sl);
    const tgtDim = _graphSoloLayer !== null ? tl !== _graphSoloLayer : _graphHiddenLayers.has(tl);
    return (srcDim || tgtDim) ? 0.04 : 0.6;
  });
}

// Highlight a node and its neighbors up to `depth` hops
function _highlightNode(nodeId, depth) {
  if (!_graphNodeData || !_graphNodeGroup || !_graphLinkSel) return;

  // BFS to find all nodes within `depth` hops
  const nodeById = Object.fromEntries(_graphNodeData.map(n => [n.id, n]));
  const adjacent = new Map(); // nodeId → min depth
  adjacent.set(nodeId, 0);
  let frontier = [nodeId];
  for (let d = 1; d <= depth; d++) {
    const next = [];
    frontier.forEach(nid => {
      (_graphData.edges || []).forEach(e => {
        const src = typeof e.source === 'object' ? e.source.id : e.source;
        const tgt = typeof e.target === 'object' ? e.target.id : e.target;
        if (src === nid && !adjacent.has(tgt)) { adjacent.set(tgt, d); next.push(tgt); }
        if (tgt === nid && !adjacent.has(src)) { adjacent.set(src, d); next.push(src); }
      });
    });
    frontier = next;
  }

  // Dim/highlight nodes
  _graphNodeGroup.each(function(d) {
    const inNeighborhood = adjacent.has(d.id);
    const isOrigin = d.id === nodeId;
    d3.select(this).select('circle')
      .attr('opacity', inNeighborhood ? 1 : 0.12)
      .attr('stroke', isOrigin ? '#fff' : '#0f1319')
      .attr('stroke-width', isOrigin ? 3 : 1.5);
    d3.select(this).select('text')
      .attr('opacity', inNeighborhood ? 1 : 0.08);
  });

  // Dim/highlight links
  _graphLinkSel.attr('stroke-opacity', d => {
    const src = typeof d.source === 'object' ? d.source.id : d.source;
    const tgt = typeof d.target === 'object' ? d.target.id : d.target;
    return (adjacent.has(src) && adjacent.has(tgt)) ? 0.9 : 0.04;
  }).attr('stroke-width', d => {
    const src = typeof d.source === 'object' ? d.source.id : d.source;
    const tgt = typeof d.target === 'object' ? d.target.id : d.target;
    return (src === nodeId || tgt === nodeId) ? 2.5 : 1;
  });
}

function _clearGraphHighlight() {
  if (!_graphNodeGroup || !_graphLinkSel) return;
  _graphNodeGroup.each(function(d) {
    d3.select(this).select('circle').attr('opacity', 1).attr('stroke', '#0f1319').attr('stroke-width', 1.5);
    d3.select(this).select('text').attr('opacity', 1);
  });
  _graphLinkSel.attr('stroke-opacity', 0.4).attr('stroke-width', 1);
}

function _buildLayerPills(layers, layerColors) {
  const wrap = document.getElementById('graph-layer-pills');
  if (!wrap) return;
  wrap.innerHTML = '';
  const hint = document.createElement('span');
  hint.className = 'graph-pill-hint';
  hint.textContent = 'click = toggle · dbl = solo';
  wrap.appendChild(hint);

  layers.forEach(layer => {
    const color = layerColors[layer] || '#64748b';
    const count = (_graphData.nodes || []).filter(n => (n.layer || '').toLowerCase() === layer).length;
    const pill = document.createElement('button');
    pill.className = 'graph-layer-pill';
    pill.dataset.layer = layer;
    pill.innerHTML = `<span class="graph-pill-dot" style="background:${color}"></span>${layer.toUpperCase()} <span class="graph-pill-count">${count}</span>`;
    pill.style.setProperty('--pill-color', color);

    pill.addEventListener('click', () => {
      if (_graphSoloLayer !== null) {
        _graphSoloLayer = null;
        wrap.querySelectorAll('.graph-layer-pill').forEach(p => p.classList.remove('solo', 'dim'));
      }
      if (_graphHiddenLayers.has(layer)) {
        _graphHiddenLayers.delete(layer);
        pill.classList.remove('dim');
      } else {
        _graphHiddenLayers.add(layer);
        pill.classList.add('dim');
      }
      _applyGraphLayerVisibility();
    });

    pill.addEventListener('dblclick', e => {
      e.stopPropagation();
      if (_graphSoloLayer === layer) {
        _graphSoloLayer = null;
        _graphHiddenLayers.clear();
        wrap.querySelectorAll('.graph-layer-pill').forEach(p => p.classList.remove('solo', 'dim'));
      } else {
        _graphSoloLayer = layer;
        _graphHiddenLayers.clear();
        wrap.querySelectorAll('.graph-layer-pill').forEach(p => { p.classList.remove('solo'); p.classList.add('dim'); });
        pill.classList.remove('dim');
        pill.classList.add('solo');
      }
      _applyGraphLayerVisibility();
    });

    wrap.appendChild(pill);
  });
}

function renderForceGraph(canvas, data) {
  canvas.innerHTML = '';
  _graphHiddenLayers.clear();
  _graphSoloLayer = null;
  _graphNodeSel = null;
  _graphSim = null;
  _graphNodeData = null;
  _graphLinkSel = null;
  _graphNodeGroup = null;

  const nodes = data.nodes || [];
  const edges = data.edges || [];
  if (!nodes.length) { canvas.innerHTML = emptyHTML('No nodes to display.'); return; }

  const W = canvas.clientWidth || 900;
  const H = canvas.clientHeight || 560;

  const layerColors = {
    ui:     '#60a5fa', bff:    '#c084fc', api:    '#4ade80',
    db:     '#fb923c', config: '#94a3b8', shared: '#e879f9',
  };
  const _defaultNodeColor = '#60a5fa';
  const color = n => {
    const useLayer = document.getElementById('graph-color-layers')?.checked !== false;
    if (useLayer) return layerColors[(n.layer || '').toLowerCase()] || '#64748b';
    // Uniform color scaled by confidence
    const c = n.confidence || 0.5;
    const r = Math.round(96 + c * 40);
    const g = Math.round(165 + c * 40);
    const b = Math.round(250);
    return `rgb(${r},${g},${b})`;
  };
  const radius = n => {
    // In flows mode: entry/terminal nodes are larger
    const base = Math.max(4, Math.min(12, 4 + (n.confidence || 0) * 8));
    if (n.is_entry) return base + 4;
    if (n.is_terminal) return base + 3;
    return base;
  };
  const nodeOpacity = n => {
    if (!data._mode || data._mode === 'full') return 1;
    // flows mode: complete flow nodes are bright, partial are dimmer
    const flowIds = n.flow_ids || [];
    const flows = data.flows || [];
    const hasComplete = flowIds.some(fid => flows.find(f => f.flow_id === fid && f.completeness === 'complete'));
    return hasComplete ? 1.0 : 0.55;
  };

  // Depth selector overlay
  const depthWrap = document.createElement('div');
  depthWrap.style.cssText = 'position:absolute;top:8px;right:12px;display:flex;align-items:center;gap:6px;font-size:11px;color:#94a3b8;z-index:10;background:rgba(10,10,20,0.7);padding:4px 8px;border-radius:6px;';
  depthWrap.innerHTML = `<span>Highlight depth:</span>
    <button onclick="_graphHighlightDepth=1;" style="background:#1e293b;border:1px solid #334155;color:#94a3b8;border-radius:4px;padding:1px 7px;cursor:pointer;font-size:11px" id="gd1">1</button>
    <button onclick="_graphHighlightDepth=2;" style="background:#3b82f6;border:1px solid #3b82f6;color:#fff;border-radius:4px;padding:1px 7px;cursor:pointer;font-size:11px" id="gd2">2</button>
    <button onclick="_graphHighlightDepth=3;" style="background:#1e293b;border:1px solid #334155;color:#94a3b8;border-radius:4px;padding:1px 7px;cursor:pointer;font-size:11px" id="gd3">3</button>
    <button onclick="_graphHighlightDepth=4;" style="background:#1e293b;border:1px solid #334155;color:#94a3b8;border-radius:4px;padding:1px 7px;cursor:pointer;font-size:11px" id="gd4">4</button>
    <button onclick="_clearGraphHighlight()" style="background:#1e293b;border:1px solid #334155;color:#94a3b8;border-radius:4px;padding:1px 7px;cursor:pointer;font-size:11px">✕</button>`;
  canvas.appendChild(depthWrap);
  // Update depth button styles on click
  [1,2,3,4].forEach(d => {
    document.getElementById(`gd${d}`)?.addEventListener('click', () => {
      _graphHighlightDepth = d;
      [1,2,3,4].forEach(x => {
        const b = document.getElementById(`gd${x}`);
        if (b) { b.style.background = x===d ? '#3b82f6' : '#1e293b'; b.style.borderColor = x===d ? '#3b82f6' : '#334155'; b.style.color = x===d ? '#fff' : '#94a3b8'; }
      });
    });
  });

  const svg = d3.select(canvas).append('svg')
    .attr('width', '100%').attr('height', '100%')
    .attr('viewBox', [0, 0, W, H]);

  // Arrow markers
  const defs = svg.append('defs');
  Object.entries(layerColors).concat([['default','#475569']]).forEach(([k, col]) => {
    defs.append('marker').attr('id', `arr-${k}`)
      .attr('viewBox','0 -4 8 8').attr('refX',14).attr('refY',0)
      .attr('markerWidth',5).attr('markerHeight',5).attr('orient','auto')
      .append('path').attr('d','M0,-4L8,0L0,4').attr('fill',col).attr('opacity',0.7);
  });

  const g = svg.append('g');
  svg.call(d3.zoom().scaleExtent([0.05, 4])
    .on('zoom', e => g.attr('transform', e.transform)));

  // Click on background clears locked highlight
  svg.on('click', () => { _graphLockedNode = null; _clearGraphHighlight(); });

  const nodeData = nodes.map(n => ({...n}));
  _graphNodeData = nodeData;
  const nodeById = Object.fromEntries(nodeData.map(n => [n.id, n]));
  const linkData = edges
    .filter(e => nodeById[e.source] && nodeById[e.target])
    .map(e => ({...e, source: nodeById[e.source], target: nodeById[e.target]}));

  const link = g.append('g').selectAll('line').data(linkData).join('line')
    .attr('stroke', d => {
      // Flow-hop edges get a brighter color based on completeness
      if (d.completeness === 'complete') return '#22c55e';
      if (d.type === 'flow_hop') return '#94a3b8';
      return layerColors[(d.source.layer||'').toLowerCase()] || '#475569';
    })
    .attr('stroke-width', d => d.completeness === 'complete' ? 2 : 1)
    .attr('stroke-opacity', d => d.completeness === 'complete' ? 0.7 : 0.4)
    .attr('stroke-dasharray', d => d.completeness === 'partial' ? '4,3' : null)
    .attr('marker-end', d => {
      const l = (d.source.layer||'').toLowerCase();
      return `url(#arr-${l in layerColors ? l : 'default'})`;
    });
  _graphLinkSel = link;

  const node = g.append('g').selectAll('g').data(nodeData).join('g')
    .attr('cursor','pointer')
    .on('click', (e, d) => {
      e.stopPropagation();
      _graphLockedNode = (_graphLockedNode === d.id) ? null : d.id;
      if (_graphLockedNode) _highlightNode(d.id, _graphHighlightDepth);
      else _clearGraphHighlight();
    })
    .on('dblclick', (e, d) => {
      e.stopPropagation();
      openNode(d.id);
    })
    .call(d3.drag()
      .on('start', (e,d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx=d.x; d.fy=d.y; })
      .on('drag',  (e,d) => { d.fx=e.x; d.fy=e.y; })
      .on('end',   (e,d) => { if (!e.active) sim.alphaTarget(0); d.fx=null; d.fy=null; }));
  _graphNodeGroup = node;

  node.append('circle')
    .attr('r', d => radius(d))
    .attr('fill', d => color(d))
    .attr('opacity', d => nodeOpacity(d))
    .attr('stroke', d => d.is_entry ? '#fff' : d.is_terminal ? '#fbbf24' : '#0f1319')
    .attr('stroke-width', d => (d.is_entry || d.is_terminal) ? 2.5 : 1.5)
    .on('mouseenter', function(e,d) {
      if (!_graphLockedNode) _highlightNode(d.id, _graphHighlightDepth);
      d3.select(this).attr('stroke','#fff').attr('stroke-width',2);
    })
    .on('mouseleave', function(e,d) {
      if (!_graphLockedNode) _clearGraphHighlight();
      else if (_graphLockedNode !== d.id) {
        d3.select(this).attr('stroke', d.is_entry?'#fff':d.is_terminal?'#fbbf24':'#0f1319').attr('stroke-width',(d.is_entry||d.is_terminal)?2.5:1.5);
      }
    });

  _graphNodeSel = node.selectAll('circle');

  node.filter(d => (d.confidence||0) >= 0.5).append('text')
    .attr('dy', d => -radius(d)-3).attr('text-anchor','middle')
    .attr('font-size','9px').attr('fill','#94a3b8').attr('pointer-events','none')
    .text(d => { const l=(d.label||d.id||'').split('::').pop(); return l.length>22?l.slice(0,20)+'…':l; });

  node.append('title').text(d => {
    const l=(d.label||d.id||'').split('::').pop();
    const flowInfo = d.flow_ids && d.flow_ids.length ? `\nFlows: ${d.flow_ids.length}` : '';
    const posInfo = d.is_entry ? '\n[ENTRY POINT]' : d.is_terminal ? '\n[TERMINAL]' : '';
    return `${l}\n[${(d.layer||'').toUpperCase()}.${d.type||''}]\nRepo: ${d.repo||'?'}\nConf: ${((d.confidence||0)*100).toFixed(0)}%\nFile: ${d.file||'?'}${d.line?':'+d.line:''}${flowInfo}${posInfo}\n\nClick = highlight neighbors\nDbl-click = open profile`;
  });

  const LAYER_Y = { ui: 0.15, bff: 0.35, api: 0.6, db: 0.85, config: 0.5, shared: 0.5 };
  const isFlowsMode = data._mode === 'flows';

  const sim = d3.forceSimulation(nodeData)
    .force('link',    d3.forceLink(linkData).id(d=>d.id).distance(80).strength(0.3))
    .force('charge',  d3.forceManyBody().strength(-220).distanceMax(400))
    .force('center',  d3.forceCenter(W/2, H/2).strength(0.08))
    .force('collide', d3.forceCollide().radius(d=>radius(d)+6).strength(0.8))
    .force('x', d3.forceX(W/2).strength(0.04))
    .force('y', isFlowsMode
      // In flows mode: push nodes to their layer's Y band for a top-down layout
      ? d3.forceY(d => H * (LAYER_Y[(d.layer||'shared').toLowerCase()] || 0.5)).strength(0.4)
      : d3.forceY(H/2).strength(0.04)
    )
    .on('tick', () => {
      link
        .attr('x1', d=>d.source.x).attr('y1', d=>d.source.y)
        .attr('x2', d=>{ const dx=d.target.x-d.source.x,dy=d.target.y-d.source.y,dist=Math.sqrt(dx*dx+dy*dy)||1; return d.target.x-(dx/dist)*(radius(d.target)+6); })
        .attr('y2', d=>{ const dx=d.target.x-d.source.x,dy=d.target.y-d.source.y,dist=Math.sqrt(dx*dx+dy*dy)||1; return d.target.y-(dy/dist)*(radius(d.target)+6); });
      node.attr('transform', d=>`translate(${d.x},${d.y})`);
    });
  _graphSim = sim;

  setTimeout(() => sim.alphaTarget(0), 3000);

  const presentLayers = [...new Set(nodes.map(n => (n.layer || '').toLowerCase()).filter(Boolean))]
    .sort((a, b) => (['ui','bff','api','db','config','shared'].indexOf(a) + 1 || 99) - (['ui','bff','api','db','config','shared'].indexOf(b) + 1 || 99));
  _buildLayerPills(presentLayers, layerColors);

  // Populate layer filter dropdown dynamically from actual data
  const layerFilterSel = document.getElementById('graph-layer-filter');
  if (layerFilterSel) {
    const curVal = layerFilterSel.value;
    layerFilterSel.innerHTML = '<option value="">All Layers</option>';
    presentLayers.forEach(l => {
      const opt = document.createElement('option');
      opt.value = l; opt.textContent = l.toUpperCase();
      if (l === curVal) opt.selected = true;
      layerFilterSel.appendChild(opt);
    });
  }

  if (data.truncated) {
    const n = document.createElement('div');
    n.style.cssText = 'position:absolute;bottom:8px;right:12px;font-size:11px;color:#64748b;pointer-events:none';
    n.textContent = `Showing ${nodes.length} of ${data.total_nodes} nodes`;
    canvas.appendChild(n);
  }

  // Flows mode legend
  if (isFlowsMode) {
    const leg = canvas.appendChild(document.createElement('div'));
    leg.style.cssText = 'position:absolute;bottom:8px;left:8px;display:flex;gap:12px;font-size:10px;color:#94a3b8;pointer-events:none;background:rgba(10,10,20,0.7);padding:4px 8px;border-radius:6px';
    leg.innerHTML =
      '<span><span style="display:inline-block;width:24px;height:2px;background:#22c55e;margin-right:4px;vertical-align:middle"></span>complete flow</span>' +
      '<span><span style="display:inline-block;width:24px;height:2px;background:#94a3b8;border-top:2px dashed #94a3b8;margin-right:4px;vertical-align:middle"></span>partial flow</span>' +
      '<span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#60a5fa;border:2px solid #fff;margin-right:4px;vertical-align:middle"></span>entry</span>' +
      '<span><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:#fb923c;border:2px solid #fbbf24;margin-right:4px;vertical-align:middle"></span>terminal</span>';
  }

  _graphSvg = svg.node();
}

function focusGraphNode() {
  const input = document.getElementById('graph-focus-input');
  if (!input || !_graphData) return;
  const q = input.value.trim().toLowerCase();
  if (!q) return;
  const match = (_graphData.nodes || []).find(n =>
    (n.label || '').toLowerCase().includes(q) || (n.id || '').toLowerCase().includes(q)
  );
  if (match) openNode(match.id);
}

// ── AST Tab ─────────────────────────────────────────────────────────────────

async function loadAstTab() {
  const container = document.getElementById('explorer-landing-tab-content');
  if (!container) return;
  container.innerHTML = loadingHTML();
  try {
    const data = await api('/ast/all?limit=500');
    renderAstList(container, data);
  } catch (e) {
    container.innerHTML = emptyHTML('Failed to load AST summaries: ' + e.message);
  }
}

function renderAstList(container, data) {
  const summaries = data.summaries || [];
  if (!summaries.length) {
    container.innerHTML = emptyHTML('No AST summaries found. Run the pipeline with tree-sitter installed.');
    return;
  }

  // Group by file
  const byFile = {};
  summaries.forEach(s => {
    const key = `${s.repo || ''}/${s.file || 'unknown'}`;
    if (!byFile[key]) byFile[key] = {repo: s.repo, file: s.file, language: s.language, methods: []};
    byFile[key].methods.push(s);
  });

  let html = `<div class="stat-grid mb-8">`;
  html += statCard(summaries.length, 'AST Summaries');
  html += statCard(Object.keys(byFile).length, 'Files');
  const langs = new Set(summaries.map(s => s.language).filter(Boolean));
  html += statCard(langs.size, 'Languages');
  html += `</div>`;

  // Filter controls
  html += `<div class="graph-controls mb-8">`;
  html += `<input type="text" id="ast-filter" placeholder="Filter by name or file…" oninput="filterAstList()" style="width:250px;padding:4px 8px;background:#0f0f1a;border:1px solid #3a3a5e;color:#e0e0e0;border-radius:4px;font-size:12px">`;
  html += `</div>`;

  html += `<div id="ast-list-content">`;
  html += renderAstFileGroups(byFile);
  html += `</div>`;

  if (data.truncated) html += `<div class="muted mt-4">Showing first ${summaries.length} summaries.</div>`;
  container.innerHTML = html;

  // Store for filtering
  window._astByFile = byFile;
}

function renderAstFileGroups(byFile) {
  let html = '';
  for (const [key, info] of Object.entries(byFile).sort((a,b) => b[1].methods.length - a[1].methods.length)) {
    const sectionId = 'ast-file-' + key.replace(/[^a-zA-Z0-9]/g, '_');
    html += `<div class="ast-file-group" data-key="${esc(key)}">`;
    html += `<div class="inv-type-header" onclick="toggleInvSection('${sectionId}')">`;
    html += `<span class="badge badge-method">${esc(info.language || '?')}</span> `;
    html += `<span class="ev-file">${esc(key)}</span> `;
    html += `<span class="muted">${info.methods.length} methods</span>`;
    html += `<span class="inv-toggle" id="${sectionId}-toggle">▶</span>`;
    html += `</div>`;
    html += `<div class="inv-section" id="${sectionId}" style="display:none">`;
    info.methods.sort((a,b) => (a.line_start||0) - (b.line_start||0));
    info.methods.forEach(m => {
      const sig = m.signature || {};
      const calls = m.calls || [];
      const comp = m.complexity || {};
      const eid = m.entity_id || m.discovered_id || '';
      html += `<div class="card" ${eid ? `onclick="showAstSummary('${esc(eid)}')"` : ''} style="cursor:${eid ? 'pointer' : 'default'}">`;
      html += `<div class="card-title">`;
      if (sig.access) html += `<span class="ast-type">${esc(sig.access)}</span> `;
      if (sig.return_type) html += `<span class="ast-type">${esc(sig.return_type)}</span> `;
      html += `<strong>${esc(sig.name || m.name || m.qualified_name || '?')}</strong>`;
      if (sig.parameters) {
        const params = sig.parameters.map(p => `${p.type||''} ${p.name||''}`).join(', ');
        html += `(${esc(params)})`;
      }
      html += ` <span class="muted">L${m.line_start||'?'}–${m.line_end||'?'}</span>`;
      html += `</div>`;
      html += `<div class="card-meta">`;
      html += confBadgePlain(m.confidence);
      if (calls.length) html += ` <span class="muted">${calls.length} calls</span>`;
      if (comp.branches) html += ` <span class="muted">${comp.branches} branches</span>`;
      if (comp.lines) html += ` <span class="muted">${comp.lines} lines</span>`;
      html += `</div>`;
      // Show annotations
      if (m.annotations && m.annotations.length) {
        html += `<div class="card-desc" style="font-size:11px">${m.annotations.map(a => `<span class="ast-ann">${esc(a)}</span>`).join(' ')}</div>`;
      }
      // Show call targets
      if (calls.length) {
        html += `<div class="card-desc" style="font-size:11px">→ ${calls.slice(0,5).map(c => esc(c.target)).join(', ')}${calls.length > 5 ? ' +' + (calls.length-5) + ' more' : ''}</div>`;
      }
      html += `</div>`;
    });
    html += `</div></div>`;
  }
  return html;
}

function filterAstList() {
  const q = (document.getElementById('ast-filter')?.value || '').toLowerCase();
  const container = document.getElementById('ast-list-content');
  if (!container || !window._astByFile) return;
  if (!q) { container.innerHTML = renderAstFileGroups(window._astByFile); return; }
  const filtered = {};
  for (const [key, info] of Object.entries(window._astByFile)) {
    const matchingMethods = info.methods.filter(m => {
      const name = (m.signature?.name || m.name || m.qualified_name || '').toLowerCase();
      const file = (m.file || '').toLowerCase();
      return name.includes(q) || file.includes(q) || key.toLowerCase().includes(q);
    });
    if (matchingMethods.length) filtered[key] = {...info, methods: matchingMethods};
  }
  container.innerHTML = renderAstFileGroups(filtered);
}

// ── Panel resize handler ────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', () => {
  const handle = document.getElementById('panel-resize');
  const panel = document.getElementById('right-panel');
  if (!handle || !panel) return;

  let dragging = false;
  handle.addEventListener('mousedown', (e) => {
    dragging = true;
    handle.classList.add('dragging');
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const newWidth = Math.max(280, Math.min(800, window.innerWidth - e.clientX));
    panel.style.width = newWidth + 'px';
  });
  document.addEventListener('mouseup', () => {
    if (dragging) {
      dragging = false;
      handle.classList.remove('dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  });
});
