"""Tests for schemas.scope — scope hierarchy and collapse rule."""

from schemas.scope import build_scope_path, Scope, Codebase, Repo, Workspace


class TestBuildScopePath:
    def test_single_repo_all_same(self):
        assert build_scope_path("X", "X", "X") == "X"

    def test_multi_repo_no_monorepo(self):
        assert build_scope_path("acme", "orders", "orders") == "acme/orders"

    def test_monorepo_codebase_equals_repo(self):
        assert build_scope_path("web", "web", "admin") == "web/admin"

    def test_full_hierarchy(self):
        assert build_scope_path("acme", "web", "admin") == "acme/web/admin"

    def test_placeholder_underscore(self):
        assert build_scope_path("acme", "_", "pg") == "acme/_/pg"


class TestScope:
    def test_path_single_repo(self):
        s = Scope(codebase="flags_api", repo="flags_api", workspace="flags_api")
        assert s.path == "flags_api"

    def test_path_monorepo(self):
        s = Scope(codebase="acme", repo="acme", workspace="admin")
        assert s.path == "acme/admin"

    def test_path_full(self):
        s = Scope(codebase="acme", repo="web", workspace="admin")
        assert s.path == "acme/web/admin"

    def test_repo_id_backward_compat(self):
        s = Scope(codebase="flags_api", repo="flags_api", workspace="flags_api")
        assert s.repo_id == s.path == "flags_api"

    def test_frozen(self):
        s = Scope(codebase="a", repo="b", workspace="c")
        try:
            s.codebase = "x"
            assert False, "Should be frozen"
        except AttributeError:
            pass


class TestDataclasses:
    def test_codebase(self):
        c = Codebase(name="acme", root="/path")
        assert c.name == "acme"

    def test_repo(self):
        r = Repo(name="web", codebase="acme")
        assert r.codebase == "acme"

    def test_workspace(self):
        w = Workspace(name="admin", repo="web", codebase="acme", classification=("ui",))
        assert w.classification == ("ui",)
