"""Tests for emitter scope-awareness (Task 5)."""

from schemas.emitter import CanonicalEmitter
from schemas.scope import Scope


class TestEmitterLegacyRepo:
    def test_legacy_repo_still_works(self):
        e = CanonicalEmitter("test")
        eid = e.emit_entity(
            layer="api", entity_type="endpoint", repo="flags_api",
            qualifier="GET:/flags", name="getFlags",
            confidence=0.95, evidence_file="F.java", evidence_method="regex",
        )
        assert eid == "api:endpoint:flags_api:GET:/flags"
        entity = e._entities[eid]
        assert entity["repo"] == "flags_api"
        assert entity["codebase"] == "flags_api"
        assert entity["workspace"] == "flags_api"
        assert entity["scope_path"] == "flags_api"


class TestEmitterWithScope:
    def test_scope_keyword(self):
        e = CanonicalEmitter("test")
        scope = Scope(codebase="acme", repo="web", workspace="admin")
        eid = e.emit_entity(
            layer="code", entity_type="function", qualifier="main",
            name="main", confidence=0.95,
            evidence_file="main.py", evidence_method="ast",
            scope=scope,
        )
        assert eid == "code:function:acme/web/admin:main"
        entity = e._entities[eid]
        assert entity["codebase"] == "acme"
        assert entity["workspace"] == "admin"
        assert entity["scope_path"] == "acme/web/admin"
        assert entity["repo"] == "acme/web/admin"  # backward compat


class TestEmitterGenericLayer:
    def test_code_module_emission(self):
        e = CanonicalEmitter("test")
        scope = Scope(codebase="proj", repo="proj", workspace="proj")
        eid = e.emit_entity(
            layer="code", entity_type="module", qualifier="src/app.ts",
            name="app.ts", confidence=0.95,
            evidence_file="src/app.ts", evidence_method="ast",
            scope=scope,
        )
        assert eid == "code:module:proj:src/app.ts"
