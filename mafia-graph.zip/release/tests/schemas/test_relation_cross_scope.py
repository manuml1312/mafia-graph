"""Tests for relation cross-scope tagging (Task 6)."""

from schemas.emitter import CanonicalEmitter


def _make_rel(source_scope, target_scope):
    """Helper: emit two entities in different scopes and a relation between them."""
    e = CanonicalEmitter("test")
    src_id = e.emit_entity(
        layer="code", entity_type="function", repo=source_scope,
        qualifier="funcA", name="funcA", confidence=0.95,
        evidence_file="a.py", evidence_method="ast",
    )
    tgt_id = e.emit_entity(
        layer="code", entity_type="function", repo=target_scope,
        qualifier="funcB", name="funcB", confidence=0.95,
        evidence_file="b.py", evidence_method="ast",
    )
    rel_id = e.emit_relation(
        source_id=src_id, target_id=tgt_id, relation_type="calls",
        confidence=0.90, evidence_file="a.py", evidence_method="ast",
    )
    return e._relations[rel_id]


class TestCrossScopeTagging:
    def test_same_workspace(self):
        rel = _make_rel("acme/web/admin", "acme/web/admin")
        assert rel["cross_scope"] is False
        assert rel["boundary"] is None

    def test_cross_workspace(self):
        rel = _make_rel("acme/web/admin", "acme/web/core")
        assert rel["cross_scope"] is True
        assert rel["boundary"] == "workspace"

    def test_cross_repo(self):
        rel = _make_rel("acme/web/admin", "acme/api/api")
        assert rel["cross_scope"] is True
        assert rel["boundary"] == "repo"

    def test_cross_codebase(self):
        rel = _make_rel("acme/web/admin", "other/svc/svc")
        assert rel["cross_scope"] is True
        assert rel["boundary"] == "codebase"

    def test_single_repo_same(self):
        rel = _make_rel("flags_api", "flags_api")
        assert rel["cross_scope"] is False
        assert rel["boundary"] is None
