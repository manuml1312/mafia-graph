"""Tests for schemas.id_format — v2 layer/type/relation extensions."""

from schemas.id_format import LAYERS, ENTITY_TYPES, RELATION_TYPES


class TestLayerExtensions:
    def test_existing_layers_preserved(self):
        for layer in ("ui", "bff", "api", "db", "config", "shared"):
            assert layer in LAYERS

    def test_new_generic_layers(self):
        for layer in ("code", "lib", "infra", "test", "doc", "data"):
            assert layer in LAYERS


class TestEntityTypeExtensions:
    def test_code_types(self):
        expected = {"module", "function", "class", "interface", "trait"}
        assert expected <= ENTITY_TYPES["code"]

    def test_lib_types(self):
        expected = {"package", "library", "binding"}
        assert expected <= ENTITY_TYPES["lib"]

    def test_infra_types(self):
        expected = {"dockerfile", "ci_pipeline", "deployment", "iac_resource"}
        assert expected <= ENTITY_TYPES["infra"]

    def test_test_types(self):
        expected = {"test_module", "test_case"}
        assert expected <= ENTITY_TYPES["test"]

    def test_doc_types(self):
        expected = {"document", "section"}
        assert expected <= ENTITY_TYPES["doc"]

    def test_data_types(self):
        assert "table" in ENTITY_TYPES["data"]

    def test_existing_ui_types_unchanged(self):
        assert "component" in ENTITY_TYPES["ui"]
        assert "hook" in ENTITY_TYPES["ui"]

    def test_existing_api_types_unchanged(self):
        assert "endpoint" in ENTITY_TYPES["api"]
        assert "controller" in ENTITY_TYPES["api"]


class TestRelationTypeExtensions:
    def test_existing_relations_preserved(self):
        for rt in ("defined_in", "calls", "fetches", "calls_api", "delegates_to"):
            assert rt in RELATION_TYPES

    def test_new_cross_scope_relations(self):
        for rt in (
            "workspace_depends_on",
            "cross_workspace_import",
            "cross_repo_import",
            "shared_lib_used_by",
            "shares_table_with",
            "shares_env_with",
            "consumes_artifact",
        ):
            assert rt in RELATION_TYPES
