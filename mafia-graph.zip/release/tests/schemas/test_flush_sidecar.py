"""Tests for id_format.json sidecar on flush (Task 8)."""

import json
import tempfile
from pathlib import Path
from schemas.emitter import CanonicalEmitter


class TestFlushSidecar:
    def test_sidecar_written(self):
        e = CanonicalEmitter("test")
        e.emit_entity(
            layer="api", entity_type="endpoint", repo="r",
            qualifier="GET:/x", name="x", confidence=0.95,
            evidence_file="f.java", evidence_method="regex",
        )
        with tempfile.TemporaryDirectory() as td:
            ent_path = str(Path(td) / "entities.jsonl")
            rel_path = str(Path(td) / "relations.jsonl")
            e.flush(ent_path, rel_path)

            sidecar = Path(td) / "id_format.json"
            assert sidecar.exists()
            data = json.loads(sidecar.read_text())
            assert data["id_format_version"] == 2
