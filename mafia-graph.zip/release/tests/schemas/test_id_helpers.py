"""Tests for ID format v2 helpers: parse, make, migrate."""

import pytest
from schemas.id_format import (
    ID_FORMAT_VERSION, ParsedEntityId,
    parse_entity_id, make_entity_id, migrate_entity_id_v1_to_v2,
)


class TestIdFormatVersion:
    def test_version_is_2(self):
        assert ID_FORMAT_VERSION == 2


class TestParseEntityId:
    def test_v1_simple(self):
        p = parse_entity_id("api:endpoint:flags_api:GET:/flagTypes")
        assert p.layer == "api"
        assert p.entity_type == "endpoint"
        assert p.scope_path == "flags_api"
        assert p.qualifier == "GET:/flagTypes"

    def test_v2_slash_scope(self):
        p = parse_entity_id("ui:component:acme/web/admin:src/App.tsx::App")
        assert p.scope_path == "acme/web/admin"
        assert p.qualifier == "src/App.tsx::App"

    def test_malformed_raises(self):
        with pytest.raises(ValueError):
            parse_entity_id("only:two:parts")


class TestMakeEntityId:
    def test_legacy_positional(self):
        eid = make_entity_id("api", "endpoint", "flags_api", "GET:/flagTypes")
        assert eid == "api:endpoint:flags_api:GET:/flagTypes"

    def test_keyword_scope_path(self):
        eid = make_entity_id("code", "function", qualifier="main",
                             scope_path="acme/web/admin")
        assert eid == "code:function:acme/web/admin:main"

    def test_scope_path_overrides_repo(self):
        eid = make_entity_id("code", "module", "ignored",
                             "file.py", scope_path="real/scope")
        assert eid == "code:module:real/scope:file.py"


class TestMigrateV1ToV2:
    def test_identity(self):
        eid = "api:endpoint:flags_api:GET:/flagTypes"
        assert migrate_entity_id_v1_to_v2(eid) == eid

    def test_validates(self):
        with pytest.raises(ValueError):
            migrate_entity_id_v1_to_v2("bad:id")
