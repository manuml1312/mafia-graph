"""Tests for validator v2 ID acceptance (Task 7)."""

from schemas.validator import validate_entity_id


class TestValidateEntityId:
    def test_v1_id_valid(self):
        assert validate_entity_id("api:endpoint:flags_api:GET:/flagTypes") is True

    def test_v2_slash_scope_valid(self):
        assert validate_entity_id("code:function:acme/web/admin:main") is True

    def test_unknown_layer_rejected(self):
        assert validate_entity_id("bogus:function:repo:main") is False

    def test_unknown_type_rejected(self):
        assert validate_entity_id("api:bogus_type:repo:qual") is False

    def test_malformed_rejected(self):
        assert validate_entity_id("only:two") is False

    def test_new_code_layer_valid(self):
        assert validate_entity_id("code:class:proj:MyClass") is True

    def test_new_lib_layer_valid(self):
        assert validate_entity_id("lib:package:proj:react") is True
