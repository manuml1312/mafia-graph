"""Tests for graph builder v2 extensions (Sub-plan 5)."""

import json
import tempfile
from pathlib import Path

from phase9_graph.graph_builder import (
    build_graph, FLOW_ALLOWLIST, STRUCTURAL,
    _build_workspace_graph, _build_shared_resources, _build_views,
)


def _write_jsonl(path, items):
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")


def _make_entity(eid, layer, etype, repo, name="x", scope_path=None, confidence=0.95):
    return {
        "id": eid, "layer": layer, "type": etype, "repo": repo,
        "name": name, "confidence": confidence,
        "scope_path": scope_path or repo,
        "codebase": repo.split("/")[0] if "/" in repo else repo,
        "workspace": repo.split("/")[-1] if "/" in repo else repo,
        "evidence": {"repo": repo, "file": "f.py", "extractor": "test", "method": "test"},
        "properties": {},
    }


def _make_rel(source, target, rtype, confidence=0.90, cross_scope=False, boundary=None, props=None):
    rid = f"{source}--{rtype}-->{target}"
    return {
        "id": rid, "source": source, "target": target, "type": rtype,
        "confidence": confidence, "cross_scope": cross_scope, "boundary": boundary,
        "evidence": {"file": "f.py", "extractor": "test", "method": "test"},
        "properties": props or {},
    }


class TestFlowAllowlistUpdates:
    def test_cross_workspace_import_in_allowlist(self):
        assert "cross_workspace_import" in FLOW_ALLOWLIST

    def test_cross_repo_import_in_allowlist(self):
        assert "cross_repo_import" in FLOW_ALLOWLIST


class TestStructuralUpdates:
    def test_new_structural_types(self):
        for rt in ("workspace_depends_on", "shared_lib_used_by", "consumes_artifact",
                    "shares_table_with", "shares_env_with"):
            assert rt in STRUCTURAL


class TestBuildGraph:
    def test_produces_all_artifacts(self):
        entities = [
            _make_entity("api:endpoint:ws_a:GET:/users", "api", "endpoint", "ws_a"),
            _make_entity("api:service:ws_a:UserService", "api", "service", "ws_a"),
        ]
        relations = [
            _make_rel("api:endpoint:ws_a:GET:/users", "api:service:ws_a:UserService", "delegates_to"),
        ]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", relations)
            build_graph(td)
            assert (Path(td) / "system_graph.json").exists()
            assert (Path(td) / "e2e_flows.json").exists()
            assert (Path(td) / "graph_views.json").exists()
            assert (Path(td) / "workspace_graph.json").exists()
            assert (Path(td) / "shared_resources.json").exists()

    def test_id_format_version_in_system_graph(self):
        entities = [_make_entity("api:endpoint:r:GET:/x", "api", "endpoint", "r")]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", [])
            build_graph(td)
            sg = json.loads((Path(td) / "system_graph.json").read_text())
            assert sg["id_format_version"] == 2

    def test_id_format_version_in_flows(self):
        entities = [_make_entity("api:endpoint:r:GET:/x", "api", "endpoint", "r")]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", [])
            build_graph(td)
            flows = json.loads((Path(td) / "e2e_flows.json").read_text())
            assert flows["id_format_version"] == 2


class TestScopeAwareNodes:
    def test_nodes_have_scope_fields(self):
        entities = [
            _make_entity("code:module:acme/web/admin:app.ts", "code", "module",
                         "acme/web/admin", scope_path="acme/web/admin"),
        ]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", [])
            build_graph(td)
            sg = json.loads((Path(td) / "system_graph.json").read_text())
            node = sg["nodes"][0]
            assert node["scope_path"] == "acme/web/admin"
            assert node["codebase"] == "acme"


class TestGraphViewsExtensions:
    def test_by_workspace_present(self):
        entities = [
            _make_entity("code:module:ws_a:a.py", "code", "module", "ws_a", scope_path="ws_a"),
            _make_entity("code:module:ws_b:b.py", "code", "module", "ws_b", scope_path="ws_b"),
        ]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", [])
            build_graph(td)
            views = json.loads((Path(td) / "graph_views.json").read_text())
            assert "by_workspace" in views
            assert "ws_a" in views["by_workspace"]
            assert "ws_b" in views["by_workspace"]
            assert views["by_workspace"]["ws_a"]["node_count"] == 1

    def test_cross_scope_summary(self):
        entities = [
            _make_entity("code:module:ws_a:a.py", "code", "module", "ws_a", scope_path="ws_a"),
            _make_entity("code:module:ws_b:b.py", "code", "module", "ws_b", scope_path="ws_b"),
        ]
        relations = [
            _make_rel("code:module:ws_a:a.py", "code:module:ws_b:b.py",
                       "cross_workspace_import", cross_scope=True, boundary="workspace"),
        ]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", relations)
            build_graph(td)
            views = json.loads((Path(td) / "graph_views.json").read_text())
            assert views["cross_scope_summary"].get("workspace", 0) >= 1


class TestWorkspaceGraph:
    def test_workspace_graph_structure(self):
        entities = [
            _make_entity("code:module:ws_a:a.py", "code", "module", "ws_a", scope_path="ws_a"),
            _make_entity("code:module:ws_b:b.py", "code", "module", "ws_b", scope_path="ws_b"),
        ]
        relations = [
            _make_rel("code:module:ws_a:a.py", "code:module:ws_b:b.py",
                       "cross_workspace_import", cross_scope=True, boundary="workspace"),
        ]
        result = _build_workspace_graph(entities, relations)
        assert result["node_count"] == 2
        assert result["edge_count"] == 1
        assert result["edges"][0]["total"] == 1


class TestSharedResources:
    def test_shared_libs(self):
        relations = [
            _make_rel("lib:package:_:react", "workspace:ws_a", "shared_lib_used_by",
                       props={"lib_name": "react"}),
            _make_rel("lib:package:_:react", "workspace:ws_b", "shared_lib_used_by",
                       props={"lib_name": "react"}),
        ]
        result = _build_shared_resources(relations)
        assert len(result["shared_libs"]) == 1
        assert result["shared_libs"][0]["name"] == "react"
        assert len(result["shared_libs"][0]["used_by"]) == 2

    def test_shared_envs(self):
        relations = [
            _make_rel("workspace:ws_a", "workspace:ws_b", "shares_env_with",
                       props={"env_name": "DB_URL"}),
        ]
        result = _build_shared_resources(relations)
        assert len(result["shared_envs"]) == 1
        assert result["shared_envs"][0]["name"] == "DB_URL"

    def test_shared_tables(self):
        relations = [
            _make_rel("workspace:ws_a", "workspace:ws_b", "shares_table_with",
                       props={"table_name": "public.users"}),
        ]
        result = _build_shared_resources(relations)
        assert len(result["shared_tables"]) == 1


class TestBackwardCompat:
    def test_v1_entities_load(self):
        """v1 entities without scope fields still build a graph."""
        entities = [{
            "id": "api:endpoint:flags_api:GET:/flags",
            "layer": "api", "type": "endpoint", "repo": "flags_api",
            "name": "getFlags", "confidence": 0.95,
            "evidence": {"repo": "flags_api", "file": "F.java", "extractor": "test", "method": "regex"},
            "properties": {},
        }]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", [])
            build_graph(td)
            sg = json.loads((Path(td) / "system_graph.json").read_text())
            assert sg["meta"]["node_count"] == 1
            # scope_path defaults to repo
            assert sg["nodes"][0]["scope_path"] == "flags_api"


class TestFlowCrossWorkspace:
    def test_flow_crosses_workspace_flag(self):
        """A flow spanning two workspaces gets crosses_workspace=True."""
        entities = [
            _make_entity("bff:endpoint:ws_a:GET:/items", "bff", "endpoint", "ws_a", name="getItems", scope_path="ws_a"),
            _make_entity("api:endpoint:ws_b:GET:/items", "api", "endpoint", "ws_b", name="getItemsApi", scope_path="ws_b"),
            _make_entity("db:table:ws_b:items", "db", "table", "ws_b", name="items", scope_path="ws_b"),
        ]
        relations = [
            _make_rel("bff:endpoint:ws_a:GET:/items", "api:endpoint:ws_b:GET:/items", "calls_api"),
            _make_rel("api:endpoint:ws_b:GET:/items", "db:table:ws_b:items", "reads_from"),
        ]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", relations)
            build_graph(td)
            flows = json.loads((Path(td) / "e2e_flows.json").read_text())
            full = flows["catalogs"]["full_chains"]
            cross_ws = [f for f in full if f.get("crosses_workspace")]
            assert len(cross_ws) >= 1


class TestTopologyCrossScopeBridges:
    def test_cross_scope_bridges_detected(self):
        """Topology report includes cross_scope_bridges for nodes spanning workspaces."""
        entities = [
            _make_entity("api:service:ws_a:Svc", "api", "service", "ws_a", name="Svc", scope_path="ws_a"),
            _make_entity("api:controller:ws_a:C1", "api", "controller", "ws_a", name="C1", scope_path="ws_a"),
            _make_entity("api:controller:ws_a:C2", "api", "controller", "ws_a", name="C2", scope_path="ws_a"),
            _make_entity("api:controller:ws_a:C3", "api", "controller", "ws_a", name="C3", scope_path="ws_a"),
            _make_entity("api:endpoint:ws_b:GET:/x", "api", "endpoint", "ws_b", name="getX", scope_path="ws_b"),
        ]
        relations = [
            _make_rel("api:controller:ws_a:C1", "api:service:ws_a:Svc", "delegates_to"),
            _make_rel("api:controller:ws_a:C2", "api:service:ws_a:Svc", "delegates_to"),
            _make_rel("api:controller:ws_a:C3", "api:service:ws_a:Svc", "delegates_to"),
            _make_rel("api:service:ws_a:Svc", "api:endpoint:ws_b:GET:/x", "calls_api"),
        ]
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", relations)
            build_graph(td)
            from phase9_graph.topology_analyzer import analyze_topology
            report = analyze_topology(td)
            assert "cross_scope_bridges" in report
            bridge_ids = {b["id"] for b in report["cross_scope_bridges"]}
            assert "api:service:ws_a:Svc" in bridge_ids


class TestGraphQueryCrossScope:
    def _build_gq(self):
        """Build a GraphQuery with cross-scope data."""
        from phase9_graph.graph_query import GraphQuery
        gq = GraphQuery()
        gq.nodes = {
            "code:module:ws_a:a.py": {"id": "code:module:ws_a:a.py", "label": "a.py",
                                       "layer": "code", "type": "module", "repo": "ws_a",
                                       "scope_path": "ws_a"},
            "code:module:ws_b:b.py": {"id": "code:module:ws_b:b.py", "label": "b.py",
                                       "layer": "code", "type": "module", "repo": "ws_b",
                                       "scope_path": "ws_b"},
            "lib:package:_:react":    {"id": "lib:package:_:react", "label": "react",
                                       "layer": "lib", "type": "package", "repo": "_",
                                       "scope_path": "_"},
            "db:table:shared:users":  {"id": "db:table:shared:users", "label": "users",
                                       "layer": "db", "type": "table", "repo": "shared",
                                       "scope_path": "shared"},
            "config:env:ws_a:DB_URL": {"id": "config:env:ws_a:DB_URL", "label": "DB_URL",
                                       "layer": "config", "type": "env", "repo": "ws_a",
                                       "scope_path": "ws_a"},
        }
        edges = [
            {"source": "code:module:ws_a:a.py", "target": "code:module:ws_b:b.py",
             "type": "cross_workspace_import", "confidence": 0.90},
            {"source": "code:module:ws_a:a.py", "target": "lib:package:_:react",
             "type": "imports", "confidence": 0.95},
            {"source": "code:module:ws_b:b.py", "target": "lib:package:_:react",
             "type": "imports", "confidence": 0.95},
            {"source": "code:module:ws_a:a.py", "target": "db:table:shared:users",
             "type": "reads_from", "confidence": 0.85},
            {"source": "code:module:ws_b:b.py", "target": "db:table:shared:users",
             "type": "reads_from", "confidence": 0.85},
            {"source": "code:module:ws_a:a.py", "target": "config:env:ws_a:DB_URL",
             "type": "reads_from", "confidence": 0.80},
            {"source": "code:module:ws_b:b.py", "target": "config:env:ws_a:DB_URL",
             "type": "reads_from", "confidence": 0.80},
        ]
        for e in edges:
            s, t = e["source"], e["target"]
            gq.adj[s].append(t)
            gq.rev[t].append(s)
            gq._edges[(s, t)] = e
        return gq

    def test_cross_scope_edges(self):
        gq = self._build_gq()
        cs = gq.cross_scope_edges()
        assert len(cs) >= 1
        types = {e["type"] for e in cs}
        assert "cross_workspace_import" in types

    def test_cross_scope_edges_boundary_filter(self):
        gq = self._build_gq()
        repo_edges = gq.cross_scope_edges(boundary="repo")
        # ws_a -> ws_b is cross-repo
        assert any(e["type"] == "cross_workspace_import" for e in repo_edges)

    def test_workspace_neighbors(self):
        gq = self._build_gq()
        neighbors = gq.workspace_neighbors("ws_a", direction="downstream")
        assert "ws_b" in neighbors

    def test_shared_libs(self):
        gq = self._build_gq()
        libs = gq.shared_libs()
        assert len(libs) == 1
        assert libs[0]["name"] == "react"
        assert len(libs[0]["used_by"]) == 2

    def test_shared_tables(self):
        gq = self._build_gq()
        tables = gq.shared_tables()
        assert len(tables) == 1
        assert tables[0]["name"] == "users"

    def test_shared_envs(self):
        gq = self._build_gq()
        envs = gq.shared_envs()
        assert len(envs) == 1
        assert envs[0]["name"] == "DB_URL"

    def test_v1_graph_loads(self):
        """GraphQuery loads a v1 graph (no scope fields) without error."""
        from phase9_graph.graph_query import GraphQuery
        gq = GraphQuery()
        gq.nodes = {
            "api:endpoint:r:GET:/x": {"id": "api:endpoint:r:GET:/x", "label": "getX",
                                       "layer": "api", "type": "endpoint", "repo": "r"},
        }
        result = gq.find_by_name("getX")
        assert len(result) == 1
