"""Tests for scope discovery, stack detector, and manifest writer (Tasks 22-24)."""

import json
from pathlib import Path

from phase2_repo_intake.scope_discovery import discover
from phase2_repo_intake.manifest_writer import write_workspace_manifest
from phase2_repo_intake.stack_detector import detect_stack

FIXTURES = Path(__file__).resolve().parent.parent / "fixtures" / "discovery"


class TestStackDetector:
    def test_detects_react(self):
        # npm_workspaces/packages/admin has react dep
        result = detect_stack(FIXTURES / "npm_workspaces" / "packages" / "admin")
        assert "react" in result.detected_stack or "ui" in result.classification


class TestScopeDiscovery:
    def test_npm_workspaces_monorepo(self):
        result = discover(str(FIXTURES / "npm_workspaces"))
        assert result.codebase.name == "npm_workspaces"
        assert len(result.repos) == 1
        assert len(result.workspaces) == 2
        ws_names = {w.name for w in result.workspaces}
        assert "core" in ws_names
        assert "admin" in ws_names

    def test_outer_folder_three_repos(self):
        result = discover(str(FIXTURES / "outer_folder_with_three_repos"))
        assert len(result.repos) == 3
        # Each repo has 1 workspace (no monorepo)
        assert len(result.workspaces) == 3

    def test_maven_multimodule(self):
        result = discover(str(FIXTURES / "maven_multimodule"))
        assert len(result.repos) == 1
        assert len(result.workspaces) == 2

    def test_single_repo_no_monorepo(self, tmp_path):
        (tmp_path / "package.json").write_text('{"name": "simple-app"}')
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "index.ts").write_text("console.log('hi')")
        result = discover(str(tmp_path))
        assert len(result.repos) == 1
        assert len(result.workspaces) == 1
        assert result.workspaces[0].name == tmp_path.name


class TestManifestWriter:
    def test_writes_both_manifests(self, tmp_path):
        result = discover(str(FIXTURES / "npm_workspaces"))
        out_dir = tmp_path / "output"
        ws_path = write_workspace_manifest(result, str(out_dir))

        assert ws_path.exists()
        assert (out_dir / "repo_manifest.json").exists()

        manifest = json.loads(ws_path.read_text())
        assert manifest["codebase"]["id"] == "npm_workspaces"
        assert len(manifest["repos"]) == 1
        assert len(manifest["repos"][0]["workspaces"]) == 2

    def test_legacy_manifest_has_repos(self, tmp_path):
        result = discover(str(FIXTURES / "outer_folder_with_three_repos"))
        out_dir = tmp_path / "output"
        write_workspace_manifest(result, str(out_dir))

        legacy = json.loads((out_dir / "repo_manifest.json").read_text())
        assert len(legacy["repos"]) == 3
