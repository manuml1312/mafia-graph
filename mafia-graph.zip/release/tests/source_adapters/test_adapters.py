"""Tests for source adapters (Tasks 1-5)."""

import os
import zipfile
import tarfile
import tempfile
import pytest
from pathlib import Path

from phase4_source_adapters import resolve_source
from phase4_source_adapters.base import SourceAdapter
from phase4_source_adapters.folder_adapter import FolderAdapter
from phase4_source_adapters.zip_adapter import ZipAdapter
from phase4_source_adapters.tar_adapter import TarAdapter
from phase4_source_adapters.git_adapter import GitAdapter


class TestSourceAdapterABC:
    def test_cannot_instantiate_base(self):
        with pytest.raises(TypeError):
            SourceAdapter()


class TestFolderAdapter:
    def test_accepts_existing_dir(self, tmp_path):
        assert FolderAdapter().accepts(str(tmp_path)) is True

    def test_rejects_nonexistent(self):
        assert FolderAdapter().accepts("/nonexistent/path/xyz") is False

    def test_resolve_returns_same_path(self, tmp_path):
        result = FolderAdapter().resolve(str(tmp_path), tmp_path)
        assert result == tmp_path.resolve()


class TestZipAdapter:
    def test_accepts_zip_file(self, tmp_path):
        zp = tmp_path / "test.zip"
        with zipfile.ZipFile(zp, "w") as zf:
            zf.writestr("hello.txt", "world")
        assert ZipAdapter().accepts(str(zp)) is True

    def test_rejects_non_zip(self, tmp_path):
        assert ZipAdapter().accepts(str(tmp_path)) is False

    def test_resolve_extracts(self, tmp_path):
        zp = tmp_path / "test.zip"
        with zipfile.ZipFile(zp, "w") as zf:
            zf.writestr("a.txt", "aaa")
            zf.writestr("sub/b.txt", "bbb")
        work = tmp_path / "work"
        result = ZipAdapter().resolve(str(zp), work)
        assert (result / "a.txt").read_text() == "aaa"
        assert (result / "sub" / "b.txt").read_text() == "bbb"

    def test_cached_on_rerun(self, tmp_path):
        zp = tmp_path / "test.zip"
        with zipfile.ZipFile(zp, "w") as zf:
            zf.writestr("x.txt", "x")
        work = tmp_path / "work"
        r1 = ZipAdapter().resolve(str(zp), work)
        r2 = ZipAdapter().resolve(str(zp), work)
        assert r1 == r2


class TestTarAdapter:
    def test_accepts_tar_gz(self, tmp_path):
        tp = tmp_path / "test.tar.gz"
        with tarfile.open(tp, "w:gz") as tf:
            info = tarfile.TarInfo(name="hello.txt")
            import io
            data = b"world"
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
        assert TarAdapter().accepts(str(tp)) is True

    def test_resolve_extracts(self, tmp_path):
        tp = tmp_path / "test.tar.gz"
        with tarfile.open(tp, "w:gz") as tf:
            info = tarfile.TarInfo(name="hello.txt")
            import io
            data = b"world"
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
        work = tmp_path / "work"
        result = TarAdapter().resolve(str(tp), work)
        assert (result / "hello.txt").read_text() == "world"


class TestGitAdapter:
    def test_accepts_https(self):
        assert GitAdapter().accepts("https://github.com/org/repo.git") is True

    def test_rejects_local_path(self, tmp_path):
        assert GitAdapter().accepts(str(tmp_path)) is False


class TestResolveSource:
    def test_resolves_folder(self, tmp_path):
        result = resolve_source(str(tmp_path), tmp_path)
        assert result == tmp_path.resolve()

    def test_resolves_zip(self, tmp_path):
        zp = tmp_path / "test.zip"
        with zipfile.ZipFile(zp, "w") as zf:
            zf.writestr("f.txt", "data")
        result = resolve_source(str(zp), tmp_path / "work")
        assert (result / "f.txt").exists()

    def test_raises_on_unknown(self):
        with pytest.raises(ValueError):
            resolve_source("s3://bucket/key", Path("/tmp/work"))
