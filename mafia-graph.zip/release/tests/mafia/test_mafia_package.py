"""Tests for mafia/ public package (Sub-plan 6)."""

import json
import tempfile
from pathlib import Path

import pytest

from mafia import MAFIA, EntityID, Graph, Skill, Scope
from mafia.compat import migrate_id


# ── Helpers ──────────────────────────────────────────────────────────────────

def _write_jsonl(path, items):
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")


def _make_entity(eid, layer, etype, repo, name="x"):
    return {
        "id": eid, "layer": layer, "type": etype, "repo": repo,
        "name": name, "confidence": 0.95, "scope_path": repo,
        "codebase": repo, "workspace": repo,
        "evidence": {"repo": repo, "file": "f.py", "extractor": "t", "method": "t"},
        "properties": {},
    }


def _make_rel(source, target, rtype):
    return {
        "id": f"{source}--{rtype}-->{target}", "source": source, "target": target,
        "type": rtype, "confidence": 0.90, "cross_scope": False, "boundary": None,
        "evidence": {"file": "f.py", "extractor": "t", "method": "t"}, "properties": {},
    }


def _setup_fixture(td):
    """Create a minimal .mafia/output with graph artifacts."""
    out = Path(td) / ".mafia" / "output"
    out.mkdir(parents=True)
    entities = [
        _make_entity("api:endpoint:r:GET:/users", "api", "endpoint", "r", "getUsers"),
        _make_entity("api:service:r:UserService", "api", "service", "r", "UserService"),
    ]
    relations = [
        _make_rel("api:endpoint:r:GET:/users", "api:service:r:UserService", "delegates_to"),
    ]
    _write_jsonl(out / "entities.jsonl", entities)
    _write_jsonl(out / "relations.jsonl", relations)

    # Build graph artifacts
    from phase9_graph.graph_builder import build_graph
    build_graph(str(out))

    # Write minimal manifests
    manifest = {
        "codebase": {"id": "test", "root": td},
        "repos": [{"id": "test/r", "name": "r", "root": td,
                    "workspaces": [{"id": "test/r/r", "name": "r", "root": td,
                                    "classification": ["api"]}]}],
    }
    (out / "workspace_manifest.json").write_text(json.dumps(manifest))
    repo_manifest = {
        "generated_at": "2024-01-01", "source_roots": [td],
        "repos": [{"repo_id": "r", "repo_name": "r", "root_path": td,
                    "classification": ["api"], "classification_confidence": 0.9,
                    "detected_stack": [], "detection_signals": [], "modules": [],
                    "scan_summary": {"total_files": 0, "scannable_files": 0,
                                     "skipped_dirs": 0, "file_extensions": {}}}],
    }
    (out / "repo_manifest.json").write_text(json.dumps(repo_manifest))
    return out


# ── EntityID ─────────────────────────────────────────────────────────────────

class TestEntityID:
    def test_parse_v1(self):
        eid = EntityID("api:endpoint:flags_api:GET:/flags")
        assert eid.layer == "api"
        assert eid.entity_type == "endpoint"
        assert eid.scope_path == "flags_api"
        assert eid.qualifier == "GET:/flags"

    def test_parse_v2(self):
        eid = EntityID("code:function:acme/web/admin:main")
        assert eid.scope_path == "acme/web/admin"
        assert eid.codebase == "acme"
        assert eid.repo == "web"
        assert eid.workspace == "admin"

    def test_roundtrip(self):
        s = "api:endpoint:r:GET:/x"
        assert str(EntityID(s)) == s

    def test_equality(self):
        a = EntityID("api:endpoint:r:x")
        b = EntityID("api:endpoint:r:x")
        assert a == b
        assert hash(a) == hash(b)

    def test_from_string(self):
        eid = EntityID.from_string("code:module:p:f.py")
        assert eid.layer == "code"


# ── Graph ────────────────────────────────────────────────────────────────────

class TestGraph:
    def test_lazy_load(self):
        with tempfile.TemporaryDirectory() as td:
            out = _setup_fixture(td)
            g = Graph(str(out))
            # Not loaded yet
            assert g._gq is None
            # First query triggers load
            nodes = g.nodes()
            assert len(nodes) >= 2
            assert g._gq is not None

    def test_search(self):
        with tempfile.TemporaryDirectory() as td:
            out = _setup_fixture(td)
            g = Graph(str(out))
            results = g.search("getUsers")
            assert len(results) >= 1

    def test_orphans(self):
        with tempfile.TemporaryDirectory() as td:
            out = _setup_fixture(td)
            g = Graph(str(out))
            orphans = g.orphans()
            assert isinstance(orphans, list)


# ── MAFIA façade ─────────────────────────────────────────────────────────────

class TestMAFIAOpen:
    def test_open_existing(self):
        with tempfile.TemporaryDirectory() as td:
            out = _setup_fixture(td)
            mafia_dir = Path(td) / ".mafia"
            m = MAFIA.open(str(mafia_dir))
            assert m._output_dir == mafia_dir / "output"

    def test_open_nonexistent_raises(self):
        with pytest.raises(FileNotFoundError):
            MAFIA.open("/nonexistent/.mafia")


class TestMAFIAQueries:
    def test_search(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            results = m.search("getUsers")
            assert len(results) >= 1

    def test_neighbors(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            result = m.neighbors("api:endpoint:r:GET:/users")
            assert "nodes" in result

    def test_orphans(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            assert isinstance(m.orphans(), list)

    def test_codebase_property(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            assert m.codebase["id"] == "test"

    def test_repos_property(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            assert len(m.repos) == 1

    def test_workspaces_property(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            assert len(m.workspaces) == 1

    def test_shared_libs(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            assert isinstance(m.shared_libs(), list)


# ── Skill adapter ────────────────────────────────────────────────────────────

class TestSkillDescribe:
    def test_anthropic_format(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            tools = m.as_skill().describe(format="anthropic")
            assert len(tools) >= 10
            assert all("name" in t for t in tools)
            assert all("description" in t for t in tools)
            assert all("input_schema" in t for t in tools)

    def test_openai_format(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            tools = m.as_skill().describe(format="openai")
            assert len(tools) >= 10
            assert all("function" in t for t in tools)
            assert all("parameters" in t["function"] for t in tools)

    def test_mcp_format(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            tools = m.as_skill().describe(format="mcp")
            assert len(tools) >= 10
            assert all("inputSchema" in t for t in tools)


class TestSkillHandleCall:
    def test_search(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            result = m.as_skill().handle_call("mafia_search", {"query": "getUsers"})
            assert "results" in result

    def test_status(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            result = m.as_skill().handle_call("mafia_status", {})
            assert "codebase" in result

    def test_orphans(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            result = m.as_skill().handle_call("mafia_orphans", {})
            assert "orphans" in result

    def test_unknown_tool(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            result = m.as_skill().handle_call("nonexistent", {})
            assert "error" in result


# ── Compat ───────────────────────────────────────────────────────────────────

class TestCompat:
    def test_migrate_id(self):
        assert migrate_id("api:endpoint:r:GET:/x") == "api:endpoint:r:GET:/x"


# ── Export ────────────────────────────────────────────────────────────────────

class TestExport:
    def test_export_graph(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            dst = Path(td) / "exported_graph.json"
            m.export_graph(str(dst))
            assert dst.exists()
            data = json.loads(dst.read_text())
            assert "nodes" in data

    def test_networkx_graph(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            G = m.networkx_graph()
            assert G.number_of_nodes() >= 2
            assert G.number_of_edges() >= 1


# ── Skill serve_http ─────────────────────────────────────────────────────────

class TestSkillServeHttp:
    def test_serve_http_creates_app(self):
        """Verify serve_http sets up Flask routes (don't actually start server)."""
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            skill = m.as_skill()
            # Verify the method exists and is callable
            assert callable(skill.serve_http)


# ── Skill serve_mcp ──────────────────────────────────────────────────────────

class TestSkillServeMcp:
    def test_serve_mcp_exists(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            skill = m.as_skill()
            assert callable(skill.serve_mcp)


# ── Config ───────────────────────────────────────────────────────────────────

class TestConfig:
    def test_load_config_empty(self):
        from mafia.config import load_config
        with tempfile.TemporaryDirectory() as td:
            assert load_config(td) == {}

    def test_load_config_present(self):
        from mafia.config import load_config
        with tempfile.TemporaryDirectory() as td:
            cfg = {"ignore_paths": ["vendor/"], "plugins": []}
            (Path(td) / "mafia.json").write_text(json.dumps(cfg))
            result = load_config(td)
            assert result["ignore_paths"] == ["vendor/"]


# ── CLI v1+v2 ID compat ─────────────────────────────────────────────────────

class TestCLIIdCompat:
    def test_v1_id_search(self):
        """v1 entity IDs work in search."""
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            # v1 style ID
            results = m.search("getUsers")
            assert len(results) >= 1

    def test_v2_id_neighbors(self):
        """v2 entity IDs work in neighbors."""
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            result = m.neighbors("api:endpoint:r:GET:/users")
            assert "nodes" in result


# ── Skill langchain format ───────────────────────────────────────────────────

class TestSkillLangchain:
    def test_langchain_format(self):
        with tempfile.TemporaryDirectory() as td:
            _setup_fixture(td)
            m = MAFIA.open(str(Path(td) / ".mafia"))
            tools = m.as_skill().describe(format="langchain")
            assert len(tools) >= 10
            assert all("args_schema" in t for t in tools)
