"""Legacy extractor smoke test (Task 9).

Verifies that the old positional emit_entity API still works
and produces entities with the expected v1-compatible fields.
"""

from schemas.emitter import CanonicalEmitter


class TestLegacyExtractorSmoke:
    def test_old_positional_api(self):
        e = CanonicalEmitter("legacy_test")
        eid = e.emit_entity(
            layer="bff",
            entity_type="endpoint",
            repo="marvel_flags_bff",
            qualifier="/flagTypes",
            name="getFlagTypes",
            confidence=0.95,
            evidence_file="src/routes.ts",
            evidence_method="regex",
        )
        assert eid == "bff:endpoint:marvel_flags_bff:/flagTypes"

        entity = e._entities[eid]
        # v1 backward compat: repo field still populated
        assert entity["repo"] == "marvel_flags_bff"
        # v2 fields also present
        assert entity["scope_path"] == "marvel_flags_bff"
        assert entity["codebase"] == "marvel_flags_bff"
        assert entity["workspace"] == "marvel_flags_bff"
        # Standard fields
        assert entity["layer"] == "bff"
        assert entity["type"] == "endpoint"
        assert entity["name"] == "getFlagTypes"
        assert entity["confidence"] == 0.95

    def test_old_relation_api(self):
        e = CanonicalEmitter("legacy_test")
        e.emit_entity(
            layer="api", entity_type="controller", repo="flags_api",
            qualifier="FlagController::get", name="get",
            confidence=0.95, evidence_file="F.java", evidence_method="regex",
        )
        e.emit_entity(
            layer="api", entity_type="service", repo="flags_api",
            qualifier="FlagService::get", name="get",
            confidence=0.95, evidence_file="S.java", evidence_method="regex",
        )
        rid = e.emit_relation(
            source_id="api:controller:flags_api:FlagController::get",
            target_id="api:service:flags_api:FlagService::get",
            relation_type="delegates_to",
            confidence=0.90,
            evidence_file="F.java", evidence_method="regex",
        )
        rel = e._relations[rid]
        assert rel["type"] == "delegates_to"
        assert rel["cross_scope"] is False
        assert rel["boundary"] is None
