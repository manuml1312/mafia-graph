"""
MAFIA 2.0 Acceptance Test Suite (Sub-plan 7)
=============================================
Tests plugin loader, migrate, fixtures, skill adapter, and v1 backward compat.
"""

import json
import tempfile
import zipfile
from pathlib import Path
from unittest.mock import patch

import pytest

from mafia import MAFIA, EntityID
from mafia.plugins import load_plugins
from mafia.migrate import migrate
from mafia.skill import Skill
from phase2_repo_intake.scope_discovery import discover
from phase4_extractors.generic.ast_extractor import GenericAstExtractor

FIXTURES = Path(__file__).resolve().parent.parent / "fixtures"


# ── Helpers ──────────────────────────────────────────────────────────────────

def _write_jsonl(path, items):
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")


def _run_generic_ast_on(fixture_path: str) -> dict:
    """Run GenericAstExtractor on a fixture and return emitter stats."""
    ext = GenericAstExtractor()
    files = ext.discover_files(fixture_path)
    for fpath in files:
        rel = str(Path(fpath).relative_to(fixture_path)).replace("\\", "/")
        try:
            content = Path(fpath).read_text(encoding="utf-8", errors="ignore")
            ext.extract_file(fpath, rel, content, "test", {})
        except Exception:
            pass
    return ext.emitter.stats()


# ── Plugin loader ────────────────────────────────────────────────────────────

class TestPluginLoader:
    def test_load_empty_group(self):
        result = load_plugins("mafia.nonexistent_group_xyz")
        assert result == {}

    def test_config_disable(self):
        plugins = {"a": int, "b": str, "c": float}
        config = {"disable": ["b"]}
        filtered = {k: v for k, v in plugins.items() if k not in set(config.get("disable", []))}
        assert "b" not in filtered
        assert "a" in filtered

    def test_config_enable(self):
        plugins = {"a": int, "b": str, "c": float}
        config = {"enable": ["a", "c"]}
        enable_set = set(config["enable"])
        filtered = {k: v for k, v in plugins.items() if k in enable_set}
        assert filtered == {"a": int, "c": float}

    def test_config_order(self):
        plugins = {"c": float, "a": int, "b": str}
        config = {"order": ["b", "a", "..."]}
        ordered = {}
        for name in config["order"]:
            if name == "...":
                for k, v in plugins.items():
                    if k not in ordered:
                        ordered[k] = v
            elif name in plugins:
                ordered[name] = plugins[name]
        assert list(ordered.keys()) == ["b", "a", "c"]

    def test_dispatcher_plugin_loader_callable(self):
        """Plugin loader function in dispatcher is importable."""
        from phase3_extraction_framework.dispatcher import _load_plugin_extractors
        result = _load_plugin_extractors()
        assert isinstance(result, dict)

    def test_workspace_detector_plugin_loader_callable(self):
        from phase4_workspace_detectors.runner import _load_plugin_detectors
        result = _load_plugin_detectors()
        assert isinstance(result, list)

    def test_source_adapter_plugin_loader_callable(self):
        from phase4_source_adapters import _load_plugin_adapters
        result = _load_plugin_adapters()
        assert isinstance(result, list)


# ── Migrate ──────────────────────────────────────────────────────────────────

class TestMigrate:
    def test_migrate_v1_artifacts(self):
        with tempfile.TemporaryDirectory() as td:
            entities = [
                {"id": "api:endpoint:r:GET:/x", "layer": "api", "type": "endpoint",
                 "repo": "r", "name": "x", "confidence": 0.95,
                 "evidence": {"repo": "r", "file": "f", "extractor": "t", "method": "t"}},
            ]
            relations = [
                {"id": "a--calls-->b", "source": "a", "target": "b", "type": "calls",
                 "confidence": 0.9, "evidence": {"file": "f", "extractor": "t", "method": "t"}},
            ]
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", relations)

            stats = migrate(td)
            assert stats["entities_migrated"] == 1
            assert stats["relations_migrated"] == 1

            # Verify v2 fields added
            ent_lines = (Path(td) / "entities.jsonl").read_text().splitlines()
            e = json.loads(ent_lines[0])
            assert "scope_path" in e
            assert "codebase" in e

            # Verify sidecar
            sidecar = json.loads((Path(td) / "id_format.json").read_text())
            assert sidecar["id_format_version"] == 2

            # Verify backup
            assert (Path(td) / "backup-v1" / "entities.jsonl").exists()

    def test_migrate_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", [])
            _write_jsonl(Path(td) / "relations.jsonl", [])
            migrate(td)
            stats2 = migrate(td)
            assert stats2["already_v2"] is True


# ── Fixture: single_repo_react ───────────────────────────────────────────────

class TestFixtureSingleRepoReact:
    def test_discovery(self):
        result = discover(str(FIXTURES / "single_repo_react"))
        assert len(result.repos) == 1
        assert len(result.workspaces) == 1

    def test_generic_ast_produces_entities(self):
        stats = _run_generic_ast_on(str(FIXTURES / "single_repo_react"))
        assert stats["entity_ids"] >= 3  # module + function + class at minimum


# ── Fixture: single_repo_spring ──────────────────────────────────────────────

class TestFixtureSingleRepoSpring:
    def test_discovery(self):
        result = discover(str(FIXTURES / "single_repo_spring"))
        assert len(result.repos) == 1

    def test_generic_ast_produces_entities(self):
        stats = _run_generic_ast_on(str(FIXTURES / "single_repo_spring"))
        assert stats["entity_ids"] >= 2  # at least module entities


# ── Fixture: npm_workspaces_monorepo ─────────────────────────────────────────

class TestFixtureNpmWorkspaces:
    def test_discovery_2_workspaces(self):
        result = discover(str(FIXTURES / "discovery" / "npm_workspaces"))
        assert len(result.workspaces) == 2

    def test_cross_workspace_import_possible(self):
        result = discover(str(FIXTURES / "discovery" / "npm_workspaces"))
        ws_names = {w.name for w in result.workspaces}
        assert "core" in ws_names
        assert "admin" in ws_names


# ── Fixture: pnpm_monorepo ───────────────────────────────────────────────────

class TestFixturePnpmMonorepo:
    def test_pnpm_detected(self):
        result = discover(str(FIXTURES / "discovery" / "pnpm_monorepo"))
        assert len(result.workspaces) == 2


# ── Fixture: maven_multimodule ───────────────────────────────────────────────

class TestFixtureMavenMultimodule:
    def test_2_workspaces(self):
        result = discover(str(FIXTURES / "discovery" / "maven_multimodule"))
        assert len(result.workspaces) == 2


# ── Fixture: lerna_monorepo ───────────────────────────────────────────────────

class TestFixtureLernaMonorepo:
    def test_lerna_detected(self):
        result = discover(str(FIXTURES / "discovery" / "lerna_monorepo"))
        assert len(result.workspaces) == 2


# ── Fixture: nx_monorepo ─────────────────────────────────────────────────────

class TestFixtureNxMonorepo:
    def test_nx_detected(self):
        result = discover(str(FIXTURES / "discovery" / "nx_monorepo"))
        assert len(result.workspaces) == 2


# ── Fixture: gradle_multiproject ─────────────────────────────────────────────

class TestFixtureGradleMultiproject:
    def test_2_workspaces(self):
        result = discover(str(FIXTURES / "discovery" / "gradle_multiproject"))
        assert len(result.workspaces) == 2


# ── Fixture: cargo_workspace ─────────────────────────────────────────────────

class TestFixtureCargoWorkspace:
    def test_2_workspaces(self):
        result = discover(str(FIXTURES / "discovery" / "cargo_workspace"))
        assert len(result.workspaces) == 2


# ── Fixture: outer_folder_with_three_repos ───────────────────────────────────

class TestFixtureOuterFolder:
    def test_3_repos(self):
        result = discover(str(FIXTURES / "discovery" / "outer_folder_with_three_repos"))
        assert len(result.repos) == 3
        assert len(result.workspaces) == 3


# ── Fixture: zip_archive ─────────────────────────────────────────────────────

class TestFixtureZipArchive:
    def test_zip_end_to_end(self):
        with tempfile.TemporaryDirectory() as td:
            # Create a zip with a small project
            zp = Path(td) / "test_project.zip"
            with zipfile.ZipFile(zp, "w") as zf:
                zf.writestr("package.json", '{"name": "zip-test"}')
                zf.writestr("src/index.ts", 'export function hello() { return "hi"; }')
            from phase4_source_adapters import resolve_source
            root = resolve_source(str(zp), Path(td) / "work")
            assert (root / "package.json").exists()
            assert (root / "src" / "index.ts").exists()


# ── Fixture: unsupported_language_repo ───────────────────────────────────────

class TestFixtureUnsupportedLanguage:
    def test_discovery_works(self):
        result = discover(str(FIXTURES / "unsupported_language_repo"))
        assert len(result.repos) == 1

    def test_generic_ast_still_runs(self):
        """Pipeline runs without errors even on unsupported files."""
        ext = GenericAstExtractor()
        # .sh and .yaml are not in supported_extensions, so discover_files returns empty
        # But the pipeline should not crash
        files = ext.discover_files(str(FIXTURES / "unsupported_language_repo"))
        # No supported files found — that's OK, graph would get module entities
        # from other extractors or be empty (which is acceptable for truly unsupported)
        assert isinstance(files, list)


# ── Fixture: cross_repo_shared_db ────────────────────────────────────────────

class TestFixtureCrossRepoSharedDb:
    def test_discovery_2_repos(self):
        result = discover(str(FIXTURES / "cross_repo_shared_db"))
        assert len(result.repos) == 2


# ── Fixture: cross_repo_shared_env ───────────────────────────────────────────

class TestFixtureCrossRepoSharedEnv:
    def test_discovery_2_repos(self):
        result = discover(str(FIXTURES / "cross_repo_shared_env"))
        assert len(result.repos) == 2


# ── Skill adapter integration ────────────────────────────────────────────────

class TestSkillIntegration:
    def _make_mafia(self, td):
        out = Path(td) / ".mafia" / "output"
        out.mkdir(parents=True)
        entities = [
            {"id": "api:endpoint:r:GET:/x", "layer": "api", "type": "endpoint",
             "repo": "r", "name": "getX", "confidence": 0.95, "scope_path": "r",
             "codebase": "r", "workspace": "r",
             "evidence": {"repo": "r", "file": "f", "extractor": "t", "method": "t"},
             "properties": {}},
        ]
        _write_jsonl(out / "entities.jsonl", entities)
        _write_jsonl(out / "relations.jsonl", [])
        from phase9_graph.graph_builder import build_graph
        build_graph(str(out))
        manifest = {"codebase": {"id": "t", "root": td},
                     "repos": [{"id": "t/r", "name": "r", "root": td, "workspaces": []}]}
        (out / "workspace_manifest.json").write_text(json.dumps(manifest))
        (out / "repo_manifest.json").write_text(json.dumps(
            {"generated_at": "", "source_roots": [], "repos": []}))
        return MAFIA.open(str(Path(td) / ".mafia"))

    def test_anthropic_spec_valid(self):
        with tempfile.TemporaryDirectory() as td:
            m = self._make_mafia(td)
            tools = m.as_skill().describe(format="anthropic")
            assert len(tools) >= 10
            for t in tools:
                assert "name" in t
                assert "input_schema" in t
                assert t["input_schema"]["type"] == "object"

    def test_openai_spec_valid(self):
        with tempfile.TemporaryDirectory() as td:
            m = self._make_mafia(td)
            tools = m.as_skill().describe(format="openai")
            for t in tools:
                assert t["type"] == "function"
                assert "parameters" in t["function"]

    def test_handle_call_search(self):
        with tempfile.TemporaryDirectory() as td:
            m = self._make_mafia(td)
            result = m.as_skill().handle_call("mafia_search", {"query": "getX"})
            assert "results" in result


# ── v1 backward compat ───────────────────────────────────────────────────────

class TestV1BackwardCompat:
    def test_v1_graph_loads(self):
        """v1 system_graph.json without scope fields loads and queries work."""
        with tempfile.TemporaryDirectory() as td:
            out = Path(td)
            sg = {
                "meta": {"node_count": 1, "edge_count": 0},
                "nodes": [{"id": "api:endpoint:r:GET:/x", "label": "getX",
                           "layer": "api", "type": "endpoint", "repo": "r",
                           "confidence": 0.95, "evidence_method": "regex",
                           "properties": {}, "warnings": []}],
                "edges": [],
            }
            (out / "system_graph.json").write_text(json.dumps(sg))
            from mafia.graph import Graph
            g = Graph(str(out))
            nodes = g.nodes()
            assert len(nodes) == 1
            results = g.search("getX")
            assert len(results) >= 1

    def test_v1_entity_id_accepted(self):
        eid = EntityID("api:endpoint:flags_api:GET:/flagTypes")
        assert eid.layer == "api"
        assert eid.scope_path == "flags_api"

    def test_v2_entity_id_accepted(self):
        eid = EntityID("code:function:acme/web/admin:main")
        assert eid.scope_path == "acme/web/admin"
