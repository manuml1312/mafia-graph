"""Tests for workspace detectors (Tasks 6-21)."""

from pathlib import Path
import pytest

from phase4_workspace_detectors.base import WorkspaceDetector, MonorepoSpec
from phase4_workspace_detectors.npm_workspaces import NpmWorkspacesDetector
from phase4_workspace_detectors.pnpm import PnpmDetector
from phase4_workspace_detectors.lerna import LernaDetector
from phase4_workspace_detectors.nx_detector import NxDetector
from phase4_workspace_detectors.turborepo import TurborepoDetector
from phase4_workspace_detectors.rush import RushDetector
from phase4_workspace_detectors.maven import MavenDetector
from phase4_workspace_detectors.gradle import GradleDetector
from phase4_workspace_detectors.bazel import BazelDetector
from phase4_workspace_detectors.cargo import CargoDetector
from phase4_workspace_detectors.go_workspaces import GoWorkspacesDetector
from phase4_workspace_detectors.dotnet import DotnetDetector
from phase4_workspace_detectors.python_workspaces import PythonWorkspacesDetector
from phase4_workspace_detectors.heuristic_fallback import HeuristicFallbackDetector
from phase4_workspace_detectors.runner import run_detectors

FIXTURES = Path(__file__).resolve().parent.parent / "fixtures" / "discovery"


class TestDetectorABC:
    def test_cannot_instantiate(self):
        with pytest.raises(TypeError):
            WorkspaceDetector()


class TestNpmWorkspaces:
    def test_detects_workspaces(self):
        result = NpmWorkspacesDetector().detect(FIXTURES / "npm_workspaces")
        assert result is not None
        assert result.system == "npm_workspaces"
        assert len(result.workspaces) == 2
        names = {w.name for w in result.workspaces}
        assert "core" in names
        assert "admin" in names

    def test_admin_has_deps(self):
        result = NpmWorkspacesDetector().detect(FIXTURES / "npm_workspaces")
        admin = [w for w in result.workspaces if w.name == "admin"][0]
        assert "@test/core" in admin.declared_deps
        assert "react" in admin.declared_deps

    def test_returns_none_on_non_workspace(self, tmp_path):
        (tmp_path / "package.json").write_text('{"name": "simple"}')
        assert NpmWorkspacesDetector().detect(tmp_path) is None


class TestPnpm:
    def test_detects_workspaces(self):
        result = PnpmDetector().detect(FIXTURES / "pnpm_monorepo")
        assert result is not None
        assert result.system == "pnpm"
        assert len(result.workspaces) == 2


class TestMaven:
    def test_detects_modules(self):
        result = MavenDetector().detect(FIXTURES / "maven_multimodule")
        assert result is not None
        assert result.system == "maven"
        assert len(result.workspaces) == 2
        names = {w.name for w in result.workspaces}
        assert "core" in names
        assert "web" in names

    def test_web_depends_on_core(self):
        result = MavenDetector().detect(FIXTURES / "maven_multimodule")
        web = [w for w in result.workspaces if w.name == "web"][0]
        assert "com.test:core" in web.declared_deps


class TestGradle:
    def test_detects_includes(self, tmp_path):
        (tmp_path / "settings.gradle").write_text("include ':app'\ninclude ':lib'")
        (tmp_path / "app").mkdir()
        (tmp_path / "lib").mkdir()
        result = GradleDetector().detect(tmp_path)
        assert result is not None
        assert len(result.workspaces) == 2


class TestCargo:
    def test_detects_members(self, tmp_path):
        (tmp_path / "Cargo.toml").write_text(
            '[workspace]\nmembers = ["crates/*"]'
        )
        (tmp_path / "crates").mkdir()
        (tmp_path / "crates" / "foo").mkdir()
        (tmp_path / "crates" / "bar").mkdir()
        result = CargoDetector().detect(tmp_path)
        assert result is not None
        assert len(result.workspaces) == 2


class TestGoWorkspaces:
    def test_detects_use(self, tmp_path):
        (tmp_path / "go.work").write_text("go 1.21\n\nuse (\n\t./svc-a\n\t./svc-b\n)\n")
        result = GoWorkspacesDetector().detect(tmp_path)
        assert result is not None
        assert len(result.workspaces) == 2


class TestDotnet:
    def test_detects_sln(self, tmp_path):
        sln_content = '''Project("{FAE04EC0}") = "App", "src\\App\\App.csproj", "{GUID1}"
Project("{FAE04EC0}") = "Lib", "src\\Lib\\Lib.csproj", "{GUID2}"
'''
        (tmp_path / "test.sln").write_text(sln_content)
        result = DotnetDetector().detect(tmp_path)
        assert result is not None
        assert len(result.workspaces) == 2


class TestHeuristicFallback:
    def test_detects_three_repos(self):
        result = HeuristicFallbackDetector().detect(
            FIXTURES / "outer_folder_with_three_repos"
        )
        assert result is not None
        assert len(result.workspaces) == 3

    def test_returns_none_for_single(self, tmp_path):
        (tmp_path / "only_one").mkdir()
        (tmp_path / "only_one" / "package.json").write_text("{}")
        assert HeuristicFallbackDetector().detect(tmp_path) is None


class TestRunner:
    def test_npm_workspaces_detected(self):
        systems, workspaces = run_detectors(FIXTURES / "npm_workspaces")
        assert "npm_workspaces" in systems
        assert len(workspaces) == 2

    def test_maven_detected(self):
        systems, workspaces = run_detectors(FIXTURES / "maven_multimodule")
        assert "maven" in systems
        assert len(workspaces) == 2

    def test_heuristic_on_outer_folder(self):
        systems, workspaces = run_detectors(
            FIXTURES / "outer_folder_with_three_repos"
        )
        assert "heuristic_fallback" in systems
        assert len(workspaces) == 3

    def test_empty_dir_returns_nothing(self, tmp_path):
        systems, workspaces = run_detectors(tmp_path)
        assert systems == []
        assert workspaces == []
