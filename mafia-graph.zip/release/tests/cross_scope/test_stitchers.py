"""Tests for cross-scope stitching (Sub-plan 4)."""

import json
import tempfile
from pathlib import Path

from phase3_extraction_framework.cross_scope import Stitcher, run_all_stitchers
from phase3_extraction_framework.cross_scope.workspace_dep_stitcher import WorkspaceDepStitcher
from phase3_extraction_framework.cross_scope.cross_workspace_imports import CrossWorkspaceImportStitcher
from phase3_extraction_framework.cross_scope.shared_lib_stitcher import SharedLibStitcher
from phase3_extraction_framework.cross_scope.shared_table_stitcher import SharedTableStitcher
from phase3_extraction_framework.cross_scope.shared_env_stitcher import SharedEnvStitcher
from phase3_extraction_framework.cross_scope.artifact_stitcher import ArtifactStitcher


def _write_jsonl(path, items):
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item) + "\n")


class TestStitcherABC:
    def test_cannot_instantiate(self):
        import pytest
        with pytest.raises(TypeError):
            Stitcher()


class TestStubStitcher:
    def test_stub_emits_one_relation(self):
        class StubStitcher(Stitcher):
            name = "stub"
            def run(self, entities, relations, manifest=None):
                return [{"id": "test--calls-->test2", "type": "calls",
                         "source": "a", "target": "b", "confidence": 0.9,
                         "evidence": {"file": "x", "extractor": "stub", "method": "test"}}]

        result = StubStitcher().run([], [])
        assert len(result) == 1


class TestRunnerIdempotent:
    def test_no_duplicates_on_rerun(self):
        class StubStitcher(Stitcher):
            name = "stub"
            def run(self, entities, relations, manifest=None):
                return [{"id": "a--calls-->b", "type": "calls",
                         "source": "a", "target": "b", "confidence": 0.9,
                         "evidence": {"file": "x", "extractor": "s", "method": "t"}}]

        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", [])
            _write_jsonl(Path(td) / "relations.jsonl", [])
            # First run
            run_all_stitchers(td, [StubStitcher()])
            # Second run — should not duplicate
            run_all_stitchers(td, [StubStitcher()])
            rels = []
            for line in (Path(td) / "relations.jsonl").read_text().splitlines():
                if line.strip():
                    rels.append(json.loads(line))
            ids = [r["id"] for r in rels]
            assert ids.count("a--calls-->b") == 1


class TestSharedLibStitcher:
    def test_detects_shared_lib(self):
        entities = [
            {"id": "code:module:acme/web/admin:app.ts", "layer": "code",
             "type": "module", "scope_path": "acme/web/admin", "repo": "acme/web/admin"},
            {"id": "code:module:acme/web/core:lib.ts", "layer": "code",
             "type": "module", "scope_path": "acme/web/core", "repo": "acme/web/core"},
        ]
        relations = [
            {"id": "r1", "type": "imports", "source": "code:module:acme/web/admin:app.ts",
             "target": "code:module:_unresolved:react", "evidence": {}},
            {"id": "r2", "type": "imports", "source": "code:module:acme/web/core:lib.ts",
             "target": "code:module:_unresolved:react", "evidence": {}},
        ]
        result = SharedLibStitcher().run(entities, relations)
        assert len(result) >= 2  # react → admin, react → core
        assert all(r["type"] == "shared_lib_used_by" for r in result)


class TestSharedEnvStitcher:
    def test_detects_shared_env(self):
        entities = [
            {"id": "config:env:ws_a:DATABASE_URL", "layer": "config",
             "type": "env", "name": "DATABASE_URL", "scope_path": "ws_a", "repo": "ws_a"},
            {"id": "config:env:ws_b:DATABASE_URL", "layer": "config",
             "type": "env", "name": "DATABASE_URL", "scope_path": "ws_b", "repo": "ws_b"},
        ]
        result = SharedEnvStitcher().run(entities, [])
        assert len(result) == 1
        assert result[0]["type"] == "shares_env_with"
        assert result[0]["properties"]["env_name"] == "DATABASE_URL"


class TestSharedTableStitcher:
    def test_detects_shared_table(self):
        entities = [
            {"id": "db:table:pg:public.users", "layer": "db", "type": "table",
             "name": "public.users", "repo": "pg"},
            {"id": "api:service:ws_a:UserService", "layer": "api", "type": "service",
             "repo": "ws_a", "scope_path": "ws_a"},
            {"id": "api:service:ws_b:AuthService", "layer": "api", "type": "service",
             "repo": "ws_b", "scope_path": "ws_b"},
        ]
        relations = [
            {"id": "r1", "type": "reads_from",
             "source": "api:service:ws_a:UserService",
             "target": "db:table:pg:public.users", "evidence": {}},
            {"id": "r2", "type": "reads_from",
             "source": "api:service:ws_b:AuthService",
             "target": "db:table:pg:public.users", "evidence": {}},
        ]
        result = SharedTableStitcher().run(entities, relations)
        assert len(result) == 1
        assert result[0]["type"] == "shares_table_with"


class TestCrossWorkspaceImports:
    def test_resolves_cross_workspace(self):
        entities = [
            {"id": "code:module:acme/web/admin:app.ts", "layer": "code",
             "type": "module", "scope_path": "acme/web/admin", "repo": "acme/web/admin"},
            {"id": "code:module:acme/web/core:utils.ts", "layer": "code",
             "type": "module", "scope_path": "acme/web/core", "repo": "acme/web/core"},
        ]
        relations = [
            {"id": "r1", "type": "imports",
             "source": "code:module:acme/web/admin:app.ts",
             "target": "code:module:_unresolved:utils",
             "evidence": {"file": "app.ts"}},
        ]
        result = CrossWorkspaceImportStitcher().run(entities, relations)
        assert len(result) == 1
        assert result[0]["type"] == "cross_workspace_import"
        assert result[0]["cross_scope"] is True


class TestWorkspaceDepStitcher:
    def test_detects_dep_from_imports(self):
        entities = [
            {"id": "code:module:acme/web/admin:app.ts", "layer": "code",
             "type": "module", "scope_path": "acme/web/admin", "repo": "acme/web/admin"},
        ]
        relations = [
            {"id": "r1", "type": "imports",
             "source": "code:module:acme/web/admin:app.ts",
             "target": "code:module:_unresolved:@test/core",
             "evidence": {}},
        ]
        manifest = {
            "repos": [{
                "workspaces": [
                    {"id": "acme/web/admin", "name": "admin", "package_name": "@test/admin"},
                    {"id": "acme/web/core", "name": "core", "package_name": "@test/core"},
                ]
            }]
        }
        result = WorkspaceDepStitcher().run(entities, relations, manifest)
        assert len(result) == 1
        assert result[0]["type"] == "workspace_depends_on"


class TestArtifactStitcher:
    def test_returns_empty_without_manifest(self):
        assert ArtifactStitcher().run([], []) == []


class TestFullPipeline:
    def test_end_to_end(self):
        """Run all stitchers on a small dataset."""
        entities = [
            {"id": "code:module:ws_a:app.py", "layer": "code", "type": "module",
             "scope_path": "ws_a", "repo": "ws_a", "name": "app.py"},
            {"id": "code:module:ws_b:lib.py", "layer": "code", "type": "module",
             "scope_path": "ws_b", "repo": "ws_b", "name": "lib.py"},
            {"id": "config:env:ws_a:DB_URL", "layer": "config", "type": "env",
             "name": "DB_URL", "scope_path": "ws_a", "repo": "ws_a"},
            {"id": "config:env:ws_b:DB_URL", "layer": "config", "type": "env",
             "name": "DB_URL", "scope_path": "ws_b", "repo": "ws_b"},
        ]
        relations = [
            {"id": "r1", "type": "imports", "source": "code:module:ws_a:app.py",
             "target": "code:module:_unresolved:requests", "evidence": {}},
            {"id": "r2", "type": "imports", "source": "code:module:ws_b:lib.py",
             "target": "code:module:_unresolved:requests", "evidence": {}},
        ]

        with tempfile.TemporaryDirectory() as td:
            _write_jsonl(Path(td) / "entities.jsonl", entities)
            _write_jsonl(Path(td) / "relations.jsonl", relations)
            result = run_all_stitchers(td)
            assert result["new_relations"] >= 3  # shared_lib(2) + shared_env(1)
