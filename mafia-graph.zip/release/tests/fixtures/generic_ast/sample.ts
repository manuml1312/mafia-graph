import { useState } from 'react';
import { fetchData } from './api';

export function useCounter() {
    const [count, setCount] = useState(0);
    return { count, increment: () => setCount(count + 1) };
}

export class DataService {
    async load() {
        return fetchData('/items');
    }
}
