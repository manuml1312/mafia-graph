import os
from pathlib import Path


class FileProcessor:
    def __init__(self, root):
        self.root = root

    def process(self, filename):
        content = read_file(filename)
        return transform(content)


def read_file(path):
    with open(path) as f:
        return f.read()


def transform(data):
    result = read_file("config.txt")
    return data.upper() + result
