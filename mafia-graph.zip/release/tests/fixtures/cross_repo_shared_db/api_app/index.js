// Reads from public.users table
const users = await db.query('SELECT * FROM public.users');
