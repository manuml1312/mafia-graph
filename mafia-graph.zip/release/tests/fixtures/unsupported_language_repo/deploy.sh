#!/bin/bash
echo "Deploy script"
docker build -t myapp .
docker push myapp:latest
