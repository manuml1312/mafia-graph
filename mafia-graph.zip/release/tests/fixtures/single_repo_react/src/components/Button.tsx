import React from 'react';

interface ButtonProps { label: string; }

export function Button({ label }: ButtonProps) {
    return <button>{label}</button>;
}
