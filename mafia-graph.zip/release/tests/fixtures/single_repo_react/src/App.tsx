import React from 'react';
import { Button } from './components/Button';

export default function App() {
    return <div><Button label="Click me" /></div>;
}
