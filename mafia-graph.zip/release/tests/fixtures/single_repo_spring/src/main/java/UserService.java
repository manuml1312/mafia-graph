package com.test;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
    public List<User> findAll() {
        return List.of();
    }
}
