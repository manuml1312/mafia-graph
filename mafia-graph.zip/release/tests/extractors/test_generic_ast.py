"""Tests for GenericAstExtractor + BaseExtractor scope support (Sub-plan 3)."""

import os
from pathlib import Path

from schemas.scope import Scope
from phase4_extractors.generic.ast_extractor import GenericAstExtractor
from phase3_extraction_framework.base_extractor import BaseExtractor, FileResult

FIXTURES = Path(__file__).resolve().parent.parent / "fixtures" / "generic_ast"


class TestBaseExtractorScope:
    def test_has_workspace_hooks(self):
        """BaseExtractor has before/after_workspace hooks."""
        class Stub(BaseExtractor):
            name = "stub"
            supported_extensions = {".txt"}
            def extract_file(self, *a, **kw):
                return FileResult(file_path="x", status="ok")

        ext = Stub()
        scope = Scope(codebase="c", repo="r", workspace="w")
        ext.before_workspace(scope)  # should not raise
        ext.after_workspace(scope)

    def test_active_scope_initialized(self):
        class Stub(BaseExtractor):
            name = "stub"
            supported_extensions = {".txt"}
            def extract_file(self, *a, **kw):
                return FileResult(file_path="x", status="ok")
        ext = Stub()
        assert ext._active_scope is None


class TestGenericAstExtractorInstantiation:
    def test_name(self):
        ext = GenericAstExtractor()
        assert ext.name == "generic_ast"

    def test_supported_extensions(self):
        ext = GenericAstExtractor()
        assert ".py" in ext.supported_extensions
        assert ".ts" in ext.supported_extensions
        assert ".java" in ext.supported_extensions
        assert ".go" in ext.supported_extensions


class TestGenericAstModuleEntity:
    def test_python_file_produces_module(self):
        ext = GenericAstExtractor()
        content = (FIXTURES / "sample.py").read_text()
        result = ext.extract_file(
            str(FIXTURES / "sample.py"), "sample.py", content,
            repo_id="test_proj", repo_meta={},
        )
        assert result.status == "ok"
        assert result.entities_emitted >= 1
        # Check module entity exists
        module_ids = [eid for eid in ext.emitter._entities
                      if eid.startswith("code:module:")]
        assert len(module_ids) >= 1

    def test_three_files_produce_three_modules(self):
        ext = GenericAstExtractor()
        for fname in ("sample.py", "sample.ts"):
            fpath = FIXTURES / fname
            if fpath.exists():
                content = fpath.read_text()
                ext.extract_file(str(fpath), fname, content,
                                 repo_id="proj", repo_meta={})
        module_ids = [eid for eid in ext.emitter._entities
                      if ":module:" in eid]
        assert len(module_ids) >= 2


class TestGenericAstFunctionClass:
    def test_python_functions_detected(self):
        ext = GenericAstExtractor()
        content = (FIXTURES / "sample.py").read_text()
        ext.extract_file(str(FIXTURES / "sample.py"), "sample.py", content,
                         repo_id="proj", repo_meta={})
        func_ids = [eid for eid in ext.emitter._entities
                    if ":function:" in eid]
        # read_file and transform at minimum (process is a method)
        assert len(func_ids) >= 2

    def test_python_class_detected(self):
        ext = GenericAstExtractor()
        content = (FIXTURES / "sample.py").read_text()
        ext.extract_file(str(FIXTURES / "sample.py"), "sample.py", content,
                         repo_id="proj", repo_meta={})
        class_ids = [eid for eid in ext.emitter._entities
                     if ":class:" in eid]
        assert len(class_ids) >= 1

    def test_defined_in_relations(self):
        ext = GenericAstExtractor()
        content = (FIXTURES / "sample.py").read_text()
        ext.extract_file(str(FIXTURES / "sample.py"), "sample.py", content,
                         repo_id="proj", repo_meta={})
        defined_in = [rid for rid in ext.emitter._relations
                      if "defined_in" in rid]
        assert len(defined_in) >= 2


class TestGenericAstImports:
    def test_python_imports_detected(self):
        ext = GenericAstExtractor()
        content = (FIXTURES / "sample.py").read_text()
        ext.extract_file(str(FIXTURES / "sample.py"), "sample.py", content,
                         repo_id="proj", repo_meta={})
        import_rels = [rid for rid in ext.emitter._relations
                       if "imports" in rid]
        assert len(import_rels) >= 1  # os, pathlib

    def test_ts_imports_detected(self):
        ext = GenericAstExtractor()
        content = (FIXTURES / "sample.ts").read_text()
        ext.extract_file(str(FIXTURES / "sample.ts"), "sample.ts", content,
                         repo_id="proj", repo_meta={})
        import_rels = [rid for rid in ext.emitter._relations
                       if "imports" in rid]
        assert len(import_rels) >= 1  # react, ./api


class TestGenericAstLargeFile:
    def test_large_file_module_only(self):
        ext = GenericAstExtractor()
        # Simulate a >2MB file
        content = "x = 1\n" * 500_000  # ~3MB
        result = ext.extract_file(
            "/fake/big.py", "big.py", content,
            repo_id="proj", repo_meta={},
        )
        assert result.entities_emitted == 1  # module only
        func_ids = [eid for eid in ext.emitter._entities if ":function:" in eid]
        assert len(func_ids) == 0


class TestGenericAstWithScope:
    def test_scope_path_in_entity_id(self):
        ext = GenericAstExtractor()
        ext._active_scope = Scope(codebase="acme", repo="web", workspace="admin")
        content = (FIXTURES / "sample.py").read_text()
        ext.extract_file(str(FIXTURES / "sample.py"), "sample.py", content,
                         repo_id="acme/web/admin", repo_meta={})
        # Module entity should use scope path
        module_ids = [eid for eid in ext.emitter._entities if ":module:" in eid]
        assert any("acme/web/admin" in eid for eid in module_ids)
